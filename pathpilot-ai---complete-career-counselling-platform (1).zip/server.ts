import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3000;

app.use(express.json({ limit: '10mb' }));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'PathPilot AI Career Counselling API',
    hasGeminiKey: !!process.env.GEMINI_API_KEY,
    n8nWebhookConfigured: true,
    timestamp: new Date().toISOString()
  });
});

const N8N_CHAT_WEBHOOK_URL = 'https://punitbehera.app.n8n.cloud/webhook/13b3635b-45d2-4454-8d06-e6fabdf1184a/chat';

// n8n Chat Workflow proxy endpoint
app.post('/api/n8n-chat', async (req, res) => {
  try {
    const { chatInput, message, sessionId, metadata, action, retrieved_context, profile_context } = req.body;
    const query = chatInput || message;

    if (!query || typeof query !== 'string') {
      res.status(400).json({ error: 'chatInput or message is required' });
      return;
    }

    const payload = {
      action: action || 'sendMessage',
      chatInput: query,
      message: query,
      sessionId: sessionId || `session_${Date.now()}`,
      retrieved_context: retrieved_context || '',
      profile_context: profile_context || '',
      metadata: metadata || {}
    };

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 25000);

    const n8nResponse = await fetch(N8N_CHAT_WEBHOOK_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Instance-Id': 'd70f1f0ca3899125dc77338b7c4b9adea0e21ea8061c2071ef92425af384628e'
      },
      body: JSON.stringify(payload),
      signal: controller.signal
    });

    clearTimeout(timeout);

    if (!n8nResponse.ok) {
      const errText = await n8nResponse.text();
      res.status(n8nResponse.status).json({
        error: `n8n Cloud returned status ${n8nResponse.status}`,
        details: errText
      });
      return;
    }

    const data = await n8nResponse.json();
    res.json(data);
  } catch (error: any) {
    console.error('Error forwarding to n8n webhook:', error);
    if (error.name === 'AbortError') {
      res.status(504).json({ error: 'n8n workflow request timed out after 25s' });
    } else {
      res.status(502).json({ error: 'Failed to connect to n8n Cloud webhook', message: error.message });
    }
  }
});

// AI Career Mentor endpoint
app.post('/api/mentor', async (req, res) => {
  try {
    const { message, history, studentProfile, assessmentSummary, currentRoadmap } = req.body;

    if (!message || typeof message !== 'string') {
      res.status(400).json({ error: 'Message is required' });
      return;
    }

    const apiKey = process.env.GEMINI_API_KEY;

    // Build rich student context for grounded guidance
    const studentContext = `
STUDENT PROFILE & ASSESSMENT CONTEXT:
- Name: ${studentProfile?.name || 'Student'}
- Current Education Stage: ${studentProfile?.stage || 'Not specified'}
- Stage Details: ${JSON.stringify(studentProfile?.stageDetails || {})}
- Favorite Subjects/Areas: ${studentProfile?.favoriteSubjects?.join(', ') || 'General'}
- Core Career Goals: ${studentProfile?.careerGoals || 'Career discovery'}
- Location & Budget: ${studentProfile?.locationPreference || 'India & Global'} (Budget: ${studentProfile?.budgetConsideration || 'moderate'})

ASSESSMENT INSIGHTS:
${assessmentSummary ? JSON.stringify(assessmentSummary, null, 2) : 'No completed assessment yet; guiding based on stage profile.'}

CURRENT TARGET CAREER & ROADMAP:
${currentRoadmap ? `Target Career: ${currentRoadmap.careerTitle}, Progress: ${currentRoadmap.progress || 0}%` : 'Exploring possibilities'}
`;

    const systemInstruction = `You are PathPilot AI, a personalized career guidance assistant for students and early-career professionals.
Tagline: "Your career. Your strengths. Your direction."

Use the retrieved career knowledge and the student's voluntarily provided profile information to generate helpful, specific, and practical guidance.

Rules:
1. Base factual career descriptions on the retrieved knowledge wherever possible.
2. Personalize your recommendations according to the student's education stage, interests, strengths, goals, and practical constraints (e.g. for Diploma students, highlight LEET lateral entry, NATS apprenticeships, SSC JE; for Class 10, neutrally compare Science, Commerce, Humanities, and Vocational).
3. When necessary information is missing, ask one or two focused questions instead of guessing.
4. Present multiple suitable options when appropriate, with explanations of why each may fit.
5. Never treat a recommendation score as a guarantee of future success.
6. Never invent salaries, college details, examination requirements, scholarships, eligibility rules, or placement statistics.
7. For changing information, identify what needs to be verified using official sources.
8. If the retrieved knowledge is insufficient, acknowledge the limitation rather than pretending to know the answer.
9. Give the student a realistic next step, such as a beginner project, skill to practise, course pathway to investigate, or professional to consult.
10. Keep answers supportive, clear, and tailored to the user's question. Do not provide generic motivational speeches in place of actual guidance.

Answer the student's question using the available evidence. Clearly distinguish general guidance from facts requiring current verification.`;

    if (apiKey) {
      const ai = new GoogleGenAI({ apiKey });
      
      // Build conversation prompt
      const conversationHistory = (history || []).slice(-6).map((h: { role: string; content: string }) => `${h.role === 'user' ? 'Student' : 'Mentor'}: ${h.content}`).join('\n\n');

      const fullPrompt = `${systemInstruction}

CONTEXT:
${studentContext}

CONVERSATION HISTORY:
${conversationHistory}

CURRENT QUESTION FROM STUDENT:
${message}

Please provide a personalized, actionable, empathetic response:`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: fullPrompt,
      });

      const responseText = response.text || 'I am here to guide your career journey. Let us look at your options step by step.';

      res.json({
        reply: responseText,
        source: 'gemini-3.8-flash',
      });
      return;
    }

    // Graceful fallback if GEMINI_API_KEY is not configured yet
    const fallbackResponse = generateIntelligentFallback(message, studentProfile, assessmentSummary);
    res.json({
      reply: fallbackResponse,
      source: 'offline-guidance-engine',
      notice: 'Operating in local counseling mode. For live Gemini AI, set GEMINI_API_KEY in your environment.'
    });

  } catch (error: any) {
    console.error('Error in /api/mentor:', error);
    // Return graceful fallback rather than 500 so UI is never blocked
    const fallback = generateIntelligentFallback(req.body.message || '', req.body.studentProfile, req.body.assessmentSummary);
    res.json({
      reply: fallback,
      source: 'offline-fallback',
      warning: 'Live AI request timed out or unavailable. Delivered grounded career advice.'
    });
  }
});

// AI Report Narrative Generation endpoint
app.post('/api/generate-insights', async (req, res) => {
  try {
    const { studentProfile, topCareers, scores } = req.body;
    const apiKey = process.env.GEMINI_API_KEY;

    if (apiKey) {
      const ai = new GoogleGenAI({ apiKey });
      const prompt = `You are PathPilot AI's Assessment Evaluation Specialist.
Provide an executive, personalized qualitative career counselling narrative (around 200 words) for:
Student: ${studentProfile?.name || 'Candidate'}
Stage: ${studentProfile?.stage || 'Student'}
Top Careers: ${topCareers?.map((c: any) => `${c.title} (${c.fitScore}% match)`).join(', ')}
Dimension Scores: Interest ${scores?.interest}%, Aptitude ${scores?.aptitude}%, Values ${scores?.values}%, WorkStyle ${scores?.workStyle}%.

Highlight:
1. Key personal strengths and natural work inclinations.
2. Why the top matching career pathways harmonize with their profile.
3. Realistic growth areas and recommended practical exploration for the next 90 days.
Keep tone empowering, precise, and practical.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
      });

      res.json({ narrative: response.text });
      return;
    }

    // Fallback narrative
    const name = studentProfile?.name || 'Candidate';
    const topCareer = topCareers?.[0]?.title || 'Technology & Engineering';
    res.json({
      narrative: `Based on your responses, ${name}, you demonstrate a strong alignment with analytical problem-solving and structured creativity. Your highest compatibility is in ${topCareer}, where your blend of practical curiosity and methodical thinking will be an asset. We recommend focusing on foundational skill-building, creating early starter projects, and exploring real-world case studies over the next 90 days to test and confirm your interest.`
    });
  } catch (err: any) {
    console.error('Error generating report insights:', err);
    res.json({
      narrative: 'Your assessment highlights balanced strengths in critical reasoning, self-directed learning, and collaborative problem-solving. Review your top recommended pathways below to explore courses, entrance routes, and foundational milestones.'
    });
  }
});

// Fallback logic for intelligent counselor responses
function generateIntelligentFallback(message: string, profile: any, assessment: any): string {
  const q = message.toLowerCase();
  const name = profile?.name || 'friend';
  const stage = profile?.stage || 'your current stage';

  if (q.includes('diploma') || q.includes('polytechnic') || stage.includes('diploma')) {
    return `Hello ${name}! As a diploma student, you have a distinct competitive advantage: **strong hands-on practical foundations**. 

Here are the 3 primary pathways open to you:
1. **Lateral Entry to B.Tech / B.E. (LEET):** Most state universities and premier institutes allow direct entry into the 2nd year (3rd semester) of an engineering degree. This saves you one year and bridges diploma with a full engineering degree.
2. **Direct Core Industry Employment / Apprenticeships:** Companies actively hire diploma holders for supervisory engineering, CAD design, automation maintenance, and field operations. Look into NATS (National Apprenticeship Training Scheme).
3. **Public Sector & Government Exams:** Exams like SSC JE (Junior Engineer), RRB JE (Railway Recruitment Board), and State Electricity Boards frequently recruit diploma candidates with solid career stability.

**Recommended Next Step:** Would you like to evaluate whether lateral entry B.Tech or a direct job fits your financial and personal goals better?`;
  }

  if (q.includes('class 10') || q.includes('stream') || q.includes('subject')) {
    return `Hello ${name}! Choosing your stream after Class 10 is about discovering where your genuine curiosity intersects with your long-term comfort:

- **Science (PCM/PCB):** Best if you enjoy understanding physical laws, mathematical problem-solving, medicine, or emerging tech. Opens gateways to engineering, architecture, biosciences, and data fields.
- **Commerce (With or Without Math):** Ideal if you enjoy business logic, markets, finance, entrepreneurship, or economics. Leads directly to Chartered Accountancy (CA), Investment Banking, Corporate Law, and Management.
- **Humanities / Arts:** Excellent if you enjoy social sciences, public policy, creative design, psychology, civil services (UPSC), journalism, and law.
- **Vocational Streams (IT, Healthcare, Design):** Fast-track practical skill programs with high industry relevance.

Remember: No stream is superior. The right stream is the one where you can excel consistently. What subjects do you find yourself studying without feeling exhausted?`;
  }

  if (q.includes('data analyst') || q.includes('data science') || q.includes('analytics')) {
    return `To become a **Data Analyst** starting from ${stage}, here is a high-leverage 3-step blueprint:

1. **Phase 1: Foundations (Month 1):**
   - Learn Excel/Google Sheets deeply: Pivot tables, VLOOKUP/XLOOKUP, and conditional formulas.
   - Master basic Statistics: Mean, Median, Standard Deviation, and Probability distributions.

2. **Phase 2: Core Tooling (Month 2):**
   - Learn **SQL**: Practice SELECT queries, JOINs, GROUP BY, and aggregations on LeetCode or Mode Analytics.
   - Learn **Power BI or Tableau**: Build a dashboard analyzing a public dataset (e.g., sports, e-commerce, or mobility).

3. **Phase 3: Python & Portfolio (Month 3):**
   - Learn Python basics with Pandas and Matplotlib.
   - Publish 2 cleaned, insightful project notebooks on GitHub or Kaggle to showcase in interviews.

Would you like me to recommend free certifications or project datasets for this roadmap?`;
  }

  return `Hello ${name}! Thank you for reaching out. Based on your stage (${stage}) and career discovery goals, the most empowering approach is to balance:

1. **Objective Aptitude:** Your natural comfort with analytical, creative, or interpersonal tasks.
2. **Market Realities:** High-growth industries, qualification requirements, and examination timelines.
3. **Sustainable Motivation:** What kind of daily work environment keeps you energized rather than burnt out.

Explore your top career recommendations in your dashboard, check the 90-day roadmap milestones, and let me know which specific career or decision you want us to dissect together!`;
}

// Development vs Production serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`PathPilot AI server running on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
