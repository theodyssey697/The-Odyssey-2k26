export type EducationStage =
  | 'class_8_9'
  | 'class_10'
  | 'class_11_12'
  | 'diploma'
  | 'undergraduate'
  | 'postgraduate'
  | 'working_professional';

export interface StageDetails {
  // Class 10 specific
  class10PreferredSubjects?: string[];
  streamExplorationInterests?: string[];
  
  // Class 11-12 specific
  stream11_12?: 'PCM' | 'PCB' | 'Commerce_Math' | 'Commerce_NoMath' | 'Humanities' | 'Vocational';
  targetEntranceExams?: string[];
  preferredDegreeTypes?: string[];
  
  // Diploma specific
  diplomaBranch?: string;
  diplomaYear?: string;
  diplomaImmediateGoal?: 'lateral_entry_btech' | 'direct_industry_job' | 'govt_exam_je' | 'undecided';
  practicalSkillsSummary?: string;
  
  // Undergraduate specific
  degreeName?: string;
  degreeBranch?: string;
  undergradYear?: string;
  immediatePostGradGoal?: 'campus_placements' | 'higher_studies_india' | 'studies_abroad' | 'startup' | 'govt_services';
  
  // Working professional specific
  currentIndustry?: string;
  currentRole?: string;
  yearsOfExperience?: number;
  pivotMotivation?: 'better_growth' | 'passion_alignment' | 'tech_upskilling' | 'work_life_balance';
}

export interface StudentProfile {
  id: string;
  name: string;
  email?: string;
  stage: EducationStage;
  stageDetails: StageDetails;
  favoriteSubjects: string[];
  knownSkills: string[];
  locationPreference: string;
  budgetConsideration: 'budget_sensitive' | 'moderate' | 'flexible';
  careerGoals: string;
  completedOnboarding: boolean;
  createdAt: string;
}

export type QuestionDimension =
  | 'interests'
  | 'strengths_aptitude'
  | 'work_preferences'
  | 'values_motivators'
  | 'learning_preferences'
  | 'career_education_preferences'
  | 'career_readiness';

export type QuestionType = 'single_choice' | 'rating_scale' | 'multiple_choice' | 'scenario';

export interface QuestionOption {
  id: string;
  label: string;
  description?: string;
  // Weight vector mapped to career categories/traits
  weights: {
    tech?: number;
    core_engineering?: number;
    healthcare?: number;
    business_finance?: number;
    design_media?: number;
    law_policy?: number;
    sciences?: number;
    applied_vocational?: number;
    analytical?: number;
    creative?: number;
    people_social?: number;
    hands_on?: number;
  };
  indicativeNote?: string;
}

export interface AssessmentQuestion {
  id: string;
  dimension: QuestionDimension;
  applicableStages: EducationStage[] | 'all';
  text: string;
  contextGuidance?: string;
  type: QuestionType;
  options: QuestionOption[];
  isRequired: boolean;
  isObjectiveReasoning?: boolean;
}

export interface AssessmentDraft {
  assessmentId: string;
  userId: string;
  startedAt: string;
  updatedAt: string;
  currentQuestionIndex: number;
  answers: Record<string, string | string[] | number>;
  completed: boolean;
}

export interface EducationPathways {
  degreeRoutes: string[];
  diplomaAndLateralRoutes: string[];
  alternativeVocationalRoutes: string[];
  certifications: string[];
  keyEntranceExams: string[];
}

export interface CareerProfile {
  id: string;
  title: string;
  category:
    | 'Technology & Software'
    | 'Engineering & Manufacturing'
    | 'Healthcare & Life Sciences'
    | 'Business, Commerce & Finance'
    | 'Design, Media & Creative'
    | 'Law, Policy & Public Administration'
    | 'Pure & Applied Sciences'
    | 'Applied Technology & Vocational';
  shortDescription: string;
  fullDescription: string;
  fitScore?: number;
  matchBreakdown?: {
    interestMatch: number;
    aptitudeMatch: number;
    valuesMatch: number;
    workStyleMatch: number;
    pathwayViability: number;
  };
  matchReasons: string[];
  strengthsUtilized: string[];
  skillGapsToAddress: string[];
  typicalResponsibilities: string[];
  educationPathways: EducationPathways;
  coreSkills: {
    technical: string[];
    soft: string[];
  };
  starterProjects: string[];
  internshipIdeas: string[];
  employmentSettings: string[];
  salaryIndicative: {
    entryLevelINR: string;
    midCareerINR: string;
    notes: string;
    source: string;
    updatedDate: string;
  };
  resources: {
    title: string;
    url: string;
    type: 'course' | 'community' | 'official_guide' | 'syllabus';
  }[];
}

export interface AssessmentResult {
  id: string;
  userId: string;
  completedAt: string;
  topCareers: CareerProfile[];
  alternativeCareers: CareerProfile[];
  dimensionScores: {
    interests: number;
    strengths_aptitude: number;
    work_preferences: number;
    values_motivators: number;
    learning_preferences: number;
    career_readiness: number;
  };
  qualitativeSummary: string;
  answersSnapshot: Record<string, any>;
}

export interface RoadmapTask {
  id: string;
  title: string;
  description: string;
  timeframe: string;
  priority: 'high' | 'medium' | 'low';
  completed: boolean;
  resourceLink?: string;
  isCustom?: boolean;
}

export interface RoadmapPhase {
  id: string;
  title: string;
  dayRange: 'Day 1–30: Foundation' | 'Day 31–60: Skill Building' | 'Day 61–90: Portfolios & Outreach';
  description: string;
  tasks: RoadmapTask[];
}

export interface CareerRoadmap {
  id: string;
  userId: string;
  careerId: string;
  careerTitle: string;
  createdAt: string;
  updatedAt: string;
  phases: RoadmapPhase[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  source?: string;
  suggestedFollowUps?: string[];
}
