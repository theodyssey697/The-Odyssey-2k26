import { CareerProfile } from '../types';

export const CAREERS_DATA: CareerProfile[] = [
  // 1. AI & Machine Learning Engineer
  {
    id: 'ai-ml-engineer',
    title: 'AI & Machine Learning Engineer',
    category: 'Technology & Software',
    shortDescription: 'Designs, trains, and deploys intelligent models, neural networks, and scalable generative AI pipelines.',
    fullDescription: 'Artificial Intelligence and Machine Learning Engineers transform vast datasets into predictive models and automated reasoning systems. They work at the cutting edge of Natural Language Processing, Computer Vision, and Generative AI, optimizing neural architectures to solve high-impact industry challenges.',
    matchReasons: [
      'Strong alignment with quantitative problem-solving and algorithmic curiosity.',
      'High compatibility with software systems, data structures, and continuous self-learning.',
      'Offers high autonomy, analytical depth, and remote/hybrid work flexibility.'
    ],
    strengthsUtilized: [
      'Mathematical modeling & statistics',
      'Systematic code debugging & logic',
      'Curiosity for self-directed research & prototyping'
    ],
    skillGapsToAddress: [
      'Hands-on experience deploying models with Docker & cloud APIs (AWS/GCP)',
      'Understanding model evaluation metrics beyond simple accuracy (F1, precision-recall)'
    ],
    typicalResponsibilities: [
      'Train, fine-tune, and evaluate deep learning and LLM architectures.',
      'Build robust data ingestion and preprocessing pipelines.',
      'Optimize model latency and memory footprints for production inference.',
      'Collaborate with product teams to translate business problems into ML formulations.'
    ],
    educationPathways: {
      degreeRoutes: [
        'B.Tech / B.E. in Computer Science, AI & Data Science, or Mathematics & Computing',
        'B.Sc in Computer Science / Statistics followed by M.Sc or MCA',
        'Integrated Dual Degree (B.Tech + M.Tech) in Computational Sciences'
      ],
      diplomaAndLateralRoutes: [
        '3-year Diploma in Computer Science / IT -> Lateral Entry into 2nd year B.Tech (LEET) -> Focus on Python & Math',
        'Direct junior programming roles from Diploma + self-paced ML portfolio building'
      ],
      alternativeVocationalRoutes: [
        'Intensive Full-Stack ML Bootcamps with verified Kaggle / Hugging Face portfolio proof',
        'Open-source contribution track combined with industry certifications'
      ],
      certifications: [
        'Google Cloud Professional Machine Learning Engineer',
        'DeepLearning.AI Machine Learning Specialization',
        'AWS Certified Machine Learning - Specialty'
      ],
      keyEntranceExams: [
        'JEE Main & JEE Advanced (for IITs/NITs)',
        'CUET (for Central University B.Sc/B.Tech programs)',
        'State CETs / LEET (for state universities & diploma lateral entry)',
        'GATE CS/DA (for M.Tech/PSUs)'
      ]
    },
    coreSkills: {
      technical: ['Python', 'PyTorch / TensorFlow', 'SQL & Data Wrangling', 'Git', 'FastAPI', 'Vector Databases', 'Docker'],
      soft: ['Hypothesis-driven thinking', 'Clarity in communicating mathematical results', 'Resilience through long debugging cycles']
    },
    starterProjects: [
      'Build a domain-specific document Q&A assistant using LangChain and a free Gemini API key.',
      'Train a tabular prediction model (e.g., student dropout risk or house price) and publish on Kaggle.',
      'Deploy a sentiment analysis API on Render or Hugging Face Spaces.'
    ],
    internshipIdeas: [
      'Research assistant intern at an academic university computing lab.',
      'Data labeling and model benchmarking intern at a high-growth SaaS startup.',
      'Open-source contributor to scikit-learn, Hugging Face transformers, or LangChain.'
    ],
    employmentSettings: [
      'AI Research Labs & Frontier Tech Startups',
      'Global Capability Centers (GCCs) in Bengaluru, Hyderabad, Pune, Gurugram',
      'Fintech and E-commerce algorithmic trading & recommendation teams'
    ],
    salaryIndicative: {
      entryLevelINR: '₹7,00,000 – ₹16,00,000 / year',
      midCareerINR: '₹22,00,000 – ₹45,00,000+ / year',
      notes: 'Top tier campuses and specialized portfolio builders regularly command higher starting packages.',
      source: 'NASSCOM Tech Talent Trends & Glassdoor India Salary Benchmark',
      updatedDate: 'Q1 2026'
    },
    resources: [
      { title: 'Fast.ai Practical Deep Learning for Coders', url: 'https://course.fast.ai', type: 'course' },
      { title: 'Kaggle Learn Micro-Courses', url: 'https://www.kaggle.com/learn', type: 'course' },
      { title: 'Hugging Face Community & Docs', url: 'https://huggingface.co', type: 'community' }
    ]
  },

  // 2. Full Stack & Cloud Software Engineer
  {
    id: 'full-stack-engineer',
    title: 'Full Stack & Cloud Software Engineer',
    category: 'Technology & Software',
    shortDescription: 'Builds end-to-end web applications, resilient backend microservices, and modern cloud architectures.',
    fullDescription: 'Full Stack Software Engineers bridge user-facing frontend interfaces with resilient backend APIs, databases, and cloud infrastructure. They architect interactive digital platforms that scale to millions of concurrent users.',
    matchReasons: [
      'Natural passion for building tangible digital products from concept to launch.',
      'Balanced appetite for both user experience aesthetics and robust backend logic.',
      'Abundant job market demand across startups, scaleups, and enterprise giants.'
    ],
    strengthsUtilized: [
      'Rapid iterative prototyping',
      'Structured logical thinking & modular code design',
      'Pragmatic problem solving & tooling mastery'
    ],
    skillGapsToAddress: [
      'Database query optimization and index design',
      'Cloud CI/CD pipelines and production monitoring'
    ],
    typicalResponsibilities: [
      'Develop dynamic web apps using React/Vue and Node.js/Go/Java.',
      'Design RESTful and GraphQL APIs with authentication and database access.',
      'Deploy infrastructure as code using Docker, Kubernetes, and Cloud providers.',
      'Conduct code reviews, write automated unit tests, and resolve performance bottlenecks.'
    ],
    educationPathways: {
      degreeRoutes: [
        'B.Tech / B.E. in Computer Science / Information Technology / Software Engineering',
        'BCA (Bachelor of Computer Applications) followed by MCA',
        'B.Sc in Computer Science or Information Technology'
      ],
      diplomaAndLateralRoutes: [
        'Diploma in Computer Engineering / Information Tech -> Lateral Entry B.Tech 2nd Year',
        'Direct Junior Developer placement post-diploma based on strong GitHub portfolio'
      ],
      alternativeVocationalRoutes: [
        'Intensive Coding Bootcamps (Full Stack MERN / Spring Boot)',
        'Self-taught developer route supported by open-source contributions'
      ],
      certifications: [
        'AWS Certified Solutions Architect - Associate',
        'Meta Front-End & Back-End Professional Certificates',
        'Kubernetes Certified Application Developer (CKAD)'
      ],
      keyEntranceExams: [
        'JEE Main, State CETs, BITSAT, VITEEE, SRMJEEE',
        'NIMCET (for top NIT MCA admissions)',
        'State LEET (for Diploma lateral entry to B.Tech)'
      ]
    },
    coreSkills: {
      technical: ['TypeScript / JavaScript', 'React', 'Node.js / Express', 'PostgreSQL / MongoDB', 'Docker', 'AWS / GCP Basics', 'Git'],
      soft: ['Code readability empathy', 'Cross-functional communication', 'Time management in agile sprints']
    },
    starterProjects: [
      'Build a full-stack personal task tracker with authentication and persistent database.',
      'Create an e-commerce catalog with search filters and a mock payment gateway.',
      'Deploy a containerized REST API with automated GitHub Actions pipeline.'
    ],
    internshipIdeas: [
      'Frontend or Backend intern at an early-stage SaaS startup.',
      'Google Summer of Code (GSoC) or Linux Foundation open-source mentee.',
      'Web developer intern for university portals or local SME digitization.'
    ],
    employmentSettings: [
      'Product-Led SaaS Companies & High-Growth Startups',
      'Global IT Consultancies & Services (TCS, Infosys, Wipro, Accenture)',
      'Remote-first International Software Teams'
    ],
    salaryIndicative: {
      entryLevelINR: '₹4,50,000 – ₹12,00,000 / year',
      midCareerINR: '₹16,00,000 – ₹32,00,000 / year',
      notes: 'Product companies offer higher stock/ESOP compensation; service companies offer stable initial career ladders.',
      source: 'AmbitionBox & Cutshort India Tech Salary Index',
      updatedDate: 'Q1 2026'
    },
    resources: [
      { title: 'The Odin Project Full Stack Curriculum', url: 'https://theodinproject.com', type: 'course' },
      { title: 'MDN Web Docs Official Reference', url: 'https://developer.mozilla.org', type: 'syllabus' },
      { title: 'Roadmap.sh Developer Roadmaps', url: 'https://roadmap.sh', type: 'syllabus' }
    ]
  },

  // 3. Robotics & Mechatronics Automation Engineer (Diploma & Degree friendly!)
  {
    id: 'robotics-mechatronics',
    title: 'Robotics & Mechatronics Engineer',
    category: 'Engineering & Manufacturing',
    shortDescription: 'Integrates mechanical design, electronic sensors, microcontrollers, and automation software for smart machines.',
    fullDescription: 'Robotics and Mechatronics Engineers stand at the intersection of mechanics, electronics, and computing. They design automated assembly lines, industrial robotic arms, automated guided vehicles (AGVs), and smart IoT equipment.',
    matchReasons: [
      'Exceptional blend of hands-on physical hardware making and computational logic.',
      'Highly accessible via both direct Polytechnic Diploma and B.Tech / Lateral Entry pathways.',
      'Rapidly accelerating demand in India with Make in India, EV manufacturing, and Industry 4.0.'
    ],
    strengthsUtilized: [
      'Physical tinkering & workshop confidence',
      'Hardware-software interface troubleshooting',
      'Spatial visualization & CAD design'
    ],
    skillGapsToAddress: [
      'Embedded C/C++ programming for microcontrollers',
      'Understanding industrial fieldbus protocols (CAN, Modbus, Profinet)'
    ],
    typicalResponsibilities: [
      'Program industrial PLCs, microcontrollers (STM32/ESP32/Arduino), and ROS (Robot Operating System).',
      'Design 3D mechanical enclosures, sensor brackets, and actuators in CAD software.',
      'Troubleshoot electrical wiring, stepper motors, and pneumatic circuits on factory floors.',
      'Calibrate camera sensors and computer vision for robotic pick-and-place automation.'
    ],
    educationPathways: {
      degreeRoutes: [
        'B.Tech in Mechatronics, Mechanical Engineering, Electrical & Electronics, or Robotics',
        'B.Voc (Bachelor of Vocation) in Production Technology / Industrial Automation'
      ],
      diplomaAndLateralRoutes: [
        '3-year Polytechnic Diploma in Mechanical / Electrical / Electronics / Mechatronics',
        'Lateral Entry into 2nd year B.Tech (LEET) with high academic credit recognition',
        'Direct Junior Automation Engineer / Maintenance Engineer placement post-diploma'
      ],
      alternativeVocationalRoutes: [
        'National Skill Training Institutes (NSTI) Advanced Diploma in IT, Networking & Cloud / Automation',
        'Apprenticeship in automotive plants (Tata Motors, Maruti Suzuki, Hero, Bajaj) under NATS'
      ],
      certifications: [
        'Certified Automation Professional (ISA-CAP)',
        'Siemens / Rockwell Automation PLC Programmer Certification',
        'SolidWorks / Autodesk Inventor Mechanical Design Certification'
      ],
      keyEntranceExams: [
        'State Polytechnic Entrance Tests (JEECUP, POLYCET, JEXPO)',
        'State LEET (Lateral Entry Entrance Test for Diploma holders into B.Tech)',
        'JEE Main for 4-year engineering colleges'
      ]
    },
    coreSkills: {
      technical: ['C/C++', 'Python', 'ROS (Robot Operating System)', 'PLC Programming (Ladder Logic)', 'CAD (SolidWorks/Fusion 360)', 'Circuit Analysis', 'Motor Control'],
      soft: ['Safety protocol discipline', 'Field troubleshooting under pressure', 'Cross-team trade coordination']
    },
    starterProjects: [
      'Build an obstacle-avoiding autonomous wheeled robot using an ESP32, ultrasonic sensors, and motor driver.',
      'Design and 3D print a 2-degree-of-freedom robotic gripper arm in Autodesk Fusion 360.',
      'Create an IoT temperature & vibration monitoring dashboard for an electric motor.'
    ],
    internshipIdeas: [
      'Maintenance apprentice in an automotive assembly or FMCG packaging facility.',
      'Hardware prototyping intern at a robotics/drone startup.',
      'Lab technician assistant in a university mechatronics or CNC lab.'
    ],
    employmentSettings: [
      'Automotive & EV Manufacturing Plants (Pune, Chennai, Manesar, Sanand)',
      'Warehouse Automation & Drone Companies',
      'Heavy Machinery, Aerospace & Defense Contractors'
    ],
    salaryIndicative: {
      entryLevelINR: '₹3,50,000 – ₹7,50,000 / year (Diploma) | ₹6,00,000 – ₹13,00,000 / year (B.Tech)',
      midCareerINR: '₹14,00,000 – ₹26,00,000 / year',
      notes: 'Strong practical workshop skills command rapid promotions to plant automation supervisor and R&D lead.',
      source: 'Industrial Automation Association & National Career Service (NCS) India',
      updatedDate: 'Q1 2026'
    },
    resources: [
      { title: 'ROS.org Official Tutorials', url: 'https://docs.ros.org', type: 'syllabus' },
      { title: 'Arduino & ESP32 Open Maker Lab', url: 'https://docs.arduino.cc', type: 'course' },
      { title: 'National Apprenticeship Training Scheme (NATS)', url: 'https://nats.education.gov.in', type: 'official_guide' }
    ]
  },

  // 4. UI/UX & Digital Product Designer
  {
    id: 'ui-ux-product-designer',
    title: 'UI/UX & Digital Product Designer',
    category: 'Design, Media & Creative',
    shortDescription: 'Crafts user research, wireframes, intuitive interfaces, and delightful digital user journeys.',
    fullDescription: 'UI/UX Designers combine empathy for human behavior with aesthetic visual craft and business strategy. They conduct user interviews, map customer journeys, architect design systems, and prototype interfaces for mobile apps and web platforms.',
    matchReasons: [
      'Harmonizes visual creativity with structured empathy and human behavior psychology.',
      'Portfolio-driven career where proof-of-work matters far more than traditional degrees.',
      'High collaboration with product managers, developers, and global audiences.'
    ],
    strengthsUtilized: [
      'Visual spatial harmony & typographic aesthetics',
      'Empathic user listening & user interviewing',
      'Translating messy requirements into clear flows'
    ],
    skillGapsToAddress: [
      'Building scalable design tokens & reusable component systems in Figma',
      'Conducting quantitative usability testing and heuristic evaluations'
    ],
    typicalResponsibilities: [
      'Conduct user interviews, surveys, and competitive usability audits.',
      'Create low-fidelity wireframes, interactive prototypes, and high-fidelity mockups in Figma.',
      'Maintain cohesive design systems with consistent typography, spacing, and accessibility standards.',
      'Collaborate with developers to ensure pixel-perfect, accessible design implementations.'
    ],
    educationPathways: {
      degreeRoutes: [
        'B.Des (Bachelor of Design) in Interaction Design, Communication Design, or Industrial Design',
        'B.Sc in Multimedia / Animation / Digital Media',
        'B.Tech / B.A. with a strong self-taught UI/UX portfolio'
      ],
      diplomaAndLateralRoutes: [
        'Diploma in Graphic Design, Applied Arts, or Commercial Arts',
        'Direct junior visual design entry based on Behance/Dribbble portfolio'
      ],
      alternativeVocationalRoutes: [
        'Google UX Design Professional Certificate on Coursera',
        'Intensive Product Design Cohorts (10kdesigners, GrowthSchool, Interaction Design Foundation)'
      ],
      certifications: [
        'Nielsen Norman Group UX Master Certified',
        'Google UX Design Certificate',
        'Interaction Design Foundation (IxDF) Certified UX Designer'
      ],
      keyEntranceExams: [
        'UCEED (for IIT Bombay, IIT Delhi, IIT Guwahati B.Des)',
        'NID DAT (National Institute of Design Design Aptitude Test)',
        'NIFT Entrance Exam (for fashion communication & design)',
        'Portfolio-based private university admissions (Srishti, MIT-ID, Pearl)'
      ]
    },
    coreSkills: {
      technical: ['Figma / FigJam', 'Design Systems & Tokens', 'Wireframing & Prototyping', 'User Research Methodologies', 'WCAG Accessibility Standards', 'Basic HTML/CSS understanding'],
      soft: ['Constructive critique receptivity', 'Storytelling and presentation', 'Cross-functional diplomacy']
    },
    starterProjects: [
      'Redesign the ticket booking or food delivery flow of a known app, documenting user friction points and before/after metrics.',
      'Design a clean, accessible mobile finance app for senior citizens with large touch targets and simplified copy.',
      'Publish an interactive Figma case study on Behance complete with user personas, sketches, and component kits.'
    ],
    internshipIdeas: [
      'UI/UX design intern at an early-stage venture or product studio.',
      'Volunteer redesign for a non-profit website to improve donation flow.',
      'Junior visual designer at a creative agency.'
    ],
    employmentSettings: [
      'Fintech, Edtech, and Healthtech consumer app startups',
      'Specialized Product Design Agencies & Design Studios',
      'Global tech enterprises (Google, Microsoft, Swiggy, Zomato, CRED)'
    ],
    salaryIndicative: {
      entryLevelINR: '₹4,50,000 – ₹10,00,000 / year',
      midCareerINR: '₹15,00,000 – ₹30,00,000 / year',
      notes: 'Exceptional portfolios and product design thinking frequently bypass standard college tier salary brackets.',
      source: 'UX India Design Salary Survey & Glassdoor',
      updatedDate: 'Q1 2026'
    },
    resources: [
      { title: 'Nielsen Norman Group Articles & Heuristics', url: 'https://nngroup.com', type: 'syllabus' },
      { title: 'Refactoring UI Book & Tips', url: 'https://refactoringui.com', type: 'course' },
      { title: 'LawsofUX Interaction Principles', url: 'https://lawsofux.com', type: 'syllabus' }
    ]
  },

  // 5. Chartered Accountant (CA) & Financial Analyst
  {
    id: 'chartered-accountant-finance',
    title: 'Chartered Accountant (CA) & Financial Analyst',
    category: 'Business, Commerce & Finance',
    shortDescription: 'Audits corporate finances, manages tax strategy, structures mergers, and ensures fiscal integrity.',
    fullDescription: 'Chartered Accountants and Corporate Financial Analysts are the fiscal backbone of the economy. They manage balance sheets, navigate direct and indirect taxation, ensure statutory corporate compliance, and advise boards on valuation and mergers.',
    matchReasons: [
      'High affinity for numerical rigor, financial law, corporate governance, and meticulous detail.',
      'One of India’s most respected, meritocratic, and prestigious professional qualifications.',
      'Clear, accessible path directly from Class 12 Commerce or any graduation background.'
    ],
    strengthsUtilized: [
      'Systematic analytical discipline & error spotting',
      'Interpretation of complex taxation and corporate legal statutes',
      'Ethical integrity under high corporate stakes'
    ],
    skillGapsToAddress: [
      'Advanced Excel financial modeling (DCF, sensitivity tables, LBO)',
      'Understanding modern ERP systems (SAP, Oracle Financials, Tally Prime)'
    ],
    typicalResponsibilities: [
      'Conduct statutory and internal financial audits for private and public companies.',
      'Formulate tax planning strategies and represent clients before tax appellate authorities.',
      'Build financial forecast models, valuations, and working capital optimization plans.',
      'Advise startup founders and corporate executives on capital structuring and risk management.'
    ],
    educationPathways: {
      degreeRoutes: [
        'ICAI Chartered Accountancy Course (Foundation -> Intermediate -> 3-year Articleship -> Final)',
        'B.Com (Hons) / BBA Finance alongside or prior to CA Intermediate',
        'Alternative global route: CFA (Chartered Financial Analyst) or ACCA (UK)'
      ],
      diplomaAndLateralRoutes: [
        'Commerce Graduates with 55%+ or Other Graduates with 60%+ get Direct Entry into CA Intermediate bypassing Foundation',
        'Diploma in Commercial Practice / Accounting -> B.Com -> CA'
      ],
      alternativeVocationalRoutes: [
        'Certified Management Accountant (CMA India / US)',
        'Company Secretary (CS) through ICSI for legal and corporate compliance specialization'
      ],
      certifications: [
        'ICAI Chartered Accountant Membership',
        'CFA Institute Charterholder (Levels 1, 2, 3)',
        'Financial Risk Manager (FRM - GARP)'
      ],
      keyEntranceExams: [
        'CA Foundation (held twice a year by ICAI)',
        'CUET UG (for premier B.Com Hons colleges like SRCC, St. Xavier’s)',
        'Direct Entry Scheme post-graduation'
      ]
    },
    coreSkills: {
      technical: ['Statutory Auditing Standards', 'Corporate Tax & GST Law', 'Advanced Financial Modeling (Excel)', 'IFRS & Ind AS', 'Cost Accounting', 'SAP FICO'],
      soft: ['Unyielding ethical rigor', 'Client confidentiality preservation', 'Clear executive communication']
    },
    starterProjects: [
      'Analyze the annual financial statements (10-K / Annual Report) of a listed Indian enterprise (e.g., Tata Motors, Infosys) and calculate 10 key solvency ratios.',
      'Build a dynamic 3-statement financial model (Income Statement, Balance Sheet, Cash Flow) with working capital assumptions.',
      'Prepare a practical guide to GST filing and input tax credit reconciliation for an MSME.'
    ],
    internshipIdeas: [
      'Mandatory 2–3 year articleship at a registered CA firm or Big 4 accounting firm (Deloitte, PwC, EY, KPMG).',
      'Finance and audit trainee in a mid-sized manufacturing company.',
      'Equity research or portfolio tracking intern at an investment advisory.'
    ],
    employmentSettings: [
      'Big 4 Accounting & Advisory Firms (Deloitte, PwC, EY, KPMG)',
      'Independent Private CA Practice & Tax Consultancy',
      'Treasury & CFO offices of Fortune 500 corporations and banks'
    ],
    salaryIndicative: {
      entryLevelINR: '₹8,00,000 – ₹15,00,000 / year (Fresher CA rank holders: ₹18,00,000 – ₹25,00,000)',
      midCareerINR: '₹20,00,000 – ₹45,00,000+ / year',
      notes: 'Partners in established firms and corporate CFOs command substantial profit-sharing and bonus packages.',
      source: 'ICAI Campus Placement Report & Michael Page India Salary Benchmark',
      updatedDate: 'Q1 2026'
    },
    resources: [
      { title: 'ICAI Official Portal & BoS Knowledge Portal', url: 'https://icai.org', type: 'official_guide' },
      { title: 'CFA Institute Curriculum Outline', url: 'https://cfainstitute.org', type: 'syllabus' },
      { title: 'Corporate Finance Institute (CFI) Free Resources', url: 'https://corporatefinanceinstitute.com', type: 'course' }
    ]
  },

  // 6. Clinical Doctor (MBBS) & Medical Specialist
  {
    id: 'doctor-medical-specialist',
    title: 'Clinical Doctor (MBBS) & Medical Specialist',
    category: 'Healthcare & Life Sciences',
    shortDescription: 'Diagnoses clinical ailments, performs treatments, saves lives, and guides patient wellness.',
    fullDescription: 'Medical doctors dedicate their careers to clinical diagnosis, therapeutic treatment, patient advocacy, and human longevity. Following the rigorous 5.5-year MBBS and internship, specialists pursue postgraduate MD/MS or DNB training to master surgery, internal medicine, pediatrics, or cardiology.',
    matchReasons: [
      'Profound, unwavering desire to make a direct, tangible difference in human lives.',
      'Deep intellectual curiosity about human anatomy, physiological pathology, and pharmacological science.',
      'Unsurpassed societal respect, enduring career stability, and purposeful daily work.'
    ],
    strengthsUtilized: [
      'Empathetic patient listening & bedside reassurance',
      'Clinical diagnostic deduction under stressful conditions',
      'Sustained stamina for intensive multi-year academic study'
    ],
    skillGapsToAddress: [
      'Emotional detachment balance (compassion without clinical burnout)',
      'Memorization strategies for dense anatomical and pharmacological nomenclature'
    ],
    typicalResponsibilities: [
      'Conduct physical clinical examinations, order diagnostic tests, and interpret results.',
      'Formulate pharmacological treatments and perform invasive procedures or surgeries.',
      'Monitor patient vitals, emergency triage, and post-operative recovery.',
      'Educate communities on preventive healthcare, immunization, and lifestyle medicine.'
    ],
    educationPathways: {
      degreeRoutes: [
        'MBBS (5.5 years including 1-year mandatory rotating clinical internship)',
        'MD / MS / DNB (Postgraduate specialization - 3 years)',
        'DM / MCh (Super-specialization in cardiology, neurology, surgical oncology - 3 years)'
      ],
      diplomaAndLateralRoutes: [
        'Direct lateral entry is NOT legally permitted into MBBS in India.',
        'Alternative allied paths for Biology/Diploma holders: B.Sc Nursing, B.Pharm, BPT (Physiotherapy), or Allied Health Sciences'
      ],
      alternativeVocationalRoutes: [
        'Diploma in Medical Laboratory Technology (DMLT) -> Clinical diagnostics technician',
        'Emergency Medical Technician (EMT) or Paramedical vocational certifications'
      ],
      certifications: [
        'National Medical Commission (NMC) Permanent Registration',
        'Basic Life Support (BLS) & Advanced Cardiac Life Support (ACLS)',
        'MRCP / USMLE (for international clinical practice)'
      ],
      keyEntranceExams: [
        'NEET UG (National Eligibility cum Entrance Test for all MBBS/BDS admissions)',
        'NEET PG / NExT (National Exit Test for MD/MS postgraduate seats)',
        'INICET (for AIIMS, JIPMER, PGI Chandigarh PG seats)'
      ]
    },
    coreSkills: {
      technical: ['Clinical Differential Diagnosis', 'Emergency Triage & Resuscitation', 'Pharmacology & Drug Interactions', 'Pathology & Radiology Interpretation', 'Surgical Aseptic Technique'],
      soft: ['Deep emotional empathy', 'High resilience under crisis', 'Ethical patient advocacy']
    },
    starterProjects: [
      'Volunteer with a local Red Cross or village health camp to observe preventive triage.',
      'Shadow a general physician for 2 weeks to document the variety of daily presenting symptoms.',
      'Write an evidence-based summary of how antimicrobial resistance develops and how to educate patients.'
    ],
    internshipIdeas: [
      'Mandatory 1-year compulsory rotating medical internship (CRMI) at attached medical college hospital.',
      'Rural health center (PHC/CHC) community posting.',
      'ICU and emergency trauma observer.'
    ],
    employmentSettings: [
      'Government Medical Colleges & District Hospitals (AIIMS, State Health Services)',
      'Multi-specialty Private Healthcare Chains (Apollo, Fortis, Max, Manipal)',
      'Autonomous Research Institutes & Global Health Organizations (WHO, ICMR)'
    ],
    salaryIndicative: {
      entryLevelINR: '₹7,00,000 – ₹12,00,000 / year (Junior Resident / Medical Officer)',
      midCareerINR: '₹20,00,000 – ₹50,00,000+ / year (Post-MD/MS Consultant)',
      notes: 'Super-specialists (Cardiologists, Neurosurgeons) command higher private earnings; public service offers immense security and pensions.',
      source: 'National Medical Commission (NMC) & Healthcare Federation of India',
      updatedDate: 'Q1 2026'
    },
    resources: [
      { title: 'National Medical Commission (NMC) Guidelines', url: 'https://nmc.org.in', type: 'official_guide' },
      { title: 'NEET UG Syllabus & Information Bulletin', url: 'https://neet.nta.nic.in', type: 'syllabus' },
      { title: 'BMJ Best Practice Evidence Summaries', url: 'https://bestpractice.bmj.com', type: 'course' }
    ]
  },

  // 7. Biotechnology Research Scientist
  {
    id: 'biotech-researcher',
    title: 'Biotechnology Research Scientist',
    category: 'Healthcare & Life Sciences',
    shortDescription: 'Engineers biological systems, gene editing therapies, vaccines, and sustainable biofuels.',
    fullDescription: 'Biotechnology Scientists harness cellular biology, genetics, and bioinformatics to discover lifesaving drugs, engineer drought-resistant crops, formulate biofuels, and produce synthetic proteins.',
    matchReasons: [
      'Fascinated by molecular biology, CRISPR gene editing, and laboratory discovery.',
      'Prefers structured scientific experimentation, hypothesis testing, and laboratory environments.',
      'Strong global relevance in pharmaceutical R&D, bioprocessing, and sustainability.'
    ],
    strengthsUtilized: [
      'Precise laboratory protocol execution',
      'Statistical validation of biological trials',
      'Scientific literature synthesis'
    ],
    skillGapsToAddress: [
      'Bioinformatics programming (Python, R, Bioconductor, BLAST)',
      'Good Laboratory Practices (GLP) and pharmaceutical regulatory filings'
    ],
    typicalResponsibilities: [
      'Perform PCR, recombinant DNA cloning, cell culture, and chromatography assays.',
      'Analyze genomic sequencing data using bioinformatics algorithms.',
      'Document experimental findings according to ISO/GLP compliance protocols.',
      'Publish research findings in peer-reviewed journals and contribute to patent filings.'
    ],
    educationPathways: {
      degreeRoutes: [
        'B.Tech / B.Sc in Biotechnology, Microbiology, Biochemistry, or Genetics',
        'M.Sc / M.Tech in Biotechnology or Bioinformatics',
        'Ph.D. in Biological Sciences for principal scientist / R&D leadership roles'
      ],
      diplomaAndLateralRoutes: [
        'Diploma in Chemical Technology / Pharmacy / Medical Lab Tech -> Lateral entry B.Tech Biotech',
        'Junior laboratory technician roles post-diploma in diagnostic labs'
      ],
      alternativeVocationalRoutes: [
        'Certification in Clinical Research & Regulatory Affairs',
        'Hands-on Bioprocessing Workshops at certified DBT / CSIR institutions'
      ],
      certifications: [
        'CSIR-UGC NET (JRF for scientific fellowship)',
        'Good Laboratory Practice (GLP) & Biosafety Compliance Certification',
        'Bioinformatics Data Analysis Specialization'
      ],
      keyEntranceExams: [
        'NEET UG (for biotechnology integrated courses) or JEE Main (for B.Tech Biotech)',
        'CUET UG / PG (for Central University biological programs)',
        'GATE Biotechnology (BT) / CSIR NET Life Sciences'
      ]
    },
    coreSkills: {
      technical: ['Cell Culture & Aseptic Technique', 'CRISPR & Recombinant DNA', 'Bioinformatics (Python, R)', 'Mass Spectrometry', 'Statistical Hypothesis Testing', 'GLP Standards'],
      soft: ['Meticulous attention to microscopic detail', 'Patience through multi-month trials', 'Scientific skepticism']
    },
    starterProjects: [
      'Analyze public COVID or cancer genomic variants using NCBI BLAST and Python Biopython libraries.',
      'Design a protocol for extracting DNA from fruit at home and document the chemical mechanics of each step.',
      'Review 3 recent papers on mRNA vaccine stability and summarize the biophysical stabilization methods.'
    ],
    internshipIdeas: [
      'Summer research fellow at CSIR-CCMB, IISc, or ICMR labs via the Indian Academy of Sciences (IASc) fellowship.',
      'Quality control intern at a pharmaceutical formulation facility (Biocon, Serum Institute, Dr. Reddy’s).',
      'Bioinformatics data annotation intern at a genomics startup.'
    ],
    employmentSettings: [
      'Biopharmaceutical R&D Centers (Biocon, Serum Institute, Bharat Biotech)',
      'Academic & National Research Institutes (IISc, IITs, CSIR, DBT)',
      'Agricultural Genetics & Crop Science Enterprises'
    ],
    salaryIndicative: {
      entryLevelINR: '₹4,50,000 – ₹8,50,000 / year (Junior Research Fellow / Scientist I)',
      midCareerINR: '₹14,00,000 – ₹28,00,000 / year (Senior Scientist / R&D Manager)',
      notes: 'Ph.D. holders with international post-doc experience command higher principal investigator packages.',
      source: 'Department of Biotechnology (DBT) & Association of Biotechnology Led Enterprises (ABLE)',
      updatedDate: 'Q1 2026'
    },
    resources: [
      { title: 'NCBI Bioinformatics Resources & Databases', url: 'https://ncbi.nlm.nih.gov', type: 'official_guide' },
      { title: 'CSIR Life Sciences Information Portal', url: 'https://csir.res.in', type: 'syllabus' },
      { title: 'Biopython Tutorial & Cookbook', url: 'https://biopython.org', type: 'course' }
    ]
  },

  // 8. Corporate Lawyer & Legal Tech Counsel
  {
    id: 'corporate-lawyer',
    title: 'Corporate Lawyer & Legal Tech Counsel',
    category: 'Law, Policy & Public Administration',
    shortDescription: 'Negotiates cross-border contracts, protects intellectual property, and navigates regulations.',
    fullDescription: 'Corporate Lawyers safeguard organizations against commercial liabilities, draft multimillion-dollar agreements, oversee venture capital funding rounds, manage corporate mergers, and resolve disputes through arbitration.',
    matchReasons: [
      'Exceptional verbal persuasion, analytical reading comprehension, and structured negotiation.',
      'Direct applicability for students of Humanities, Commerce, or Science (all streams eligible for 5-year Law).',
      'Intellectually prestigious profession with clear corporate advancement and advocacy tracks.'
    ],
    strengthsUtilized: [
      'Rapid assimilation of dense legal texts and precedents',
      'Structured logical counter-arguments & dispute negotiation',
      'Precise statutory drafting and risk mitigation'
    ],
    skillGapsToAddress: [
      'Understanding modern AI legal contract review tools and e-discovery platforms',
      'Knowledge of cross-border data privacy regulations (DPDP Act India, GDPR EU)'
    ],
    typicalResponsibilities: [
      'Draft and negotiate Master Services Agreements, Shareholder Agreements, and NDAs.',
      'Conduct legal due diligence for corporate acquisitions and venture financing.',
      'Represent corporate clients in commercial arbitration tribunals and high courts.',
      'Ensure statutory compliance with SEBI, Competition Commission of India, and MCA rules.'
    ],
    educationPathways: {
      degreeRoutes: [
        '5-Year Integrated B.A. LL.B. / B.B.A. LL.B. / B.Sc. LL.B. from a National Law University (NLU)',
        '3-Year LL.B. following any undergraduate degree (B.Com, B.A, B.Sc, B.Tech)',
        'LL.M. (Master of Laws) in Corporate Law, IP, or International Trade'
      ],
      diplomaAndLateralRoutes: [
        'Diploma in Cyber Law, Intellectual Property, or Labor Law (supplementary to degrees)',
        'Graduates can join the 3-Year LL.B. course at leading universities (DU, GLC Mumbai, ILS Pune)'
      ],
      alternativeVocationalRoutes: [
        'Legal Operations and Paralegal certifications',
        'Company Secretary (CS) qualification through ICSI for corporate governance'
      ],
      certifications: [
        'Bar Council of India (BCI) License & All India Bar Examination (AIBE)',
        'WIPO Certified Intellectual Property Specialization',
        'IAPP Certified Information Privacy Professional (CIPP)'
      ],
      keyEntranceExams: [
        'CLAT UG (Common Law Admission Test for NLUs across India)',
        'AILET (All India Law Entrance Test for NLU Delhi)',
        'LSAT India / MHCET Law (for GLC Mumbai, ILS, Jindal Global Law School)'
      ]
    },
    coreSkills: {
      technical: ['Contract Drafting & Redlining', 'Statutory Corporate Compliance', 'Commercial Arbitration Procedure', 'IP / Patent Law', 'Legal Due Diligence', 'Data Privacy Law'],
      soft: ['Strategic persuasion under pressure', 'Client negotiation tact', 'Uncompromising attention to contract clauses']
    },
    starterProjects: [
      'Draft a standard Founder Agreement and Non-Disclosure Agreement (NDA) for a hypothetical tech startup.',
      'Write a 1,000-word critique analyzing a recent Supreme Court or NCLT ruling on corporate insolvency.',
      'Participate in a university or school moot court competition on constitutional or commercial rights.'
    ],
    internshipIdeas: [
      'Summer legal intern at a Tier-1 law firm (Shardul Amarchand Mangaldas, Trilegal, Cyril Amarchand, Khaitan).',
      'Judicial clerkship or chamber intern under a Senior Advocate or High Court judge.',
      'In-house legal intern at a fintech or consumer tech company.'
    ],
    employmentSettings: [
      'Top-Tier Corporate Law Firms (SAM, CAM, Trilegal, AZB & Partners)',
      'In-House Legal Departments of Multinationals (Google, Reliance, Tata, Amazon)',
      'Litigation Chambers & Independent Appellate Practice'
    ],
    salaryIndicative: {
      entryLevelINR: '₹7,00,000 – ₹18,00,000 / year (Tier-1 NLU graduates command ₹16L–₹22L at top firms)',
      midCareerINR: '₹22,00,000 – ₹55,00,000+ / year',
      notes: 'Partners in corporate law firms and successful litigators enjoy substantial profit equity.',
      source: 'Bar Council of India & Legally India Compensation Survey',
      updatedDate: 'Q1 2026'
    },
    resources: [
      { title: 'Consortium of National Law Universities (CLAT)', url: 'https://consortiumofnlus.ac.in', type: 'official_guide' },
      { title: 'LiveLaw & Bar and Bench Legal Precedents', url: 'https://livelaw.in', type: 'syllabus' },
      { title: 'WIPO Free IP Learning Modules', url: 'https://wipo.int', type: 'course' }
    ]
  },

  // 9. Civil Services Officer & Public Administrator (UPSC)
  {
    id: 'civil-services-upsc',
    title: 'Civil Services Officer & Public Administrator (UPSC)',
    category: 'Law, Policy & Public Administration',
    shortDescription: 'Administers public policy, leads district governance, directs law enforcement, or shapes foreign policy.',
    fullDescription: 'Civil Services officers (IAS, IPS, IFS, IRS) govern public districts, implement welfare policies, safeguard public order, execute economic tax reforms, and represent the nation on international diplomatic stages.',
    matchReasons: [
      'Ultimate devotion to public welfare, constitutional administration, and societal impact.',
      'Open to graduates of every academic stream without restriction.',
      'Unsurpassed leadership scope, policy influence, and institutional governance power.'
    ],
    strengthsUtilized: [
      'Holistic understanding of socio-economic and political challenges',
      'Decisive crisis administration & public leadership',
      'Articulate analytical writing and policy synthesis'
    ],
    skillGapsToAddress: [
      'Deep, sustained discipline for 12–18 months of intensive multi-stage examination preparation',
      'Objective neutrality free from personal ideological biases'
    ],
    typicalResponsibilities: [
      'Direct district administration, revenue collection, and social development schemes (IAS).',
      'Maintain public order, counter crime, and lead state police forces (IPS).',
      'Negotiate treaties, protect national interests, and conduct bilateral diplomacy (IFS).',
      'Formulate national fiscal, budget, and customs policies (IRS).'
    ],
    educationPathways: {
      degreeRoutes: [
        'Any recognized Bachelor’s Degree (B.A, B.Sc, B.Com, B.Tech, MBBS, B.Des, LLB)',
        'Optional subjects during graduation can be chosen to align with UPSC Mains optionals (e.g., History, Pol Science, Geography, Sociology, Public Administration, Engineering)'
      ],
      diplomaAndLateralRoutes: [
        'Diploma holders can complete a lateral entry B.Tech, distance B.A/B.Com, or standard degree to satisfy the graduation eligibility requirement.'
      ],
      alternativeVocationalRoutes: [
        'State Public Service Commission (State PCS / Group 1 services)',
        'Staff Selection Commission (SSC CGL) for Central government administrative cadres'
      ],
      certifications: [
        'LBSNAA (Lal Bahadur Shastri National Academy of Administration) Foundation Course',
        'National e-Governance Division (NeGD) certifications'
      ],
      keyEntranceExams: [
        'UPSC Civil Services Examination (Prelims -> Mains [9 papers] -> Personality Test/Interview)',
        'State Public Service Commission Exams (UPPSC, MPSC, BPSC, KPSC, OPSC)',
        'SSC CGL (Combined Graduate Level Exam)'
      ]
    },
    coreSkills: {
      technical: ['Public Administration & Governance Law', 'Socio-Economic Policy Evaluation', 'Disaster & Crisis Management', 'District Budget Allocation', 'Constitutional Jurisprudence'],
      soft: ['Steadfast moral integrity', 'High emotional composure during public unrest', 'Empathetic public listening']
    },
    starterProjects: [
      'Conduct an informal survey of 20 rural or urban households assessing their awareness of the Ayushman Bharat or PM Kisan schemes.',
      'Write a 1,500-word policy brief recommending 3 actionable fixes for municipal waste segregation in your town.',
      'Practice writing structured 200-word answers on current national issues following the UPSC GS Mains answer format.'
    ],
    internshipIdeas: [
      'NITI Aayog internship program for young policy researchers.',
      'District Collectorate summer intern or volunteer with a district development initiative.',
      'Legislative Assistants to Members of Parliament (LAMP) Fellowship.'
    ],
    employmentSettings: [
      'District Collectorates & Sub-Divisions across Indian States',
      'Central Government Ministries (North & South Block, New Delhi)',
      'Indian Embassies & Consulates worldwide (Ministry of External Affairs)'
    ],
    salaryIndicative: {
      entryLevelINR: '₹56,100 / month basic + DA, HRA + Official accommodation, transport & allowances (7th Pay Commission Pay Level 10)',
      midCareerINR: 'Pay Level 14–17 (Chief Secretary / Cabinet Secretary: ₹2,25,000–₹2,50,000 / month basic + perks)',
      notes: 'Value is primarily rooted in immense constitutional authority, public welfare impact, and state facilities rather than purely corporate equity.',
      source: 'Union Public Service Commission (UPSC) & 7th Central Pay Commission',
      updatedDate: 'Q1 2026'
    },
    resources: [
      { title: 'UPSC Official Portal & Exam Notifications', url: 'https://upsc.gov.in', type: 'official_guide' },
      { title: 'NITI Aayog Policy Documents & Reports', url: 'https://niti.gov.in', type: 'syllabus' },
      { title: 'National Portal of India Schemes', url: 'https://india.gov.in', type: 'official_guide' }
    ]
  },

  // 10. Product Manager (Tech & Growth)
  {
    id: 'product-manager-tech',
    title: 'Product Manager (Tech & Growth)',
    category: 'Business, Commerce & Finance',
    shortDescription: 'Directs the product vision, prioritizes feature roadmaps, and aligns engineering with user value.',
    fullDescription: 'Product Managers operate at the intersection of business strategy, technology, and user experience. They define the "what" and "why" of a software product, prioritize sprint backlogs, track metrics, and drive product-market fit.',
    matchReasons: [
      'Thrives in cross-functional orchestrator roles without wanting to code 100% of the day.',
      'Combines strategic business ambition with genuine curiosity for design and technology.',
      'High ownership, strategic leadership visibility, and accelerated career trajectory.'
    ],
    strengthsUtilized: [
      'Synthesizing customer feedback into crisp requirements (PRDs)',
      'Ruthless prioritization of business ROI vs engineering effort',
      'Influence without direct hierarchical authority'
    ],
    skillGapsToAddress: [
      'Product analytics tools (Mixpanel, Amplitude, Google Analytics 4)',
      'Running statistically significant A/B experiments'
    ],
    typicalResponsibilities: [
      'Write Product Requirement Documents (PRDs) and user stories with clear acceptance criteria.',
      'Run weekly sprint planning, backlog grooming, and post-launch retrospectives.',
      'Analyze funnel drop-offs, user retention cohorts, and Net Promoter Scores (NPS).',
      'Conduct user interviews to discover unmet customer pains.'
    ],
    educationPathways: {
      degreeRoutes: [
        'B.Tech / B.E. in Computer Science or any engineering branch',
        'MBA from premier institutes (IIMs, ISB, XLRI, FMS) with product management focus',
        'Any undergraduate degree + transition via Associate Product Manager (APM) programs'
      ],
      diplomaAndLateralRoutes: [
        'Diploma -> Lateral B.Tech -> Software Engineering / QA -> Transition to APM role'
      ],
      alternativeVocationalRoutes: [
        'Associate Product Manager (APM) fellowships (NextLeap, Upraised, GrowthX)',
        'Transitioning internally from Software Engineer, UI/UX Designer, or Business Analyst roles'
      ],
      certifications: [
        'Certified Scrum Product Owner (CSPO)',
        'Product School Certified Product Manager (CPM)',
        'Pragmatic Institute Certified Product Master'
      ],
      keyEntranceExams: [
        'CAT / GMAT / XAT (for top MBA colleges in India & abroad)',
        'APM fellowship entrance challenges'
      ]
    },
    coreSkills: {
      technical: ['Product Analytics (Mixpanel/Amplitude)', 'A/B Testing Methodologies', 'SQL & Data Querying', 'Figma Wireframing', 'Jira / Linear Agile Management'],
      soft: ['Executive consensus building', 'Customer empathy interviewing', 'Decisiveness with incomplete data']
    },
    starterProjects: [
      'Write a complete PRD for an innovative feature on WhatsApp (e.g. collaborative expense splitting), detailing user personas, metrics, and wireframes.',
      'Perform a teardown of Spotify or Duolingo onboarding, identifying 3 friction points and proposing solutions.',
      'Query a public e-commerce SQLite dataset to calculate monthly cohort retention rates.'
    ],
    internshipIdeas: [
      'Associate Product Management intern at a seed or Series A tech startup.',
      'Product operations or customer success intern to learn user pain points directly.',
      'Business analyst intern at a digital transformation consultancy.'
    ],
    employmentSettings: [
      'Consumer Tech Unicorns (Swiggy, Zomato, PhonePe, Flipkart, Uber)',
      'Enterprise B2B SaaS Companies (Postman, BrowserStack, Zoho, Freshworks)',
      'Venture-backed Fintech, Healthtech, and Edtech scaleups'
    ],
    salaryIndicative: {
      entryLevelINR: '₹8,00,000 – ₹18,00,000 / year (APM roles)',
      midCareerINR: '₹25,00,000 – ₹55,00,000+ / year (Senior PM / Director of Product)',
      notes: 'PM roles offer substantial stock grants (ESOPs) that amplify total compensation in growing companies.',
      source: 'Payscale & Cutshort Product Manager Salary Report',
      updatedDate: 'Q1 2026'
    },
    resources: [
      { title: 'Lenny’s Newsletter Product Playbooks', url: 'https://lennysnewsletter.com', type: 'community' },
      { title: 'Mind the Product Guides', url: 'https://mindtheproduct.com', type: 'syllabus' },
      { title: 'Reforge Growth & Product Articles', url: 'https://reforge.com', type: 'course' }
    ]
  },

  // 11. Electric Vehicle (EV) Systems & Battery Engineer
  {
    id: 'ev-systems-engineer',
    title: 'Electric Vehicle (EV) Systems & Battery Engineer',
    category: 'Engineering & Manufacturing',
    shortDescription: 'Architects battery management systems (BMS), electric powertrains, motor controllers, and charging tech.',
    fullDescription: 'EV Systems Engineers lead the green mobility revolution. They design high-voltage lithium battery packs, optimize thermal dissipation, program embedded Battery Management Systems (BMS), and tune permanent magnet synchronous motors.',
    matchReasons: [
      'Passionate about automobiles, sustainable green technology, and electrical systems.',
      'Huge hiring surge in India with companies like Tata Motors, Ola Electric, Ather, and Mahindra.',
      'Welcoming to both B.Tech graduates and polytechnic diploma holders in Electrical/Mechanical.'
    ],
    strengthsUtilized: [
      'Electrical circuit analysis & power electronics',
      'Thermal simulation & mechanical pack assembly',
      'Firmware programming for safety-critical hardware'
    ],
    skillGapsToAddress: [
      'Battery chemistry cell degradation modeling',
      'CAN communication protocols and automotive functional safety (ISO 26262)'
    ],
    typicalResponsibilities: [
      'Develop embedded algorithms for State of Charge (SOC) and State of Health (SOH) estimation in BMS.',
      'Conduct thermal modeling in ANSYS to prevent lithium battery thermal runaway.',
      'Test motor controllers (inverters) on dynamometer test benches.',
      'Ensure vehicle compliance with AIS 156 battery safety standards in India.'
    ],
    educationPathways: {
      degreeRoutes: [
        'B.Tech in Electrical Engineering, Electronics, Mechanical, or Automotive Engineering',
        'M.Tech in Electric Vehicle Technology or Power Electronics'
      ],
      diplomaAndLateralRoutes: [
        'Polytechnic Diploma in Electrical / Mechanical / Automobile Engineering',
        'Lateral Entry into 2nd year B.Tech Electrical/Automobile',
        'EV Assembly Technician & Testing roles post-diploma in EV gigafactories'
      ],
      alternativeVocationalRoutes: [
        'Automotive Skills Development Council (ASDC) EV technician certificates',
        'Skill-Lync / DIYguru EV Powertrain Post-Graduate Programs'
      ],
      certifications: [
        'ISO 26262 Functional Safety Engineer',
        'MATLAB & Simulink Automotive Powertrain Certification'
      ],
      keyEntranceExams: [
        'JEE Main, State CETs, GATE Electrical/Mechanical',
        'State LEET for Diploma holders'
      ]
    },
    coreSkills: {
      technical: ['Battery Management Systems (BMS)', 'MATLAB / Simulink', 'Power Electronics (Inverters/Converters)', 'CAN bus / CANoe', 'Thermal Simulation (ANSYS)', 'Embedded C'],
      soft: ['Safety vigilance under high voltage', 'Root-cause failure analysis', 'Interdisciplinary engineering teamwork']
    },
    starterProjects: [
      'Simulate an EV battery pack discharge curve in MATLAB/Simulink with varying temperature conditions.',
      'Build a simple 3S lithium-ion battery pack with a protection board and monitor individual cell voltages using an Arduino.',
      'Write a CAN bus parser in Python to read mock vehicle speed and battery telemetry.'
    ],
    internshipIdeas: [
      'Battery testing intern at Ather Energy, Ola Electric, or Tata Elxsi.',
      'Powertrain lab intern at an automotive testing agency (ARAI, ICAT).',
      'Electric 2-wheeler conversion mechanic apprentice.'
    ],
    employmentSettings: [
      'EV OEMs (Tata Motors Electric Mobility, Ather Energy, Ola, Mahindra Electric)',
      'Battery Pack & Gigafactory Manufacturers (Exide, Amara Raja, Tata AutoComp)',
      'Automotive Engineering Tier-1 Suppliers (Bosch, Continental, Uno Minda)'
    ],
    salaryIndicative: {
      entryLevelINR: '₹4,00,000 – ₹8,00,000 / year (Diploma: ₹3.2L–₹5.5L) | (B.Tech: ₹6L–₹12L)',
      midCareerINR: '₹15,00,000 – ₹32,00,000 / year',
      notes: 'Specialists in BMS algorithm design and battery safety command significant talent premiums.',
      source: 'Society of Indian Automobile Manufacturers (SIAM) & ASDC Reports',
      updatedDate: 'Q1 2026'
    },
    resources: [
      { title: 'ARAI Automotive Research Association of India', url: 'https://araiindia.com', type: 'official_guide' },
      { title: 'NPTEL Electric Vehicles Course (IIT Madras)', url: 'https://nptel.ac.in', type: 'course' },
      { title: 'ASDC Automotive Skills Council', url: 'https://asdc.org.in', type: 'official_guide' }
    ]
  },

  // 12. Cybersecurity Specialist & Ethical Hacker
  {
    id: 'cybersecurity-ethical-hacker',
    title: 'Cybersecurity Specialist & Ethical Hacker',
    category: 'Technology & Software',
    shortDescription: 'Defends digital networks, discovers system vulnerabilities, and mitigates cyber attacks.',
    fullDescription: 'Cybersecurity Specialists protect national infrastructure, banks, and enterprises from malicious cyber threats. They conduct penetration tests, audit source code for security flaws, configure firewalls, and respond to live security incidents.',
    matchReasons: [
      'Passionate about networking protocols, investigative problem solving, and digital defense.',
      'High demand driven by global privacy regulations and increasing cyber warfare threats.',
      'Certification and skill-heavy industry where hands-on lab proof shines.'
    ],
    strengthsUtilized: [
      'Adversarial thinking (anticipating how an attacker will exploit a weakness)',
      'Deep network protocol analysis (TCP/IP, DNS, TLS)',
      'Rapid incident triage under emergency conditions'
    ],
    skillGapsToAddress: [
      'Linux kernel security and memory exploitation (buffer overflows)',
      'Cloud security architecture in AWS/Azure'
    ],
    typicalResponsibilities: [
      'Execute authorized penetration tests on web apps, mobile apps, and internal networks.',
      'Monitor Security Operations Center (SOC) telemetry using SIEM tools (Splunk, Elastic).',
      'Formulate incident response plans following ransomware or phishing attacks.',
      'Perform static and dynamic application security testing (SAST/DAST) in CI/CD pipelines.'
    ],
    educationPathways: {
      degreeRoutes: [
        'B.Tech / B.E. in Cybersecurity, Computer Science, or Information Technology',
        'BCA / B.Sc in Information Security followed by MCA or M.Tech'
      ],
      diplomaAndLateralRoutes: [
        'Diploma in Computer Engineering / IT -> Lateral B.Tech or Direct Junior SOC Analyst role',
        'Direct junior penetration tester roles via TryHackMe / HackTheBox badges'
      ],
      alternativeVocationalRoutes: [
        'Self-taught bug bounty hunter via HackerOne and Bugcrowd',
        'Certifications-first pathway (CompTIA Security+ -> CEH -> OSCP)'
      ],
      certifications: [
        'CompTIA Security+',
        'Offensive Security Certified Professional (OSCP)',
        'Certified Ethical Hacker (CEH)',
        'Certified Information Systems Security Professional (CISSP)'
      ],
      keyEntranceExams: [
        'JEE Main, State CETs, BITSAT',
        'State LEET for Diploma holders'
      ]
    },
    coreSkills: {
      technical: ['Network Analysis (Wireshark)', 'Penetration Testing (Burp Suite, Metasploit)', 'Python / Bash Scripting', 'Linux Administration', 'SIEM & SOC Tools', 'Cryptography Fundamentals'],
      soft: ['Unshakable ethical standards', 'Cool-headed composure during security breaches', 'Translating technical risks into business impact']
    },
    starterProjects: [
      'Set up a vulnerable virtual lab (Metasploitable) and successfully identify and document 3 vulnerabilities.',
      'Build a port scanner script in Python that identifies open network ports and service versions.',
      'Achieve top 10% ranking on TryHackMe or HackTheBox entry-level rooms.'
    ],
    internshipIdeas: [
      'Junior SOC analyst intern monitoring alerts at a managed security service provider (MSSP).',
      'Vulnerability assessment intern for a fintech startup.',
      'Bug bounty contributor documenting responsible disclosures.'
    ],
    employmentSettings: [
      'Financial Institutions & Banks (HDFC, SBI, ICICI, RBI, Morgan Stanley)',
      'Cybersecurity Consultancies (PwC, EY, Mandiant, CrowdStrike)',
      'National Defense, CERT-In, and Intelligence Agencies'
    ],
    salaryIndicative: {
      entryLevelINR: '₹5,00,000 – ₹11,00,000 / year',
      midCareerINR: '₹18,00,000 – ₹38,00,000 / year (OSCP certified: ₹22L+)',
      notes: 'Certified ethical hackers who discover critical bugs on Bugcrowd/HackerOne earn additional global bounties.',
      source: 'Data Security Council of India (DSCI) & TeamLease Cyber Trends',
      updatedDate: 'Q1 2026'
    },
    resources: [
      { title: 'TryHackMe Cybersecurity Practice Labs', url: 'https://tryhackme.com', type: 'course' },
      { title: 'Hack The Box Training Labs', url: 'https://hackthebox.com', type: 'course' },
      { title: 'OWASP Top 10 Security Vulnerabilities', url: 'https://owasp.org', type: 'official_guide' }
    ]
  }
];
