import { AssessmentQuestion } from '../types';

export const QUESTION_BANK: AssessmentQuestion[] = [
  // ==========================================
  // DIMENSION 1: INTERESTS (Activities, Topics, Curiosity)
  // ==========================================
  {
    id: 'int_01',
    dimension: 'interests',
    applicableStages: 'all',
    type: 'single_choice',
    isRequired: true,
    text: 'When you have free time to learn or explore something on your own, which type of activity draws you in most naturally?',
    contextGuidance: 'Think about what you do when no one is grading you or watching your performance.',
    options: [
      {
        id: 'opt_tech_code',
        label: 'Building apps, playing with automation tools, or exploring computer code and gadgets',
        weights: { tech: 5, analytical: 4, hands_on: 3 },
      },
      {
        id: 'opt_mechanics_making',
        label: 'Tinkering with hardware, physical tools, electronic circuits, or mechanical structures',
        weights: { core_engineering: 5, applied_vocational: 4, hands_on: 5 },
      },
      {
        id: 'opt_biology_health',
        label: 'Understanding how the human body functions, medical breakthroughs, or nature and life sciences',
        weights: { healthcare: 5, sciences: 4, people_social: 3 },
      },
      {
        id: 'opt_markets_finance',
        label: 'Tracking business trends, stock markets, startups, or how companies make money',
        weights: { business_finance: 5, analytical: 4 },
      },
      {
        id: 'opt_design_arts',
        label: 'Sketching, graphic design, editing videos, UI/UX aesthetics, or creative storytelling',
        weights: { design_media: 5, creative: 5 },
      },
      {
        id: 'opt_society_justice',
        label: 'Debating social policies, laws, governance, justice, or how societies are organized',
        weights: { law_policy: 5, people_social: 4 },
      },
    ],
  },
  {
    id: 'int_02',
    dimension: 'interests',
    applicableStages: 'all',
    type: 'rating_scale',
    isRequired: true,
    text: 'Rate your level of excitement for solving complex numerical, logical, or data puzzles.',
    contextGuidance: '1 = I actively dread it; 5 = I find genuine satisfaction when I crack tough logic.',
    options: [
      { id: 'rate_1', label: '1 - Strongly Dislike', weights: { creative: 3, people_social: 2 } },
      { id: 'rate_2', label: '2 - Rather Avoid', weights: { design_media: 2 } },
      { id: 'rate_3', label: '3 - Neutral / Manageable', weights: { applied_vocational: 2 } },
      { id: 'rate_4', label: '4 - Quite Enjoyable', weights: { tech: 3, business_finance: 3, analytical: 4 } },
      { id: 'rate_5', label: '5 - Highly Stimulating', weights: { tech: 5, analytical: 5, core_engineering: 4, sciences: 4 } },
    ],
  },
  {
    id: 'int_03',
    dimension: 'interests',
    applicableStages: 'all',
    type: 'single_choice',
    isRequired: true,
    text: 'Which real-world problem would you feel most proud of dedicating 5 years to solve?',
    contextGuidance: 'This helps identify the intrinsic mission that sustains your energy.',
    options: [
      {
        id: 'opt_clean_tech',
        label: 'Developing renewable energy, electric vehicle motors, or sustainable urban infrastructure',
        weights: { core_engineering: 5, applied_vocational: 4, sciences: 3 },
      },
      {
        id: 'opt_ai_health',
        label: 'Preventing chronic illnesses, improving patient care, or developing targeted therapies',
        weights: { healthcare: 5, sciences: 4, people_social: 3 },
      },
      {
        id: 'opt_cyber_software',
        label: 'Protecting vital digital infrastructure from cyber attacks or building scalable cloud AI systems',
        weights: { tech: 5, analytical: 4 },
      },
      {
        id: 'opt_fin_inclusion',
        label: 'Creating financial systems that help small businesses prosper and build wealth',
        weights: { business_finance: 5, analytical: 3 },
      },
      {
        id: 'opt_legal_rights',
        label: 'Defending fundamental legal rights, crafting fair constitutional policies, or reforming governance',
        weights: { law_policy: 5, people_social: 5 },
      },
      {
        id: 'opt_user_product',
        label: 'Designing intuitive products, interfaces, and experiences that millions enjoy every day',
        weights: { design_media: 5, creative: 4, tech: 3 },
      },
    ],
  },
  {
    id: 'int_04',
    dimension: 'interests',
    applicableStages: ['class_8_9', 'class_10'],
    type: 'single_choice',
    isRequired: true,
    text: 'Looking forward to senior secondary studies, which subject category sounds most appealing to study in depth?',
    contextGuidance: 'Remember: All streams offer reputable, lucrative, and meaningful careers.',
    options: [
      {
        id: 'stream_sci_math',
        label: 'Physics, Chemistry, and Advanced Mathematics (PCM stream)',
        weights: { tech: 4, core_engineering: 5, analytical: 4 },
        indicativeNote: 'Leads to Engineering, Data Science, Architecture, Physical Sciences',
      },
      {
        id: 'stream_sci_bio',
        label: 'Physics, Chemistry, and Biology (PCB stream)',
        weights: { healthcare: 5, sciences: 5 },
        indicativeNote: 'Leads to Medicine, Biotechnology, Pharmacy, Clinical Research',
      },
      {
        id: 'stream_comm',
        label: 'Accountancy, Business Studies, and Economics (Commerce stream)',
        weights: { business_finance: 5, analytical: 3 },
        indicativeNote: 'Leads to CA, Finance, Management, Corporate Law, Entrepreneurship',
      },
      {
        id: 'stream_arts',
        label: 'Psychology, Political Science, Sociology, and Literature (Humanities stream)',
        weights: { law_policy: 4, design_media: 3, people_social: 4 },
        indicativeNote: 'Leads to Law, Civil Services (UPSC), Journalism, Design, Counselling',
      },
      {
        id: 'stream_voc',
        label: 'Applied Computer Applications, Mechatronics, or Applied Design (Vocational / Polytechnic route)',
        weights: { applied_vocational: 5, hands_on: 5, tech: 3 },
        indicativeNote: 'Leads to Polytechnic Diploma, Applied Tech, Skill Degrees',
      },
    ],
  },
  {
    id: 'int_05',
    dimension: 'interests',
    applicableStages: ['diploma'],
    type: 'single_choice',
    isRequired: true,
    text: 'What aspects of your diploma coursework do you find most engaging?',
    contextGuidance: 'Your answer clarifies whether you lean toward direct operational mastery or academic engineering.',
    options: [
      {
        id: 'dip_lab_practical',
        label: 'Workshop machinery, lab experiments, wiring/circuits, or physical drafting (Hands-on)',
        weights: { applied_vocational: 5, core_engineering: 4, hands_on: 5 },
      },
      {
        id: 'dip_software_cad',
        label: 'Software modeling, CAD/CAM drafting, PLC programming, or web/code modules',
        weights: { tech: 4, core_engineering: 4, analytical: 3 },
      },
      {
        id: 'dip_site_management',
        label: 'Project site management, vendor coordination, cost estimation, and quality assurance',
        weights: { business_finance: 3, applied_vocational: 4, people_social: 3 },
      },
      {
        id: 'dip_higher_theory',
        label: 'Advanced mathematical formulas, thermodynamic/computational theory, and R&D papers',
        weights: { core_engineering: 5, analytical: 4, sciences: 3 },
      },
    ],
  },
  {
    id: 'int_06',
    dimension: 'interests',
    applicableStages: ['undergraduate', 'postgraduate', 'working_professional'],
    type: 'single_choice',
    isRequired: true,
    text: 'At this stage in your journey, what kind of work output makes you feel most satisfied?',
    contextGuidance: 'Focus on the actual deliverable you take pride in.',
    options: [
      {
        id: 'out_code_system',
        label: 'Deploying a reliable, clean codebase or automated architecture that works smoothly',
        weights: { tech: 5, analytical: 4 },
      },
      {
        id: 'out_pnl_strategy',
        label: 'Delivering a financial model, marketing growth campaign, or strategic business deck',
        weights: { business_finance: 5, people_social: 3 },
      },
      {
        id: 'out_hardware_prod',
        label: 'Seeing a physical product, machine prototype, or civil structure stand completed',
        weights: { core_engineering: 5, hands_on: 5 },
      },
      {
        id: 'out_human_impact',
        label: 'Directly mentoring, healing, diagnosing, or resolving an acute crisis for a human being',
        weights: { healthcare: 5, people_social: 5, law_policy: 3 },
      },
      {
        id: 'out_visual_delight',
        label: 'Publishing a beautifully crafted user interface, motion graphic, or product design',
        weights: { design_media: 5, creative: 5 },
      },
    ],
  },

  // ==========================================
  // DIMENSION 2: STRENGTHS & APTITUDE (Logic, Problem Solving, Reasoning)
  // ==========================================
  {
    id: 'apt_01',
    dimension: 'strengths_aptitude',
    applicableStages: 'all',
    type: 'scenario',
    isObjectiveReasoning: true,
    isRequired: true,
    text: 'Logic Exercise: A manufacturing plant needs to inspect 3 machines (X, Y, Z). Machine X fails every 4 hours. Machine Y fails every 6 hours. Machine Z fails every 9 hours. If all 3 are repaired at 12:00 PM today, after how many hours will all 3 fail simultaneously again?',
    contextGuidance: 'This tests foundational quantitative reasoning (Least Common Multiple). Take your time to calculate.',
    options: [
      { id: 'math_24', label: '24 hours', weights: { analytical: 1 } },
      { id: 'math_36', label: '36 hours (Correct: LCM of 4, 6, 9 is 36)', weights: { analytical: 5, tech: 4, core_engineering: 4 } },
      { id: 'math_72', label: '72 hours', weights: { analytical: 2 } },
      { id: 'math_108', label: '108 hours', weights: { analytical: 1 } },
      { id: 'math_skip', label: 'I prefer not to calculate / unsure', weights: { creative: 2, people_social: 2 } },
    ],
  },
  {
    id: 'apt_02',
    dimension: 'strengths_aptitude',
    applicableStages: 'all',
    type: 'scenario',
    isObjectiveReasoning: true,
    isRequired: true,
    text: 'Critical Thinking Scenario: A mobile app experiences an unexpected 20% drop in active users following a major feature launch. What is the most rigorous first step?',
    contextGuidance: 'This tests scientific diagnostic thinking versus jumping to hasty conclusions.',
    options: [
      {
        id: 'diag_rollback',
        label: 'Immediately roll back all new code without checking user analytics logs',
        weights: { applied_vocational: 1 },
      },
      {
        id: 'diag_segment',
        label: 'Segment the drop by device type, app version, and crash logs to isolate whether the root cause is technical or behavioral',
        weights: { analytical: 5, tech: 4, business_finance: 3 },
      },
      {
        id: 'diag_discount',
        label: 'Offer instant discount coupons to win users back before finding the issue',
        weights: { business_finance: 2 },
      },
      {
        id: 'diag_poll',
        label: 'Blame user resistance to change and wait 30 days before taking any action',
        weights: { people_social: 1 },
      },
    ],
  },
  {
    id: 'apt_03',
    dimension: 'strengths_aptitude',
    applicableStages: 'all',
    type: 'single_choice',
    isRequired: true,
    text: 'When learning a complicated new concept, which ability comes most easily to you?',
    contextGuidance: 'Be candid about your natural cognitive style.',
    options: [
      {
        id: 'str_mental_models',
        label: 'Breaking down abstract logic, equations, and algorithmic flows in my head',
        weights: { analytical: 5, tech: 4, sciences: 3 },
      },
      {
        id: 'str_verbal_persuasion',
        label: 'Explaining ideas persuasively, writing clearly, and engaging others verbally',
        weights: { people_social: 5, law_policy: 4, business_finance: 3 },
      },
      {
        id: 'str_visual_spatial',
        label: 'Visualizing 3D structures, color harmony, layouts, and spatial arrangements',
        weights: { design_media: 5, core_engineering: 3, creative: 4 },
      },
      {
        id: 'str_tactile_fixing',
        label: 'Using my hands to assemble, fix, tune, or construct tangible objects',
        weights: { hands_on: 5, applied_vocational: 5, core_engineering: 3 },
      },
      {
        id: 'str_empathy_listening',
        label: 'Reading people’s emotions, resolving team conflicts, and active listening',
        weights: { people_social: 5, healthcare: 4 },
      },
    ],
  },
  {
    id: 'apt_04',
    dimension: 'strengths_aptitude',
    applicableStages: 'all',
    type: 'rating_scale',
    isRequired: true,
    text: 'How comfortable are you with interpreting charts, statistical graphs, and financial balance tables?',
    contextGuidance: '1 = Confusing and unappealing; 5 = Very clear, I spot trends instantly.',
    options: [
      { id: 'data_1', label: '1 - Low comfort', weights: { creative: 2 } },
      { id: 'data_2', label: '2 - Basic comfort', weights: { design_media: 2 } },
      { id: 'data_3', label: '3 - Moderate comfort', weights: { applied_vocational: 2 } },
      { id: 'data_4', label: '4 - Strong comfort', weights: { analytical: 3, tech: 3, business_finance: 4 } },
      { id: 'data_5', label: '5 - Exceptional comfort', weights: { analytical: 5, business_finance: 5, tech: 4, sciences: 4 } },
    ],
  },
  {
    id: 'apt_05',
    dimension: 'strengths_aptitude',
    applicableStages: 'all',
    type: 'single_choice',
    isRequired: true,
    text: 'When faced with an open-ended project with very few instructions, what is your instinctive approach?',
    contextGuidance: 'Highlights your self-regulation and problem structure preference.',
    options: [
      {
        id: 'app_research_outline',
        label: 'Draft a structured project roadmap, timeline, and objective milestones first',
        weights: { analytical: 4, business_finance: 4 },
      },
      {
        id: 'app_tinker_prototype',
        label: 'Start experimenting immediately with a messy prototype to see what works',
        weights: { creative: 4, tech: 3, applied_vocational: 4, hands_on: 4 },
      },
      {
        id: 'app_collaborate_talk',
        label: 'Talk to peers, mentors, or potential users to understand different viewpoints',
        weights: { people_social: 5, design_media: 3 },
      },
      {
        id: 'app_deep_literature',
        label: 'Read research papers, documentation, or books to understand foundational principles',
        weights: { sciences: 5, law_policy: 4, analytical: 3 },
      },
    ],
  },

  // ==========================================
  // DIMENSION 3: WORK PREFERENCES (Environments, Collaboration, Structure)
  // ==========================================
  {
    id: 'work_01',
    dimension: 'work_preferences',
    applicableStages: 'all',
    type: 'single_choice',
    isRequired: true,
    text: 'What physical and operational work setting would help you do your best work?',
    contextGuidance: 'Consider where you want to spend 40+ hours each week.',
    options: [
      {
        id: 'env_desk_digital',
        label: 'A modern computer workstation with high flexibility (office, remote, or hybrid)',
        weights: { tech: 5, design_media: 4, business_finance: 3 },
      },
      {
        id: 'env_field_workshop',
        label: 'Industrial plant floor, construction site, hardware laboratory, or field setting',
        weights: { core_engineering: 5, applied_vocational: 5, hands_on: 5 },
      },
      {
        id: 'env_clinic_lab',
        label: 'Hospital ward, diagnostic clinic, or biological research laboratory',
        weights: { healthcare: 5, sciences: 4 },
      },
      {
        id: 'env_court_boardroom',
        label: 'Boardrooms, courtrooms, government secretariat, or public forums',
        weights: { law_policy: 5, business_finance: 4, people_social: 4 },
      },
      {
        id: 'env_creative_studio',
        label: 'Design studio, multimedia editing suite, or collaborative creative workshop',
        weights: { design_media: 5, creative: 5 },
      },
    ],
  },
  {
    id: 'work_02',
    dimension: 'work_preferences',
    applicableStages: 'all',
    type: 'single_choice',
    isRequired: true,
    text: 'Between solo deep focus and frequent team collaboration, where is your sweet spot?',
    contextGuidance: 'Both styles are vital; this helps match the day-to-day rhythm of different roles.',
    options: [
      {
        id: 'collab_mostly_solo',
        label: '70%+ independent deep work; I produce best when uninterrupted for hours',
        weights: { tech: 4, analytical: 4, sciences: 4 },
      },
      {
        id: 'collab_balanced',
        label: '50/50 balance between solo focus and structured team sprint syncs',
        weights: { design_media: 3, core_engineering: 3, business_finance: 3 },
      },
      {
        id: 'collab_people_heavy',
        label: '70%+ dynamic interaction: client discussions, meetings, negotiations, and mentoring',
        weights: { people_social: 5, business_finance: 4, law_policy: 4, healthcare: 3 },
      },
    ],
  },
  {
    id: 'work_03',
    dimension: 'work_preferences',
    applicableStages: 'all',
    type: 'rating_scale',
    isRequired: true,
    text: 'How well do you handle tasks that change rapidly every few weeks versus predictable, stable routines?',
    contextGuidance: '1 = Prefer highly predictable tasks; 5 = Thrive in fast-paced, evolving environments.',
    options: [
      { id: 'stab_1', label: '1 - Strict predictability', weights: { applied_vocational: 3 } },
      { id: 'stab_2', label: '2 - Mostly stable', weights: { law_policy: 2, core_engineering: 2 } },
      { id: 'stab_3', label: '3 - Moderate adaptability', weights: { healthcare: 2, business_finance: 2 } },
      { id: 'stab_4', label: '4 - High flexibility', weights: { tech: 3, design_media: 3 } },
      { id: 'stab_5', label: '5 - Thrives in rapid iteration', weights: { tech: 5, business_finance: 4, creative: 4 } },
    ],
  },
  {
    id: 'work_04',
    dimension: 'work_preferences',
    applicableStages: 'all',
    type: 'single_choice',
    isRequired: true,
    text: 'In group assignments or collaborative efforts, which role do you naturally step into?',
    contextGuidance: 'Reflects your natural operational leadership style.',
    options: [
      {
        id: 'role_architect_tech',
        label: 'The Technical Problem-Solver: I figure out the toughest calculation or code logic',
        weights: { tech: 4, core_engineering: 4, analytical: 4 },
      },
      {
        id: 'role_organizer_leader',
        label: 'The Coordinator / Captain: I set deadlines, assign roles, and keep everyone aligned',
        weights: { business_finance: 5, people_social: 4 },
      },
      {
        id: 'role_presenter',
        label: 'The Storyteller / Presenter: I craft the slide deck, deliver the pitch, and persuade',
        weights: { design_media: 4, law_policy: 4, people_social: 4 },
      },
      {
        id: 'role_researcher_fact',
        label: 'The Fact-Checker: I dig into the background data to ensure our solution is sound',
        weights: { sciences: 4, analytical: 4, law_policy: 3 },
      },
      {
        id: 'role_hands_on_maker',
        label: 'The Builder: I build the physical model, wiring, or practical demo artifact',
        weights: { hands_on: 5, applied_vocational: 4, core_engineering: 3 },
      },
    ],
  },

  // ==========================================
  // DIMENSION 4: VALUES & MOTIVATORS (Impact, Wealth, Stability, Autonomy)
  // ==========================================
  {
    id: 'val_01',
    dimension: 'values_motivators',
    applicableStages: 'all',
    type: 'single_choice',
    isRequired: true,
    text: 'When you picture your ideal career 10 years from now, what is your top non-negotiable value?',
    contextGuidance: 'Be truthful. Different individuals have different life priorities.',
    options: [
      {
        id: 'val_high_income',
        label: 'High financial reward, wealth creation, and rapid economic advancement',
        weights: { business_finance: 5, tech: 4 },
      },
      {
        id: 'val_social_impact',
        label: 'Directly helping underserved people, saving lives, or making society more equitable',
        weights: { healthcare: 5, law_policy: 5, people_social: 5 },
      },
      {
        id: 'val_intellectual_mastery',
        label: 'Continuous scientific discovery, mastery over complex systems, and intellectual growth',
        weights: { sciences: 5, tech: 4, core_engineering: 4 },
      },
      {
        id: 'val_stability_security',
        label: 'Job security, predictable hours, reliable pensions, and low corporate volatility',
        weights: { core_engineering: 3, applied_vocational: 4, law_policy: 3 },
      },
      {
        id: 'val_creative_expression',
        label: 'Creative autonomy, aesthetic beauty, and freedom from rigid corporate bureaucracy',
        weights: { design_media: 5, creative: 5 },
      },
    ],
  },
  {
    id: 'val_02',
    dimension: 'values_motivators',
    applicableStages: 'all',
    type: 'rating_scale',
    isRequired: true,
    text: 'How important is achieving public prestige, social recognition, or leadership authority to you?',
    contextGuidance: '1 = Completely indifferent, prefer quiet competence; 5 = A major personal driver.',
    options: [
      { id: 'prestige_1', label: '1 - Prefer quiet focus', weights: { tech: 2, sciences: 3 } },
      { id: 'prestige_2', label: '2 - Minor factor', weights: { applied_vocational: 2 } },
      { id: 'prestige_3', label: '3 - Moderate value', weights: { core_engineering: 2 } },
      { id: 'prestige_4', label: '4 - Important motivator', weights: { business_finance: 3, law_policy: 3 } },
      { id: 'prestige_5', label: '5 - Key life objective', weights: { law_policy: 5, business_finance: 5, people_social: 4 } },
    ],
  },
  {
    id: 'val_03',
    dimension: 'values_motivators',
    applicableStages: 'all',
    type: 'single_choice',
    isRequired: true,
    text: 'How do you view taking calculated risks (e.g. startup ventures, freelance commissions, commissioned sales)?',
    contextGuidance: 'Assesses appetite for uncertainty versus stable salaried tracks.',
    options: [
      {
        id: 'risk_avoidant',
        label: 'I strongly prefer guaranteed steady compensation and established corporate/govt ladders',
        weights: { core_engineering: 3, applied_vocational: 4, healthcare: 3 },
      },
      {
        id: 'risk_moderate',
        label: 'I want a stable base salary with performance bonuses or stock equity incentives',
        weights: { tech: 4, business_finance: 4 },
      },
      {
        id: 'risk_embrace',
        label: 'I welcome high uncertainty if there is substantial upside, independence, and equity ownership',
        weights: { business_finance: 5, creative: 4, tech: 4 },
      },
    ],
  },

  // ==========================================
  // DIMENSION 5: LEARNING PREFERENCES (Pedagogy, Building, Reading)
  // ==========================================
  {
    id: 'lrn_01',
    dimension: 'learning_preferences',
    applicableStages: 'all',
    type: 'single_choice',
    isRequired: true,
    text: 'How do you retain difficult technical knowledge most permanently?',
    contextGuidance: 'Shows whether practice-oriented or book-oriented career paths match your learning pace.',
    options: [
      {
        id: 'lrn_building_hands_on',
        label: 'By building an actual project or working prototype from scratch (Project-Based)',
        weights: { tech: 5, applied_vocational: 5, core_engineering: 4, hands_on: 5 },
      },
      {
        id: 'lrn_textbooks_theory',
        label: 'By reading textbooks, whitepapers, academic proofs, and analyzing principles (Deductive)',
        weights: { sciences: 5, analytical: 4, law_policy: 4 },
      },
      {
        id: 'lrn_discussion_debates',
        label: 'By debating case studies, asking questions, and discussing with peers (Interactive)',
        weights: { law_policy: 4, business_finance: 4, people_social: 4 },
      },
      {
        id: 'lrn_visual_flowcharts',
        label: 'By studying visual diagrams, mind maps, infographics, and design demos (Visual)',
        weights: { design_media: 5, creative: 4 },
      },
    ],
  },
  {
    id: 'lrn_02',
    dimension: 'learning_preferences',
    applicableStages: 'all',
    type: 'rating_scale',
    isRequired: true,
    text: 'Rate your willingness to engage in continuous self-study throughout your career (even after graduating).',
    contextGuidance: 'Some careers (like tech or medical research) require constant reskilling every 18 months.',
    options: [
      { id: 'reskill_1', label: '1 - Prefer skills that remain fixed for life', weights: { applied_vocational: 2 } },
      { id: 'reskill_2', label: '2 - Occasional updates are okay', weights: { core_engineering: 2 } },
      { id: 'reskill_3', label: '3 - Moderate willingness to adapt', weights: { business_finance: 3 } },
      { id: 'reskill_4', label: '4 - Enthusiastic about regular updates', weights: { healthcare: 4, law_policy: 3 } },
      { id: 'reskill_5', label: '5 - Relish rapid evolution and constant new tools', weights: { tech: 5, sciences: 5, analytical: 4 } },
    ],
  },

  // ==========================================
  // DIMENSION 6: CAREER & EDUCATION PREFERENCES (Durations, Exams, Budget)
  // ==========================================
  {
    id: 'pref_01',
    dimension: 'career_education_preferences',
    applicableStages: 'all',
    type: 'single_choice',
    isRequired: true,
    text: 'What is your preferred educational timeline before entering full-time employment?',
    contextGuidance: 'Ensures we suggest paths that respect your personal and financial timeline.',
    options: [
      {
        id: 'dur_fast_diploma',
        label: 'Fastest route (1 to 3 years): Polytechnic Diploma, vocational certificate, or quick skill bootcamp',
        weights: { applied_vocational: 5, hands_on: 4 },
      },
      {
        id: 'dur_standard_degree',
        label: 'Standard Bachelor’s Degree (3 to 4 years): B.Tech, B.Sc, B.Com, BBA, B.Des, or BCA',
        weights: { tech: 4, core_engineering: 4, business_finance: 4, design_media: 4 },
      },
      {
        id: 'dur_long_postgrad',
        label: 'Long-term rigorous training (5 to 8+ years): Medicine (MBBS+MD), Ph.D., CA, or Dual Degrees',
        weights: { healthcare: 5, sciences: 5, law_policy: 4, business_finance: 3 },
      },
      {
        id: 'dur_lateral_or_work',
        label: 'Work immediately while pursuing distance/evening degree or lateral entry progression',
        weights: { applied_vocational: 4, tech: 3 },
      },
    ],
  },
  {
    id: 'pref_02',
    dimension: 'career_education_preferences',
    applicableStages: ['class_10', 'class_11_12', 'diploma'],
    type: 'single_choice',
    isRequired: true,
    text: 'How do you view intense national entrance examinations (e.g., JEE, NEET, CUET, CLAT, LEET)?',
    contextGuidance: 'Exam preferences help us balance high-stakes versus merit/portfolio-based entry options.',
    options: [
      {
        id: 'exam_all_in',
        label: 'I am ready to dedicate 1–2 years of intensive coaching for competitive entrance exams',
        weights: { core_engineering: 4, healthcare: 4, law_policy: 3 },
      },
      {
        id: 'exam_selective',
        label: 'I will write select exams (CUET / State CET / LEET) without putting all eggs in one basket',
        weights: { business_finance: 4, tech: 3, applied_vocational: 3 },
      },
      {
        id: 'exam_portfolio_first',
        label: 'I prefer admissions based on school merit, personal portfolios, design tests (e.g. UCEED), or interview rounds',
        weights: { design_media: 5, creative: 4, business_finance: 3 },
      },
      {
        id: 'exam_direct_practical',
        label: 'I prioritize direct skill certifications, diploma lateral entry, or practical vocational tests',
        weights: { applied_vocational: 5, hands_on: 4 },
      },
    ],
  },
  {
    id: 'pref_03',
    dimension: 'career_education_preferences',
    applicableStages: 'all',
    type: 'single_choice',
    isRequired: true,
    text: 'What is your primary approach to higher education costs and financial return on investment (ROI)?',
    contextGuidance: 'Helps ensure recommendations present realistic pathways.',
    options: [
      {
        id: 'bud_low_cost_govt',
        label: 'Priority on affordable government institutions, polytechnics, state universities, or scholarships',
        weights: { applied_vocational: 4, core_engineering: 3 },
      },
      {
        id: 'bud_moderate_balanced',
        label: 'Moderate budget; open to education loans if placement records justify the expense',
        weights: { tech: 3, business_finance: 3, core_engineering: 3 },
      },
      {
        id: 'bud_flexible_premium',
        label: 'Flexible; willing to invest in premium private universities, specialized design institutes, or study abroad',
        weights: { design_media: 4, business_finance: 4, tech: 3 },
      },
    ],
  },

  // ==========================================
  // DIMENSION 7: CAREER READINESS & EXPOSURE (Confidence, Gaps, Goals)
  // ==========================================
  {
    id: 'read_01',
    dimension: 'career_readiness',
    applicableStages: 'all',
    type: 'single_choice',
    isRequired: true,
    text: 'How clear do you currently feel about your next 3-year educational or career decisions?',
    contextGuidance: 'Assessing your readiness ensures we provide appropriately scoped guidance.',
    options: [
      {
        id: 'read_foggy',
        label: 'Completely uncertain; I feel overwhelmed by too many choices and conflicting family advice',
        weights: { people_social: 1 },
      },
      {
        id: 'read_between_two',
        label: 'Torn between 2 or 3 distinct fields (e.g. engineering vs design, or job vs higher degree)',
        weights: { analytical: 2 },
      },
      {
        id: 'read_clear_target',
        label: 'I have a clear goal in mind, but I need a step-by-step roadmap and backup strategy',
        weights: { analytical: 3 },
      },
      {
        id: 'read_upskilling',
        label: 'I know my target domain; I need specific skill gap analysis and portfolio guidance',
        weights: { tech: 2, applied_vocational: 2 },
      },
    ],
  },
  {
    id: 'read_02',
    dimension: 'career_readiness',
    applicableStages: 'all',
    type: 'rating_scale',
    isRequired: true,
    text: 'Rate your confidence in explaining your top 3 personal strengths to a prospective interviewer or mentor.',
    contextGuidance: '1 = Very unconfident; 5 = Highly confident with specific real-world examples.',
    options: [
      { id: 'conf_1', label: '1 - Low confidence', weights: {} },
      { id: 'conf_2', label: '2 - Developing', weights: {} },
      { id: 'conf_3', label: '3 - Moderate', weights: {} },
      { id: 'conf_4', label: '4 - Good', weights: { people_social: 2 } },
      { id: 'conf_5', label: '5 - High clarity and confidence', weights: { people_social: 4, business_finance: 3 } },
    ],
  },
  {
    id: 'read_03',
    dimension: 'career_readiness',
    applicableStages: ['undergraduate', 'postgraduate', 'working_professional'],
    type: 'single_choice',
    isRequired: true,
    text: 'What do you consider your biggest bottleneck right now?',
    contextGuidance: 'Helps our scoring and roadmap modules suggest high-impact interventions.',
    options: [
      {
        id: 'bot_portfolio_projects',
        label: 'Lack of tangible proof-of-work (GitHub repo, design portfolio, or case study)',
        weights: { tech: 2, design_media: 2 },
      },
      {
        id: 'bot_networking_mentors',
        label: 'No industry network, alumni mentors, or referrals in my target sector',
        weights: { business_finance: 2, people_social: 2 },
      },
      {
        id: 'bot_interview_aptitude',
        label: 'Clearing technical screening interviews, coding rounds, or domain tests',
        weights: { analytical: 3, tech: 2 },
      },
      {
        id: 'bot_degree_prestige',
        label: 'My college brand or past academic marks may limit initial resume screening',
        weights: { applied_vocational: 2, tech: 2 },
      },
    ],
  },
];
