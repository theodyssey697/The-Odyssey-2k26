import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  sendEmailVerification,
  User,
} from 'firebase/auth';
import { auth } from './firebase';

export interface AuthErrorResponse {
  message: string;
  code?: string;
}

export class EmailNotVerifiedError extends Error {
  email: string;
  constructor(email: string) {
    super(`We have sent you a verification email to ${email}. Please verify it and log in.`);
    this.name = 'EmailNotVerifiedError';
    this.email = email;
  }
}

export const authService = {
  // Sign in using email and password
  async signIn(email: string, password: string): Promise<User> {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email.trim(), password);
      const user = userCredential.user;

      // Check if user email is verified
      if (!user.emailVerified) {
        // Block access immediately: sign out
        await firebaseSignOut(auth);
        throw new EmailNotVerifiedError(user.email || email.trim());
      }

      return user;
    } catch (error: any) {
      if (error instanceof EmailNotVerifiedError) {
        throw error;
      }

      console.warn('Firebase Sign-In Error:', error?.code, error?.message);
      const code = error?.code || '';

      // Exact requirement: If credentials are incorrect, show: "Email or password is incorrect"
      if (
        code === 'auth/invalid-credential' ||
        code === 'auth/wrong-password' ||
        code === 'auth/user-not-found' ||
        code === 'auth/invalid-email'
      ) {
        throw new Error('Email or password is incorrect');
      }

      if (code === 'auth/too-many-requests') {
        throw new Error('Too many failed attempts. Please try again later.');
      }

      // Default safe fallback for incorrect credentials
      throw new Error('Email or password is incorrect');
    }
  },

  // Sign up using email and password
  // Requirement:
  // - When a user registers with email/password, do not sign them in automatically.
  // - Send a verification email and show a verification screen
  // - Firebase Authentication only
  async signUp(email: string, password: string): Promise<{ email: string }> {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email.trim(), password);
      const user = userCredential.user;

      // Send verification email via Firebase Auth
      try {
        await sendEmailVerification(user);
      } catch (sendError) {
        console.warn('sendEmailVerification notice:', sendError);
      }

      // Requirement: Do not sign them in automatically - sign out immediately
      await firebaseSignOut(auth);

      return { email: user.email || email.trim() };
    } catch (error: any) {
      console.warn('Firebase Sign-Up Error:', error?.code, error?.message);
      const code = error?.code || '';

      // Exact requirement: If the email already exists, show: "User already exists. Please sign in"
      if (code === 'auth/email-already-in-use') {
        throw new Error('User already exists. Please sign in');
      }

      if (code === 'auth/weak-password') {
        throw new Error('Password should be at least 6 characters.');
      }

      if (code === 'auth/invalid-email') {
        throw new Error('Please enter a valid email address.');
      }

      throw new Error(error?.message || 'Failed to create account. Please try again.');
    }
  },

  // Resend verification email helper
  async resendVerification(email: string, password?: string): Promise<void> {
    if (!password) {
      throw new Error('Password is required to resend verification link.');
    }
    const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
    if (!cred.user.emailVerified) {
      await sendEmailVerification(cred.user);
    }
    await firebaseSignOut(auth);
  },

  // Log out current user
  async logOut(): Promise<void> {
    try {
      await firebaseSignOut(auth);
    } catch (error: any) {
      console.error('Firebase Sign-Out Error:', error);
      throw error;
    }
  },

  // Get current user (only if verified)
  getCurrentUser(): User | null {
    const user = auth.currentUser;
    if (user && !user.emailVerified) {
      return null;
    }
    return user;
  },

  // Listen to auth state changes
  onAuthChange(callback: (user: User | null) => void) {
    return onAuthStateChanged(auth, (user) => {
      if (user && !user.emailVerified) {
        callback(null);
      } else {
        callback(user);
      }
    });
  },
};
