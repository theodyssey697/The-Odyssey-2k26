import { ChatMessage, StudentProfile, AssessmentResult, CareerRoadmap } from '../types';

export const N8N_CHAT_WEBHOOK_URL =
  'https://punitbehera.app.n8n.cloud/webhook/13b3635b-45d2-4454-8d06-e6fabdf1184a/chat';

export interface N8nChatResult {
  reply: string;
  rawResponse?: any;
}

export const mentorService = {
  // Call n8n Cloud Workflow
  async sendN8nMessage(
    chatInput: string,
    sessionId: string,
    studentProfile?: StudentProfile
  ): Promise<N8nChatResult> {
    const profile_context = studentProfile
      ? `Name: ${studentProfile.name}, Stage: ${studentProfile.stage}, Details: ${JSON.stringify(studentProfile.stageDetails)}, Goals: ${studentProfile.careerGoals}, Preferred Subjects: ${studentProfile.favoriteSubjects.join(', ')}, Location/Budget: ${studentProfile.locationPreference} (${studentProfile.budgetConsideration})`
      : 'General student profile';

    const payload = {
      action: 'sendMessage',
      chatInput,
      message: chatInput,
      sessionId,
      retrieved_context:
        'PathPilot AI Verified Knowledge Base: Robotics & Mechatronics (Accessible via 3-yr Diploma + LEET 2nd-year B.Tech lateral entry, NATS apprenticeships, SSC JE), AI/ML Engineering (B.Tech/B.Sc + GATE/CUET), Full Stack Cloud (B.Tech/BCA/MCA), UI/UX Product Design (B.Des/UCEED/NID/Portfolios), Chartered Accountancy (ICAI Foundation/Direct Entry), Corporate Law (CLAT 5-yr LLB), MBBS Clinical Medicine (NEET UG), EV Powertrains (Diploma/B.Tech). All match scores are indicative profile-fit estimates, not guarantees.',
      profile_context,
      metadata: studentProfile
        ? {
            studentName: studentProfile.name,
            stage: studentProfile.stage,
            stageDetails: studentProfile.stageDetails,
            careerGoals: studentProfile.careerGoals,
          }
        : undefined,
    };

    // Attempt 1: Call through backend proxy to bypass any CORS restrictions
    try {
      const response = await fetch('/api/n8n-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        const data = await response.json();
        const reply =
          data.output ||
          data.text ||
          data.message ||
          data.response ||
          (Array.isArray(data) && data[0]?.output) ||
          (typeof data === 'string' ? data : JSON.stringify(data));

        return { reply, rawResponse: data };
      }
    } catch (err) {
      console.warn('Proxy /api/n8n-chat failed, attempting direct webhook call:', err);
    }

    // Attempt 2: Direct call to n8n webhook URL
    const directResponse = await fetch(N8N_CHAT_WEBHOOK_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Instance-Id': 'd70f1f0ca3899125dc77338b7c4b9adea0e21ea8061c2071ef92425af384628e',
      },
      body: JSON.stringify(payload),
    });

    if (!directResponse.ok) {
      const errText = await directResponse.text().catch(() => '');
      throw new Error(
        `n8n Cloud Webhook error (HTTP ${directResponse.status}): ${errText || 'Workflow did not return a 200 response'}`
      );
    }

    const directData = await directResponse.json();
    const reply =
      directData.output ||
      directData.text ||
      directData.message ||
      directData.response ||
      (Array.isArray(directData) && directData[0]?.output) ||
      (typeof directData === 'string' ? directData : JSON.stringify(directData));

    return { reply, rawResponse: directData };
  },

  // Existing Gemini AI endpoint (preserved)
  async sendMessage(
    message: string,
    history: ChatMessage[],
    studentProfile: StudentProfile,
    assessmentSummary?: AssessmentResult | null,
    currentRoadmap?: CareerRoadmap | null
  ): Promise<{ reply: string; source: string; suggestedFollowUps?: string[] }> {
    try {
      const response = await fetch('/api/mentor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message,
          history: history.slice(-6).map((m) => ({ role: m.role, content: m.content })),
          studentProfile,
          assessmentSummary: assessmentSummary
            ? {
                topCareers: assessmentSummary.topCareers.slice(0, 3).map((c) => ({
                  title: c.title,
                  fitScore: c.fitScore,
                  category: c.category,
                })),
                scores: assessmentSummary.dimensionScores,
              }
            : null,
          currentRoadmap: currentRoadmap
            ? {
                careerTitle: currentRoadmap.careerTitle,
                progress: calculateRoadmapProgress(currentRoadmap),
              }
            : null,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();
      return {
        reply: data.reply,
        source: data.source || 'gemini-3.8-flash',
        suggestedFollowUps: generateDynamicFollowUps(message, studentProfile),
      };
    } catch (err) {
      console.warn('API call to /api/mentor failed, using client fallback:', err);
      return {
        reply: getClientFallbackReply(message, studentProfile),
        source: 'client-offline-counselor',
        suggestedFollowUps: [
          'What are the key entrance exams for this path?',
          'What starter projects should I build first?',
          'Can you compare this with another career?',
        ],
      };
    }
  },

  async generateReportNarrative(
    studentProfile: StudentProfile,
    topCareers: any[],
    scores: any
  ): Promise<string> {
    try {
      const response = await fetch('/api/generate-insights', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ studentProfile, topCareers, scores }),
      });
      if (response.ok) {
        const data = await response.json();
        if (data.narrative) return data.narrative;
      }
    } catch (e) {
      console.warn('Error fetching report insights:', e);
    }

    return `Your evaluation indicates distinctive strengths in analytical reasoning and goal-oriented exploration. For your current stage (${studentProfile.stage}), your alignment with ${topCareers[0]?.title || 'Technology & Engineering'} suggests significant potential when paired with hands-on projects and consistent foundational practice over the next 90 days.`;
  },
};

function calculateRoadmapProgress(roadmap: CareerRoadmap): number {
  let total = 0;
  let done = 0;
  roadmap.phases.forEach((p) => {
    p.tasks.forEach((t) => {
      total++;
      if (t.completed) done++;
    });
  });
  return total > 0 ? Math.round((done / total) * 100) : 0;
}

function generateDynamicFollowUps(query: string, profile: StudentProfile): string[] {
  const q = query.toLowerCase();
  if (q.includes('diploma') || profile.stage === 'diploma') {
    return [
      'What are the eligibility marks for LEET B.Tech entry?',
      'Which private vs government companies hire diploma freshers?',
    ];
  }
  if (q.includes('exam') || q.includes('jee') || q.includes('neet')) {
    return [
      'What are the best backup degrees if exam scores are average?',
      'How to balance board exams with entrance exam preparation?',
    ];
  }
  return [
    'What skills should I prioritize in my first 30 days?',
    'What does a typical day look like in this career?',
  ];
}

function getClientFallbackReply(message: string, profile: StudentProfile): string {
  const name = profile.name || 'Friend';
  const stage = profile.stage;
  const q = message.toLowerCase();

  if (stage === 'diploma' || q.includes('diploma')) {
    return `Hello ${name}! As a Diploma student, you are in a great position because industry values practical laboratory and workshop fluency.

Key pathways to evaluate:
1. **Lateral Entry to 2nd Year B.Tech (LEET):** Allows you to complete your B.Tech in 3 years with engineering peers.
2. **Core Industry Apprentice (NATS):** Direct hands-on roles at automotive, automation, and electronics manufacturing facilities.
3. **Junior Engineer (SSC JE / RRB JE / State Electricity Boards):** Highly respected public sector employment with job stability.

Would you like advice on preparing for lateral entrance exams or creating a technical project portfolio?`;
  }

  return `Hello ${name}! Thank you for your question. As you navigate your career path from your stage (${stage}), remember that top career decisions are built on three pillars:

1. **Demonstrated Interest:** Doing real mini-projects to test whether you enjoy the daily work.
2. **Clear Educational Gateways:** Knowing the exact entrance exams, degree, or lateral routes needed.
3. **Market Relevance:** Understanding industry demand and building verified skills.

Take a look at your customized roadmap and let me know which area you'd like to explore in detail!`;
}
