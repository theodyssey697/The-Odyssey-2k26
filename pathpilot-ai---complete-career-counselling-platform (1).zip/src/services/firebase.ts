import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getAnalytics, isSupported } from 'firebase/analytics';

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDtxmkbIpynTuNtkvQDyEv8H5xD7EqaZc4",
  authDomain: "roomora-9ef5f.firebaseapp.com",
  projectId: "roomora-9ef5f",
  storageBucket: "roomora-9ef5f.firebasestorage.app",
  messagingSenderId: "1097578930143",
  appId: "1:1097578930143:web:8a1fd3822042c1f87aee6a",
  measurementId: "G-TLBVGK7822"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);

// Initialize Firebase Authentication only (no Firestore or Storage as requested)
export const auth = getAuth(app);

// Initialize Analytics conditionally in browser environment
if (typeof window !== 'undefined') {
  isSupported().then((supported) => {
    if (supported) {
      try {
        getAnalytics(app);
      } catch (err) {
        console.debug('Firebase Analytics initialization skipped:', err);
      }
    }
  }).catch(() => {});
}
