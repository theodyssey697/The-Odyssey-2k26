import { AssessmentQuestion, AssessmentResult, CareerProfile, StudentProfile } from '../types';
import { CAREERS_DATA } from '../data/careersData';
import { QUESTION_BANK } from '../data/questionBank';

interface ScoringVector {
  tech: number;
  core_engineering: number;
  healthcare: number;
  business_finance: number;
  design_media: number;
  law_policy: number;
  sciences: number;
  applied_vocational: number;
  analytical: number;
  creative: number;
  people_social: number;
  hands_on: number;
}

export function calculateAssessmentResults(
  studentProfile: StudentProfile,
  answers: Record<string, string | string[] | number>
): AssessmentResult {
  // 1. Initialize user trait vector
  const traitVector: ScoringVector = {
    tech: 0,
    core_engineering: 0,
    healthcare: 0,
    business_finance: 0,
    design_media: 0,
    law_policy: 0,
    sciences: 0,
    applied_vocational: 0,
    analytical: 0,
    creative: 0,
    people_social: 0,
    hands_on: 0,
  };

  // Dimension totals for percentage breakdown
  const dimRawScores: Record<string, { earned: number; total: number }> = {
    interests: { earned: 0, total: 0 },
    strengths_aptitude: { earned: 0, total: 0 },
    work_preferences: { earned: 0, total: 0 },
    values_motivators: { earned: 0, total: 0 },
    learning_preferences: { earned: 0, total: 0 },
    career_readiness: { earned: 0, total: 0 },
  };

  // 2. Iterate through answers and apply question weights
  QUESTION_BANK.forEach((q) => {
    const userAns = answers[q.id];
    if (userAns === undefined || userAns === null) return;

    if (q.type === 'single_choice' || q.type === 'scenario') {
      const selectedOption = q.options.find((opt) => opt.id === userAns);
      if (selectedOption) {
        Object.entries(selectedOption.weights).forEach(([trait, weight]) => {
          if (weight && trait in traitVector) {
            traitVector[trait as keyof ScoringVector] += weight;
          }
        });
        if (dimRawScores[q.dimension]) {
          dimRawScores[q.dimension].earned += 4;
          dimRawScores[q.dimension].total += 5;
        }
      }
    } else if (q.type === 'rating_scale') {
      const selectedOption = q.options.find((opt) => opt.id === userAns);
      if (selectedOption) {
        Object.entries(selectedOption.weights).forEach(([trait, weight]) => {
          if (weight && trait in traitVector) {
            traitVector[trait as keyof ScoringVector] += weight;
          }
        });
        const ratingNum = parseInt(String(userAns).replace(/\D/g, ''), 10) || 3;
        if (dimRawScores[q.dimension]) {
          dimRawScores[q.dimension].earned += ratingNum;
          dimRawScores[q.dimension].total += 5;
        }
      }
    }
  });

  // Calculate normalized dimension percentages (0 - 100%)
  const dimensionScores = {
    interests: calculateDimensionPercentage(dimRawScores['interests'], 78),
    strengths_aptitude: calculateDimensionPercentage(dimRawScores['strengths_aptitude'], 82),
    work_preferences: calculateDimensionPercentage(dimRawScores['work_preferences'], 75),
    values_motivators: calculateDimensionPercentage(dimRawScores['values_motivators'], 80),
    learning_preferences: calculateDimensionPercentage(dimRawScores['learning_preferences'], 85),
    career_readiness: calculateDimensionPercentage(dimRawScores['career_readiness'], 70),
  };

  // 3. Score each career deterministically
  const scoredCareers: CareerProfile[] = CAREERS_DATA.map((career) => {
    let rawScore = 0;
    let maxPossible = 0;

    // Career category affinities
    switch (career.category) {
      case 'Technology & Software':
        rawScore += traitVector.tech * 3.5 + traitVector.analytical * 2.5;
        maxPossible += 45;
        break;
      case 'Engineering & Manufacturing':
        rawScore += traitVector.core_engineering * 3.5 + traitVector.hands_on * 2.5 + traitVector.applied_vocational * 2.0;
        maxPossible += 45;
        break;
      case 'Healthcare & Life Sciences':
        rawScore += traitVector.healthcare * 3.5 + traitVector.sciences * 2.5 + traitVector.people_social * 2.0;
        maxPossible += 45;
        break;
      case 'Business, Commerce & Finance':
        rawScore += traitVector.business_finance * 3.5 + traitVector.analytical * 2.0 + traitVector.people_social * 2.0;
        maxPossible += 45;
        break;
      case 'Design, Media & Creative':
        rawScore += traitVector.design_media * 3.5 + traitVector.creative * 3.0;
        maxPossible += 45;
        break;
      case 'Law, Policy & Public Administration':
        rawScore += traitVector.law_policy * 3.5 + traitVector.people_social * 2.5 + traitVector.analytical * 2.0;
        maxPossible += 45;
        break;
      case 'Applied Technology & Vocational':
        rawScore += traitVector.applied_vocational * 4.0 + traitVector.hands_on * 3.0;
        maxPossible += 40;
        break;
      default:
        rawScore += traitVector.analytical * 2.0;
        maxPossible += 30;
    }

    // Stage viability modifier
    let stageModifier = 0;
    const stage = studentProfile.stage;

    // Diploma student boost for practical engineering and robotics
    if (stage === 'diploma') {
      if (career.educationPathways.diplomaAndLateralRoutes.length > 0) {
        stageModifier += 6;
      }
      if (career.category === 'Engineering & Manufacturing' || career.category === 'Technology & Software') {
        stageModifier += 4;
      }
    }

    // Class 10 stream discovery alignment
    if (stage === 'class_10' && studentProfile.stageDetails.streamExplorationInterests) {
      const streams = studentProfile.stageDetails.streamExplorationInterests;
      if (streams.includes('Science') && (career.category.includes('Tech') || career.category.includes('Engineering'))) {
        stageModifier += 5;
      }
      if (streams.includes('Commerce') && career.category.includes('Business')) {
        stageModifier += 5;
      }
      if (streams.includes('Humanities') && (career.category.includes('Law') || career.category.includes('Design'))) {
        stageModifier += 5;
      }
    }

    // Class 11-12 stream compatibility
    if (stage === 'class_11_12' && studentProfile.stageDetails.stream11_12) {
      const stream = studentProfile.stageDetails.stream11_12;
      if (stream === 'PCM' && (career.category.includes('Tech') || career.category.includes('Engineering'))) {
        stageModifier += 5;
      }
      if (stream === 'PCB' && career.category.includes('Healthcare')) {
        stageModifier += 6;
      }
      if ((stream === 'Commerce_Math' || stream === 'Commerce_NoMath') && career.category.includes('Business')) {
        stageModifier += 5;
      }
    }

    // Normalize fit score between 55% and 96% for realistic calibration
    const baseFit = Math.min(94, Math.max(52, Math.round((rawScore / Math.max(maxPossible, 1)) * 100)));
    const normalizedFitScore = Math.min(96, Math.max(54, baseFit + stageModifier));

    // Calculate sub-factors
    const interestMatch = Math.min(98, Math.max(60, normalizedFitScore + (traitVector.analytical > 10 ? 3 : -2)));
    const aptitudeMatch = Math.min(97, Math.max(58, dimensionScores.strengths_aptitude));
    const valuesMatch = Math.min(96, Math.max(60, dimensionScores.values_motivators));
    const workStyleMatch = Math.min(95, Math.max(55, dimensionScores.work_preferences));
    const pathwayViability = Math.min(98, Math.max(65, 80 + stageModifier));

    return {
      ...career,
      fitScore: normalizedFitScore,
      matchBreakdown: {
        interestMatch,
        aptitudeMatch,
        valuesMatch,
        workStyleMatch,
        pathwayViability,
      },
    };
  });

  // Sort descending by fit score
  scoredCareers.sort((a, b) => (b.fitScore || 0) - (a.fitScore || 0));

  const topCareers = scoredCareers.slice(0, 5);
  const alternativeCareers = scoredCareers.slice(5, 10);

  // Default qualitative summary (enhanced later by live AI if available)
  const topCareerTitle = topCareers[0]?.title || 'Professional Career';
  const qualitativeSummary = `Your assessment reveals an impressive aptitude for structured problem solving and goal-directed learning. With high alignment in ${topCareers[0]?.category || 'Applied Disciplines'}, your profile indicates that pathways such as ${topCareerTitle} offer an ideal convergence of your intrinsic curiosity and practical capabilities. These results represent indicative profile-fit estimates to guide your research and mentorship conversations.`;

  return {
    id: `result_${Date.now()}`,
    userId: studentProfile.id,
    completedAt: new Date().toISOString(),
    topCareers,
    alternativeCareers,
    dimensionScores,
    qualitativeSummary,
    answersSnapshot: answers,
  };
}

function calculateDimensionPercentage(
  scoreObj: { earned: number; total: number } | undefined,
  fallback: number
): number {
  if (!scoreObj || scoreObj.total === 0) return fallback;
  const pct = Math.round((scoreObj.earned / scoreObj.total) * 100);
  return Math.min(98, Math.max(45, pct));
}
