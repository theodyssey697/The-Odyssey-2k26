import {
  AssessmentDraft,
  AssessmentResult,
  CareerProfile,
  CareerRoadmap,
  ChatMessage,
  EducationStage,
  RoadmapPhase,
  StudentProfile,
} from '../types';
import { CAREERS_DATA } from '../data/careersData';

const STORAGE_KEYS = {
  CURRENT_USER: 'pathpilot_current_user',
  ASSESSMENT_DRAFT: 'pathpilot_assessment_draft',
  ASSESSMENT_RESULTS: 'pathpilot_assessment_results',
  SAVED_CAREERS: 'pathpilot_saved_careers',
  COMPARE_CAREERS: 'pathpilot_compare_careers',
  ACTIVE_ROADMAP: 'pathpilot_active_roadmap',
  CHAT_MESSAGES: 'pathpilot_chat_messages',
};

// Default Guest Profile
export const DEFAULT_PROFILE: StudentProfile = {
  id: 'student_priya_demo',
  name: 'Priya Sharma',
  email: 'priya.sharma@example.edu',
  stage: 'diploma',
  stageDetails: {
    diplomaBranch: 'Mechanical & Automation Engineering',
    diplomaYear: 'Final Year (Semester 5)',
    diplomaImmediateGoal: 'lateral_entry_btech',
    practicalSkillsSummary: 'CAD modeling, basic PLC wiring, lathe machining',
  },
  favoriteSubjects: ['Applied Mechanics', 'Robotics & Automation', 'Mathematics'],
  knownSkills: ['AutoCAD', 'C Basics', 'Technical Drawing', 'Circuit Prototyping'],
  locationPreference: 'India (Open to Bengaluru, Pune, Delhi NCR)',
  budgetConsideration: 'moderate',
  careerGoals: 'Lead automation & robotics projects in smart factories or EV systems.',
  completedOnboarding: true,
  createdAt: new Date().toISOString(),
};

// Preset demo profiles for quick testing of any stage!
export const DEMO_PROFILES: Record<string, StudentProfile> = {
  diploma: DEFAULT_PROFILE,
  class_10: {
    id: 'student_aarav_10',
    name: 'Aarav Patel',
    email: 'aarav.10@example.edu',
    stage: 'class_10',
    stageDetails: {
      class10PreferredSubjects: ['Mathematics', 'Science (Physics)', 'Computer Applications'],
      streamExplorationInterests: ['Science', 'Commerce'],
    },
    favoriteSubjects: ['Maths', 'Physics', 'Coding basics'],
    knownSkills: ['Python Scratch', 'Mental Math', 'Logical Puzzles'],
    locationPreference: 'India',
    budgetConsideration: 'moderate',
    careerGoals: 'Decide whether to pick PCM or Commerce with Maths for software/fintech.',
    completedOnboarding: true,
    createdAt: new Date().toISOString(),
  },
  class_11_12: {
    id: 'student_sneha_12',
    name: 'Sneha Roy',
    email: 'sneha.roy@example.edu',
    stage: 'class_11_12',
    stageDetails: {
      stream11_12: 'PCM',
      targetEntranceExams: ['JEE Main', 'CUET', 'UCEED'],
      preferredDegreeTypes: ['B.Tech Computer Science', 'B.Des Interaction Design'],
    },
    favoriteSubjects: ['Physics', 'Computer Science', 'Art & Design'],
    knownSkills: ['Python', 'Figma Wireframing', 'Mathematics'],
    locationPreference: 'India & International',
    budgetConsideration: 'flexible',
    careerGoals: 'Bridge tech and user interface design in modern product companies.',
    completedOnboarding: true,
    createdAt: new Date().toISOString(),
  },
  undergrad: {
    id: 'student_rohan_ug',
    name: 'Rohan Verma',
    email: 'rohan.v@example.edu',
    stage: 'undergraduate',
    stageDetails: {
      degreeName: 'B.Tech',
      degreeBranch: 'Information Technology',
      undergradYear: '3rd Year',
      immediatePostGradGoal: 'campus_placements',
    },
    favoriteSubjects: ['Data Structures', 'Database Systems', 'Cloud Computing'],
    knownSkills: ['Java', 'SQL', 'React', 'Git'],
    locationPreference: 'Bengaluru / Hyderabad',
    budgetConsideration: 'moderate',
    careerGoals: 'Secure a high-impact Software Engineer role at a tech product company.',
    completedOnboarding: true,
    createdAt: new Date().toISOString(),
  },
  working_pro: {
    id: 'student_vikram_pro',
    name: 'Vikram Menon',
    email: 'vikram.m@example.com',
    stage: 'working_professional',
    stageDetails: {
      currentIndustry: 'IT Services / QA Testing',
      currentRole: 'Manual QA Analyst',
      yearsOfExperience: 3,
      pivotMotivation: 'tech_upskilling',
    },
    favoriteSubjects: ['Automation Scripts', 'Data Analytics', 'System Design'],
    knownSkills: ['Selenium', 'SQL', 'Postman', 'Python Basics'],
    locationPreference: 'Remote / Hybrid India',
    budgetConsideration: 'flexible',
    careerGoals: 'Transition from manual testing to AI/ML or Cloud DevOps engineering.',
    completedOnboarding: true,
    createdAt: new Date().toISOString(),
  },
};

export const storageService = {
  // PROFILE
  getProfile(): StudentProfile {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
      return data ? JSON.parse(data) : DEFAULT_PROFILE;
    } catch {
      return DEFAULT_PROFILE;
    }
  },

  saveProfile(profile: StudentProfile): void {
    try {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(profile));
    } catch (e) {
      console.warn('Storage save failed:', e);
    }
  },

  switchDemoProfile(key: string): StudentProfile {
    const profile = DEMO_PROFILES[key] || DEFAULT_PROFILE;
    this.saveProfile(profile);
    return profile;
  },

  // ASSESSMENT DRAFT
  getDraft(): AssessmentDraft | null {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ASSESSMENT_DRAFT);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  },

  saveDraft(draft: AssessmentDraft): void {
    try {
      localStorage.setItem(STORAGE_KEYS.ASSESSMENT_DRAFT, JSON.stringify(draft));
    } catch (e) {
      console.warn('Draft save failed:', e);
    }
  },

  clearDraft(): void {
    try {
      localStorage.removeItem(STORAGE_KEYS.ASSESSMENT_DRAFT);
    } catch (e) {
      console.warn('Draft clear failed:', e);
    }
  },

  // RESULTS
  getLatestResult(): AssessmentResult | null {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ASSESSMENT_RESULTS);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  },

  saveResult(result: AssessmentResult): void {
    try {
      localStorage.setItem(STORAGE_KEYS.ASSESSMENT_RESULTS, JSON.stringify(result));
    } catch (e) {
      console.warn('Result save failed:', e);
    }
  },

  // SAVED CAREERS
  getSavedCareerIds(): string[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SAVED_CAREERS);
      return data ? JSON.parse(data) : ['robotics-mechatronics', 'ai-ml-engineer'];
    } catch {
      return ['robotics-mechatronics', 'ai-ml-engineer'];
    }
  },

  toggleSaveCareer(careerId: string): string[] {
    const current = this.getSavedCareerIds();
    const exists = current.includes(careerId);
    const updated = exists ? current.filter((id) => id !== careerId) : [...current, careerId];
    try {
      localStorage.setItem(STORAGE_KEYS.SAVED_CAREERS, JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed saving bookmarks:', e);
    }
    return updated;
  },

  // COMPARE CAREERS
  getCompareCareerIds(): string[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.COMPARE_CAREERS);
      return data ? JSON.parse(data) : ['robotics-mechatronics', 'full-stack-engineer'];
    } catch {
      return ['robotics-mechatronics', 'full-stack-engineer'];
    }
  },

  toggleCompareCareer(careerId: string): string[] {
    const current = this.getCompareCareerIds();
    const exists = current.includes(careerId);
    let updated: string[];
    if (exists) {
      updated = current.filter((id) => id !== careerId);
    } else {
      if (current.length >= 3) {
        // limit to 3 max for side-by-side comparison
        updated = [...current.slice(1), careerId];
      } else {
        updated = [...current, careerId];
      }
    }
    try {
      localStorage.setItem(STORAGE_KEYS.COMPARE_CAREERS, JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed compare storage:', e);
    }
    return updated;
  },

  // CAREER ROADMAP
  getActiveRoadmap(careerId?: string): CareerRoadmap {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ACTIVE_ROADMAP);
      if (data) {
        const roadmap: CareerRoadmap = JSON.parse(data);
        if (!careerId || roadmap.careerId === careerId) {
          return roadmap;
        }
      }
    } catch (e) {
      console.warn('Failed reading roadmap:', e);
    }

    // Generate default roadmap for career
    const targetCareer = CAREERS_DATA.find((c) => c.id === careerId) || CAREERS_DATA[0];
    return generateDefaultRoadmap(targetCareer);
  },

  saveRoadmap(roadmap: CareerRoadmap): void {
    try {
      localStorage.setItem(STORAGE_KEYS.ACTIVE_ROADMAP, JSON.stringify(roadmap));
    } catch (e) {
      console.warn('Roadmap save failed:', e);
    }
  },

  // CHAT MESSAGES
  getChatMessages(): ChatMessage[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CHAT_MESSAGES);
      return data
        ? JSON.parse(data)
        : [
            {
              id: 'msg_welcome',
              role: 'assistant',
              content:
                'Hello! I am your PathPilot AI Career Mentor. I have reviewed your education stage, interests, and profile. What career pathways, exams, or next steps would you like to explore today?',
              timestamp: new Date().toISOString(),
              suggestedFollowUps: [
                'Which careers suit my practical skills best?',
                'What are the pros and cons of lateral entry vs direct job?',
                'Can you build me a 90-day learning roadmap?',
              ],
            },
          ];
    } catch {
      return [];
    }
  },

  saveChatMessages(messages: ChatMessage[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.CHAT_MESSAGES, JSON.stringify(messages));
    } catch (e) {
      console.warn('Chat storage failed:', e);
    }
  },

  clearChatMessages(): void {
    try {
      localStorage.removeItem(STORAGE_KEYS.CHAT_MESSAGES);
    } catch (e) {
      console.warn('Failed clearing chat:', e);
    }
  },
};

export function generateDefaultRoadmap(career: CareerProfile): CareerRoadmap {
  const phases: RoadmapPhase[] = [
    {
      id: 'phase_1',
      title: 'Foundation & Discovery',
      dayRange: 'Day 1–30: Foundation',
      description: 'Audit prerequisite fundamentals, master introductory core concepts, and build a toy project.',
      tasks: [
        {
          id: 'task_1_1',
          title: `Study core fundamentals for ${career.title}`,
          description: `Complete introductory video modules or documentation covering ${career.coreSkills.technical.slice(0, 2).join(' and ')}.`,
          timeframe: 'Week 1–2',
          priority: 'high',
          completed: true,
          resourceLink: career.resources[0]?.url,
        },
        {
          id: 'task_1_2',
          title: 'Map out entrance exams & admission timelines',
          description: `Research deadlines and syllabi for: ${career.educationPathways.keyEntranceExams.slice(0, 2).join(', ')}.`,
          timeframe: 'Week 2',
          priority: 'medium',
          completed: false,
        },
        {
          id: 'task_1_3',
          title: 'Build first starter proof-of-concept project',
          description: career.starterProjects[0] || 'Build an initial prototype to validate interest.',
          timeframe: 'Week 3–4',
          priority: 'high',
          completed: false,
        },
      ],
    },
    {
      id: 'phase_2',
      title: 'Hands-on Skill Building',
      dayRange: 'Day 31–60: Skill Building',
      description: 'Acquire professional tooling, practice intermediate problems, and engage with community peers.',
      tasks: [
        {
          id: 'task_2_1',
          title: `Master technical tooling: ${career.coreSkills.technical.slice(2, 4).join(', ')}`,
          description: 'Dedicate 1 hour daily to deliberate hands-on practice exercises.',
          timeframe: 'Week 5–6',
          priority: 'high',
          completed: false,
        },
        {
          id: 'task_2_2',
          title: 'Engage with industry communities and alumni',
          description: 'Follow 5 practitioners on LinkedIn/GitHub and observe current hiring expectations.',
          timeframe: 'Week 6–7',
          priority: 'medium',
          completed: false,
        },
        {
          id: 'task_2_3',
          title: 'Complete a second intermediate portfolio project',
          description: career.starterProjects[1] || 'Construct a comprehensive end-to-end case study.',
          timeframe: 'Week 7–8',
          priority: 'high',
          completed: false,
        },
      ],
    },
    {
      id: 'phase_3',
      title: 'Portfolios, Outreach & Applications',
      dayRange: 'Day 61–90: Portfolios & Outreach',
      description: 'Assemble a polished portfolio, prepare for interviews or entrance exams, and seek apprenticeships.',
      tasks: [
        {
          id: 'task_3_1',
          title: 'Publish public portfolio or GitHub documentation',
          description: 'Document your project with clean architecture diagrams, problem statements, and live demos.',
          timeframe: 'Week 9–10',
          priority: 'high',
          completed: false,
        },
        {
          id: 'task_3_2',
          title: 'Target certifications or practice mock tests',
          description: `Prepare for: ${career.educationPathways.certifications[0] || 'Domain certificate'}.`,
          timeframe: 'Week 10–11',
          priority: 'medium',
          completed: false,
        },
        {
          id: 'task_3_3',
          title: 'Submit applications for internships or higher-ed programs',
          description: 'Target at least 5 relevant opportunities with tailored portfolios.',
          timeframe: 'Week 11–12',
          priority: 'high',
          completed: false,
        },
      ],
    },
  ];

  return {
    id: `roadmap_${career.id}`,
    userId: 'current_student',
    careerId: career.id,
    careerTitle: career.title,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    phases,
  };
}
