import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/common/Sidebar';
import { MobileHeader } from './components/common/MobileHeader';
import { Footer } from './components/common/Footer';
import { LandingPage } from './components/landing/LandingPage';
import { OnboardingModal } from './components/onboarding/OnboardingModal';
import { AssessmentWizard } from './components/assessment/AssessmentWizard';
import { ResultsView } from './components/results/ResultsView';
import { CareerLibraryView } from './components/library/CareerLibraryView';
import { MentorChatView } from './components/mentor/MentorChatView';
import { RoadmapView } from './components/roadmap/RoadmapView';
import { CareerCompareView } from './components/compare/CareerCompareView';
import { ReportView } from './components/report/ReportView';
import { DashboardView } from './components/dashboard/DashboardView';
import { AuthScreen } from './components/auth/AuthScreen';
import { authService } from './services/authService';
import { User } from 'firebase/auth';

import {
  AssessmentDraft,
  AssessmentResult,
  CareerProfile,
  CareerRoadmap,
  StudentProfile,
} from './types';
import { calculateAssessmentResults } from './services/scoringEngine';
import { generateDefaultRoadmap, storageService } from './services/storageService';
import { CAREERS_DATA } from './data/careersData';

export default function App() {
  // Firebase Authenticated User State
  const [currentUser, setCurrentUser] = useState<User | null>(() => authService.getCurrentUser());

  // Navigation View State - Defaults to 'auth' if not authenticated, or 'dashboard' if signed in
  const [activeView, setActiveView] = useState<string>(() =>
    authService.getCurrentUser() ? 'dashboard' : 'auth'
  );

  // Listen to Firebase Auth state changes
  useEffect(() => {
    const unsubscribe = authService.onAuthChange((user) => {
      setCurrentUser(user);
    });
    return () => unsubscribe();
  }, []);

  // Logout handler returning to auth screen
  const handleLogout = async () => {
    try {
      await authService.logOut();
    } catch (err) {
      console.warn('Logout error:', err);
    }
    setCurrentUser(null);
    setActiveView('auth');
  };

  // Student Profile State
  const [studentProfile, setStudentProfile] = useState<StudentProfile>(() =>
    storageService.getProfile()
  );

  // Onboarding Modal Open State
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);

  // Assessment Draft & Results State
  const [assessmentDraft, setAssessmentDraft] = useState<AssessmentDraft | null>(() =>
    storageService.getDraft()
  );
  const [assessmentResult, setAssessmentResult] = useState<AssessmentResult | null>(() => {
    const existing = storageService.getLatestResult();
    if (existing) return existing;
    // Pre-calculate sample result for initial rich demo experience
    return calculateAssessmentResults(storageService.getProfile(), {
      int_01: 'opt_mechanics_making',
      int_02: 'rate_5',
      int_03: 'opt_clean_tech',
      int_05: 'dip_lab_practical',
      apt_01: 'math_36',
      apt_02: 'diag_segment',
      apt_03: 'str_tactile_fixing',
      apt_04: 'data_4',
      apt_05: 'app_tinker_prototype',
      work_01: 'env_field_workshop',
      work_02: 'collab_balanced',
      work_03: 'stab_4',
      work_04: 'role_hands_on_maker',
      val_01: 'val_intellectual_mastery',
      val_02: 'prestige_3',
      val_03: 'risk_moderate',
      lrn_01: 'lrn_building_hands_on',
      lrn_02: 'reskill_4',
      pref_01: 'dur_standard_degree',
      pref_02: 'exam_selective',
      pref_03: 'bud_moderate_balanced',
      read_01: 'read_between_two',
      read_02: 'conf_4',
    });
  });

  // Active Roadmap State
  const [activeRoadmap, setActiveRoadmap] = useState<CareerRoadmap>(() =>
    storageService.getActiveRoadmap('robotics-mechatronics')
  );

  // Saved & Compare career IDs
  const [savedCareerIds, setSavedCareerIds] = useState<string[]>(() =>
    storageService.getSavedCareerIds()
  );
  const [compareCareerIds, setCompareCareerIds] = useState<string[]>(() =>
    storageService.getCompareCareerIds()
  );

  // Mentor Initial Query
  const [mentorInitialQuery, setMentorInitialQuery] = useState<string | undefined>(undefined);

  // Sync saved profile
  const handleSaveProfile = (updated: StudentProfile) => {
    setStudentProfile(updated);
    storageService.saveProfile(updated);
    // Recalculate results if answers exist
    if (assessmentResult?.answersSnapshot) {
      const freshResults = calculateAssessmentResults(updated, assessmentResult.answersSnapshot);
      setAssessmentResult(freshResults);
      storageService.saveResult(freshResults);
    }
  };

  // Switch demo persona
  const handleSwitchDemoProfile = (key: string) => {
    const fresh = storageService.switchDemoProfile(key);
    setStudentProfile(fresh);

    // Provide tailored sample responses for that stage
    let sampleAnswers: Record<string, any> = {};
    if (key === 'diploma') {
      sampleAnswers = {
        int_01: 'opt_mechanics_making',
        int_02: 'rate_5',
        int_03: 'opt_clean_tech',
        int_05: 'dip_lab_practical',
        apt_01: 'math_36',
        apt_02: 'diag_segment',
        work_01: 'env_field_workshop',
        work_04: 'role_hands_on_maker',
        lrn_01: 'lrn_building_hands_on',
        pref_01: 'dur_standard_degree',
      };
    } else if (key === 'class_10') {
      sampleAnswers = {
        int_01: 'opt_tech_code',
        int_02: 'rate_4',
        int_03: 'opt_cyber_software',
        int_04: 'stream_sci_math',
        apt_01: 'math_36',
        work_01: 'env_desk_digital',
        val_01: 'val_high_income',
        lrn_01: 'lrn_building_hands_on',
      };
    } else if (key === 'class_11_12') {
      sampleAnswers = {
        int_01: 'opt_design_arts',
        int_02: 'rate_4',
        int_03: 'opt_user_product',
        apt_03: 'str_visual_spatial',
        work_01: 'env_creative_studio',
        val_01: 'val_creative_expression',
        lrn_01: 'lrn_visual_flowcharts',
      };
    } else {
      sampleAnswers = {
        int_01: 'opt_tech_code',
        int_02: 'rate_5',
        int_06: 'out_code_system',
        apt_01: 'math_36',
        work_01: 'env_desk_digital',
        val_01: 'val_high_income',
      };
    }

    const newResult = calculateAssessmentResults(fresh, sampleAnswers);
    setAssessmentResult(newResult);
    storageService.saveResult(newResult);

    if (newResult.topCareers[0]) {
      const newRoadmap = generateDefaultRoadmap(newResult.topCareers[0]);
      setActiveRoadmap(newRoadmap);
      storageService.saveRoadmap(newRoadmap);
    }

    setActiveView('dashboard');
  };

  // Assessment Completion handler
  const handleCompleteAssessment = (answers: Record<string, any>) => {
    const calculatedResult = calculateAssessmentResults(studentProfile, answers);
    setAssessmentResult(calculatedResult);
    storageService.saveResult(calculatedResult);
    setAssessmentDraft(null);

    // Auto set top career as active roadmap
    if (calculatedResult.topCareers[0]) {
      const newRoadmap = generateDefaultRoadmap(calculatedResult.topCareers[0]);
      setActiveRoadmap(newRoadmap);
      storageService.saveRoadmap(newRoadmap);
    }

    setActiveView('results');
  };

  // Handle career selection for roadmap
  const handleSelectCareerForRoadmap = (career: CareerProfile) => {
    const rm = storageService.getActiveRoadmap(career.id);
    setActiveRoadmap(rm);
    storageService.saveRoadmap(rm);
    setActiveView('roadmap');
  };

  // Handle career selection for AI Mentor
  const handleSelectCareerForMentor = (career: CareerProfile) => {
    setMentorInitialQuery(
      `Hello! I want to explore the career path for "${career.title}". Can you break down the required qualifications, entrance exams, and first 30-day focus for a ${studentProfile.stage.replace('_', ' ')} student?`
    );
    setActiveView('mentor');
  };

  // Mobile Sidebar Drawer State
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  const savedCareersList: CareerProfile[] = savedCareerIds
    .map((id) => CAREERS_DATA.find((c) => c.id === id))
    .filter(Boolean) as CareerProfile[];

  if (activeView === 'auth') {
    return (
      <AuthScreen
        onAuthSuccess={() => setActiveView('dashboard')}
        onExploreGuest={() => setActiveView('dashboard')}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col lg:flex-row font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Mobile Top Header (compact, with drawer toggle, only on mobile) */}
      <MobileHeader
        onOpenSidebar={() => setMobileSidebarOpen(true)}
        activeView={activeView}
        studentProfile={studentProfile}
        currentUser={currentUser}
        onLogout={handleLogout}
        onNavigateToAuth={() => setActiveView('auth')}
      />

      {/* Left Sidebar (fixed on desktop, drawer on mobile) */}
      <Sidebar
        activeView={activeView}
        setActiveView={setActiveView}
        studentProfile={studentProfile}
        onSwitchProfile={handleSwitchDemoProfile}
        onOpenOnboarding={() => setIsOnboardingOpen(true)}
        hasDraft={!!assessmentDraft}
        hasResults={!!assessmentResult}
        savedCareersCount={savedCareerIds.length}
        compareCareersCount={compareCareerIds.length}
        mobileOpen={mobileSidebarOpen}
        setMobileOpen={setMobileSidebarOpen}
        currentUser={currentUser}
        onLogout={handleLogout}
        onNavigateToAuth={() => setActiveView('auth')}
      />

      {/* Main Content Area on the right */}
      <div className="flex-1 min-w-0 flex flex-col min-h-screen">
        <main className="flex-1">
          {activeView === 'landing' && (
          <LandingPage
            onStartDiscovery={() => {
              if (studentProfile.completedOnboarding) {
                setActiveView('assessment');
              } else {
                setIsOnboardingOpen(true);
              }
            }}
            onExploreCareers={() => setActiveView('library')}
            onTryDemo={(stageKey) => handleSwitchDemoProfile(stageKey)}
            onViewSampleReport={() => setActiveView('report')}
            onNavigateToAuth={() => setActiveView('auth')}
          />
        )}

        {activeView === 'dashboard' && (
          <DashboardView
            studentProfile={studentProfile}
            assessmentDraft={assessmentDraft}
            assessmentResult={assessmentResult}
            activeRoadmap={activeRoadmap}
            savedCareers={savedCareersList}
            compareCareersCount={compareCareerIds.length}
            onNavigate={setActiveView}
            onOpenOnboarding={() => setIsOnboardingOpen(true)}
            onSelectCareerForRoadmap={handleSelectCareerForRoadmap}
            onSelectCareerForMentor={handleSelectCareerForMentor}
            currentUser={currentUser}
            onLogout={handleLogout}
          />
        )}

        {activeView === 'assessment' && (
          <AssessmentWizard
            studentProfile={studentProfile}
            onCompleteAssessment={handleCompleteAssessment}
            onCancel={() => setActiveView('dashboard')}
          />
        )}

        {activeView === 'results' && assessmentResult && (
          <ResultsView
            studentProfile={studentProfile}
            result={assessmentResult}
            onNavigate={setActiveView}
            onSelectCareerForRoadmap={handleSelectCareerForRoadmap}
            onSelectCareerForMentor={handleSelectCareerForMentor}
            onRetakeAssessment={() => setActiveView('assessment')}
          />
        )}

        {activeView === 'library' && (
          <CareerLibraryView
            onSelectCareerForRoadmap={handleSelectCareerForRoadmap}
            onSelectCareerForMentor={handleSelectCareerForMentor}
            onNavigate={setActiveView}
          />
        )}

        {activeView === 'mentor' && (
          <MentorChatView
            studentProfile={studentProfile}
            assessmentResult={assessmentResult}
            activeRoadmap={activeRoadmap}
            initialQuery={mentorInitialQuery}
            onClearInitialQuery={() => setMentorInitialQuery(undefined)}
            onNavigate={setActiveView}
          />
        )}

        {activeView === 'roadmap' && (
          <RoadmapView
            studentProfile={studentProfile}
            initialRoadmap={activeRoadmap}
            onNavigate={setActiveView}
            onAskMentorWithContext={(taskTitle) => {
              setMentorInitialQuery(
                `Regarding my roadmap for ${activeRoadmap.careerTitle}: how can I best tackle this task: "${taskTitle}"?`
              );
              setActiveView('mentor');
            }}
          />
        )}

        {activeView === 'compare' && (
          <CareerCompareView
            studentProfile={studentProfile}
            onSelectCareerForRoadmap={handleSelectCareerForRoadmap}
            onSelectCareerForMentor={handleSelectCareerForMentor}
            onNavigate={setActiveView}
          />
        )}

        {activeView === 'report' && (
          <ReportView
            studentProfile={studentProfile}
            assessmentResult={assessmentResult}
            activeRoadmap={activeRoadmap}
            onNavigate={setActiveView}
          />
        )}
      </main>

      {/* Footer (hidden in print) */}
      <Footer onNavigate={setActiveView} />
    </div>

    {/* Onboarding Modal */}
    <OnboardingModal
      isOpen={isOnboardingOpen}
      onClose={() => setIsOnboardingOpen(false)}
      currentProfile={studentProfile}
      onSaveProfile={handleSaveProfile}
      onStartAssessment={() => setActiveView('assessment')}
    />
  </div>
  );
}
