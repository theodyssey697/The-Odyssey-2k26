import React, { useState, useEffect, useMemo } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  BookmarkCheck,
  CheckCircle2,
  HelpCircle,
  RotateCcw,
  Sparkles,
  LayoutGrid,
  AlertCircle,
  Check,
  BrainCircuit,
  Compass,
} from 'lucide-react';
import { AssessmentDraft, AssessmentQuestion, EducationStage, StudentProfile } from '../../types';
import { QUESTION_BANK } from '../../data/questionBank';
import { storageService } from '../../services/storageService';

interface AssessmentWizardProps {
  studentProfile: StudentProfile;
  onCompleteAssessment: (answers: Record<string, any>) => void;
  onCancel: () => void;
}

export const AssessmentWizard: React.FC<AssessmentWizardProps> = ({
  studentProfile,
  onCompleteAssessment,
  onCancel,
}) => {
  // Filter questions applicable to the student's stage
  const questions: AssessmentQuestion[] = useMemo(() => {
    return QUESTION_BANK.filter((q) => {
      if (q.applicableStages === 'all') return true;
      return q.applicableStages.includes(studentProfile.stage);
    });
  }, [studentProfile.stage]);

  // Load existing draft or initialize
  const existingDraft = useMemo(() => storageService.getDraft(), []);

  const [currentIndex, setCurrentIndex] = useState<number>(() => {
    if (existingDraft && typeof existingDraft.currentQuestionIndex === 'number') {
      const idx = existingDraft.currentQuestionIndex;
      return idx >= 0 && idx < questions.length ? idx : 0;
    }
    return 0;
  });

  const [answers, setAnswers] = useState<Record<string, any>>(() => {
    return existingDraft?.answers || {};
  });

  const [saveDraftFeedback, setSaveDraftFeedback] = useState<string | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [showQuestionDrawer, setShowQuestionDrawer] = useState(false);
  const [showReviewScreen, setShowReviewScreen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showWhyWeAsk, setShowWhyWeAsk] = useState(false);

  const currentQuestion = questions[currentIndex];
  const totalQuestions = questions.length;
  const currentAnswer = currentQuestion ? answers[currentQuestion.id] : undefined;

  // Auto-save draft on every answer change
  useEffect(() => {
    if (Object.keys(answers).length > 0) {
      const draft: AssessmentDraft = {
        assessmentId: existingDraft?.assessmentId || `draft_${Date.now()}`,
        userId: studentProfile.id,
        startedAt: existingDraft?.startedAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        currentQuestionIndex: currentIndex,
        answers,
        completed: false,
      };
      storageService.saveDraft(draft);
    }
  }, [answers, currentIndex, studentProfile.id, existingDraft]);

  // Keyboard navigation support (1 to 5 for rating/choice)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (showReviewScreen || showQuestionDrawer || !currentQuestion) return;

      if (['1', '2', '3', '4', '5'].includes(e.key)) {
        const num = parseInt(e.key, 10);
        if (currentQuestion.type === 'rating_scale') {
          const opt = currentQuestion.options[num - 1];
          if (opt) handleSelectOption(opt.id);
        } else if (currentQuestion.type === 'single_choice' || currentQuestion.type === 'scenario') {
          const opt = currentQuestion.options[num - 1];
          if (opt) handleSelectOption(opt.id);
        }
      } else if (e.key === 'ArrowRight' && !validationError) {
        handleNext();
      } else if (e.key === 'ArrowLeft' && currentIndex > 0) {
        handlePrev();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex, currentQuestion, answers, showReviewScreen, showQuestionDrawer, validationError]);

  const handleSelectOption = (optionId: string) => {
    setValidationError(null);
    setAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: optionId,
    }));
  };

  const handleSaveDraftExplicit = () => {
    const draft: AssessmentDraft = {
      assessmentId: existingDraft?.assessmentId || `draft_${Date.now()}`,
      userId: studentProfile.id,
      startedAt: existingDraft?.startedAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      currentQuestionIndex: currentIndex,
      answers,
      completed: false,
    };
    storageService.saveDraft(draft);
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    setSaveDraftFeedback(`Draft saved at ${timeStr}`);
    setTimeout(() => setSaveDraftFeedback(null), 3000);
  };

  const handleNext = () => {
    if (currentQuestion.isRequired && (currentAnswer === undefined || currentAnswer === null)) {
      setValidationError('Please select an answer to continue. You can always review or change it later.');
      return;
    }

    setValidationError(null);

    if (currentIndex < totalQuestions - 1) {
      setCurrentIndex((prev) => prev + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      // Reached the end; show review screen
      setShowReviewScreen(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handlePrev = () => {
    setValidationError(null);
    if (showReviewScreen) {
      setShowReviewScreen(false);
      return;
    }
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleJumpToQuestion = (idx: number) => {
    setCurrentIndex(idx);
    setShowQuestionDrawer(false);
    setShowReviewScreen(false);
    setValidationError(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSubmitFinal = () => {
    // Check if any required question is missing
    const missing = questions.find((q) => q.isRequired && !answers[q.id]);
    if (missing) {
      const missingIdx = questions.indexOf(missing);
      handleJumpToQuestion(missingIdx);
      setValidationError('This required question must be answered before final submission.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      storageService.clearDraft();
      onCompleteAssessment(answers);
    }, 600);
  };

  const answeredCount = Object.keys(answers).length;
  const progressPercent = Math.round(((currentIndex + 1) / totalQuestions) * 100);

  const dimensionBadgeStyles: Record<string, { label: string; color: string }> = {
    interests: { label: 'Dimension: Curiosity & Interests', color: 'bg-cyan-950 text-cyan-400 border-cyan-800' },
    strengths_aptitude: { label: 'Dimension: Reasoning & Aptitude', color: 'bg-emerald-950 text-emerald-400 border-emerald-800' },
    work_preferences: { label: 'Dimension: Work Style & Environment', color: 'bg-indigo-950 text-indigo-400 border-indigo-800' },
    values_motivators: { label: 'Dimension: Life Values & Motivators', color: 'bg-amber-950 text-amber-400 border-amber-800' },
    learning_preferences: { label: 'Dimension: Learning Modality', color: 'bg-teal-950 text-teal-400 border-teal-800' },
    career_education_preferences: { label: 'Dimension: Educational Constraints', color: 'bg-purple-950 text-purple-400 border-purple-800' },
    career_readiness: { label: 'Dimension: Readiness & Confidence', color: 'bg-rose-950 text-rose-400 border-rose-800' },
  };

  // ==========================================
  // REVIEW SCREEN
  // ==========================================
  if (showReviewScreen) {
    const unAnsweredCount = questions.filter((q) => !answers[q.id]).length;

    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto space-y-8">
          {/* Header */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl">
            <div className="flex items-center gap-3 mb-2">
              <span className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                <BrainCircuit className="h-6 w-6" />
              </span>
              <div>
                <h2 className="text-xl sm:text-2xl font-bold font-['Space_Grotesk'] text-white">
                  Assessment Complete — Review Your Responses
                </h2>
                <p className="text-xs sm:text-sm text-slate-400 mt-1">
                  Candidate: <strong className="text-cyan-300">{studentProfile.name}</strong> • Stage:{' '}
                  <strong className="text-slate-300">{studentProfile.stage.replace('_', ' ')}</strong>
                </p>
              </div>
            </div>

            <div className="mt-6 grid grid-cols-3 gap-3 bg-slate-950/80 p-4 rounded-xl border border-slate-800 text-center">
              <div>
                <div className="text-xl sm:text-2xl font-bold text-cyan-400">{totalQuestions}</div>
                <div className="text-[11px] text-slate-400 uppercase tracking-wider">Total Questions</div>
              </div>
              <div>
                <div className="text-xl sm:text-2xl font-bold text-emerald-400">{answeredCount}</div>
                <div className="text-[11px] text-slate-400 uppercase tracking-wider">Answered</div>
              </div>
              <div>
                <div className={`text-xl sm:text-2xl font-bold ${unAnsweredCount === 0 ? 'text-slate-400' : 'text-amber-400'}`}>
                  {unAnsweredCount}
                </div>
                <div className="text-[11px] text-slate-400 uppercase tracking-wider">Remaining</div>
              </div>
            </div>

            {unAnsweredCount > 0 && (
              <div className="mt-4 p-3 bg-amber-950/40 border border-amber-800/60 rounded-xl text-xs text-amber-300 flex items-center gap-2">
                <AlertCircle className="h-4 w-4 shrink-0 text-amber-400" />
                <span>
                  You have {unAnsweredCount} unanswered question(s). You can click them below to answer before submitting.
                </span>
              </div>
            )}
          </div>

          {/* Question Grid Review */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <h3 className="text-sm font-semibold text-slate-200 uppercase tracking-wider">
              Question Summary (Click any to edit)
            </h3>

            <div className="space-y-2.5 max-h-[420px] overflow-y-auto pr-1">
              {questions.map((q, idx) => {
                const ans = answers[q.id];
                const selectedOpt = q.options.find((opt) => opt.id === ans);
                return (
                  <button
                    key={q.id}
                    onClick={() => handleJumpToQuestion(idx)}
                    className="w-full text-left p-3.5 rounded-xl border bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-800/50 transition-all flex items-start justify-between gap-3 text-xs"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-bold text-cyan-400">Q{idx + 1}</span>
                        <span className="text-[10px] text-slate-400 truncate font-normal">
                          {q.dimension.replace('_', ' ')}
                        </span>
                      </div>
                      <p className="text-slate-200 line-clamp-1">{q.text}</p>
                      {selectedOpt ? (
                        <p className="text-emerald-400 text-[11px] mt-1 line-clamp-1 font-medium">
                          ✓ {selectedOpt.label}
                        </p>
                      ) : (
                        <p className="text-amber-400 text-[11px] mt-1 font-medium">
                          ⚠️ Skipped / Unanswered
                        </p>
                      )}
                    </div>
                    <div className="shrink-0 text-slate-400 hover:text-cyan-400 underline text-[11px]">
                      Edit
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Submission Actions */}
          <div className="flex items-center justify-between pt-4">
            <button
              onClick={() => setShowReviewScreen(false)}
              className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-2 transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Question {currentIndex + 1}
            </button>

            <button
              onClick={handleSubmitFinal}
              disabled={isSubmitting}
              className="px-7 py-3 rounded-xl bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 hover:from-cyan-400 hover:to-teal-300 text-slate-950 font-bold text-sm flex items-center gap-2 shadow-xl shadow-cyan-500/20 transition-all hover:scale-[1.02]"
            >
              {isSubmitting ? (
                <>
                  <div className="h-4 w-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                  Generating Transparent Fit Scores...
                </>
              ) : (
                <>
                  <CheckCircle2 className="h-5 w-5" />
                  Submit Assessment & View Career Matches
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ==========================================
  // MANDATORY ONE-QUESTION-PER-PAGE SCREEN
  // ==========================================
  if (!currentQuestion) return null;

  const currentBadge = dimensionBadgeStyles[currentQuestion.dimension] || {
    label: currentQuestion.dimension,
    color: 'bg-slate-800 text-slate-300 border-slate-700',
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between py-6 px-4 sm:px-6 lg:px-8">
      {/* Top Header Bar */}
      <div className="max-w-3xl w-full mx-auto space-y-4">
        {/* Navigation & Progress row */}
        <div className="flex items-center justify-between text-xs text-slate-400">
          <button
            onClick={onCancel}
            className="flex items-center gap-1.5 hover:text-white transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Dashboard</span>
          </button>

          <div className="flex items-center gap-3">
            <span className="font-semibold text-slate-200">
              Question <span className="text-cyan-400 text-sm font-bold">{currentIndex + 1}</span> of{' '}
              {totalQuestions}
            </span>
            <span className="text-slate-600">•</span>
            <button
              onClick={() => setShowQuestionDrawer(true)}
              className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 bg-cyan-950/60 px-2.5 py-1 rounded-lg border border-cyan-800/60"
            >
              <LayoutGrid className="h-3.5 w-3.5" />
              <span>Question Grid ({answeredCount}/{totalQuestions})</span>
            </button>
          </div>
        </div>

        {/* Animated Progress Bar */}
        <div className="relative w-full h-2 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
          <div
            className="absolute top-0 left-0 h-full bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 transition-all duration-300 rounded-full"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Center Question Card */}
      <main className="max-w-3xl w-full mx-auto my-6 flex-1 flex flex-col justify-center">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-10 shadow-2xl space-y-6">
          {/* Dimension Tag & Meta */}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className={`text-[11px] font-semibold uppercase tracking-wider px-2.5 py-1 rounded-lg border ${currentBadge.color}`}>
              {currentBadge.label}
            </span>

            {currentQuestion.isObjectiveReasoning && (
              <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-amber-950/80 text-amber-300 border border-amber-800 flex items-center gap-1">
                <BrainCircuit className="h-3 w-3" />
                Objective Reasoning Exercise
              </span>
            )}
          </div>

          {/* Question Text */}
          <div>
            <h1 className="text-lg sm:text-2xl font-bold text-white leading-relaxed font-['Space_Grotesk']">
              {currentQuestion.text}
            </h1>
            {currentQuestion.contextGuidance && (
              <p className="text-xs sm:text-sm text-slate-400 mt-2 leading-relaxed">
                {currentQuestion.contextGuidance}
              </p>
            )}
          </div>

          {/* Answer Options */}
          <div className="pt-2">
            {/* 1. Rating Scale (1 to 5) */}
            {currentQuestion.type === 'rating_scale' && (
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-5 gap-2.5">
                  {currentQuestion.options.map((opt, idx) => {
                    const isSelected = currentAnswer === opt.id;
                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => handleSelectOption(opt.id)}
                        className={`p-3.5 rounded-xl border text-center transition-all flex flex-col items-center justify-center gap-1.5 ${
                          isSelected
                            ? 'bg-cyan-950 border-cyan-400 text-white shadow-lg shadow-cyan-950 ring-2 ring-cyan-500/30'
                            : 'bg-slate-950/70 border-slate-800 text-slate-300 hover:bg-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <span className={`text-base font-bold ${isSelected ? 'text-cyan-400' : 'text-slate-400'}`}>
                          {idx + 1}
                        </span>
                        <span className="text-[11px] font-medium leading-tight line-clamp-2">
                          {opt.label.split('-')[1]?.trim() || opt.label}
                        </span>
                        {isSelected && <Check className="h-3.5 w-3.5 text-cyan-400 mt-0.5" />}
                      </button>
                    );
                  })}
                </div>
                <div className="text-[11px] text-slate-500 flex justify-between px-1">
                  <span>← Least preferred (1)</span>
                  <span className="hidden sm:inline">Press keys 1 to 5 to vote</span>
                  <span>Most stimulated (5) →</span>
                </div>
              </div>
            )}

            {/* 2. Single Choice & Scenario Options */}
            {(currentQuestion.type === 'single_choice' || currentQuestion.type === 'scenario') && (
              <div className="space-y-2.5">
                {currentQuestion.options.map((opt, idx) => {
                  const isSelected = currentAnswer === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => handleSelectOption(opt.id)}
                      className={`w-full text-left p-4 rounded-xl border transition-all flex items-start gap-3.5 ${
                        isSelected
                          ? 'bg-cyan-950/70 border-cyan-400 text-white shadow-md shadow-cyan-950/50 ring-1 ring-cyan-500/40'
                          : 'bg-slate-950/70 border-slate-800 text-slate-300 hover:bg-slate-800/80 hover:border-slate-700'
                      }`}
                    >
                      <div
                        className={`h-5 w-5 rounded-full border flex items-center justify-center shrink-0 mt-0.5 text-[10px] font-bold ${
                          isSelected
                            ? 'bg-cyan-400 border-cyan-400 text-slate-950'
                            : 'border-slate-600 text-slate-400'
                        }`}
                      >
                        {isSelected ? <Check className="h-3 w-3 stroke-[3]" /> : idx + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs sm:text-sm font-medium leading-relaxed">
                          {opt.label}
                        </div>
                        {opt.indicativeNote && (
                          <div className="text-[11px] text-cyan-400/90 mt-1 font-normal">
                            ↳ {opt.indicativeNote}
                          </div>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Validation Error Message */}
          {validationError && (
            <div className="p-3 bg-rose-950/60 border border-rose-800 rounded-xl text-xs text-rose-300 flex items-center gap-2 animate-in fade-in duration-200">
              <AlertCircle className="h-4 w-4 shrink-0 text-rose-400" />
              <span>{validationError}</span>
            </div>
          )}

          {/* "Why We Ask This" Guidance Accordion */}
          <div className="pt-2 border-t border-slate-800/60">
            <button
              type="button"
              onClick={() => setShowWhyWeAsk(!showWhyWeAsk)}
              className="text-slate-400 hover:text-cyan-400 text-xs flex items-center gap-1.5 transition-colors"
            >
              <HelpCircle className="h-3.5 w-3.5" />
              <span>Why does PathPilot evaluate this question?</span>
            </button>
            {showWhyWeAsk && (
              <div className="mt-2 p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-[11px] text-slate-400 leading-relaxed animate-in fade-in">
                This metric calibrates the <strong>{currentQuestion.dimension.replace('_', ' ')}</strong> weight
                vector for your profile. Rather than relying on subjective guessing, our scoring engine uses these
                signals to balance technical aptitude, work stamina, and genuine personal curiosity.
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Persistent Bottom Sticky Action Bar */}
      <footer className="max-w-3xl w-full mx-auto">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl px-5 py-3.5 flex items-center justify-between shadow-2xl">
          {/* Back button */}
          <button
            type="button"
            onClick={handlePrev}
            disabled={currentIndex === 0}
            className={`px-4 py-2 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-colors ${
              currentIndex === 0
                ? 'text-slate-600 bg-slate-950/40 cursor-not-allowed border border-slate-800/40'
                : 'text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700'
            }`}
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Previous
          </button>

          {/* Center Save Draft Status */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleSaveDraftExplicit}
              className="px-3 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white text-xs font-medium flex items-center gap-1.5 transition-colors"
            >
              <BookmarkCheck className="h-3.5 w-3.5 text-cyan-400" />
              <span>Save Draft</span>
            </button>
            {saveDraftFeedback && (
              <span className="text-[11px] text-emerald-400 font-medium animate-in fade-in">
                ✓ {saveDraftFeedback}
              </span>
            )}
          </div>

          {/* Next / Review button */}
          <button
            type="button"
            onClick={handleNext}
            className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-teal-500 hover:from-cyan-500 hover:to-teal-400 text-white font-semibold text-xs flex items-center gap-1.5 transition-all shadow-md shadow-cyan-900/30"
          >
            <span>{currentIndex === totalQuestions - 1 ? 'Review & Submit' : 'Next Question'}</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </footer>

      {/* Question Navigator Drawer / Modal */}
      {showQuestionDrawer && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white font-['Space_Grotesk']">
                  Question Navigator
                </h3>
                <p className="text-[11px] text-slate-400">
                  {answeredCount} of {totalQuestions} answered
                </p>
              </div>
              <button
                onClick={() => setShowQuestionDrawer(false)}
                className="text-slate-400 hover:text-white text-xs font-medium px-2 py-1 bg-slate-800 rounded-lg"
              >
                Close
              </button>
            </div>

            <div className="grid grid-cols-6 sm:grid-cols-8 gap-2 max-h-[300px] overflow-y-auto py-2">
              {questions.map((q, idx) => {
                const isAnswered = answers[q.id] !== undefined;
                const isCurrent = idx === currentIndex;
                return (
                  <button
                    key={q.id}
                    onClick={() => handleJumpToQuestion(idx)}
                    className={`h-10 rounded-xl font-bold text-xs flex items-center justify-center transition-all ${
                      isCurrent
                        ? 'bg-cyan-500 text-slate-950 ring-2 ring-cyan-400'
                        : isAnswered
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 hover:bg-emerald-900'
                        : 'bg-slate-800 text-slate-400 border border-slate-700 hover:bg-slate-750'
                    }`}
                  >
                    {idx + 1}
                  </button>
                );
              })}
            </div>

            <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
              <div className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-400"></span>
                <span>Answered</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-cyan-400"></span>
                <span>Current</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-slate-700"></span>
                <span>Unanswered</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
