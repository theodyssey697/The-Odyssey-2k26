import React from 'react';
import {
  Compass,
  ClipboardList,
  Milestone,
  BookOpen,
  BotMessageSquare,
  GitCompare,
  FileText,
  Sparkles,
  ArrowRight,
  TrendingUp,
  BookmarkCheck,
  CheckCircle2,
  Calendar,
  Layers,
  GraduationCap,
  Building,
  RotateCcw,
  LogOut,
} from 'lucide-react';
import { AssessmentDraft, AssessmentResult, CareerProfile, CareerRoadmap, StudentProfile } from '../../types';
import { CAREERS_DATA } from '../../data/careersData';

interface DashboardViewProps {
  studentProfile: StudentProfile;
  assessmentDraft: AssessmentDraft | null;
  assessmentResult: AssessmentResult | null;
  activeRoadmap: CareerRoadmap | null;
  savedCareers: CareerProfile[];
  compareCareersCount: number;
  onNavigate: (view: string) => void;
  onOpenOnboarding: () => void;
  onSelectCareerForRoadmap: (career: CareerProfile) => void;
  onSelectCareerForMentor: (career: CareerProfile) => void;
  currentUser?: { email?: string | null } | null;
  onLogout?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  studentProfile,
  assessmentDraft,
  assessmentResult,
  activeRoadmap,
  savedCareers,
  compareCareersCount,
  onNavigate,
  onOpenOnboarding,
  onSelectCareerForRoadmap,
  onSelectCareerForMentor,
  currentUser,
  onLogout,
}) => {
  const stageBadges: Record<string, string> = {
    class_8_9: 'Class 8–9 Student',
    class_10: 'Class 10 Stream Explorer',
    class_11_12: 'Class 11–12 Senior Secondary',
    diploma: 'Polytechnic Diploma Candidate',
    undergraduate: 'Undergraduate Degree',
    postgraduate: 'Postgraduate / Master’s',
    working_professional: 'Working Professional',
  };

  // Roadmap metrics
  let totalTasks = 0;
  let doneTasks = 0;
  if (activeRoadmap) {
    activeRoadmap.phases.forEach((p) => {
      p.tasks.forEach((t) => {
        totalTasks++;
        if (t.completed) doneTasks++;
      });
    });
  }
  const roadmapProgress = totalTasks > 0 ? Math.round((doneTasks / totalTasks) * 100) : 0;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-8 px-4 sm:px-6 lg:px-8 space-y-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Welcome Banner */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/40 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative overflow-hidden">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800 flex items-center gap-1.5">
                <GraduationCap className="h-3.5 w-3.5" />
                {stageBadges[studentProfile.stage] || studentProfile.stage}
              </span>
              <span className="text-xs text-slate-400">
                {studentProfile.locationPreference}
              </span>
              {currentUser?.email && (
                <span className="text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-800">
                  {currentUser.email}
                </span>
              )}
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-['Space_Grotesk'] tracking-tight">
              Welcome back, <span className="text-cyan-400">{currentUser?.email?.split('@')[0] || studentProfile.name}</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 max-w-2xl leading-relaxed">
              {studentProfile.careerGoals ||
                'Your individualized career dashboard for assessments, pathways, and structured 90-day execution.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={onOpenOnboarding}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
            >
              Update Profile Stage
            </button>
            <button
              onClick={() => onNavigate('mentor')}
              className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-cyan-950 transition-all hover:scale-[1.02]"
            >
              <BotMessageSquare className="h-4 w-4" />
              <span>Ask AI Mentor</span>
            </button>
            {onLogout && (
              <button
                onClick={onLogout}
                className="px-4 py-2 rounded-xl bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 hover:text-white text-xs font-bold flex items-center gap-1.5 border border-rose-800/80 transition-colors"
                title="Sign out of Firebase account"
              >
                <LogOut className="h-3.5 w-3.5" />
                <span>Log Out</span>
              </button>
            )}
          </div>
        </div>

        {/* Primary Action Card: Assessment Status */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Assessment Card (2 cols) */}
          <div className="md:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-xl flex flex-col justify-between gap-5 relative overflow-hidden">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 flex items-center justify-center shrink-0">
                  <ClipboardList className="h-6 w-6" />
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-400">
                    Core Psychometric Diagnostic
                  </span>
                  <h2 className="text-lg sm:text-xl font-bold text-white font-['Space_Grotesk'] mt-0.5">
                    {assessmentResult
                      ? 'Assessment Completed — View Latest Synthesis'
                      : assessmentDraft
                      ? `Assessment in Progress (${Object.keys(assessmentDraft.answers).length} Questions Saved)`
                      : 'Career Discovery Assessment'}
                  </h2>
                </div>
              </div>

              {assessmentResult && (
                <span className="text-[11px] font-bold text-emerald-400 bg-emerald-950/80 px-2.5 py-1 rounded-full border border-emerald-800">
                  Evaluated
                </span>
              )}
            </div>

            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              {assessmentResult
                ? `Your profile is matched with ${assessmentResult.topCareers.length} career pathways. Highest compatibility: ${assessmentResult.topCareers[0]?.title} (${assessmentResult.topCareers[0]?.fitScore}% match).`
                : assessmentDraft
                ? `You have saved answers from question ${assessmentDraft.currentQuestionIndex + 1}. Resume anytime with exact draft persistence.`
                : 'Take our 1-by-1 multidimensional questionnaire covering interests, logic puzzles, work preferences, and educational constraints.'}
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-3">
              {assessmentResult ? (
                <>
                  <button
                    onClick={() => onNavigate('results')}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-teal-500 hover:from-cyan-500 hover:to-teal-400 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-cyan-950 transition-all hover:scale-[1.02]"
                  >
                    <span>View Career Matches & Fit Scores</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => onNavigate('assessment')}
                    className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 flex items-center gap-1.5 transition-colors"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    <span>Retake Assessment</span>
                  </button>
                </>
              ) : assessmentDraft ? (
                <button
                  onClick={() => onNavigate('assessment')}
                  className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-cyan-950 transition-all hover:scale-[1.02]"
                >
                  <span>Resume Assessment (Question {assessmentDraft.currentQuestionIndex + 1})</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              ) : (
                <button
                  onClick={() => onNavigate('assessment')}
                  className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-cyan-950 transition-all hover:scale-[1.02]"
                >
                  <span>Start Career Assessment</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>

          {/* Quick Stats Widget (1 col) */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col justify-between gap-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Career Intel Overview
            </h3>

            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <div className="flex items-center gap-2 text-xs text-slate-300">
                  <BookmarkCheck className="h-4 w-4 text-cyan-400" />
                  <span>Bookmarked Careers</span>
                </div>
                <strong className="text-sm text-white">{savedCareers.length}</strong>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <div className="flex items-center gap-2 text-xs text-slate-300">
                  <GitCompare className="h-4 w-4 text-indigo-400" />
                  <span>In Compare Tray</span>
                </div>
                <strong className="text-sm text-white">{compareCareersCount} / 3</strong>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <div className="flex items-center gap-2 text-xs text-slate-300">
                  <Milestone className="h-4 w-4 text-emerald-400" />
                  <span>Roadmap Progress</span>
                </div>
                <strong className="text-sm text-emerald-400">{roadmapProgress}%</strong>
              </div>
            </div>

            <button
              onClick={() => onNavigate('report')}
              className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 border border-slate-700 transition-colors"
            >
              <FileText className="h-3.5 w-3.5 text-cyan-400" />
              <span>Diagnostic PDF Report</span>
            </button>
          </div>
        </div>

        {/* Active Roadmap Snapshot & Top Recommendations Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Active Roadmap Snapshot (2 cols) */}
          {activeRoadmap && (
            <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-xl space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-400">
                    Active 90-Day Plan
                  </span>
                  <h3 className="text-lg font-bold text-white font-['Space_Grotesk'] mt-0.5">
                    Target: {activeRoadmap.careerTitle}
                  </h3>
                </div>
                <button
                  onClick={() => onNavigate('roadmap')}
                  className="text-xs text-cyan-400 hover:underline font-semibold flex items-center gap-1"
                >
                  <span>Full Roadmap</span>
                  <ArrowRight className="h-3 w-3" />
                </button>
              </div>

              {/* Progress bar */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs text-slate-400">
                  <span>Milestone Completion</span>
                  <span className="font-bold text-cyan-400">{roadmapProgress}%</span>
                </div>
                <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                  <div
                    className="bg-gradient-to-r from-cyan-500 to-emerald-400 h-full rounded-full transition-all"
                    style={{ width: `${roadmapProgress}%` }}
                  />
                </div>
              </div>

              {/* Next upcoming tasks */}
              <div className="space-y-2">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                  Upcoming Action Items:
                </span>
                {activeRoadmap.phases[0]?.tasks.slice(0, 3).map((task) => (
                  <div
                    key={task.id}
                    onClick={() => onNavigate('roadmap')}
                    className="p-3 bg-slate-950/70 hover:bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-between text-xs text-slate-300 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <span className={task.completed ? 'text-emerald-400' : 'text-slate-600'}>
                        {task.completed ? '✓' : '○'}
                      </span>
                      <span className={task.completed ? 'line-through text-slate-500' : 'font-medium'}>
                        {task.title}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-500 uppercase px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800">
                      {task.timeframe}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Quick AI Prompts & Saved Careers (1 col) */}
          <div className="space-y-6">
            {/* Quick AI Prompts */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 uppercase tracking-wider">
                <BotMessageSquare className="h-4 w-4" />
                <span>Instant AI Counseling</span>
              </div>
              <p className="text-xs text-slate-400">
                Click any question to get immediate guidance tailored to your stage:
              </p>
              <div className="space-y-2">
                {[
                  studentProfile.stage === 'diploma'
                    ? 'What are the top government JE exams for diploma?'
                    : 'What careers align best with my profile?',
                  'How do I create a 30-day proof-of-work project?',
                  'What entrance exams should I prioritize?',
                ].map((q, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      onNavigate('mentor');
                    }}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-[11px] text-slate-300 hover:text-cyan-300 transition-colors"
                  >
                    💬 {q}
                  </button>
                ))}
              </div>
            </div>

            {/* Saved Careers Quick List */}
            {savedCareers.length > 0 && (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                    Bookmarked Careers ({savedCareers.length})
                  </span>
                  <button
                    onClick={() => onNavigate('library')}
                    className="text-xs text-cyan-400 hover:underline"
                  >
                    View All
                  </button>
                </div>
                <div className="space-y-2">
                  {savedCareers.slice(0, 3).map((sc) => (
                    <div
                      key={sc.id}
                      onClick={() => onSelectCareerForRoadmap(sc)}
                      className="p-2.5 bg-slate-950/70 hover:bg-slate-800 border border-slate-800 rounded-xl flex items-center justify-between text-xs cursor-pointer transition-colors"
                    >
                      <span className="font-semibold text-white">{sc.title}</span>
                      <ArrowRight className="h-3 w-3 text-cyan-400" />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
