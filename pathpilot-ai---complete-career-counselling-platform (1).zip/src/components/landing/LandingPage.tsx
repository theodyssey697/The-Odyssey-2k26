import React, { useState } from 'react';
import {
  Compass,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  BrainCircuit,
  Milestone,
  BotMessageSquare,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  GraduationCap,
  Building,
  Briefcase,
  Layers,
  FileText,
  Star,
  Users,
} from 'lucide-react';
import { EducationStage } from '../../types';

interface LandingPageProps {
  onStartDiscovery: () => void;
  onExploreCareers: () => void;
  onTryDemo: (stageKey: string) => void;
  onViewSampleReport: () => void;
  onNavigateToAuth?: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onStartDiscovery,
  onExploreCareers,
  onTryDemo,
  onViewSampleReport,
  onNavigateToAuth,
}) => {
  const [activeStageTab, setActiveStageTab] = useState<EducationStage>('diploma');
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const stageFeatures: Record<
    EducationStage,
    { title: string; subtitle: string; highlights: string[]; quote: string }
  > = {
    class_8_9: {
      title: 'Classes 8–9: Foundational Curiosity',
      subtitle: 'Identify natural inclinations before high-stakes board choices arrive.',
      highlights: [
        'Explores scientific, verbal, creative, and physical activities without exam pressure.',
        'Builds healthy habits for curiosity and deep focus.',
        'Helps parents understand a child’s intrinsic strengths without bias.',
      ],
      quote: 'Early discovery turns learning from a forced chore into purposeful curiosity.',
    },
    class_10: {
      title: 'Class 10: Unbiased Stream Discovery',
      subtitle: 'Compare Science (PCM/PCB), Commerce, Humanities, and Vocational routes neutrally.',
      highlights: [
        'No stream is treated as superior; each is mapped to lucrative, respected real-world careers.',
        'Evaluates mathematics aptitude, biology curiosity, and social/commerce interests.',
        'Clear decision matrices for 11th grade subjects and competitive examination readiness.',
      ],
      quote: 'Choose your stream based on where you can excel sustainably, not peer prestige.',
    },
    class_11_12: {
      title: 'Classes 11–12: Degree & Exam Strategy',
      subtitle: 'Navigate entrance exams (JEE, NEET, CUET, CLAT, UCEED) and backup pathways.',
      highlights: [
        'Comprehensive degree roadmaps across B.Tech, B.Des, B.Com, Integrated Law, and Allied Sciences.',
        'Backup degree options so your future is never dependent on a single exam day.',
        'Budget-sensitive vs private university vs study abroad return-on-investment (ROI) analysis.',
      ],
      quote: 'Have an ambitious Plan A, a structured Plan B, and a resilient Plan C.',
    },
    diploma: {
      title: 'Polytechnic Diploma: Hands-on to Leadership',
      subtitle: 'Bridge practical workshop skills with Lateral Entry B.Tech (LEET) or direct industry jobs.',
      highlights: [
        'Direct guidance on 2nd year B.Tech Lateral Entry (LEET exams) across Indian state universities.',
        'Core industry apprenticeships (NATS) and junior engineer government recruitment (SSC JE / RRB JE).',
        'Leverages your hands-on laboratory mastery as a distinct competitive edge.',
      ],
      quote: 'Diploma students possess practical workshop fluency that pure academic graduates often lack.',
    },
    undergraduate: {
      title: 'Undergraduate: Placements & High-Growth Skills',
      subtitle: 'Transform college coursework into verified proof-of-work and high-paying roles.',
      highlights: [
        'Concrete 30-day starter projects and public GitHub / Behance portfolio architectures.',
        'Campus placement coding prep, systems design, and product management fellowships.',
        'Higher studies planning (GATE, CAT, IIT JAM, GRE/MS) with timeline milestones.',
      ],
      quote: 'Degrees open doors; proof-of-work, projects, and domain skills secure offers.',
    },
    postgraduate: {
      title: 'Postgraduate & Research: Deep Specialization',
      subtitle: 'Focus on R&D fellowships, executive MBAs, doctoral grants, and leadership roles.',
      highlights: [
        'CSIR / UGC NET, GATE fellowships, and international research lab transitions.',
        'Executive MBA and lateral corporate promotions.',
        'Bridging academic science with commercial venture creation.',
      ],
      quote: 'Refine your niche expertise into high-value intellectual capital.',
    },
    working_professional: {
      title: 'Working Professionals: Strategic Career Pivots',
      subtitle: 'Transition into AI, Cloud, Product, or Management without starting from zero.',
      highlights: [
        'Identifies transferable skills from manual QA, sales, operations, or non-tech roles.',
        'Structured 90-day reskilling roadmaps with evening/weekend micro-commitments.',
        'Strategies to navigate resume screening and negotiate salary jumps.',
      ],
      quote: 'A pivot is not starting over — it is carrying your valuable wisdom into a higher-leverage field.',
    },
  };

  const faqs = [
    {
      q: 'How is PathPilot AI different from generic career quizzes?',
      a: 'Generic quizzes ask 5 superficial questions and guess a random job. PathPilot AI uses a 36-question multidimensional framework tailored to your specific education stage (Class 10, 11-12, Diploma, Undergrad, etc.), evaluates objective reasoning, and runs transparent, deterministic scoring rules combined with real Indian educational pathways (LEET, CUET, JEE, NEET, Apprenticeships).',
    },
    {
      q: 'Does an AI invent the match percentages arbitrarily?',
      a: 'No! Our scoring engine uses deterministic, mathematically calibrated rubric vectors across interests, skills, work styles, values, and stage prerequisites. The Gemini AI is utilized strictly to provide empathetic qualitative counseling narrative and conversational mentoring, not black-box numbers.',
    },
    {
      q: 'I am a Polytechnic Diploma student. How does this help me?',
      a: 'PathPilot AI is uniquely designed for diploma candidates. It recognizes polytechnic streams (Mechanical, Electrical, Civil, CS), highlights Lateral Entry to 2nd year B.Tech (LEET), maps Government Junior Engineer exams (SSC JE/RRB JE), and provides industrial apprenticeship pathways (NATS).',
    },
    {
      q: 'What is the "One-Question-Per-Screen" experience?',
      a: 'Rather than overwhelming you with an exhausting 40-question endless scroll, every assessment question has its own dedicated screen with progress tracking, context guidance, and instant auto-draft saving. You can pause, close your tab, and resume anytime without losing a single answer.',
    },
    {
      q: 'Can I export or print my assessment results as a PDF?',
      a: 'Yes! PathPilot generates a formal, print-optimized Career Discovery Diagnostic Report. You can print it or save it as a clean PDF to share with parents, teachers, and school mentors.',
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 selection:bg-cyan-500 selection:text-slate-950">
      {/* Hero Section */}
      <section className="relative pt-16 pb-24 px-4 sm:px-6 lg:px-8 overflow-hidden">
        {/* Glow ambient lights */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-gradient-to-tr from-cyan-500/15 via-teal-500/10 to-indigo-500/10 rounded-full blur-[130px] pointer-events-none" />

        <div className="max-w-5xl mx-auto text-center relative z-10 space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-cyan-950/80 border border-cyan-800 text-cyan-300 text-xs font-semibold animate-in fade-in slide-in-from-top-3">
            <Sparkles className="h-3.5 w-3.5 text-amber-400" />
            <span>PathPilot AI Career Counselling Platform</span>
            <span className="text-slate-500">•</span>
            <span className="text-slate-400">Classes 8–12, Diploma, Degrees & Beyond</span>
          </div>

          <h1 className="text-3xl sm:text-6xl font-black text-white font-['Space_Grotesk'] tracking-tight leading-tight">
            Your career. Your strengths.{' '}
            <span className="bg-gradient-to-r from-cyan-400 via-teal-300 to-emerald-400 bg-clip-text text-transparent">
              Your direction.
            </span>
          </h1>

          <p className="text-sm sm:text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Discover suitable career pathways through stage-tailored multidimensional assessments, transparent scoring rules, grounded AI mentoring, and actionable 90-day roadmaps.
          </p>

          {/* Primary CTA Buttons */}
          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3.5">
            <button
              onClick={onStartDiscovery}
              className="w-full sm:w-auto px-7 py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 hover:from-cyan-400 hover:to-teal-300 text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 shadow-xl shadow-cyan-500/25 transition-all hover:scale-[1.03]"
            >
              <Compass className="h-5 w-5" />
              <span>Discover My Career Path</span>
              <ArrowRight className="h-4 w-4" />
            </button>

            <button
              onClick={onExploreCareers}
              className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-slate-200 text-sm font-bold flex items-center justify-center gap-2 border border-slate-700 transition-colors"
            >
              <span>Explore 30+ Career Pathways</span>
            </button>

            {onNavigateToAuth && (
              <button
                onClick={onNavigateToAuth}
                className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 text-cyan-300 text-sm font-bold flex items-center justify-center gap-2 border border-cyan-800/80 transition-colors"
              >
                <span>Sign In / Sign Up</span>
              </button>
            )}
          </div>

          {/* Quick Demo Personas pills */}
          <div className="pt-6 flex flex-wrap items-center justify-center gap-2 text-xs text-slate-400">
            <span className="text-slate-500">Quick Test Personas:</span>
            <button
              onClick={() => onTryDemo('diploma')}
              className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-slate-800 hover:border-cyan-700 transition-colors"
            >
              🔧 Priya (Diploma Mech)
            </button>
            <button
              onClick={() => onTryDemo('class_10')}
              className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-amber-300 border border-slate-800 hover:border-amber-700 transition-colors"
            >
              🧭 Aarav (Class 10)
            </button>
            <button
              onClick={() => onTryDemo('class_11_12')}
              className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-purple-300 border border-slate-800 hover:border-purple-700 transition-colors"
            >
              📐 Sneha (Class 12 PCM)
            </button>
            <button
              onClick={() => onTryDemo('undergrad')}
              className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-emerald-300 border border-slate-800 hover:border-emerald-700 transition-colors"
            >
              💻 Rohan (B.Tech Undergrad)
            </button>
          </div>
        </div>
      </section>

      {/* Feature Highlights Grid */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 border-y border-slate-900 bg-slate-950/60">
        <div className="max-w-6xl mx-auto space-y-12">
          <div className="text-center space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">
              Why PathPilot Stands Apart
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-['Space_Grotesk']">
              Engineered for Real Clarity, Not Generic Clichés
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-3 shadow-xl">
              <div className="h-10 w-10 rounded-2xl bg-cyan-950 border border-cyan-800 text-cyan-400 flex items-center justify-center font-bold">
                1
              </div>
              <h3 className="text-base font-bold text-white font-['Space_Grotesk']">
                Strict 1-by-1 Question Experience
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Zero overwhelming forms. Every question gets full focus with auto-draft saving and progress navigation.
              </p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-3 shadow-xl">
              <div className="h-10 w-10 rounded-2xl bg-emerald-950 border border-emerald-800 text-emerald-400 flex items-center justify-center font-bold">
                2
              </div>
              <h3 className="text-base font-bold text-white font-['Space_Grotesk']">
                Deterministic Scoring Rubric
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Transparent match formulas. We explain exactly which answers contributed to your career fit score.
              </p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-3 shadow-xl">
              <div className="h-10 w-10 rounded-2xl bg-indigo-950 border border-indigo-800 text-indigo-400 flex items-center justify-center font-bold">
                3
              </div>
              <h3 className="text-base font-bold text-white font-['Space_Grotesk']">
                30–60–90 Day Roadmaps
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Turn guidance into action with starter projects, entrance exam schedules, and interactive task trackers.
              </p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-3 shadow-xl">
              <div className="h-10 w-10 rounded-2xl bg-teal-950 border border-teal-800 text-teal-400 flex items-center justify-center font-bold">
                4
              </div>
              <h3 className="text-base font-bold text-white font-['Space_Grotesk']">
                24/7 Grounded AI Mentor
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Powered by Gemini 3.8 Flash, contextualized with your education stage and target career milestones.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stage Interactive Explorer Carousel */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto space-y-8">
          <div className="text-center space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">
              Personalized Architecture
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-['Space_Grotesk']">
              Tailored Guidance for Every Education Stage
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto">
              Select an education stage to preview how PathPilot crafts tailored questions and practical pathways.
            </p>
          </div>

          {/* Stage Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none justify-start sm:justify-center">
            {[
              { id: 'class_8_9', label: 'Classes 8–9' },
              { id: 'class_10', label: 'Class 10' },
              { id: 'class_11_12', label: 'Classes 11–12' },
              { id: 'diploma', label: 'Polytechnic Diploma' },
              { id: 'undergraduate', label: 'Undergraduate' },
              { id: 'working_professional', label: 'Working Pro' },
            ].map((tab) => {
              const isSelected = activeStageTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveStageTab(tab.id as EducationStage)}
                  className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                    isSelected
                      ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-950'
                      : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* Stage Content Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-xl sm:text-2xl font-bold text-white font-['Space_Grotesk']">
                  {stageFeatures[activeStageTab].title}
                </h3>
                <p className="text-xs sm:text-sm text-cyan-400 mt-1">
                  {stageFeatures[activeStageTab].subtitle}
                </p>
              </div>

              <button
                onClick={() => onTryDemo(activeStageTab)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 self-start sm:self-auto flex items-center gap-1.5 transition-colors"
              >
                <span>Preview {stageFeatures[activeStageTab].title.split(':')[0]} Persona</span>
                <ArrowRight className="h-3 w-3" />
              </button>
            </div>

            <div className="space-y-3">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Stage Capabilities:
              </span>
              <ul className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {stageFeatures[activeStageTab].highlights.map((item, idx) => (
                  <li
                    key={idx}
                    className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800/80 text-xs text-slate-300 leading-relaxed flex items-start gap-2.5"
                  >
                    <CheckCircle2 className="h-4 w-4 text-cyan-400 shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-4 bg-slate-950/60 rounded-xl border border-slate-800/60 text-xs italic text-slate-400">
              "{stageFeatures[activeStageTab].quote}"
            </div>
          </div>
        </div>
      </section>

      {/* Frequently Asked Questions */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 border-t border-slate-900 bg-slate-950/40">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="text-center space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">
              Frequently Asked Questions
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-['Space_Grotesk']">
              Clear Answers to Common Questions
            </h2>
          </div>

          <div className="space-y-3">
            {faqs.map((faq, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div
                  key={idx}
                  className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden transition-colors"
                >
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : idx)}
                    className="w-full text-left p-5 flex items-center justify-between gap-4 text-sm font-bold text-white hover:text-cyan-300"
                  >
                    <span>{faq.q}</span>
                    {isOpen ? (
                      <ChevronUp className="h-4 w-4 text-cyan-400 shrink-0" />
                    ) : (
                      <ChevronDown className="h-4 w-4 text-slate-400 shrink-0" />
                    )}
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-5 text-xs text-slate-300 leading-relaxed border-t border-slate-800/60 pt-3">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Bottom CTA Banner */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto bg-gradient-to-r from-slate-900 via-cyan-950/60 to-slate-900 border border-cyan-800/60 rounded-3xl p-8 sm:p-14 text-center space-y-6 shadow-2xl relative overflow-hidden">
          <div className="space-y-3 relative z-10">
            <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest">
              Ready to Navigate Your True Potential?
            </span>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-white font-['Space_Grotesk']">
              Begin Your Stage-Tailored Career Discovery
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto leading-relaxed">
              Step into an honest, structured assessment designed for clarity. Take the first step with zero pressure.
            </p>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3 relative z-10">
            <button
              onClick={onStartDiscovery}
              className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 hover:from-cyan-400 hover:to-teal-300 text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 shadow-xl shadow-cyan-500/25 transition-all hover:scale-[1.03]"
            >
              <Compass className="h-5 w-5" />
              <span>Launch Assessment Now</span>
              <ArrowRight className="h-4 w-4" />
            </button>
            <button
              onClick={onViewSampleReport}
              className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-semibold border border-slate-700 flex items-center justify-center gap-1.5 transition-colors"
            >
              <FileText className="h-4 w-4 text-cyan-400" />
              <span>View Sample Report</span>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
