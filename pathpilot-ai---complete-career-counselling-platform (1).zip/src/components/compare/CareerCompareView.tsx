import React, { useState } from 'react';
import {
  GitCompare,
  X,
  Plus,
  Milestone,
  BotMessageSquare,
  GraduationCap,
  Sparkles,
  DollarSign,
  Building,
  CheckCircle2,
  Layers,
} from 'lucide-react';
import { CareerProfile, StudentProfile } from '../../types';
import { CAREERS_DATA } from '../../data/careersData';
import { storageService } from '../../services/storageService';

interface CareerCompareViewProps {
  studentProfile: StudentProfile;
  onSelectCareerForRoadmap: (career: CareerProfile) => void;
  onSelectCareerForMentor: (career: CareerProfile) => void;
  onNavigate: (view: string) => void;
}

export const CareerCompareView: React.FC<CareerCompareViewProps> = ({
  studentProfile,
  onSelectCareerForRoadmap,
  onSelectCareerForMentor,
  onNavigate,
}) => {
  const [compareIds, setCompareIds] = useState<string[]>(() => storageService.getCompareCareerIds());

  const comparedCareers: CareerProfile[] = compareIds
    .map((id) => CAREERS_DATA.find((c) => c.id === id))
    .filter(Boolean) as CareerProfile[];

  const handleRemoveCareer = (id: string) => {
    const updated = storageService.toggleCompareCareer(id);
    setCompareIds(updated);
  };

  const handleAddCareer = (id: string) => {
    if (!compareIds.includes(id)) {
      const updated = storageService.toggleCompareCareer(id);
      setCompareIds(updated);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[11px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-md bg-cyan-950 text-cyan-300 border border-cyan-800">
                Decision Matrix
              </span>
              <span className="text-xs text-slate-400">
                Side-by-Side Comparison ({comparedCareers.length} of 3 Selected)
              </span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold text-white font-['Space_Grotesk'] tracking-tight">
              Compare Career Pathways
            </h1>
            <p className="text-sm text-slate-400 mt-1 max-w-2xl leading-relaxed">
              Weigh education routes, diploma lateral eligibility, examination intensity, technical skills, and salary bands to make an informed decision.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                const names = comparedCareers.map((c) => c.title).join(' and ');
                onSelectCareerForMentor(comparedCareers[0] || CAREERS_DATA[0]);
              }}
              disabled={comparedCareers.length < 2}
              className="px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-800 disabled:text-slate-600 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-cyan-950 transition-colors"
            >
              <BotMessageSquare className="h-4 w-4" />
              <span>Ask AI Mentor to Compare</span>
            </button>
          </div>
        </div>

        {/* Add Career Selector bar if less than 3 */}
        {comparedCareers.length < 3 && (
          <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <span className="text-slate-300 font-medium">
              You can add up to {3 - comparedCareers.length} more career(s) to this comparison:
            </span>
            <select
              onChange={(e) => {
                if (e.target.value) handleAddCareer(e.target.value);
              }}
              value=""
              className="px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-500"
            >
              <option value="">+ Add a career from library...</option>
              {CAREERS_DATA.filter((c) => !compareIds.includes(c.id)).map((c) => (
                <option key={c.id} value={c.id}>
                  {c.title} ({c.category})
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Comparison Matrix Table */}
        {comparedCareers.length > 0 ? (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                {/* Column Headers: Career Titles */}
                <thead>
                  <tr className="bg-slate-950 border-b border-slate-800">
                    <th className="p-5 font-bold text-slate-400 uppercase tracking-wider w-48 text-[11px]">
                      Parameter
                    </th>
                    {comparedCareers.map((c) => (
                      <th key={c.id} className="p-5 min-w-[260px] align-top">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded bg-slate-900 text-cyan-400 border border-cyan-800">
                              {c.category}
                            </span>
                            <h3 className="text-base font-bold text-white font-['Space_Grotesk'] mt-1.5">
                              {c.title}
                            </h3>
                          </div>
                          <button
                            onClick={() => handleRemoveCareer(c.id)}
                            className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-colors"
                            title="Remove"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>

                        <div className="mt-3 flex items-center gap-2">
                          <button
                            onClick={() => onSelectCareerForRoadmap(c)}
                            className="flex-1 py-1.5 px-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-[11px] flex items-center justify-center gap-1 transition-colors"
                          >
                            <Milestone className="h-3 w-3" />
                            <span>Set Roadmap</span>
                          </button>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-800/80">
                  {/* Category & Intro */}
                  <tr className="hover:bg-slate-800/30">
                    <td className="p-5 font-semibold text-slate-300 bg-slate-950/40">
                      Summary
                    </td>
                    {comparedCareers.map((c) => (
                      <td key={c.id} className="p-5 text-slate-300 leading-relaxed">
                        {c.shortDescription}
                      </td>
                    ))}
                  </tr>

                  {/* Degree Routes */}
                  <tr className="hover:bg-slate-800/30">
                    <td className="p-5 font-semibold text-slate-300 bg-slate-950/40">
                      Degree Pathways
                    </td>
                    {comparedCareers.map((c) => (
                      <td key={c.id} className="p-5 text-slate-400 space-y-1">
                        {c.educationPathways.degreeRoutes.map((r, i) => (
                          <div key={i} className="flex items-start gap-1.5">
                            <span className="text-cyan-400">•</span>
                            <span className="text-slate-300">{r}</span>
                          </div>
                        ))}
                      </td>
                    ))}
                  </tr>

                  {/* Diploma & Lateral Routes */}
                  <tr className="hover:bg-slate-800/30">
                    <td className="p-5 font-semibold text-cyan-400 bg-slate-950/40">
                      Diploma & Lateral Entry (LEET)
                    </td>
                    {comparedCareers.map((c) => (
                      <td key={c.id} className="p-5 text-slate-300 space-y-1">
                        {c.educationPathways.diplomaAndLateralRoutes.length > 0 ? (
                          c.educationPathways.diplomaAndLateralRoutes.map((r, i) => (
                            <div key={i} className="flex items-start gap-1.5">
                              <span className="text-emerald-400">✓</span>
                              <span>{r}</span>
                            </div>
                          ))
                        ) : (
                          <span className="text-slate-500 italic">No direct lateral entry</span>
                        )}
                      </td>
                    ))}
                  </tr>

                  {/* Entrance Exams */}
                  <tr className="hover:bg-slate-800/30">
                    <td className="p-5 font-semibold text-amber-300 bg-slate-950/40">
                      Key Entrance Exams
                    </td>
                    {comparedCareers.map((c) => (
                      <td key={c.id} className="p-5 text-slate-200 font-medium">
                        {c.educationPathways.keyEntranceExams.join(', ')}
                      </td>
                    ))}
                  </tr>

                  {/* Core Technical Skills */}
                  <tr className="hover:bg-slate-800/30">
                    <td className="p-5 font-semibold text-slate-300 bg-slate-950/40">
                      Core Technical Skills
                    </td>
                    {comparedCareers.map((c) => (
                      <td key={c.id} className="p-5">
                        <div className="flex flex-wrap gap-1.5">
                          {c.coreSkills.technical.map((sk, i) => (
                            <span
                              key={i}
                              className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-[10px] text-cyan-300"
                            >
                              {sk}
                            </span>
                          ))}
                        </div>
                      </td>
                    ))}
                  </tr>

                  {/* Starter Proof-of-Work Projects */}
                  <tr className="hover:bg-slate-800/30">
                    <td className="p-5 font-semibold text-emerald-400 bg-slate-950/40">
                      Starter Proof-of-Work Project
                    </td>
                    {comparedCareers.map((c) => (
                      <td key={c.id} className="p-5 text-slate-300 leading-relaxed text-[11px]">
                        {c.starterProjects[0] || 'Build portfolio project'}
                      </td>
                    ))}
                  </tr>

                  {/* Indicative Salary (INR) */}
                  <tr className="hover:bg-slate-800/30">
                    <td className="p-5 font-semibold text-slate-300 bg-slate-950/40">
                      Indicative Starting Compensation
                    </td>
                    {comparedCareers.map((c) => (
                      <td key={c.id} className="p-5">
                        <div className="text-emerald-400 font-bold text-sm">
                          {c.salaryIndicative.entryLevelINR}
                        </div>
                        <div className="text-[10px] text-slate-500 mt-0.5">
                          {c.salaryIndicative.notes}
                        </div>
                      </td>
                    ))}
                  </tr>

                  {/* Mid Career Salary */}
                  <tr className="hover:bg-slate-800/30">
                    <td className="p-5 font-semibold text-slate-300 bg-slate-950/40">
                      Mid-Career Compensation
                    </td>
                    {comparedCareers.map((c) => (
                      <td key={c.id} className="p-5 font-bold text-white text-sm">
                        {c.salaryIndicative.midCareerINR}
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="text-center py-16 bg-slate-900 border border-slate-800 rounded-3xl p-8 space-y-3">
            <GitCompare className="h-8 w-8 text-slate-600 mx-auto" />
            <h3 className="text-base font-bold text-white">No careers selected for comparison</h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Select 2 or 3 careers from the Career Library or Assessment Results to compare their pathways side by side.
            </p>
            <button
              onClick={() => onNavigate('library')}
              className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs rounded-xl"
            >
              Browse Career Library
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
