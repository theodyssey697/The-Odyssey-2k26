import React from 'react';
import { Menu, Compass } from 'lucide-react';
import { StudentProfile } from '../../types';

interface MobileHeaderProps {
  onOpenSidebar: () => void;
  activeView: string;
  studentProfile: StudentProfile;
  currentUser?: { email?: string | null } | null;
  onLogout?: () => void;
  onNavigateToAuth?: () => void;
}

export const MobileHeader: React.FC<MobileHeaderProps> = ({
  onOpenSidebar,
  activeView,
  studentProfile,
  currentUser,
  onLogout,
  onNavigateToAuth,
}) => {
  const viewTitles: Record<string, string> = {
    auth: 'Sign In / Sign Up',
    landing: 'Home',
    dashboard: 'Dashboard',
    assessment: 'Assessment',
    library: 'Career Library',
    mentor: 'AI Mentor (n8n)',
    roadmap: 'Roadmap',
    compare: 'Comparison',
    report: 'Diagnostic Report',
  };

  return (
    <header className="lg:hidden sticky top-0 z-20 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 text-white px-4 py-3 flex items-center justify-between print:hidden">
      <div className="flex items-center gap-2.5">
        <button
          onClick={onOpenSidebar}
          className="p-2 rounded-xl bg-slate-800 text-slate-200 hover:text-white border border-slate-700"
          aria-label="Open Sidebar Menu"
        >
          <Menu className="h-5 w-5" />
        </button>

        <div className="flex items-center gap-2">
          <div className="h-7 w-7 rounded-lg bg-gradient-to-tr from-cyan-500 to-teal-400 p-0.5">
            <div className="h-full w-full bg-slate-950 rounded-[6px] flex items-center justify-center">
              <Compass className="h-3.5 w-3.5 text-cyan-400" />
            </div>
          </div>
          <div>
            <span className="font-bold text-sm tracking-tight text-white font-['Space_Grotesk']">
              PathPilot<span className="text-cyan-400">.ai</span>
            </span>
            <span className="text-[10px] text-cyan-400 ml-1.5 font-medium">
              • {viewTitles[activeView] || 'Overview'}
            </span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2">
        {currentUser ? (
          <button
            onClick={onLogout}
            className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-rose-950/80 border border-rose-800/80 text-rose-300 hover:bg-rose-900/80"
          >
            Log Out
          </button>
        ) : (
          <button
            onClick={onNavigateToAuth}
            className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-cyan-950/80 border border-cyan-800/80 text-cyan-300 hover:bg-cyan-900/80"
          >
            Sign In
          </button>
        )}
      </div>
    </header>
  );
};
