import React, { useState } from 'react';
import {
  Compass,
  LayoutDashboard,
  ClipboardList,
  BookOpen,
  BotMessageSquare,
  Milestone,
  GitCompare,
  FileText,
  User,
  Menu,
  X,
  ChevronDown,
  Sparkles,
} from 'lucide-react';
import { StudentProfile } from '../../types';
import { DEMO_PROFILES } from '../../services/storageService';

interface HeaderProps {
  activeView: string;
  setActiveView: (view: string) => void;
  studentProfile: StudentProfile;
  onSwitchProfile: (profileKey: string) => void;
  onOpenOnboarding: () => void;
  hasDraft: boolean;
  hasResults: boolean;
  savedCareersCount: number;
  compareCareersCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeView,
  setActiveView,
  studentProfile,
  onSwitchProfile,
  onOpenOnboarding,
  hasDraft,
  hasResults,
  savedCareersCount,
  compareCareersCount,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    {
      id: 'assessment',
      label: 'Assessment',
      icon: ClipboardList,
      badge: hasDraft ? 'Draft' : hasResults ? 'Done' : 'New',
      badgeColor: hasDraft ? 'bg-amber-100 text-amber-800' : hasResults ? 'bg-emerald-100 text-emerald-800' : 'bg-cyan-100 text-cyan-800',
    },
    { id: 'library', label: 'Careers', icon: BookOpen },
    { id: 'mentor', label: 'AI Mentor', icon: BotMessageSquare, special: true },
    { id: 'roadmap', label: 'Roadmap', icon: Milestone },
    {
      id: 'compare',
      label: 'Compare',
      icon: GitCompare,
      badge: compareCareersCount > 0 ? String(compareCareersCount) : undefined,
      badgeColor: 'bg-indigo-100 text-indigo-800',
    },
    { id: 'report', label: 'Report', icon: FileText },
  ];

  const stageLabels: Record<string, string> = {
    class_8_9: 'Class 8–9',
    class_10: 'Class 10',
    class_11_12: 'Class 11–12',
    diploma: 'Polytechnic Diploma',
    undergraduate: 'Undergraduate',
    postgraduate: 'Postgraduate',
    working_professional: 'Working Pro',
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 text-white shadow-sm print:hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo & Tagline */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveView('landing')}>
            <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-cyan-500 via-teal-400 to-emerald-400 p-0.5 shadow-md shadow-cyan-500/20">
              <div className="h-full w-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Compass className="h-5 w-5 text-cyan-400 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg tracking-tight text-white font-['Space_Grotesk']">
                  PathPilot<span className="text-cyan-400">.ai</span>
                </span>
                <span className="text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">
                  Career Intelligence
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Your career. Your strengths. Your direction.
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveView(item.id)}
                  className={`relative px-3 py-2 rounded-lg text-xs font-medium transition-all duration-150 flex items-center gap-1.5 ${
                    isActive
                      ? 'bg-slate-800 text-cyan-400 border border-slate-700/80 shadow-inner'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className={`h-4 w-4 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full ${item.badgeColor || 'bg-slate-700 text-slate-200'}`}>
                      {item.badge}
                    </span>
                  )}
                  {item.special && (
                    <Sparkles className="h-3 w-3 text-amber-400" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* User Profile / Stage Switcher */}
          <div className="hidden sm:flex items-center gap-3">
            <div className="relative">
              <button
                onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                className="flex items-center gap-2.5 px-3 py-1.5 rounded-lg bg-slate-800/90 hover:bg-slate-800 border border-slate-700 text-left transition-colors"
              >
                <div className="h-7 w-7 rounded-full bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 flex items-center justify-center font-semibold text-xs">
                  {studentProfile.name.charAt(0)}
                </div>
                <div>
                  <div className="text-xs font-medium text-slate-200 leading-tight">
                    {studentProfile.name}
                  </div>
                  <div className="text-[10px] text-cyan-400 font-normal">
                    {stageLabels[studentProfile.stage] || studentProfile.stage}
                  </div>
                </div>
                <ChevronDown className="h-3.5 w-3.5 text-slate-400" />
              </button>

              {/* Profile Dropdown */}
              {profileDropdownOpen && (
                <div
                  className="absolute right-0 mt-2 w-72 bg-slate-900 border border-slate-700 rounded-xl shadow-xl py-2 z-50 animate-in fade-in slide-in-from-top-2"
                  onMouseLeave={() => setProfileDropdownOpen(false)}
                >
                  <div className="px-3 py-2 border-b border-slate-800">
                    <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      Switch Demo Stage Persona
                    </p>
                    <p className="text-[11px] text-slate-500">
                      Test stage-specific conditional questionnaires & pathways
                    </p>
                  </div>

                  <div className="py-1">
                    <button
                      onClick={() => {
                        onSwitchProfile('diploma');
                        setProfileDropdownOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-slate-800 flex items-center justify-between text-xs text-slate-200"
                    >
                      <div>
                        <span className="font-medium text-cyan-400">Priya (Diploma Final Year)</span>
                        <div className="text-[10px] text-slate-400">Mechanical, Lateral Entry & Jobs</div>
                      </div>
                      {studentProfile.stage === 'diploma' && (
                        <span className="h-2 w-2 rounded-full bg-emerald-400"></span>
                      )}
                    </button>

                    <button
                      onClick={() => {
                        onSwitchProfile('class_10');
                        setProfileDropdownOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-slate-800 flex items-center justify-between text-xs text-slate-200"
                    >
                      <div>
                        <span className="font-medium text-amber-400">Aarav (Class 10)</span>
                        <div className="text-[10px] text-slate-400">Stream Exploration (PCM/Comm/Arts)</div>
                      </div>
                      {studentProfile.stage === 'class_10' && (
                        <span className="h-2 w-2 rounded-full bg-emerald-400"></span>
                      )}
                    </button>

                    <button
                      onClick={() => {
                        onSwitchProfile('class_11_12');
                        setProfileDropdownOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-slate-800 flex items-center justify-between text-xs text-slate-200"
                    >
                      <div>
                        <span className="font-medium text-purple-400">Sneha (Class 11–12 PCM)</span>
                        <div className="text-[10px] text-slate-400">JEE/CUET/Design entrance planning</div>
                      </div>
                      {studentProfile.stage === 'class_11_12' && (
                        <span className="h-2 w-2 rounded-full bg-emerald-400"></span>
                      )}
                    </button>

                    <button
                      onClick={() => {
                        onSwitchProfile('undergrad');
                        setProfileDropdownOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-slate-800 flex items-center justify-between text-xs text-slate-200"
                    >
                      <div>
                        <span className="font-medium text-emerald-400">Rohan (Undergrad B.Tech)</span>
                        <div className="text-[10px] text-slate-400">Software Placements & Cloud Roadmap</div>
                      </div>
                      {studentProfile.stage === 'undergraduate' && (
                        <span className="h-2 w-2 rounded-full bg-emerald-400"></span>
                      )}
                    </button>

                    <button
                      onClick={() => {
                        onSwitchProfile('working_pro');
                        setProfileDropdownOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-slate-800 flex items-center justify-between text-xs text-slate-200"
                    >
                      <div>
                        <span className="font-medium text-rose-400">Vikram (Working Pro - 3 Yrs)</span>
                        <div className="text-[10px] text-slate-400">Career Pivot from QA to AI/DevOps</div>
                      </div>
                      {studentProfile.stage === 'working_professional' && (
                        <span className="h-2 w-2 rounded-full bg-emerald-400"></span>
                      )}
                    </button>
                  </div>

                  <div className="border-t border-slate-800 p-2">
                    <button
                      onClick={() => {
                        onOpenOnboarding();
                        setProfileDropdownOpen(false);
                      }}
                      className="w-full py-1.5 px-3 rounded-lg bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 text-xs font-medium flex items-center justify-center gap-1.5 border border-cyan-500/30 transition-colors"
                    >
                      <User className="h-3.5 w-3.5" />
                      Edit My Profile & Goals
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Mobile menu trigger */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={() => onOpenOnboarding()}
              className="text-xs bg-slate-800 px-2.5 py-1.5 rounded-lg border border-slate-700 text-cyan-300"
            >
              Stage: {stageLabels[studentProfile.stage]?.split(' ')[0]}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Panel */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-slate-900 border-b border-slate-800 px-4 pt-2 pb-4 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveView(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium ${
                  isActive
                    ? 'bg-slate-800 text-cyan-400'
                    : 'text-slate-300 hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className="h-4 w-4" />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className={`text-xs px-2 py-0.5 rounded-full ${item.badgeColor}`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
          <div className="pt-2 border-t border-slate-800">
            <button
              onClick={() => {
                onOpenOnboarding();
                setMobileMenuOpen(false);
              }}
              className="w-full text-center py-2 rounded-lg bg-cyan-600 text-white text-xs font-semibold"
            >
              Configure Profile & Education Stage
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
