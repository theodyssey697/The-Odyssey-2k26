import React, { useState } from 'react';
import {
  Compass,
  LayoutDashboard,
  ClipboardList,
  BookOpen,
  BotMessageSquare,
  Milestone,
  GitCompare,
  FileText,
  User,
  ChevronDown,
  Sparkles,
  Workflow,
  X,
  Menu,
  LogOut,
  LogIn,
} from 'lucide-react';
import { StudentProfile } from '../../types';

interface SidebarProps {
  activeView: string;
  setActiveView: (view: string) => void;
  studentProfile: StudentProfile;
  onSwitchProfile: (profileKey: string) => void;
  onOpenOnboarding: () => void;
  hasDraft: boolean;
  hasResults: boolean;
  savedCareersCount: number;
  compareCareersCount: number;
  mobileOpen: boolean;
  setMobileOpen: (open: boolean) => void;
  currentUser?: { email?: string | null } | null;
  onLogout?: () => void;
  onNavigateToAuth?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeView,
  setActiveView,
  studentProfile,
  onSwitchProfile,
  onOpenOnboarding,
  hasDraft,
  hasResults,
  savedCareersCount,
  compareCareersCount,
  mobileOpen,
  setMobileOpen,
  currentUser,
  onLogout,
  onNavigateToAuth,
}) => {
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);

  const navItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      description: 'Overview & progress',
      icon: LayoutDashboard,
      iconColor: 'text-cyan-600',
    },
    {
      id: 'assessment',
      label: 'Assessment',
      description: 'Stage-tailored wizard',
      icon: ClipboardList,
      iconColor: 'text-teal-600',
      badge: hasDraft ? 'Draft' : hasResults ? 'Done' : 'New',
      badgeColor: hasDraft
        ? 'bg-amber-100 text-amber-900 border-amber-300'
        : hasResults
        ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
        : 'bg-cyan-100 text-cyan-900 border-cyan-300',
    },
    {
      id: 'library',
      label: 'Career Library',
      description: '30+ verified dossiers',
      icon: BookOpen,
      iconColor: 'text-indigo-600',
    },
    {
      id: 'mentor',
      label: 'AI Mentor',
      description: 'n8n & Gemini counselling',
      icon: BotMessageSquare,
      iconColor: 'text-violet-600',
      specialBadge: 'n8n Active',
    },
    {
      id: 'roadmap',
      label: 'Career Roadmap',
      description: '30-60-90 Day milestones',
      icon: Milestone,
      iconColor: 'text-emerald-600',
    },
    {
      id: 'compare',
      label: 'Compare Careers',
      description: 'Side-by-side matrices',
      icon: GitCompare,
      iconColor: 'text-rose-600',
      badge: compareCareersCount > 0 ? `${compareCareersCount}/3` : undefined,
      badgeColor: 'bg-rose-100 text-rose-900 border-rose-300',
    },
    {
      id: 'report',
      label: 'Diagnostic Report',
      description: 'Printable PDF dossier',
      icon: FileText,
      iconColor: 'text-amber-600',
    },
  ];

  const stageLabels: Record<string, string> = {
    class_8_9: 'Class 8–9',
    class_10: 'Class 10 Explorer',
    class_11_12: 'Class 11–12 Senior',
    diploma: 'Polytechnic Diploma',
    undergraduate: 'Undergraduate',
    postgraduate: 'Postgraduate',
    working_professional: 'Working Pro',
  };

  const sidebarContent = (
    <div className="flex flex-col h-full bg-slate-900 border-r border-slate-800 text-slate-100 p-4 justify-between select-none">
      <div className="space-y-5">
        {/* Brand Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800/90">
          <div
            className="flex items-center gap-2.5 cursor-pointer group"
            onClick={() => {
              setActiveView('landing');
              setMobileOpen(false);
            }}
          >
            <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-cyan-500 via-teal-400 to-emerald-400 p-0.5 shadow-md shadow-cyan-500/20 group-hover:scale-105 transition-transform shrink-0">
              <div className="h-full w-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Compass className="h-5 w-5 text-cyan-400 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-base tracking-tight text-white font-['Space_Grotesk']">
                  PathPilot<span className="text-cyan-400">.ai</span>
                </span>
                <span className="text-[9px] font-bold uppercase tracking-wider px-1 py-0.2 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">
                  Pro
                </span>
              </div>
              <p className="text-[10px] text-slate-400 leading-tight">
                Your career. Your strengths.
              </p>
            </div>
          </div>

          {/* Close button on mobile */}
          <button
            onClick={() => setMobileOpen(false)}
            className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Student Profile Card with Persona Switcher */}
        <div className="relative">
          <button
            onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
            className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-950/80 hover:bg-slate-950 border border-slate-800 hover:border-slate-700 transition-all text-left"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="h-8 w-8 rounded-full bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 flex items-center justify-center font-bold text-xs shrink-0">
                {currentUser?.email ? currentUser.email.charAt(0).toUpperCase() : studentProfile.name.charAt(0)}
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-xs font-semibold text-white truncate">
                  {currentUser?.email || studentProfile.name}
                </div>
                <div className="text-[10px] text-cyan-400 truncate">
                  {currentUser ? 'Firebase Authenticated' : (stageLabels[studentProfile.stage] || studentProfile.stage)}
                </div>
              </div>
            </div>
            <ChevronDown className="h-3.5 w-3.5 text-slate-400 shrink-0 ml-1" />
          </button>

          {/* Stage Dropdown */}
          {profileDropdownOpen && (
            <div
              className="absolute left-0 right-0 mt-2 bg-slate-950 border border-slate-700 rounded-xl shadow-2xl py-2 z-50 animate-in fade-in slide-in-from-top-2 text-xs"
              onMouseLeave={() => setProfileDropdownOpen(false)}
            >
              <div className="px-3 py-1.5 border-b border-slate-800">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  Switch Demo Persona
                </p>
              </div>

              <div className="py-1">
                <button
                  onClick={() => {
                    onSwitchProfile('diploma');
                    setProfileDropdownOpen(false);
                    setMobileOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 hover:bg-slate-800 flex items-center justify-between text-slate-200"
                >
                  <div>
                    <span className="font-semibold text-cyan-400">Priya (Diploma Final Year)</span>
                    <div className="text-[10px] text-slate-400">Mechanical, Lateral Entry (LEET)</div>
                  </div>
                  {studentProfile.stage === 'diploma' && <span className="h-2 w-2 rounded-full bg-emerald-400" />}
                </button>

                <button
                  onClick={() => {
                    onSwitchProfile('class_10');
                    setProfileDropdownOpen(false);
                    setMobileOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 hover:bg-slate-800 flex items-center justify-between text-slate-200"
                >
                  <div>
                    <span className="font-semibold text-amber-400">Aarav (Class 10)</span>
                    <div className="text-[10px] text-slate-400">Stream Exploration (PCM/Comm/Arts)</div>
                  </div>
                  {studentProfile.stage === 'class_10' && <span className="h-2 w-2 rounded-full bg-emerald-400" />}
                </button>

                <button
                  onClick={() => {
                    onSwitchProfile('class_11_12');
                    setProfileDropdownOpen(false);
                    setMobileOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 hover:bg-slate-800 flex items-center justify-between text-slate-200"
                >
                  <div>
                    <span className="font-semibold text-purple-400">Sneha (Class 11–12 PCM)</span>
                    <div className="text-[10px] text-slate-400">JEE/CUET/Design entrance planning</div>
                  </div>
                  {studentProfile.stage === 'class_11_12' && <span className="h-2 w-2 rounded-full bg-emerald-400" />}
                </button>

                <button
                  onClick={() => {
                    onSwitchProfile('undergrad');
                    setProfileDropdownOpen(false);
                    setMobileOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 hover:bg-slate-800 flex items-center justify-between text-slate-200"
                >
                  <div>
                    <span className="font-semibold text-emerald-400">Rohan (Undergrad B.Tech)</span>
                    <div className="text-[10px] text-slate-400">Software Placements & Cloud Roadmap</div>
                  </div>
                  {studentProfile.stage === 'undergraduate' && <span className="h-2 w-2 rounded-full bg-emerald-400" />}
                </button>
              </div>

              <div className="border-t border-slate-800 p-2 space-y-1">
                <button
                  onClick={() => {
                    onOpenOnboarding();
                    setProfileDropdownOpen(false);
                    setMobileOpen(false);
                  }}
                  className="w-full py-1.5 px-3 rounded-lg bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 text-xs font-semibold flex items-center justify-center gap-1.5 border border-cyan-500/30 transition-colors"
                >
                  <User className="h-3.5 w-3.5" />
                  Customize My Profile
                </button>

                {currentUser && onLogout && (
                  <button
                    onClick={() => {
                      onLogout();
                      setProfileDropdownOpen(false);
                      setMobileOpen(false);
                    }}
                    className="w-full py-1.5 px-3 rounded-lg bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 text-xs font-semibold flex items-center justify-center gap-1.5 border border-rose-800/80 transition-colors"
                  >
                    <LogOut className="h-3.5 w-3.5" />
                    Log Out
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* SIDEBAR NAVIGATION TABS WITH PEARL WHITE BACKGROUND */}
        <div className="space-y-2">
          <div className="flex items-center justify-between px-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
              Navigation Menu
            </span>
            <span className="text-[9px] text-cyan-400 font-semibold">
              Pearl White Tabs
            </span>
          </div>

          <nav className="space-y-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeView === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveView(item.id);
                    setMobileOpen(false);
                  }}
                  style={{ backgroundColor: '#FAF9F6' }}
                  className={`w-full text-left p-3 rounded-2xl transition-all duration-200 flex items-center justify-between gap-3 shadow-sm hover:shadow-md ${
                    isActive
                      ? 'border-2 border-cyan-500 ring-2 ring-cyan-400/30 shadow-md scale-[1.01]'
                      : 'border border-slate-200/90 hover:border-cyan-400/70 hover:scale-[1.005]'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`h-9 w-9 rounded-xl flex items-center justify-center shrink-0 shadow-xs ${
                        isActive
                          ? 'bg-cyan-600 text-white'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      <Icon className="h-4 w-4" />
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`text-xs tracking-tight ${
                            isActive
                              ? 'font-extrabold text-slate-950'
                              : 'font-bold text-slate-900'
                          }`}
                        >
                          {item.label}
                        </span>
                        {item.specialBadge && (
                          <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-violet-100 text-violet-800 border border-violet-200 flex items-center gap-0.5">
                            <Workflow className="h-2.5 w-2.5 text-violet-600" />
                            {item.specialBadge}
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-slate-500 font-normal truncate mt-0.5">
                        {item.description}
                      </p>
                    </div>
                  </div>

                  {item.badge && (
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full border shrink-0 ${
                        item.badgeColor || 'bg-slate-200 text-slate-800'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Bottom Footer Info in Sidebar */}
      <div className="pt-4 mt-4 border-t border-slate-800 space-y-3">
        {/* n8n Integration indicator */}
        <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800/90 space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              n8n Cloud Workflow
            </span>
            <span className="text-[9px] text-emerald-400 font-bold bg-emerald-950/80 px-1.5 py-0.2 rounded border border-emerald-800">
              Live
            </span>
          </div>
          <p className="text-[10px] text-slate-400 leading-tight">
            Connected to Roomora Concierge webhook
          </p>
        </div>

        <button
          onClick={() => {
            onOpenOnboarding();
            setMobileOpen(false);
          }}
          className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 border border-slate-700 transition-colors"
        >
          <User className="h-3.5 w-3.5 text-cyan-400" />
          <span>Edit Profile & Preferences</span>
        </button>

        {/* Firebase Authentication: Logout / Sign-In Button */}
        {currentUser ? (
          <button
            onClick={() => {
              if (onLogout) onLogout();
              setMobileOpen(false);
            }}
            className="w-full py-2.5 px-3 rounded-xl bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 hover:text-white text-xs font-bold flex items-center justify-center gap-2 border border-rose-800/80 transition-colors shadow-sm"
          >
            <LogOut className="h-4 w-4" />
            <span>Log Out</span>
          </button>
        ) : (
          <button
            onClick={() => {
              if (onNavigateToAuth) onNavigateToAuth();
              setMobileOpen(false);
            }}
            className="w-full py-2.5 px-3 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 hover:text-white text-xs font-bold flex items-center justify-center gap-2 border border-cyan-500/40 transition-colors shadow-sm"
          >
            <LogIn className="h-4 w-4" />
            <span>Sign In / Sign Up</span>
          </button>
        )}
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Left Sidebar: Always visible on large screens */}
      <aside className="hidden lg:flex w-64 xl:w-72 h-screen sticky top-0 shrink-0 z-30 print:hidden">
        {sidebarContent}
      </aside>

      {/* Mobile Slide-in Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm transition-opacity"
            onClick={() => setMobileOpen(false)}
          />
          <div className="relative w-72 max-w-[85vw] h-full z-10 shadow-2xl animate-in slide-in-from-left duration-200">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};
