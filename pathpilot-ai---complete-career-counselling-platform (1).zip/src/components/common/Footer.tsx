import React from 'react';
import { Compass, ShieldCheck, HeartHandshake, Sparkles, ExternalLink } from 'lucide-react';

interface FooterProps {
  onNavigate: (view: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 text-slate-400 py-12 px-4 sm:px-6 lg:px-8 print:hidden">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Brand info */}
          <div className="space-y-4 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 flex items-center justify-center">
                <Compass className="h-4 w-4" />
              </div>
              <span className="font-bold text-white text-base font-['Space_Grotesk']">
                PathPilot<span className="text-cyan-400">.ai</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Your career. Your strengths. Your direction. A transparent, stage-tailored career counseling platform empowering students and professionals in India and worldwide.
            </p>
            <div className="flex items-center gap-2 text-[11px] text-emerald-400 font-medium">
              <ShieldCheck className="h-3.5 w-3.5" />
              <span>Independent, Unbiased, Student-First</span>
            </div>
          </div>

          {/* Platform Exploration */}
          <div>
            <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">
              Platform Features
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onNavigate('assessment')} className="hover:text-cyan-400 transition-colors">
                  Multidimensional Assessment (1-by-1)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('library')} className="hover:text-cyan-400 transition-colors">
                  Career Knowledge Base (30+ Profiles)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('mentor')} className="hover:text-cyan-400 transition-colors flex items-center gap-1">
                  AI Career Mentor <Sparkles className="h-3 w-3 text-amber-400" />
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('roadmap')} className="hover:text-cyan-400 transition-colors">
                  Actionable 90-Day Roadmaps
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('compare')} className="hover:text-cyan-400 transition-colors">
                  Side-by-Side Career Comparison
                </button>
              </li>
            </ul>
          </div>

          {/* Education Stages */}
          <div>
            <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">
              Education Stages
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onNavigate('assessment')} className="hover:text-cyan-400 transition-colors">
                  Class 10 Stream Exploration
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('assessment')} className="hover:text-cyan-400 transition-colors">
                  Classes 11–12 Degree & Exam Planning
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('assessment')} className="hover:text-cyan-400 transition-colors">
                  Polytechnic Diploma & Lateral Entry (LEET)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('assessment')} className="hover:text-cyan-400 transition-colors">
                  Undergraduate & Engineering Placements
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('assessment')} className="hover:text-cyan-400 transition-colors">
                  Working Professional Career Pivots
                </button>
              </li>
            </ul>
          </div>

          {/* Ethical & Trust Disclaimers */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-1 flex items-center gap-1.5">
              <HeartHandshake className="h-3.5 w-3.5 text-cyan-400" />
              Ethics & Trust Notice
            </h4>
            <p className="text-[11px] text-slate-400 leading-relaxed bg-slate-900/60 p-3 rounded-lg border border-slate-800">
              PathPilot AI produces indicative profile-fit estimates derived from self-reported answers and deterministic rubrics. It is neither a psychological diagnostic nor a guarantee of college admission, employment, or exact salary. For high-stakes decisions, students should consult certified career counselors and family mentors.
            </p>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-400 gap-4">
          <p>© {new Date().getFullYear()} PathPilot AI. Crafted for student empowerment. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <button onClick={() => onNavigate('landing')} className="hover:text-slate-300">Privacy Principles</button>
            <span>•</span>
            <button onClick={() => onNavigate('landing')} className="hover:text-slate-300">Methodology & Rubrics</button>
            <span>•</span>
            <button onClick={() => onNavigate('report')} className="hover:text-slate-300">Sample Report</button>
          </div>
        </div>
      </div>
    </footer>
  );
};
