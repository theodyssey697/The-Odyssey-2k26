import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Bookmark,
  BookmarkCheck,
  GitCompare,
  Milestone,
  BotMessageSquare,
  X,
  ExternalLink,
  GraduationCap,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  Building,
  DollarSign,
  BookOpen,
} from 'lucide-react';
import { CareerProfile } from '../../types';
import { CAREERS_DATA } from '../../data/careersData';
import { storageService } from '../../services/storageService';

interface CareerLibraryViewProps {
  onSelectCareerForRoadmap: (career: CareerProfile) => void;
  onSelectCareerForMentor: (career: CareerProfile) => void;
  onNavigate: (view: string) => void;
}

export const CareerLibraryView: React.FC<CareerLibraryViewProps> = ({
  onSelectCareerForRoadmap,
  onSelectCareerForMentor,
  onNavigate,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [diplomaOnlyFilter, setDiplomaOnlyFilter] = useState(false);
  const [selectedCareerModal, setSelectedCareerModal] = useState<CareerProfile | null>(null);

  const [savedIds, setSavedIds] = useState<string[]>(() => storageService.getSavedCareerIds());
  const [compareIds, setCompareIds] = useState<string[]>(() => storageService.getCompareCareerIds());

  const categories = [
    'All',
    'Technology & Software',
    'Engineering & Manufacturing',
    'Healthcare & Life Sciences',
    'Business, Commerce & Finance',
    'Design, Media & Creative',
    'Law, Policy & Public Administration',
  ];

  const filteredCareers = useMemo(() => {
    return CAREERS_DATA.filter((c) => {
      // Category filter
      if (selectedCategory !== 'All' && c.category !== selectedCategory) {
        return false;
      }

      // Diploma friendly filter
      if (diplomaOnlyFilter) {
        if (!c.educationPathways.diplomaAndLateralRoutes || c.educationPathways.diplomaAndLateralRoutes.length === 0) {
          return false;
        }
      }

      // Search query filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = c.title.toLowerCase().includes(q);
        const matchesCategory = c.category.toLowerCase().includes(q);
        const matchesDesc = c.shortDescription.toLowerCase().includes(q) || c.fullDescription.toLowerCase().includes(q);
        const matchesSkills = c.coreSkills.technical.some((s) => s.toLowerCase().includes(q));
        const matchesExams = c.educationPathways.keyEntranceExams.some((e) => e.toLowerCase().includes(q));
        if (!matchesTitle && !matchesCategory && !matchesDesc && !matchesSkills && !matchesExams) {
          return false;
        }
      }

      return true;
    });
  }, [searchQuery, selectedCategory, diplomaOnlyFilter]);

  const handleToggleSave = (id: string) => {
    const updated = storageService.toggleSaveCareer(id);
    setSavedIds(updated);
  };

  const handleToggleCompare = (id: string) => {
    const updated = storageService.toggleCompareCareer(id);
    setCompareIds(updated);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-md bg-cyan-950 text-cyan-300 border border-cyan-800">
              Verified Career Library
            </span>
            <span className="text-xs text-slate-400">
              {filteredCareers.length} Careers Documented
            </span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-white font-['Space_Grotesk'] tracking-tight">
            Explore Career Pathways & Gateways
          </h1>
          <p className="text-sm text-slate-400 mt-2 max-w-2xl leading-relaxed">
            Detailed profiles featuring verified degree routes, polytechnic diploma lateral options (LEET), entrance exam timelines, starter projects, and indicative salary bands.
          </p>
        </div>

        {/* Filters and Search Bar */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row items-center gap-3">
            {/* Search Input */}
            <div className="relative flex-1 w-full">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by career, skill (e.g. Python, CAD, Tax), or entrance exam (JEE, LEET, NEET)..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
              />
            </div>

            {/* Diploma friendly filter toggle */}
            <button
              onClick={() => setDiplomaOnlyFilter(!diplomaOnlyFilter)}
              className={`px-3.5 py-2.5 rounded-xl border text-xs font-semibold flex items-center gap-2 shrink-0 transition-all ${
                diplomaOnlyFilter
                  ? 'bg-cyan-950 border-cyan-500 text-cyan-200'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <Building className="h-4 w-4" />
              <span>Diploma / Lateral Friendly</span>
              {diplomaOnlyFilter && <span className="h-2 w-2 rounded-full bg-cyan-400" />}
            </button>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {categories.map((cat) => {
              const isSelected = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-colors ${
                    isSelected
                      ? 'bg-cyan-600 text-white font-semibold shadow-md shadow-cyan-950'
                      : 'bg-slate-950/80 text-slate-400 hover:text-slate-200 border border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </div>

        {/* Career Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredCareers.map((career) => {
            const isSaved = savedIds.includes(career.id);
            const isComparing = compareIds.includes(career.id);

            return (
              <div
                key={career.id}
                className="bg-slate-900 border border-slate-800 hover:border-slate-700/80 rounded-2xl p-5 sm:p-6 flex flex-col justify-between gap-5 transition-all hover:shadow-xl hover:-translate-y-0.5 group"
              >
                <div>
                  {/* Category & Bookmarks */}
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-950 text-slate-300 border border-slate-800">
                      {career.category}
                    </span>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleToggleCompare(career.id)}
                        title={isComparing ? 'Remove from compare' : 'Compare side-by-side'}
                        className={`p-1.5 rounded-lg border transition-colors ${
                          isComparing
                            ? 'bg-indigo-950 border-indigo-500 text-indigo-300'
                            : 'bg-slate-950 border-slate-800 text-slate-500 hover:text-white'
                        }`}
                      >
                        <GitCompare className="h-3.5 w-3.5" />
                      </button>

                      <button
                        onClick={() => handleToggleSave(career.id)}
                        title={isSaved ? 'Bookmarked' : 'Bookmark career'}
                        className={`p-1.5 rounded-lg border transition-colors ${
                          isSaved
                            ? 'bg-amber-950 border-amber-500 text-amber-300'
                            : 'bg-slate-950 border-slate-800 text-slate-500 hover:text-white'
                        }`}
                      >
                        {isSaved ? (
                          <BookmarkCheck className="h-3.5 w-3.5 text-amber-400" />
                        ) : (
                          <Bookmark className="h-3.5 w-3.5" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Title & Description */}
                  <h3 className="text-base sm:text-lg font-bold text-white font-['Space_Grotesk'] group-hover:text-cyan-300 transition-colors">
                    {career.title}
                  </h3>
                  <p className="text-xs text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                    {career.shortDescription}
                  </p>

                  {/* Key Skills */}
                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {career.coreSkills.technical.slice(0, 3).map((skill, i) => (
                      <span
                        key={i}
                        className="text-[10px] bg-slate-950/80 text-cyan-300/90 px-2 py-0.5 rounded border border-slate-800"
                      >
                        {skill}
                      </span>
                    ))}
                    {career.coreSkills.technical.length > 3 && (
                      <span className="text-[10px] text-slate-500 px-1 py-0.5">
                        +{career.coreSkills.technical.length - 3} more
                      </span>
                    )}
                  </div>
                </div>

                {/* Footer metadata & triggers */}
                <div className="pt-4 border-t border-slate-800/80 space-y-3">
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>Indicative Starting:</span>
                    <span className="text-emerald-400 font-bold">
                      {career.salaryIndicative.entryLevelINR.split('–')[0]}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setSelectedCareerModal(career)}
                      className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
                    >
                      Full Dossier
                    </button>
                    <button
                      onClick={() => onSelectCareerForRoadmap(career)}
                      className="w-full py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition-all shadow-md shadow-cyan-950 flex items-center justify-center gap-1"
                    >
                      <Milestone className="h-3.5 w-3.5" />
                      <span>Roadmap</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {filteredCareers.length === 0 && (
          <div className="text-center py-16 bg-slate-900 border border-slate-800 rounded-3xl p-8 space-y-3">
            <BookOpen className="h-8 w-8 text-slate-600 mx-auto" />
            <h3 className="text-base font-bold text-white">No careers match your filter</h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Try clearing the search query or selecting "All" categories to view all available pathways.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('All');
                setDiplomaOnlyFilter(false);
              }}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs font-medium rounded-xl border border-slate-700"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>

      {/* Full Career Detail Modal */}
      {selectedCareerModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="p-6 sm:p-8 border-b border-slate-800 bg-slate-950 flex items-start justify-between gap-4">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">
                  {selectedCareerModal.category}
                </span>
                <h2 className="text-xl sm:text-3xl font-extrabold text-white font-['Space_Grotesk'] mt-2">
                  {selectedCareerModal.title}
                </h2>
                <p className="text-xs sm:text-sm text-slate-400 mt-1 leading-relaxed">
                  {selectedCareerModal.shortDescription}
                </p>
              </div>
              <button
                onClick={() => setSelectedCareerModal(null)}
                className="text-slate-400 hover:text-white p-2 rounded-xl bg-slate-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 sm:p-8 overflow-y-auto space-y-6 flex-1 text-slate-300 text-xs sm:text-sm">
              {/* Detailed Overview */}
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                  Comprehensive Overview
                </h4>
                <p className="text-slate-300 leading-relaxed text-xs sm:text-sm">
                  {selectedCareerModal.fullDescription}
                </p>
              </div>

              {/* Responsibilities */}
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                  Typical Day-to-Day Responsibilities
                </h4>
                <ul className="space-y-1.5 text-xs text-slate-300">
                  {selectedCareerModal.typicalResponsibilities.map((resp, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-cyan-400 font-bold">•</span>
                      <span>{resp}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Educational Pathways */}
              <div className="space-y-3 p-4 bg-slate-950 rounded-2xl border border-slate-800">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <GraduationCap className="h-4 w-4 text-cyan-400" />
                  Educational Pathways & Entry Gates
                </h4>

                <div className="space-y-2 text-xs">
                  <div>
                    <span className="font-semibold text-slate-300">Degree Routes:</span>
                    <ul className="mt-1 space-y-0.5 text-slate-400 pl-3">
                      {selectedCareerModal.educationPathways.degreeRoutes.map((r, i) => (
                        <li key={i}>• {r}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <span className="font-semibold text-cyan-300">Diploma & Lateral Entry (LEET):</span>
                    <ul className="mt-1 space-y-0.5 text-slate-400 pl-3">
                      {selectedCareerModal.educationPathways.diplomaAndLateralRoutes.map((r, i) => (
                        <li key={i}>• {r}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <span className="font-semibold text-amber-300">Key Entrance Exams:</span>
                    <p className="mt-1 text-slate-300 pl-3">
                      {selectedCareerModal.educationPathways.keyEntranceExams.join(', ')}
                    </p>
                  </div>
                </div>
              </div>

              {/* Starter Projects & Portfolios */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                  <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="h-3.5 w-3.5" />
                    Beginner Proof-of-Work Projects
                  </h4>
                  <ul className="space-y-1.5 text-xs text-slate-300">
                    {selectedCareerModal.starterProjects.map((proj, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="text-emerald-400">✓</span>
                        <span>{proj}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                  <h4 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                    <DollarSign className="h-3.5 w-3.5" />
                    Indicative Compensation & Source
                  </h4>
                  <div className="text-xs space-y-1">
                    <div>
                      <span className="text-slate-400">Entry Level:</span>{' '}
                      <strong className="text-emerald-400">{selectedCareerModal.salaryIndicative.entryLevelINR}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400">Mid-Career:</span>{' '}
                      <strong className="text-white">{selectedCareerModal.salaryIndicative.midCareerINR}</strong>
                    </div>
                    <div className="text-[11px] text-slate-400 pt-1">
                      Source: {selectedCareerModal.salaryIndicative.source} ({selectedCareerModal.salaryIndicative.updatedDate})
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer Actions */}
            <div className="p-4 sm:p-6 border-t border-slate-800 bg-slate-950 flex flex-wrap items-center justify-between gap-3">
              <button
                onClick={() => {
                  const career = selectedCareerModal;
                  setSelectedCareerModal(null);
                  onSelectCareerForMentor(career);
                }}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-2 border border-slate-700 transition-colors"
              >
                <BotMessageSquare className="h-4 w-4 text-cyan-400" />
                <span>Ask AI Mentor About {selectedCareerModal.title}</span>
              </button>

              <button
                onClick={() => {
                  const career = selectedCareerModal;
                  setSelectedCareerModal(null);
                  onSelectCareerForRoadmap(career);
                }}
                className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-cyan-950 transition-all hover:scale-[1.02]"
              >
                <Milestone className="h-4 w-4" />
                <span>Build 90-Day Action Roadmap</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
