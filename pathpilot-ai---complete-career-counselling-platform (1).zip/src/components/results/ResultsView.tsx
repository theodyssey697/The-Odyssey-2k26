import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  ArrowRight,
  Bookmark,
  BookmarkCheck,
  GitCompare,
  Milestone,
  BotMessageSquare,
  Printer,
  ChevronDown,
  ChevronUp,
  ShieldAlert,
  GraduationCap,
  TrendingUp,
  Brain,
  Layers,
  Heart,
  CheckCircle2,
} from 'lucide-react';
import { AssessmentResult, CareerProfile, StudentProfile } from '../../types';
import { mentorService } from '../../services/mentorService';
import { storageService } from '../../services/storageService';

interface ResultsViewProps {
  studentProfile: StudentProfile;
  result: AssessmentResult;
  onNavigate: (view: string) => void;
  onSelectCareerForRoadmap: (career: CareerProfile) => void;
  onSelectCareerForMentor: (career: CareerProfile) => void;
  onRetakeAssessment: () => void;
}

export const ResultsView: React.FC<ResultsViewProps> = ({
  studentProfile,
  result,
  onNavigate,
  onSelectCareerForRoadmap,
  onSelectCareerForMentor,
  onRetakeAssessment,
}) => {
  const [savedIds, setSavedIds] = useState<string[]>(() => storageService.getSavedCareerIds());
  const [compareIds, setCompareIds] = useState<string[]>(() => storageService.getCompareCareerIds());
  const [expandedCareerId, setExpandedCareerId] = useState<string | null>(
    result.topCareers[0]?.id || null
  );
  const [aiNarrative, setAiNarrative] = useState<string>(result.qualitativeSummary);
  const [loadingAi, setLoadingAi] = useState(false);

  useEffect(() => {
    // Generate fresh qualitative narrative if available
    let isMounted = true;
    async function loadNarrative() {
      setLoadingAi(true);
      try {
        const text = await mentorService.generateReportNarrative(
          studentProfile,
          result.topCareers,
          result.dimensionScores
        );
        if (isMounted && text) setAiNarrative(text);
      } catch (err) {
        console.warn('Narrative error:', err);
      } finally {
        if (isMounted) setLoadingAi(false);
      }
    }

    if (!result.qualitativeSummary || result.qualitativeSummary.length < 50) {
      loadNarrative();
    }
    return () => {
      isMounted = false;
    };
  }, [studentProfile, result]);

  const handleToggleSave = (id: string) => {
    const updated = storageService.toggleSaveCareer(id);
    setSavedIds(updated);
  };

  const handleToggleCompare = (id: string) => {
    const updated = storageService.toggleCompareCareer(id);
    setCompareIds(updated);
  };

  const dimensionCards = [
    { label: 'Analytical Aptitude', score: result.dimensionScores.strengths_aptitude, icon: Brain, color: 'text-emerald-400' },
    { label: 'Curiosity & Interests', score: result.dimensionScores.interests, icon: Sparkles, color: 'text-cyan-400' },
    { label: 'Work Style Alignment', score: result.dimensionScores.work_preferences, icon: Layers, color: 'text-indigo-400' },
    { label: 'Core Values & Motives', score: result.dimensionScores.values_motivators, icon: Heart, color: 'text-rose-400' },
    { label: 'Learning Agility', score: result.dimensionScores.learning_preferences, icon: TrendingUp, color: 'text-teal-400' },
    { label: 'Decision Readiness', score: result.dimensionScores.career_readiness, icon: GraduationCap, color: 'text-amber-400' },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto space-y-10">
        {/* Top Header Card */}
        <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />

          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[11px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-md bg-cyan-950 text-cyan-300 border border-cyan-800">
                  Career Intelligence Synthesis
                </span>
                <span className="text-xs text-slate-400">
                  Completed on {new Date(result.completedAt).toLocaleDateString()}
                </span>
              </div>
              <h1 className="text-2xl sm:text-4xl font-extrabold text-white font-['Space_Grotesk'] tracking-tight">
                Recommended Pathways for <span className="text-cyan-400">{studentProfile.name}</span>
              </h1>
              <p className="text-sm text-slate-400 mt-2 max-w-2xl leading-relaxed">
                Profile Stage:{' '}
                <strong className="text-slate-200 capitalize">
                  {studentProfile.stage.replace('_', ' ')}
                </strong>
                {studentProfile.stageDetails.diplomaBranch && ` • ${studentProfile.stageDetails.diplomaBranch}`}
                {studentProfile.stageDetails.stream11_12 && ` • Stream: ${studentProfile.stageDetails.stream11_12}`}
                {studentProfile.stageDetails.degreeName && ` • ${studentProfile.stageDetails.degreeName}`}
              </p>
            </div>

            {/* Quick Actions */}
            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={() => onNavigate('report')}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-2 border border-slate-700 transition-colors"
              >
                <Printer className="h-4 w-4 text-cyan-400" />
                <span>Full Diagnostic Report</span>
              </button>
              <button
                onClick={() => onNavigate('mentor')}
                className="px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-cyan-950 transition-all hover:scale-[1.02]"
              >
                <BotMessageSquare className="h-4 w-4" />
                <span>Ask AI Mentor</span>
              </button>
            </div>
          </div>

          {/* Ethics / Indicative disclaimer pill */}
          <div className="mt-8 p-3.5 bg-slate-950/70 border border-slate-800 rounded-xl flex items-start sm:items-center gap-3 text-xs text-slate-400">
            <ShieldAlert className="h-4 w-4 shrink-0 text-cyan-400 mt-0.5 sm:mt-0" />
            <span>
              <strong>Ethical Transparency Note:</strong> Fit percentages below are{' '}
              <span className="text-cyan-300 font-medium">indicative profile-fit estimates</span> computed via
              multidimensional rubric matching, not deterministic predictions or admission guarantees. Use them as an empowering compass to prioritize exploration.
            </span>
          </div>

          {/* AI Qualitative Narrative */}
          <div className="mt-6 p-5 bg-gradient-to-r from-cyan-950/40 via-slate-900 to-teal-950/40 rounded-2xl border border-cyan-900/40">
            <div className="flex items-center gap-2 mb-2 text-xs font-bold text-cyan-300 uppercase tracking-wider">
              <Sparkles className="h-4 w-4 text-cyan-400" />
              <span>Personalized Counselor Insight</span>
              {loadingAi && <span className="text-[10px] text-slate-400 font-normal animate-pulse">(Synthesizing nuance...)</span>}
            </div>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {aiNarrative}
            </p>
          </div>
        </div>

        {/* Dimension Breakdown Bar Matrix */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white font-['Space_Grotesk']">
                Multidimensional Profile Calibration
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Evaluated across 6 cognitive, behavioral, and structural dimensions
              </p>
            </div>
            <button
              onClick={onRetakeAssessment}
              className="text-xs text-cyan-400 hover:text-cyan-300 underline font-medium"
            >
              Update / Retake Assessment
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
            {dimensionCards.map((dim) => {
              const Icon = dim.icon;
              return (
                <div
                  key={dim.label}
                  className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-4 flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between mb-3">
                    <Icon className={`h-4 w-4 ${dim.color}`} />
                    <span className="text-sm font-black text-white">{dim.score}%</span>
                  </div>
                  <div>
                    <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mb-2">
                      <div
                        className="bg-gradient-to-r from-cyan-500 to-teal-400 h-full rounded-full"
                        style={{ width: `${dim.score}%` }}
                      />
                    </div>
                    <span className="text-[11px] text-slate-400 font-medium leading-tight block">
                      {dim.label}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Top 5 Recommended Pathways */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-white font-['Space_Grotesk']">
                Top 5 Recommended Career Pathways
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Ranked by alignment with your self-reported preferences, skills, and current education gateway
              </p>
            </div>
            <span className="text-xs text-cyan-400 font-semibold hidden sm:inline">
              Click any card to expand comprehensive roadmap & pathways
            </span>
          </div>

          <div className="space-y-4">
            {result.topCareers.map((career, idx) => {
              const isExpanded = expandedCareerId === career.id;
              const isSaved = savedIds.includes(career.id);
              const isComparing = compareIds.includes(career.id);

              return (
                <div
                  key={career.id}
                  className={`bg-slate-900 border rounded-2xl overflow-hidden transition-all duration-200 ${
                    isExpanded
                      ? 'border-cyan-500/70 shadow-2xl shadow-cyan-950/40 ring-1 ring-cyan-500/30'
                      : 'border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {/* Card Header Summary */}
                  <div className="p-6 sm:p-7 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5">
                    <div className="flex items-start gap-4">
                      {/* Rank badge */}
                      <div className="h-10 w-10 rounded-2xl bg-slate-950 border border-slate-800 text-cyan-400 font-black text-base flex items-center justify-center shrink-0">
                        #{idx + 1}
                      </div>

                      <div>
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                            {career.category}
                          </span>
                          <span className="text-[11px] text-emerald-400 font-bold bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                            {career.fitScore}% Fit Estimate
                          </span>
                        </div>
                        <h3 className="text-lg sm:text-xl font-bold text-white font-['Space_Grotesk']">
                          {career.title}
                        </h3>
                        <p className="text-xs text-slate-400 mt-1 line-clamp-2 max-w-2xl leading-relaxed">
                          {career.shortDescription}
                        </p>
                      </div>
                    </div>

                    {/* Actions & Expand button */}
                    <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleSave(career.id);
                        }}
                        title={isSaved ? 'Remove Bookmark' : 'Save Career'}
                        className={`p-2.5 rounded-xl border transition-colors ${
                          isSaved
                            ? 'bg-amber-950/80 border-amber-500 text-amber-300'
                            : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-white'
                        }`}
                      >
                        {isSaved ? <BookmarkCheck className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleCompare(career.id);
                        }}
                        title={isComparing ? 'Remove from Compare' : 'Add to Compare'}
                        className={`p-2.5 rounded-xl border transition-colors ${
                          isComparing
                            ? 'bg-indigo-950/80 border-indigo-500 text-indigo-300'
                            : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-white'
                        }`}
                      >
                        <GitCompare className="h-4 w-4" />
                      </button>

                      <button
                        onClick={() => setExpandedCareerId(isExpanded ? null : career.id)}
                        className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-colors"
                      >
                        <span>{isExpanded ? 'Less Details' : 'Explore Pathway'}</span>
                        {isExpanded ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
                      </button>
                    </div>
                  </div>

                  {/* Expanded In-Depth Dossier */}
                  {isExpanded && (
                    <div className="px-6 sm:px-7 pb-7 pt-2 border-t border-slate-800/80 space-y-6 bg-slate-950/40 animate-in fade-in duration-200">
                      {/* Why this matches you & Strengths */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-2">
                          <h4 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                            <CheckCircle2 className="h-3.5 w-3.5" />
                            Why This Matches Your Responses
                          </h4>
                          <ul className="space-y-1.5 text-xs text-slate-300">
                            {career.matchReasons.map((reason, rIdx) => (
                              <li key={rIdx} className="flex items-start gap-2">
                                <span className="text-cyan-400 font-bold">•</span>
                                <span>{reason}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-2">
                          <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                            <Sparkles className="h-3.5 w-3.5" />
                            Strengths You Will Utilize
                          </h4>
                          <ul className="space-y-1.5 text-xs text-slate-300">
                            {career.strengthsUtilized.map((str, sIdx) => (
                              <li key={sIdx} className="flex items-start gap-2">
                                <span className="text-emerald-400 font-bold">•</span>
                                <span>{str}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      {/* Educational Gateways (Degree, Diploma lateral, Exams) */}
                      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3">
                        <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                          <GraduationCap className="h-4 w-4 text-cyan-400" />
                          Educational Gateways & Real Pathways
                        </h4>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                            <span className="font-semibold text-slate-300 block mb-1 text-[11px] uppercase tracking-wider">
                              Degree Options
                            </span>
                            <ul className="space-y-1 text-slate-400 text-[11px]">
                              {career.educationPathways.degreeRoutes.slice(0, 2).map((r, i) => (
                                <li key={i}>• {r}</li>
                              ))}
                            </ul>
                          </div>

                          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                            <span className="font-semibold text-cyan-300 block mb-1 text-[11px] uppercase tracking-wider">
                              Diploma & Lateral Options (LEET)
                            </span>
                            <ul className="space-y-1 text-slate-400 text-[11px]">
                              {career.educationPathways.diplomaAndLateralRoutes.slice(0, 2).map((r, i) => (
                                <li key={i}>• {r}</li>
                              ))}
                            </ul>
                          </div>

                          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                            <span className="font-semibold text-amber-300 block mb-1 text-[11px] uppercase tracking-wider">
                              Entrance Exams
                            </span>
                            <p className="text-slate-300 text-[11px] leading-relaxed">
                              {career.educationPathways.keyEntranceExams.slice(0, 3).join(', ')}
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Salary, Projects & Primary Actions */}
                      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
                        <div className="text-xs text-slate-400 self-start sm:self-auto">
                          <span className="font-semibold text-slate-300">Indicative Compensation:</span>{' '}
                          <span className="text-emerald-400 font-bold">{career.salaryIndicative.entryLevelINR}</span>{' '}
                          <span className="text-[10px] text-slate-400">({career.salaryIndicative.notes})</span>
                        </div>

                        <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto">
                          <button
                            onClick={() => onSelectCareerForMentor(career)}
                            className="flex-1 sm:flex-none px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 border border-slate-700 transition-colors"
                          >
                            <BotMessageSquare className="h-3.5 w-3.5 text-cyan-400" />
                            <span>Discuss with AI Mentor</span>
                          </button>

                          <button
                            onClick={() => onSelectCareerForRoadmap(career)}
                            className="flex-1 sm:flex-none px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-cyan-950 transition-all hover:scale-[1.02]"
                          >
                            <Milestone className="h-3.5 w-3.5" />
                            <span>Activate 90-Day Roadmap</span>
                            <ArrowRight className="h-3 w-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Alternative Pathways Section */}
        {result.alternativeCareers.length > 0 && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-4">
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white font-['Space_Grotesk']">
                Alternative & Emerging Pathways
              </h3>
              <p className="text-xs text-slate-400">
                Adjacent careers that share overlapping competencies with your core strengths
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {result.alternativeCareers.slice(0, 3).map((alt) => (
                <div
                  key={alt.id}
                  className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between gap-3 hover:border-slate-700 transition-colors"
                >
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] text-slate-400 uppercase tracking-wider">
                        {alt.category}
                      </span>
                      <span className="text-xs font-bold text-cyan-400">{alt.fitScore}%</span>
                    </div>
                    <h4 className="text-sm font-bold text-white font-['Space_Grotesk']">
                      {alt.title}
                    </h4>
                    <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                      {alt.shortDescription}
                    </p>
                  </div>

                  <button
                    onClick={() => onSelectCareerForRoadmap(alt)}
                    className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1 pt-1"
                  >
                    <span>View Roadmap</span>
                    <ArrowRight className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
