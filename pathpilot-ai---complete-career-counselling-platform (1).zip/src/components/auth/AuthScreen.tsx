import React, { useState } from 'react';
import {
  Compass,
  Lock,
  Mail,
  ArrowRight,
  AlertCircle,
  CheckCircle2,
  Sparkles,
  ShieldCheck,
  RefreshCw,
  LogIn,
} from 'lucide-react';
import { authService, EmailNotVerifiedError } from '../../services/authService';

interface AuthScreenProps {
  onAuthSuccess: () => void;
  onExploreGuest?: () => void;
  initialMode?: 'signin' | 'signup';
}

export const AuthScreen: React.FC<AuthScreenProps> = ({
  onAuthSuccess,
  onExploreGuest,
  initialMode = 'signin',
}) => {
  const [mode, setMode] = useState<'signin' | 'signup'>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Email verification state
  const [verificationPendingEmail, setVerificationPendingEmail] = useState<string | null>(null);
  const [resendStatus, setResendStatus] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setResendStatus(null);

    const trimmedEmail = email.trim();
    if (!trimmedEmail || !password) {
      setErrorMessage('Please enter both email and password.');
      return;
    }

    setIsLoading(true);

    try {
      if (mode === 'signin') {
        await authService.signIn(trimmedEmail, password);
        // Verified user signed in successfully:
        onAuthSuccess();
      } else {
        // Registration flow:
        // Requirement:
        // - When a user registers with email/password, do not sign them in automatically.
        // - Send a verification email and show a verification screen with this message:
        //   “We have sent you a verification email to [user email]. Please verify it and log in.”
        // - Include a Login button on the verification screen.
        const res = await authService.signUp(trimmedEmail, password);
        setVerificationPendingEmail(res.email);
      }
    } catch (err: any) {
      if (err instanceof EmailNotVerifiedError) {
        // Requirement:
        // - If a user logs in and their email is not verified, block access and show the same verification screen.
        setVerificationPendingEmail(err.email);
      } else {
        setErrorMessage(err?.message || 'An error occurred during authentication.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleReturnToLogin = () => {
    setVerificationPendingEmail(null);
    setMode('signin');
    setErrorMessage(null);
    setResendStatus(null);
    setPassword('');
  };


  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-center items-center py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Background ambient glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-cyan-500/10 via-teal-500/10 to-indigo-500/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-md w-full space-y-6 relative z-10">
        {/* Header Branding */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center h-12 w-12 rounded-2xl bg-gradient-to-tr from-cyan-500 via-teal-400 to-emerald-400 p-0.5 shadow-lg shadow-cyan-500/20 mb-2">
            <div className="h-full w-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <Compass className="h-6 w-6 text-cyan-400 animate-pulse" />
            </div>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-['Space_Grotesk'] tracking-tight">
            PathPilot<span className="text-cyan-400">.ai</span>
          </h1>
          <p className="text-xs text-slate-400">
            {mode === 'signin'
              ? 'Sign in to access your dashboard, assessments & roadmaps'
              : 'Create an account to begin your personalized career discovery'}
          </p>
        </div>

        {/* Verification Screen or Auth Card */}
        {verificationPendingEmail ? (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 text-center animate-in fade-in duration-300">
            {/* Mail Icon with animated ring */}
            <div className="mx-auto inline-flex items-center justify-center h-16 w-16 rounded-2xl bg-gradient-to-tr from-cyan-500/20 via-teal-500/20 to-emerald-500/20 border border-cyan-500/30 p-1">
              <Mail className="h-8 w-8 text-cyan-400" />
            </div>

            <div className="space-y-2">
              <h2 className="text-xl font-bold text-white font-['Space_Grotesk']">
                Verify Your Email
              </h2>
              {/* Exact user-requested message:
                  “We have sent you a verification email to [user email]. Please verify it and log in.” */}
              <p className="text-sm text-slate-300 leading-relaxed max-w-sm mx-auto">
                We have sent you a verification email to{' '}
                <span className="font-semibold text-cyan-400 break-all">
                  {verificationPendingEmail}
                </span>
                . Please verify it and log in.
              </p>
            </div>

            <div className="p-3.5 bg-slate-950/70 border border-slate-800 rounded-2xl text-xs text-slate-400 text-left space-y-1.5">
              <div className="flex items-center gap-1.5 font-medium text-slate-300">
                <CheckCircle2 className="h-3.5 w-3.5 text-teal-400 shrink-0" />
                <span>Next steps:</span>
              </div>
              <ol className="list-decimal list-inside space-y-1 pl-1 text-[11px] text-slate-400">
                <li>Open your inbox at <span className="text-slate-300">{verificationPendingEmail}</span>.</li>
                <li>Click the verification link from Firebase / Roomora.</li>
                <li>Click the <strong>Login</strong> button below to sign in to your dashboard.</li>
              </ol>
            </div>

            {/* Login Button - Exact requirement: Include a Login button on the verification screen */}
            <div className="pt-2 space-y-3">
              <button
                type="button"
                onClick={handleReturnToLogin}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 hover:from-cyan-400 hover:to-teal-300 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 shadow-xl shadow-cyan-950 transition-all hover:scale-[1.01]"
              >
                <LogIn className="h-4 w-4" />
                <span>Login</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setVerificationPendingEmail(null);
                  setMode('signup');
                  setErrorMessage(null);
                  setEmail('');
                  setPassword('');
                }}
                className="text-xs text-slate-500 hover:text-slate-300 transition-colors"
              >
                Entered wrong email? Register with another address
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
            {/* Mode Switcher Tabs */}
            <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-950 rounded-2xl border border-slate-800">
              <button
                type="button"
                onClick={() => {
                  setMode('signin');
                  setErrorMessage(null);
                }}
                className={`py-2 text-xs font-bold rounded-xl transition-all ${
                  mode === 'signin'
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('signup');
                  setErrorMessage(null);
                }}
                className={`py-2 text-xs font-bold rounded-xl transition-all ${
                  mode === 'signup'
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Sign Up
              </button>
            </div>

            {/* Error Message Display */}
            {errorMessage && (
              <div className="p-3.5 bg-rose-950/70 border border-rose-800/80 rounded-2xl flex items-start gap-2.5 text-xs text-rose-300 animate-in fade-in">
                <AlertCircle className="h-4 w-4 text-rose-400 shrink-0 mt-0.5" />
                <div className="flex-1 leading-relaxed">
                  <span>{errorMessage}</span>
                  {errorMessage === 'User already exists. Please sign in' && (
                    <button
                      type="button"
                      onClick={() => {
                        setMode('signin');
                        setErrorMessage(null);
                      }}
                      className="block text-cyan-400 hover:underline font-semibold mt-1"
                    >
                      Click here to switch to Sign In →
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 hover:from-cyan-400 hover:to-teal-300 text-slate-950 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xl shadow-cyan-950 transition-all hover:scale-[1.01] disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="h-4 w-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                    <span>{mode === 'signin' ? 'Signing In...' : 'Creating Account...'}</span>
                  </div>
                ) : (
                  <>
                    <span>{mode === 'signin' ? 'Sign In to Dashboard' : 'Sign Up & Continue'}</span>
                    <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </button>
            </form>

            {/* Switch Mode Footer */}
            <div className="pt-2 text-center text-xs text-slate-400">
              {mode === 'signin' ? (
                <p>
                  Don't have an account?{' '}
                  <button
                    type="button"
                    onClick={() => {
                      setMode('signup');
                      setErrorMessage(null);
                    }}
                    className="text-cyan-400 hover:underline font-semibold"
                  >
                    Sign up now
                  </button>
                </p>
              ) : (
                <p>
                  Already have an account?{' '}
                  <button
                    type="button"
                    onClick={() => {
                      setMode('signin');
                      setErrorMessage(null);
                    }}
                    className="text-cyan-400 hover:underline font-semibold"
                  >
                    Sign in
                  </button>
                </p>
              )}
            </div>
          </div>
        )}

        {/* Optional Explore as Guest */}
        {onExploreGuest && !verificationPendingEmail && (
          <div className="text-center">
            <button
              type="button"
              onClick={onExploreGuest}
              className="text-xs text-slate-500 hover:text-slate-300 transition-colors"
            >
              ← Back to Overview / Explore as Guest
            </button>
          </div>
        )}

        {/* Security badge */}
        <div className="text-center flex items-center justify-center gap-1.5 text-[11px] text-slate-500">
          <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
          <span>Secured with Firebase Authentication</span>
        </div>
      </div>
    </div>
  );
};
