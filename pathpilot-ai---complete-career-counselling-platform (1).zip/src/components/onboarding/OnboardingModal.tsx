import React, { useState } from 'react';
import {
  X,
  GraduationCap,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  BookOpen,
  Briefcase,
  Compass,
  Building,
  Target,
} from 'lucide-react';
import { EducationStage, StudentProfile } from '../../types';

interface OnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentProfile: StudentProfile;
  onSaveProfile: (profile: StudentProfile) => void;
  onStartAssessment?: () => void;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({
  isOpen,
  onClose,
  currentProfile,
  onSaveProfile,
  onStartAssessment,
}) => {
  const [step, setStep] = useState(1);
  const [name, setName] = useState(currentProfile.name || '');
  const [email, setEmail] = useState(currentProfile.email || '');
  const [stage, setStage] = useState<EducationStage>(currentProfile.stage || 'diploma');

  // Stage conditional fields
  // Class 10
  const [class10Subjects, setClass10Subjects] = useState<string[]>(
    currentProfile.stageDetails.class10PreferredSubjects || ['Mathematics', 'Science']
  );
  const [streamExploration, setStreamExploration] = useState<string[]>(
    currentProfile.stageDetails.streamExplorationInterests || ['Science', 'Commerce']
  );

  // Class 11-12
  const [stream11_12, setStream11_12] = useState<any>(
    currentProfile.stageDetails.stream11_12 || 'PCM'
  );
  const [targetExams, setTargetExams] = useState<string[]>(
    currentProfile.stageDetails.targetEntranceExams || ['JEE Main', 'CUET']
  );

  // Diploma
  const [diplomaBranch, setDiplomaBranch] = useState(
    currentProfile.stageDetails.diplomaBranch || 'Mechanical Engineering'
  );
  const [diplomaYear, setDiplomaYear] = useState(
    currentProfile.stageDetails.diplomaYear || 'Final Year (Semester 5/6)'
  );
  const [diplomaGoal, setDiplomaGoal] = useState<any>(
    currentProfile.stageDetails.diplomaImmediateGoal || 'lateral_entry_btech'
  );
  const [practicalSkills, setPracticalSkills] = useState(
    currentProfile.stageDetails.practicalSkillsSummary || 'AutoCAD, Workshop Lathe, Circuit Wiring'
  );

  // Undergrad
  const [degreeName, setDegreeName] = useState(
    currentProfile.stageDetails.degreeName || 'B.Tech'
  );
  const [degreeBranch, setDegreeBranch] = useState(
    currentProfile.stageDetails.degreeBranch || 'Computer Science & Engineering'
  );
  const [undergradYear, setUndergradYear] = useState(
    currentProfile.stageDetails.undergradYear || '3rd Year'
  );
  const [undergradGoal, setUndergradGoal] = useState<any>(
    currentProfile.stageDetails.immediatePostGradGoal || 'campus_placements'
  );

  // Working Pro
  const [industry, setIndustry] = useState(
    currentProfile.stageDetails.currentIndustry || 'Information Technology'
  );
  const [role, setRole] = useState(
    currentProfile.stageDetails.currentRole || 'Associate Software Engineer'
  );
  const [yearsExp, setYearsExp] = useState(
    currentProfile.stageDetails.yearsOfExperience || 2
  );
  const [pivotMotivation, setPivotMotivation] = useState<any>(
    currentProfile.stageDetails.pivotMotivation || 'tech_upskilling'
  );

  // General Preferences (Step 3)
  const [locationPref, setLocationPref] = useState(
    currentProfile.locationPreference || 'India (Metro cities & tech hubs)'
  );
  const [budgetConsideration, setBudgetConsideration] = useState<any>(
    currentProfile.budgetConsideration || 'moderate'
  );
  const [careerGoals, setCareerGoals] = useState(
    currentProfile.careerGoals || 'Build high-impact technical expertise and work on cutting-edge innovations.'
  );

  if (!isOpen) return null;

  const stagesList: { id: EducationStage; label: string; desc: string; icon: any }[] = [
    {
      id: 'class_8_9',
      label: 'Classes 8–9',
      desc: 'Early curiosity, foundation habits & subject interests',
      icon: BookOpen,
    },
    {
      id: 'class_10',
      label: 'Class 10',
      desc: 'Neutral stream evaluation (Science, Commerce, Arts, Vocational)',
      icon: Compass,
    },
    {
      id: 'class_11_12',
      label: 'Classes 11–12',
      desc: 'Stream specialization, entrance exams & degree options',
      icon: GraduationCap,
    },
    {
      id: 'diploma',
      label: 'Polytechnic Diploma',
      desc: 'Practical skills, LEET lateral entry to B.Tech, or direct industry jobs',
      icon: Building,
    },
    {
      id: 'undergraduate',
      label: 'Undergraduate Degree',
      desc: 'B.Tech, B.Sc, B.Com, BCA, BBA, B.Des — skills, portfolios & placements',
      icon: Briefcase,
    },
    {
      id: 'postgraduate',
      label: 'Graduate / Postgraduate',
      desc: 'M.Tech, MBA, M.Sc, MCA — research, leadership & specialization',
      icon: Target,
    },
    {
      id: 'working_professional',
      label: 'Working Professional',
      desc: 'Career pivot, domain switch, salary acceleration & reskilling',
      icon: Sparkles,
    },
  ];

  const handleSave = (startNow = false) => {
    const updatedProfile: StudentProfile = {
      ...currentProfile,
      name: name.trim() || 'Student',
      email: email.trim() || undefined,
      stage,
      stageDetails: {
        class10PreferredSubjects: stage === 'class_10' ? class10Subjects : undefined,
        streamExplorationInterests: stage === 'class_10' ? streamExploration : undefined,
        stream11_12: stage === 'class_11_12' ? stream11_12 : undefined,
        targetEntranceExams: stage === 'class_11_12' ? targetExams : undefined,
        diplomaBranch: stage === 'diploma' ? diplomaBranch : undefined,
        diplomaYear: stage === 'diploma' ? diplomaYear : undefined,
        diplomaImmediateGoal: stage === 'diploma' ? diplomaGoal : undefined,
        practicalSkillsSummary: stage === 'diploma' ? practicalSkills : undefined,
        degreeName: stage === 'undergraduate' ? degreeName : undefined,
        degreeBranch: stage === 'undergraduate' ? degreeBranch : undefined,
        undergradYear: stage === 'undergraduate' ? undergradYear : undefined,
        immediatePostGradGoal: stage === 'undergraduate' ? undergradGoal : undefined,
        currentIndustry: stage === 'working_professional' ? industry : undefined,
        currentRole: stage === 'working_professional' ? role : undefined,
        yearsOfExperience: stage === 'working_professional' ? yearsExp : undefined,
        pivotMotivation: stage === 'working_professional' ? pivotMotivation : undefined,
      },
      locationPreference: locationPref,
      budgetConsideration,
      careerGoals,
      completedOnboarding: true,
    };

    onSaveProfile(updatedProfile);
    onClose();
    if (startNow && onStartAssessment) {
      onStartAssessment();
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-800 flex items-center justify-between bg-slate-950">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800">
                Step {step} of 3
              </span>
              <h3 className="text-base font-bold text-white font-['Space_Grotesk']">
                Student Profile & Education Stage
              </h3>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              PathPilot AI customizes assessment questions & pathways specifically for your stage.
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-slate-200">
          {/* STEP 1: Name & Stage Selection */}
          {step === 1 && (
            <div className="space-y-5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  What is your name?
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter your name or preferred nickname"
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Select Your Current Education Stage
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {stagesList.map((st) => {
                    const Icon = st.icon;
                    const isSelected = stage === st.id;
                    return (
                      <button
                        key={st.id}
                        type="button"
                        onClick={() => setStage(st.id)}
                        className={`text-left p-3.5 rounded-xl border transition-all flex items-start gap-3 ${
                          isSelected
                            ? 'bg-cyan-950/60 border-cyan-500 text-white shadow-md shadow-cyan-950'
                            : 'bg-slate-800/60 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:border-slate-600'
                        }`}
                      >
                        <div
                          className={`p-2 rounded-lg shrink-0 ${
                            isSelected
                              ? 'bg-cyan-500 text-slate-950 font-bold'
                              : 'bg-slate-700 text-slate-400'
                          }`}
                        >
                          <Icon className="h-4 w-4" />
                        </div>
                        <div className="min-w-0">
                          <div className="text-xs font-semibold leading-tight">{st.label}</div>
                          <div className="text-[11px] text-slate-400 mt-1 leading-normal line-clamp-2">
                            {st.desc}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: Conditional Stage-Specific Questions */}
          {step === 2 && (
            <div className="space-y-5">
              <div className="p-3 bg-cyan-950/40 border border-cyan-800/50 rounded-xl text-xs text-cyan-300 flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 shrink-0 text-cyan-400" />
                <span>
                  Tailoring questions for: <strong>{stagesList.find((s) => s.id === stage)?.label}</strong>
                </span>
              </div>

              {/* Class 10 Conditional */}
              {stage === 'class_10' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Which streams are you open to exploring? (Select all that apply)
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      {['Science (PCM / PCB)', 'Commerce (With or without Math)', 'Humanities & Social Sciences', 'Vocational / Polytechnic'].map((str) => (
                        <button
                          key={str}
                          type="button"
                          onClick={() => {
                            if (streamExploration.includes(str)) {
                              setStreamExploration(streamExploration.filter((s) => s !== str));
                            } else {
                              setStreamExploration([...streamExploration, str]);
                            }
                          }}
                          className={`px-3 py-2 rounded-lg border text-xs text-left font-medium transition-colors ${
                            streamExploration.includes(str)
                              ? 'bg-cyan-900/60 border-cyan-500 text-cyan-200'
                              : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                          }`}
                        >
                          {str}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Your Favorite Class 10 Subjects
                    </label>
                    <input
                      type="text"
                      value={class10Subjects.join(', ')}
                      onChange={(e) =>
                        setClass10Subjects(e.target.value.split(',').map((s) => s.trim()))
                      }
                      placeholder="e.g. Mathematics, Science, English, Social Science"
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                </div>
              )}

              {/* Class 11-12 Conditional */}
              {stage === 'class_11_12' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Current Stream
                    </label>
                    <select
                      value={stream11_12}
                      onChange={(e) => setStream11_12(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                    >
                      <option value="PCM">Science with Math (PCM / PCMB)</option>
                      <option value="PCB">Science with Biology (PCB)</option>
                      <option value="Commerce_Math">Commerce with Mathematics</option>
                      <option value="Commerce_NoMath">Commerce without Mathematics</option>
                      <option value="Humanities">Humanities / Arts</option>
                      <option value="Vocational">Vocational / Skill Stream</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Target Entrance Examinations (comma-separated)
                    </label>
                    <input
                      type="text"
                      value={targetExams.join(', ')}
                      onChange={(e) =>
                        setTargetExams(e.target.value.split(',').map((s) => s.trim()))
                      }
                      placeholder="e.g. JEE Main, NEET, CUET, CLAT, UCEED, NIFT, SAT"
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                </div>
              )}

              {/* Diploma Conditional */}
              {stage === 'diploma' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Diploma Branch / Specialization
                      </label>
                      <input
                        type="text"
                        value={diplomaBranch}
                        onChange={(e) => setDiplomaBranch(e.target.value)}
                        placeholder="e.g. Mechanical, Electrical, Civil, CS"
                        className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Current Semester / Year
                      </label>
                      <input
                        type="text"
                        value={diplomaYear}
                        onChange={(e) => setDiplomaYear(e.target.value)}
                        placeholder="e.g. Final Year / 5th Sem"
                        className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Immediate Post-Diploma Goal
                    </label>
                    <select
                      value={diplomaGoal}
                      onChange={(e) => setDiplomaGoal(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                    >
                      <option value="lateral_entry_btech">
                        Lateral Entry into 2nd Year B.Tech (LEET Exam)
                      </option>
                      <option value="direct_industry_job">
                        Direct Core Industry Employment / Apprenticeship (NATS)
                      </option>
                      <option value="govt_exam_je">
                        Government Exam (Junior Engineer - SSC JE / RRB JE)
                      </option>
                      <option value="undecided">
                        Undecided (Need PathPilot comparison & guidance)
                      </option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Practical Skills Learned (Labs, Workshops, Software)
                    </label>
                    <input
                      type="text"
                      value={practicalSkills}
                      onChange={(e) => setPracticalSkills(e.target.value)}
                      placeholder="e.g. AutoCAD, Lathe, PLC, Circuit soldering, Python"
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                </div>
              )}

              {/* Undergraduate Conditional */}
              {stage === 'undergraduate' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Degree & Branch
                      </label>
                      <input
                        type="text"
                        value={`${degreeName} - ${degreeBranch}`}
                        onChange={(e) => {
                          const parts = e.target.value.split('-');
                          setDegreeName(parts[0]?.trim() || 'B.Tech');
                          setDegreeBranch(parts[1]?.trim() || 'Computer Science');
                        }}
                        placeholder="e.g. B.Tech - IT or B.Sc - Physics"
                        className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Current Year
                      </label>
                      <input
                        type="text"
                        value={undergradYear}
                        onChange={(e) => setUndergradYear(e.target.value)}
                        placeholder="e.g. 3rd Year / 6th Sem"
                        className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Immediate Post-Graduation Focus
                    </label>
                    <select
                      value={undergradGoal}
                      onChange={(e) => setUndergradGoal(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                    >
                      <option value="campus_placements">Campus Placements / Software Jobs</option>
                      <option value="higher_studies_india">Higher Studies in India (GATE, CAT, IIT JAM)</option>
                      <option value="studies_abroad">Higher Studies Abroad (GRE, TOEFL, MS)</option>
                      <option value="startup">Building a Startup / Early-Stage Venture</option>
                      <option value="govt_services">Civil Services / Defense / PSU Examination</option>
                    </select>
                  </div>
                </div>
              )}

              {/* Working Professional Conditional */}
              {stage === 'working_professional' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Current Role & Domain
                      </label>
                      <input
                        type="text"
                        value={role}
                        onChange={(e) => setRole(e.target.value)}
                        placeholder="e.g. QA Engineer, Operations Associate"
                        className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Years of Experience
                      </label>
                      <input
                        type="number"
                        value={yearsExp}
                        onChange={(e) => setYearsExp(Number(e.target.value))}
                        className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Primary Motivation for Career Transition
                    </label>
                    <select
                      value={pivotMotivation}
                      onChange={(e) => setPivotMotivation(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                    >
                      <option value="tech_upskilling">Upskilling to High-Growth Tech (AI, Cloud, DevOps)</option>
                      <option value="better_growth">Higher Salary & Accelerating Growth Trajectory</option>
                      <option value="passion_alignment">Alignment with True Personal Passions</option>
                      <option value="work_life_balance">Better Work-Life Balance & Remote Flexibility</option>
                    </select>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* STEP 3: Location, Budget & Ambitions */}
          {step === 3 && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Preferred Location / Study Region
                </label>
                <input
                  type="text"
                  value={locationPref}
                  onChange={(e) => setLocationPref(e.target.value)}
                  placeholder="e.g. Pan-India (Bengaluru, Pune, Delhi NCR) or Overseas"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Higher Education Budget Approach
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'budget_sensitive', label: 'Budget Sensitive', desc: 'Govt polytechnics, state colleges, scholarships' },
                    { id: 'moderate', label: 'Moderate / Balanced', desc: 'Open to reasonable student loans with strong ROI' },
                    { id: 'flexible', label: 'Flexible / Premium', desc: 'Top tier private institutes or international study' },
                  ].map((b) => (
                    <button
                      key={b.id}
                      type="button"
                      onClick={() => setBudgetConsideration(b.id)}
                      className={`p-2.5 rounded-xl border text-left text-xs transition-colors ${
                        budgetConsideration === b.id
                          ? 'bg-cyan-950 border-cyan-500 text-cyan-200'
                          : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
                      }`}
                    >
                      <div className="font-semibold text-slate-200">{b.label}</div>
                      <div className="text-[10px] text-slate-400 mt-1">{b.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Broad Career Goals or Aspirations
                </label>
                <textarea
                  rows={3}
                  value={careerGoals}
                  onChange={(e) => setCareerGoals(e.target.value)}
                  placeholder="Tell us what you envision for your future in 1-2 sentences..."
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
          {step > 1 ? (
            <button
              type="button"
              onClick={() => setStep(step - 1)}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium flex items-center gap-1.5 transition-colors"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              Back
            </button>
          ) : (
            <div></div>
          )}

          <div className="flex items-center gap-3">
            {step < 3 ? (
              <button
                type="button"
                onClick={() => setStep(step + 1)}
                className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-lg shadow-cyan-900/30"
              >
                Continue
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            ) : (
              <>
                <button
                  type="button"
                  onClick={() => handleSave(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors"
                >
                  Save Profile
                </button>
                <button
                  type="button"
                  onClick={() => handleSave(true)}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-teal-500 hover:from-cyan-500 hover:to-teal-400 text-white text-xs font-semibold flex items-center gap-1.5 transition-all shadow-lg shadow-cyan-900/30"
                >
                  Save & Launch Assessment
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
