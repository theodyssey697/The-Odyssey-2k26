import React, { useState } from 'react';
import {
  Milestone,
  CheckCircle2,
  Circle,
  Plus,
  Sparkles,
  ExternalLink,
  BotMessageSquare,
  ArrowRight,
  TrendingUp,
  Calendar,
  AlertCircle,
  X,
  Target,
} from 'lucide-react';
import { CareerProfile, CareerRoadmap, RoadmapTask, StudentProfile } from '../../types';
import { CAREERS_DATA } from '../../data/careersData';
import { generateDefaultRoadmap, storageService } from '../../services/storageService';

interface RoadmapViewProps {
  studentProfile: StudentProfile;
  initialRoadmap: CareerRoadmap;
  onNavigate: (view: string) => void;
  onAskMentorWithContext: (taskTitle: string) => void;
}

export const RoadmapView: React.FC<RoadmapViewProps> = ({
  studentProfile,
  initialRoadmap,
  onNavigate,
  onAskMentorWithContext,
}) => {
  const [roadmap, setRoadmap] = useState<CareerRoadmap>(initialRoadmap);
  const [selectedCareerId, setSelectedCareerId] = useState<string>(initialRoadmap.careerId);
  const [showAddTaskModal, setShowAddTaskModal] = useState(false);
  const [targetPhaseId, setTargetPhaseId] = useState<string>('phase_1');

  // Custom task form state
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskDesc, setNewTaskDesc] = useState('');
  const [newTaskPriority, setNewTaskPriority] = useState<'high' | 'medium' | 'low'>('medium');
  const [newTaskTimeframe, setNewTaskTimeframe] = useState('Week 3');

  // Switch target career
  const handleSwitchCareer = (careerId: string) => {
    setSelectedCareerId(careerId);
    const existing = storageService.getActiveRoadmap(careerId);
    setRoadmap(existing);
  };

  // Toggle task completion
  const handleToggleTask = (phaseId: string, taskId: string) => {
    const updatedPhases = roadmap.phases.map((phase) => {
      if (phase.id !== phaseId) return phase;
      return {
        ...phase,
        tasks: phase.tasks.map((task) => {
          if (task.id !== taskId) return task;
          return { ...task, completed: !task.completed };
        }),
      };
    });

    const updatedRoadmap: CareerRoadmap = {
      ...roadmap,
      updatedAt: new Date().toISOString(),
      phases: updatedPhases,
    };

    setRoadmap(updatedRoadmap);
    storageService.saveRoadmap(updatedRoadmap);
  };

  // Add custom task
  const handleAddCustomTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;

    const newTask: RoadmapTask = {
      id: `task_custom_${Date.now()}`,
      title: newTaskTitle.trim(),
      description: newTaskDesc.trim() || 'Custom goal added by student.',
      priority: newTaskPriority,
      timeframe: newTaskTimeframe,
      completed: false,
      isCustom: true,
    };

    const updatedPhases = roadmap.phases.map((phase) => {
      if (phase.id !== targetPhaseId) return phase;
      return {
        ...phase,
        tasks: [...phase.tasks, newTask],
      };
    });

    const updatedRoadmap: CareerRoadmap = {
      ...roadmap,
      updatedAt: new Date().toISOString(),
      phases: updatedPhases,
    };

    setRoadmap(updatedRoadmap);
    storageService.saveRoadmap(updatedRoadmap);

    setNewTaskTitle('');
    setNewTaskDesc('');
    setShowAddTaskModal(false);
  };

  // Calculate metrics
  let totalTasks = 0;
  let completedTasks = 0;
  roadmap.phases.forEach((p) => {
    p.tasks.forEach((t) => {
      totalTasks++;
      if (t.completed) completedTasks++;
    });
  });
  const progressPercent = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  const currentCareer = CAREERS_DATA.find((c) => c.id === roadmap.careerId) || CAREERS_DATA[0];

  const priorityStyles = {
    high: 'bg-rose-950/80 text-rose-400 border-rose-800',
    medium: 'bg-amber-950/80 text-amber-400 border-amber-800',
    low: 'bg-slate-800 text-slate-400 border-slate-700',
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto space-y-8">
        {/* Top Header Card */}
        <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[11px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-md bg-cyan-950 text-cyan-300 border border-cyan-800">
                  Execution Blueprint
                </span>
                <span className="text-xs text-slate-400">
                  Structured 30–60–90 Day Milestones
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-['Space_Grotesk'] tracking-tight">
                Roadmap to {currentCareer.title}
              </h1>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                Candidate: <strong className="text-slate-200">{studentProfile.name}</strong> • Current Stage:{' '}
                <strong className="text-cyan-300 capitalize">{studentProfile.stage.replace('_', ' ')}</strong>
              </p>
            </div>

            {/* Target Career Dropdown */}
            <div className="shrink-0">
              <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                Switch Target Career
              </label>
              <select
                value={selectedCareerId}
                onChange={(e) => handleSwitchCareer(e.target.value)}
                className="px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500 font-medium"
              >
                {CAREERS_DATA.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.title}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Progress Meter */}
          <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800/80 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                <TrendingUp className="h-4 w-4 text-cyan-400" />
                Overall Preparation Progress
              </span>
              <span className="font-bold text-cyan-400 text-sm">
                {completedTasks} of {totalTasks} Tasks Done ({progressPercent}%)
              </span>
            </div>
            <div className="w-full bg-slate-900 h-2.5 rounded-full overflow-hidden border border-slate-800">
              <div
                className="bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 h-full rounded-full transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* 3 Phases Grid / Vertical Timeline */}
        <div className="space-y-6">
          {roadmap.phases.map((phase, pIdx) => {
            const phaseCompleted = phase.tasks.filter((t) => t.completed).length;
            const phaseTotal = phase.tasks.length;

            return (
              <div
                key={phase.id}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-xl space-y-5"
              >
                {/* Phase Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
                  <div className="flex items-center gap-3">
                    <div className="h-9 w-9 rounded-xl bg-cyan-950 border border-cyan-800 text-cyan-400 font-bold text-sm flex items-center justify-center shrink-0">
                      P{pIdx + 1}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                          {phase.dayRange}
                        </span>
                        <span className="text-slate-600">•</span>
                        <span className="text-xs text-slate-400">
                          {phaseCompleted}/{phaseTotal} completed
                        </span>
                      </div>
                      <h3 className="text-base sm:text-lg font-bold text-white font-['Space_Grotesk']">
                        {phase.title}
                      </h3>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setTargetPhaseId(phase.id);
                      setShowAddTaskModal(true);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-colors self-start sm:self-auto"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    <span>Add Personal Task</span>
                  </button>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed">
                  {phase.description}
                </p>

                {/* Tasks List */}
                <div className="space-y-3">
                  {phase.tasks.map((task) => (
                    <div
                      key={task.id}
                      onClick={() => handleToggleTask(phase.id, task.id)}
                      className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3.5 group ${
                        task.completed
                          ? 'bg-slate-950/40 border-slate-800/60 text-slate-400 opacity-80'
                          : 'bg-slate-950/90 border-slate-800 text-slate-200 hover:border-slate-700 hover:bg-slate-900/80 shadow-md'
                      }`}
                    >
                      {/* Checkbox */}
                      <button
                        type="button"
                        className="mt-0.5 text-slate-500 group-hover:text-cyan-400 transition-colors shrink-0"
                      >
                        {task.completed ? (
                          <CheckCircle2 className="h-5 w-5 text-emerald-400" />
                        ) : (
                          <Circle className="h-5 w-5" />
                        )}
                      </button>

                      {/* Task details */}
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <span
                            className={`text-xs font-bold ${
                              task.completed ? 'line-through text-slate-500' : 'text-white'
                            }`}
                          >
                            {task.title}
                          </span>
                          <span
                            className={`text-[10px] font-semibold uppercase px-2 py-0.5 rounded border ${
                              priorityStyles[task.priority]
                            }`}
                          >
                            {task.priority}
                          </span>
                          <span className="text-[11px] text-slate-500 flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {task.timeframe}
                          </span>
                        </div>

                        <p className="text-xs text-slate-400 leading-relaxed">
                          {task.description}
                        </p>

                        <div className="mt-2.5 flex flex-wrap items-center gap-3">
                          {task.resourceLink && (
                            <a
                              href={task.resourceLink}
                              target="_blank"
                              rel="noreferrer"
                              onClick={(e) => e.stopPropagation()}
                              className="text-[11px] text-cyan-400 hover:underline flex items-center gap-1 font-medium"
                            >
                              <ExternalLink className="h-3 w-3" />
                              <span>Recommended Resource</span>
                            </a>
                          )}

                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onAskMentorWithContext(`How can I best complete this task: "${task.title}" for ${currentCareer.title}?`);
                            }}
                            className="text-[11px] text-slate-400 hover:text-cyan-300 flex items-center gap-1 font-medium transition-colors"
                          >
                            <BotMessageSquare className="h-3 w-3 text-cyan-400" />
                            <span>Ask Mentor For Tips</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Add Custom Task Modal */}
        {showAddTaskModal && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-base font-bold text-white font-['Space_Grotesk']">
                  Add Personal Roadmap Goal
                </h3>
                <button
                  onClick={() => setShowAddTaskModal(false)}
                  className="text-slate-400 hover:text-white"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <form onSubmit={handleAddCustomTask} className="space-y-4 text-xs">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Goal or Task Title
                  </label>
                  <input
                    type="text"
                    required
                    value={newTaskTitle}
                    onChange={(e) => setNewTaskTitle(e.target.value)}
                    placeholder="e.g. Complete LEET Physics mock test paper"
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Description & Target Outcome
                  </label>
                  <textarea
                    rows={2}
                    value={newTaskDesc}
                    onChange={(e) => setNewTaskDesc(e.target.value)}
                    placeholder="What specific outcome or learning do you want to accomplish?"
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-300 mb-1">Priority</label>
                    <select
                      value={newTaskPriority}
                      onChange={(e) => setNewTaskPriority(e.target.value as any)}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500"
                    >
                      <option value="high">High Priority</option>
                      <option value="medium">Medium Priority</option>
                      <option value="low">Low Priority</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-300 mb-1">Timeframe</label>
                    <input
                      type="text"
                      value={newTaskTimeframe}
                      onChange={(e) => setNewTaskTimeframe(e.target.value)}
                      placeholder="e.g. Week 2 or Day 45"
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddTaskModal(false)}
                    className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold"
                  >
                    Save Task
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
