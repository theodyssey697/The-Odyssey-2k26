import React from 'react';
import {
  Printer,
  Compass,
  CheckCircle2,
  GraduationCap,
  Sparkles,
  ShieldAlert,
  ArrowLeft,
  Calendar,
  Layers,
  Heart,
  Brain,
  DollarSign,
  Milestone,
} from 'lucide-react';
import { AssessmentResult, CareerRoadmap, StudentProfile } from '../../types';

interface ReportViewProps {
  studentProfile: StudentProfile;
  assessmentResult: AssessmentResult | null;
  activeRoadmap: CareerRoadmap | null;
  onNavigate: (view: string) => void;
}

export const ReportView: React.FC<ReportViewProps> = ({
  studentProfile,
  assessmentResult,
  activeRoadmap,
  onNavigate,
}) => {
  const handlePrint = () => {
    window.print();
  };

  if (!assessmentResult) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 py-16 px-4 flex items-center justify-center text-center">
        <div className="max-w-md space-y-4">
          <GraduationCap className="h-12 w-12 text-slate-600 mx-auto" />
          <h2 className="text-xl font-bold text-white font-['Space_Grotesk']">
            No Assessment Results Available Yet
          </h2>
          <p className="text-xs text-slate-400">
            Please complete the stage-tailored career assessment first to generate your official personalized diagnostic report.
          </p>
          <button
            onClick={() => onNavigate('assessment')}
            className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs"
          >
            Start Career Assessment
          </button>
        </div>
      </div>
    );
  }

  const topCareers = assessmentResult.topCareers.slice(0, 5);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8 print:bg-white print:text-black print:p-0">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Print Action Bar (Hidden in print) */}
        <div className="flex items-center justify-between bg-slate-900 border border-slate-800 rounded-2xl p-4 print:hidden shadow-lg">
          <button
            onClick={() => onNavigate('dashboard')}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Dashboard</span>
          </button>

          <div className="flex items-center gap-3">
            <span className="text-xs text-slate-400 hidden sm:inline">
              Optimized for A4 Print & PDF Export
            </span>
            <button
              onClick={handlePrint}
              className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-cyan-950 transition-all hover:scale-[1.02]"
            >
              <Printer className="h-4 w-4" />
              <span>Print / Save as PDF</span>
            </button>
          </div>
        </div>

        {/* ========================================================
            FORMAL REPORT DOCUMENT CONTAINER (PRINT-OPTIMIZED)
           ======================================================== */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 sm:p-12 space-y-8 shadow-2xl print:bg-white print:border-none print:shadow-none print:p-0 print:space-y-6">
          {/* Document Header & Logo */}
          <div className="border-b border-slate-800 pb-6 print:border-black flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <div className="h-8 w-8 rounded-lg bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 flex items-center justify-center print:border-black print:text-black">
                  <Compass className="h-4 w-4" />
                </div>
                <span className="font-extrabold text-lg text-white font-['Space_Grotesk'] print:text-black">
                  PathPilot<span className="text-cyan-400 print:text-black">.ai</span>
                </span>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-800 text-slate-300 print:border print:border-black print:text-black">
                  Official Diagnostic Dossier
                </span>
              </div>
              <p className="text-xs text-slate-400 print:text-gray-600">
                Independent Multidimensional Career Guidance & Education Pathway Synthesis
              </p>
            </div>

            <div className="text-left sm:text-right text-xs text-slate-400 print:text-gray-600 space-y-0.5">
              <div><strong>Report ID:</strong> {assessmentResult.id}</div>
              <div><strong>Evaluation Date:</strong> {new Date(assessmentResult.completedAt).toLocaleDateString()}</div>
              <div><strong>Status:</strong> Verified Psychometric Calibration</div>
            </div>
          </div>

          {/* 1. Student Profile Summary */}
          <section className="space-y-3">
            <h2 className="text-sm font-bold text-cyan-400 uppercase tracking-wider print:text-black">
              1. Candidate Academic Profile
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950/80 p-4 rounded-2xl border border-slate-800 print:bg-gray-50 print:border-gray-300 print:text-black text-xs">
              <div>
                <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Candidate Name</span>
                <strong className="text-white print:text-black text-sm">{studentProfile.name}</strong>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Current Stage</span>
                <strong className="text-cyan-300 print:text-black capitalize">
                  {studentProfile.stage.replace('_', ' ')}
                </strong>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Specialization / Stream</span>
                <span className="text-slate-300 print:text-black">
                  {studentProfile.stageDetails.diplomaBranch ||
                    studentProfile.stageDetails.stream11_12 ||
                    studentProfile.stageDetails.degreeName ||
                    'General Studies'}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Target Region</span>
                <span className="text-slate-300 print:text-black">{studentProfile.locationPreference}</span>
              </div>
            </div>
          </section>

          {/* 2. Qualitative Synthesis */}
          <section className="space-y-3">
            <h2 className="text-sm font-bold text-cyan-400 uppercase tracking-wider print:text-black">
              2. Executive Counseling Summary
            </h2>
            <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800/80 text-xs text-slate-300 print:bg-gray-50 print:border-gray-300 print:text-black leading-relaxed">
              {assessmentResult.qualitativeSummary}
            </div>
          </section>

          {/* 3. Dimension Scores */}
          <section className="space-y-3">
            <h2 className="text-sm font-bold text-cyan-400 uppercase tracking-wider print:text-black">
              3. Multidimensional Evaluation Breakdown
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
              {[
                { label: 'Analytical Aptitude', score: assessmentResult.dimensionScores.strengths_aptitude },
                { label: 'Curiosity & Interests', score: assessmentResult.dimensionScores.interests },
                { label: 'Work Style Alignment', score: assessmentResult.dimensionScores.work_preferences },
                { label: 'Core Values & Motives', score: assessmentResult.dimensionScores.values_motivators },
                { label: 'Learning Agility', score: assessmentResult.dimensionScores.learning_preferences },
                { label: 'Decision Readiness', score: assessmentResult.dimensionScores.career_readiness },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 print:bg-gray-50 print:border-gray-300 flex items-center justify-between"
                >
                  <span className="text-slate-400 print:text-gray-700">{item.label}</span>
                  <span className="font-bold text-cyan-400 print:text-black">{item.score}%</span>
                </div>
              ))}
            </div>
          </section>

          {/* 4. Ranked Career Recommendations */}
          <section className="space-y-4">
            <h2 className="text-sm font-bold text-cyan-400 uppercase tracking-wider print:text-black">
              4. Ranked Career Pathways & Gateway Analysis
            </h2>

            <div className="space-y-4">
              {topCareers.map((c, idx) => (
                <div
                  key={c.id}
                  className="bg-slate-950/80 border border-slate-800 rounded-2xl p-5 print:bg-white print:border-gray-300 space-y-3"
                >
                  <div className="flex items-center justify-between gap-2 border-b border-slate-800/80 pb-2 print:border-gray-200">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-cyan-400 print:text-black">#{idx + 1}</span>
                      <h3 className="font-bold text-sm text-white print:text-black">{c.title}</h3>
                      <span className="text-[10px] text-slate-400 print:text-gray-600">({c.category})</span>
                    </div>
                    <span className="text-xs font-bold text-emerald-400 print:text-black">
                      {c.fitScore}% Profile Fit
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 print:text-gray-700 leading-relaxed">
                    {c.shortDescription}
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1">
                    <div>
                      <strong className="text-slate-300 print:text-black block mb-1">
                        Degree Routes & Entrance Exams:
                      </strong>
                      <ul className="text-slate-400 print:text-gray-600 space-y-0.5 text-[11px]">
                        {c.educationPathways.degreeRoutes.slice(0, 2).map((r, i) => (
                          <li key={i}>• {r}</li>
                        ))}
                        <li>• Exams: {c.educationPathways.keyEntranceExams.slice(0, 3).join(', ')}</li>
                      </ul>
                    </div>

                    <div>
                      <strong className="text-cyan-300 print:text-black block mb-1">
                        Diploma Lateral Routes (LEET) & Skills:
                      </strong>
                      <ul className="text-slate-400 print:text-gray-600 space-y-0.5 text-[11px]">
                        {c.educationPathways.diplomaAndLateralRoutes.length > 0 ? (
                          c.educationPathways.diplomaAndLateralRoutes.slice(0, 2).map((r, i) => (
                            <li key={i}>• {r}</li>
                          ))
                        ) : (
                          <li>• No direct lateral route (Degree pathway standard)</li>
                        )}
                        <li>• Core Skills: {c.coreSkills.technical.slice(0, 3).join(', ')}</li>
                      </ul>
                    </div>
                  </div>

                  <div className="text-[11px] text-slate-400 print:text-gray-600 pt-1 border-t border-slate-900 print:border-gray-100 flex justify-between">
                    <span>
                      Indicative Starting Salary: <strong className="text-emerald-400 print:text-black">{c.salaryIndicative.entryLevelINR}</strong>
                    </span>
                    <span>Source: {c.salaryIndicative.source}</span>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* 5. 90-Day Action Roadmap */}
          {activeRoadmap && (
            <section className="space-y-3">
              <h2 className="text-sm font-bold text-cyan-400 uppercase tracking-wider print:text-black">
                5. Selected Target Roadmap ({activeRoadmap.careerTitle})
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                {activeRoadmap.phases.map((p, i) => (
                  <div
                    key={p.id}
                    className="p-3 bg-slate-950/80 rounded-xl border border-slate-800 print:bg-gray-50 print:border-gray-300 space-y-1.5"
                  >
                    <span className="font-bold text-cyan-400 print:text-black block text-[11px]">
                      {p.dayRange}
                    </span>
                    <strong className="text-white print:text-black block">{p.title}</strong>
                    <ul className="text-slate-400 print:text-gray-600 text-[11px] space-y-1 pt-1">
                      {p.tasks.slice(0, 2).map((t) => (
                        <li key={t.id} className="flex items-start gap-1">
                          <span>{t.completed ? '✓' : '•'}</span>
                          <span className={t.completed ? 'line-through' : ''}>{t.title}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* 6. Disclaimers & Ethics */}
          <section className="pt-4 border-t border-slate-800 print:border-black text-[11px] text-slate-400 print:text-gray-600 space-y-1.5 leading-relaxed">
            <h4 className="font-bold text-slate-300 print:text-black uppercase tracking-wider">
              Verification Notice & Ethical Disclaimers
            </h4>
            <p>
              This diagnostic report is synthesized using student self-reported preferences, stage prerequisites, and deterministic scoring rubrics. It does not constitute a psychological diagnostic, medical evaluation, or a legal guarantee of college admissions, job placement, or exact salary figures. Admission cutoffs, syllabi, and examination patterns must be verified against official agency websites (NTA, UPSC, ICAI, State Directorate of Technical Education).
            </p>
          </section>
        </div>
      </div>
    </div>
  );
};
