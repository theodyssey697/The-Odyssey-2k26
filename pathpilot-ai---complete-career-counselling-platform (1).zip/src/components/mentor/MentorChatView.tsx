import React, { useState, useEffect, useRef } from 'react';
import {
  Send,
  BotMessageSquare,
  User,
  Sparkles,
  RotateCcw,
  Copy,
  Check,
  ShieldAlert,
  ArrowRight,
  Workflow,
  ExternalLink,
  AlertTriangle,
  RefreshCw,
  HelpCircle,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { AssessmentResult, CareerRoadmap, ChatMessage, StudentProfile } from '../../types';
import { mentorService, N8N_CHAT_WEBHOOK_URL } from '../../services/mentorService';
import { storageService } from '../../services/storageService';

interface MentorChatViewProps {
  studentProfile: StudentProfile;
  assessmentResult: AssessmentResult | null;
  activeRoadmap: CareerRoadmap | null;
  initialQuery?: string;
  onClearInitialQuery?: () => void;
  onNavigate: (view: string) => void;
}

type MentorEngine = 'n8n_workflow' | 'n8n_embedded' | 'gemini_flash';

export const MentorChatView: React.FC<MentorChatViewProps> = ({
  studentProfile,
  assessmentResult,
  activeRoadmap,
  initialQuery,
  onClearInitialQuery,
  onNavigate,
}) => {
  // Engine Mode: 'n8n_workflow' (Active by default), 'n8n_embedded', or 'gemini_flash'
  const [engine, setEngine] = useState<MentorEngine>('n8n_workflow');

  // n8n Chat Session state
  const [n8nSessionId, setN8nSessionId] = useState<string>(() => {
    const existing = localStorage.getItem('pathpilot_n8n_session_id');
    if (existing) return existing;
    const newId = `session_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    localStorage.setItem('pathpilot_n8n_session_id', newId);
    return newId;
  });

  // Messages for n8n workflow
  const [n8nMessages, setN8nMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('pathpilot_n8n_chat_history');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {}
    }
    return [
      {
        id: 'msg_n8n_init',
        role: 'assistant',
        content: `Hi there! 👋 I'm Roomora Concierge powered by your n8n Cloud Workflow. How can I assist you with your career planning, guidance, or queries today?`,
        timestamp: new Date().toISOString(),
        source: 'n8n-cloud-workflow',
      },
    ];
  });

  // Messages for Gemini (preserved)
  const [geminiMessages, setGeminiMessages] = useState<ChatMessage[]>(() =>
    storageService.getChatMessages()
  );

  const [inputMessage, setInputMessage] = useState(initialQuery || '');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [lastFailedQuery, setLastFailedQuery] = useState<string | null>(null);
  const [showCorsHelp, setShowCorsHelp] = useState(false);
  const [iframeLoading, setIframeLoading] = useState(true);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Save n8n messages to localStorage
  useEffect(() => {
    localStorage.setItem('pathpilot_n8n_chat_history', JSON.stringify(n8nMessages));
  }, [n8nMessages]);

  // Save Gemini messages
  useEffect(() => {
    storageService.saveChatMessages(geminiMessages);
  }, [geminiMessages]);

  // Scroll to bottom on updates
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [n8nMessages, geminiMessages, isLoading, engine]);

  // Handle incoming initial queries from other pages
  useEffect(() => {
    if (initialQuery && initialQuery.trim().length > 0) {
      handleSendMessage(initialQuery);
      if (onClearInitialQuery) onClearInitialQuery();
    }
  }, [initialQuery]);

  const activeMessages = engine === 'gemini_flash' ? geminiMessages : n8nMessages;

  const promptChips = [
    studentProfile.stage === 'diploma'
      ? 'I am a diploma student. Should I do lateral entry B.Tech (LEET) or take a job?'
      : 'Which career options best suit my interests and stage?',
    'How do I balance board exams with competitive entrance tests?',
    'What should I learn in my first 30 days to prepare for this career?',
    'What can I do if my favourite subject is not my strongest subject?',
    'Create a beginner-friendly 3-month skill roadmap for me.',
  ];

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputMessage).trim();
    if (!query || isLoading) return;

    setConnectionError(null);
    setLastFailedQuery(null);

    const userMsg: ChatMessage = {
      id: `msg_user_${Date.now()}`,
      role: 'user',
      content: query,
      timestamp: new Date().toISOString(),
    };

    if (engine === 'gemini_flash') {
      setGeminiMessages((prev) => [...prev, userMsg]);
    } else {
      setN8nMessages((prev) => [...prev, userMsg]);
    }

    setInputMessage('');
    setIsLoading(true);

    if (engine === 'gemini_flash') {
      // Send to existing Gemini API endpoint
      try {
        const response = await mentorService.sendMessage(
          query,
          geminiMessages,
          studentProfile,
          assessmentResult,
          activeRoadmap
        );

        const assistantMsg: ChatMessage = {
          id: `msg_asst_${Date.now()}`,
          role: 'assistant',
          content: response.reply,
          timestamp: new Date().toISOString(),
          source: response.source,
          suggestedFollowUps: response.suggestedFollowUps,
        };

        setGeminiMessages((prev) => [...prev, assistantMsg]);
      } catch (err: any) {
        console.error('Gemini error:', err);
        setConnectionError('Unable to connect to Gemini API. Please retry.');
        setLastFailedQuery(query);
      } finally {
        setIsLoading(false);
      }
    } else {
      // Send to n8n Cloud Workflow
      try {
        const result = await mentorService.sendN8nMessage(query, n8nSessionId, studentProfile);

        const assistantMsg: ChatMessage = {
          id: `msg_n8n_${Date.now()}`,
          role: 'assistant',
          content: result.reply,
          timestamp: new Date().toISOString(),
          source: 'n8n Cloud Workflow',
          suggestedFollowUps: [
            'Can you provide next steps for this?',
            'What resources do you recommend?',
          ],
        };

        setN8nMessages((prev) => [...prev, assistantMsg]);
      } catch (err: any) {
        console.error('n8n error:', err);
        setConnectionError(
          err.message || 'Failed to connect to the n8n Cloud workflow. Check network connection or CORS.'
        );
        setLastFailedQuery(query);
      } finally {
        setIsLoading(false);
      }
    }
  };

  const handleRetry = () => {
    if (lastFailedQuery) {
      handleSendMessage(lastFailedQuery);
    }
  };

  const handleCopyMessage = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleResetChat = () => {
    if (engine === 'gemini_flash') {
      storageService.clearChatMessages();
      setGeminiMessages([
        {
          id: `msg_init_${Date.now()}`,
          role: 'assistant',
          content: `Hello ${studentProfile.name}! I am your PathPilot AI Career Mentor powered by Gemini. I have your profile loaded (${studentProfile.stage.replace('_', ' ')}). How can I guide you today?`,
          timestamp: new Date().toISOString(),
          suggestedFollowUps: [
            'Which career options suit my practical skills best?',
            'What are the pros and cons of lateral entry vs direct job?',
          ],
        },
      ]);
    } else {
      const newSession = `session_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
      setN8nSessionId(newSession);
      localStorage.setItem('pathpilot_n8n_session_id', newSession);
      setN8nMessages([
        {
          id: `msg_n8n_reset_${Date.now()}`,
          role: 'assistant',
          content: `Hi there! 👋 I'm Roomora Concierge. New session started. How can I assist you with your career journey or plans today?`,
          timestamp: new Date().toISOString(),
          source: 'n8n-cloud-workflow',
        },
      ]);
      setConnectionError(null);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-6 px-4 sm:px-6 lg:px-8 flex flex-col justify-between">
      <div className="max-w-4xl w-full mx-auto flex-1 flex flex-col">
        {/* Top Control Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 mb-5 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            {/* Header info */}
            <div className="flex items-center gap-3">
              <div className="h-11 w-11 rounded-2xl bg-gradient-to-tr from-violet-600 via-indigo-500 to-cyan-400 p-0.5 shadow-md shadow-violet-950 shrink-0">
                <div className="h-full w-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                  <Workflow className="h-5 w-5 text-violet-400 animate-pulse" />
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base sm:text-lg font-bold text-white font-['Space_Grotesk']">
                    AI Career Concierge & Mentor
                  </h2>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 flex items-center gap-1">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" />
                    Live
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  Candidate: <strong className="text-slate-200">{studentProfile.name}</strong> • Stage:{' '}
                  <span className="text-cyan-400 capitalize">{studentProfile.stage.replace('_', ' ')}</span>
                  {activeRoadmap && ` • Target: ${activeRoadmap.careerTitle}`}
                </p>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 self-end sm:self-center">
              <button
                onClick={handleResetChat}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-colors"
              >
                <RotateCcw className="h-3 w-3" />
                <span>New Session</span>
              </button>
            </div>
          </div>

          {/* Engine Selector Tabs */}
          <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-2xl border border-slate-800">
              <button
                onClick={() => setEngine('n8n_workflow')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                  engine === 'n8n_workflow'
                    ? 'bg-violet-600 text-white shadow-md shadow-violet-950'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Workflow className="h-3.5 w-3.5" />
                <span>n8n Cloud Workflow</span>
                <span className="text-[9px] bg-violet-950 text-violet-200 px-1.5 py-0.2 rounded border border-violet-800">
                  Primary
                </span>
              </button>

              <button
                onClick={() => setEngine('n8n_embedded')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                  engine === 'n8n_embedded'
                    ? 'bg-violet-600 text-white shadow-md shadow-violet-950'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <ExternalLink className="h-3.5 w-3.5" />
                <span>Embedded Webhook (iframe)</span>
              </button>

              <button
                onClick={() => setEngine('gemini_flash')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                  engine === 'gemini_flash'
                    ? 'bg-cyan-600 text-white shadow-md shadow-cyan-950'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Sparkles className="h-3.5 w-3.5 text-amber-400" />
                <span>Gemini 3.8 Flash</span>
                <span className="text-[9px] bg-cyan-950 text-cyan-200 px-1.5 py-0.2 rounded border border-cyan-800">
                  Preserved
                </span>
              </button>
            </div>

            {/* CORS / Webhook Help Toggle */}
            <button
              onClick={() => setShowCorsHelp(!showCorsHelp)}
              className="text-[11px] text-slate-400 hover:text-cyan-300 flex items-center gap-1"
            >
              <HelpCircle className="h-3.5 w-3.5" />
              <span>n8n Webhook & CORS Docs</span>
              {showCorsHelp ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
            </button>
          </div>

          {/* Collapsible CORS & Workflow Help Card */}
          {showCorsHelp && (
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-xs text-slate-300 space-y-2 animate-in fade-in">
              <div className="font-bold text-cyan-400 flex items-center gap-1.5">
                <Workflow className="h-4 w-4" />
                <span>n8n Cloud Webhook Configuration Details</span>
              </div>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                <strong>Configured Webhook URL:</strong>{' '}
                <code className="text-cyan-300 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800 break-all">
                  {N8N_CHAT_WEBHOOK_URL}
                </code>
              </p>
              <div className="space-y-1 text-[11px] text-slate-400">
                <p>
                  <strong>How requests are routed:</strong> The frontend routes requests through a resilient backend proxy (<code>/api/n8n-chat</code>) with automatic direct fallback to avoid browser CORS blocks.
                </p>
                <p>
                  <strong>To configure CORS in your n8n workflow:</strong>
                </p>
                <ol className="list-decimal pl-4 space-y-0.5 text-slate-400">
                  <li>Open your workflow in n8n Cloud and double-click the <strong>Chat Trigger</strong> or <strong>Webhook</strong> node.</li>
                  <li>In the node settings, navigate to <strong>Allowed Origins (CORS)</strong>.</li>
                  <li>Add <code>*</code> (for any origin) or your app's domain (e.g. <code>https://ais-dev-...run.app</code>).</li>
                  <li>Ensure the workflow is toggled to <strong>Active / Production</strong>.</li>
                </ol>
              </div>
            </div>
          )}
        </div>

        {/* =========================================================
            VIEW 1: EMBEDDED IFRAME VIEW
           ========================================================= */}
        {engine === 'n8n_embedded' && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex-1 flex flex-col min-h-[580px] relative">
            <div className="p-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between text-xs text-slate-400">
              <span className="flex items-center gap-1.5">
                <Workflow className="h-3.5 w-3.5 text-violet-400" />
                <span>Hosting Official n8n Chat Interface</span>
              </span>
              <a
                href={N8N_CHAT_WEBHOOK_URL}
                target="_blank"
                rel="noreferrer"
                className="text-cyan-400 hover:underline flex items-center gap-1 text-[11px] font-semibold"
              >
                <span>Open Direct in New Tab</span>
                <ExternalLink className="h-3 w-3" />
              </a>
            </div>

            {/* Iframe */}
            <div className="relative flex-1 w-full h-full min-h-[520px]">
              {iframeLoading && (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950 z-10 space-y-3">
                  <div className="h-8 w-8 border-3 border-violet-500 border-t-transparent rounded-full animate-spin" />
                  <p className="text-xs text-slate-400">
                    Connecting to n8n Cloud Webhook interface...
                  </p>
                </div>
              )}
              <iframe
                src={N8N_CHAT_WEBHOOK_URL}
                title="n8n Roomora Concierge Chat"
                className="w-full h-full min-h-[520px] border-none bg-white rounded-b-3xl"
                onLoad={() => setIframeLoading(false)}
                allow="clipboard-write; microphone"
              />
            </div>
          </div>
        )}

        {/* =========================================================
            VIEW 2: INTERACTIVE CUSTOM UI (n8n_workflow OR gemini_flash)
           ========================================================= */}
        {engine !== 'n8n_embedded' && (
          <div className="flex-1 flex flex-col">
            {/* Connection Error Banner */}
            {connectionError && (
              <div className="mb-4 p-4 bg-rose-950/70 border border-rose-800 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-rose-300 shadow-lg animate-in fade-in">
                <div className="flex items-start gap-2.5">
                  <AlertTriangle className="h-5 w-5 text-rose-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-white font-semibold">
                      Connection Issue with {engine === 'n8n_workflow' ? 'n8n Cloud Workflow' : 'Gemini API'}
                    </strong>
                    <span className="text-rose-300/90 leading-relaxed block mt-0.5">
                      {connectionError}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                  {lastFailedQuery && (
                    <button
                      onClick={handleRetry}
                      className="px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold flex items-center gap-1.5 shadow-md"
                    >
                      <RefreshCw className="h-3.5 w-3.5" />
                      <span>Retry</span>
                    </button>
                  )}
                  {engine === 'n8n_workflow' && (
                    <button
                      onClick={() => setEngine('gemini_flash')}
                      className="px-3 py-1.5 rounded-xl bg-slate-900 border border-rose-700 hover:bg-slate-800 text-slate-200 font-semibold"
                    >
                      Switch to Gemini
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Message Stream */}
            <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-4 sm:p-6 flex-1 overflow-y-auto space-y-5 max-h-[56vh] sm:max-h-[60vh] shadow-inner">
              {activeMessages.map((msg) => {
                const isUser = msg.role === 'user';
                return (
                  <div
                    key={msg.id}
                    className={`flex gap-3 sm:gap-4 ${isUser ? 'justify-end' : 'justify-start'}`}
                  >
                    {!isUser && (
                      <div
                        className={`h-8 w-8 rounded-xl border flex items-center justify-center shrink-0 text-xs font-bold mt-1 ${
                          engine === 'n8n_workflow'
                            ? 'bg-violet-950 border-violet-800 text-violet-400'
                            : 'bg-cyan-950 border-cyan-800 text-cyan-400'
                        }`}
                      >
                        {engine === 'n8n_workflow' ? (
                          <Workflow className="h-4 w-4" />
                        ) : (
                          <BotMessageSquare className="h-4 w-4" />
                        )}
                      </div>
                    )}

                    <div className="max-w-[85%] sm:max-w-[78%] space-y-2">
                      <div
                        className={`rounded-2xl p-4 sm:p-5 text-xs sm:text-sm leading-relaxed ${
                          isUser
                            ? 'bg-cyan-600 text-white rounded-tr-none shadow-md shadow-cyan-950 font-medium'
                            : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none shadow-lg'
                        }`}
                      >
                        <div className="whitespace-pre-line space-y-2">
                          {msg.content}
                        </div>

                        {!isUser && (
                          <div className="pt-3 mt-3 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
                            <span className="flex items-center gap-1">
                              {engine === 'n8n_workflow' ? (
                                <>
                                  <Workflow className="h-3 w-3 text-violet-400" />
                                  <span>Roomora Concierge (n8n Cloud)</span>
                                </>
                              ) : (
                                <>
                                  <Sparkles className="h-3 w-3 text-cyan-400" />
                                  <span>Gemini 3.8 Flash Model</span>
                                </>
                              )}
                            </span>
                            <button
                              onClick={() => handleCopyMessage(msg.id, msg.content)}
                              className="hover:text-cyan-400 flex items-center gap-1 transition-colors"
                            >
                              {copiedId === msg.id ? (
                                <>
                                  <Check className="h-3 w-3 text-emerald-400" />
                                  <span className="text-emerald-400">Copied</span>
                                </>
                              ) : (
                                <>
                                  <Copy className="h-3 w-3" />
                                  <span>Copy</span>
                                </>
                              )}
                            </button>
                          </div>
                        )}
                      </div>

                      {/* Suggested follow up chips */}
                      {!isUser && msg.suggestedFollowUps && msg.suggestedFollowUps.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 pt-1 pl-1">
                          {msg.suggestedFollowUps.map((chip, idx) => (
                            <button
                              key={idx}
                              onClick={() => handleSendMessage(chip)}
                              className="text-[11px] bg-slate-950 hover:bg-slate-800 text-cyan-300 hover:text-cyan-200 px-2.5 py-1 rounded-lg border border-slate-800 hover:border-cyan-700 transition-colors text-left"
                            >
                              ↳ {chip}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>

                    {isUser && (
                      <div className="h-8 w-8 rounded-xl bg-slate-800 border border-slate-700 text-cyan-300 flex items-center justify-center shrink-0 text-xs font-bold mt-1">
                        <User className="h-4 w-4" />
                      </div>
                    )}
                  </div>
                );
              })}

              {/* Loading Indicator */}
              {isLoading && (
                <div className="flex gap-3 justify-start items-center">
                  <div
                    className={`h-8 w-8 rounded-xl border flex items-center justify-center shrink-0 ${
                      engine === 'n8n_workflow'
                        ? 'bg-violet-950 border-violet-800 text-violet-400'
                        : 'bg-cyan-950 border-cyan-800 text-cyan-400'
                    }`}
                  >
                    <RefreshCw className="h-4 w-4 animate-spin" />
                  </div>
                  <div className="bg-slate-900 border border-slate-800 rounded-2xl rounded-tl-none p-3.5 text-xs text-slate-400 flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-violet-400 animate-bounce" />
                    <div className="h-2 w-2 rounded-full bg-violet-400 animate-bounce [animation-delay:0.2s]" />
                    <div className="h-2 w-2 rounded-full bg-violet-400 animate-bounce [animation-delay:0.4s]" />
                    <span className="ml-1 text-[11px] text-slate-400">
                      {engine === 'n8n_workflow'
                        ? 'Executing n8n Cloud Workflow for you...'
                        : `Synthesizing guidance for ${studentProfile.name}...`}
                    </span>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Quick Prompts Chips Drawer */}
            <div className="my-3 flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
              {promptChips.map((chip, i) => (
                <button
                  key={i}
                  onClick={() => handleSendMessage(chip)}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-cyan-300 text-[11px] font-medium border border-slate-800 hover:border-slate-700 whitespace-nowrap transition-colors"
                >
                  {chip}
                </button>
              ))}
            </div>

            {/* Input Bar */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="relative"
            >
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder={
                  engine === 'n8n_workflow'
                    ? 'Message n8n Roomora Concierge workflow...'
                    : 'Ask Gemini Career Mentor anything...'
                }
                className="w-full pl-4 pr-14 py-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500 shadow-xl"
              />
              <button
                type="submit"
                disabled={!inputMessage.trim() || isLoading}
                className={`absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-xl transition-all ${
                  inputMessage.trim() && !isLoading
                    ? engine === 'n8n_workflow'
                      ? 'bg-violet-600 hover:bg-violet-500 text-white shadow-md shadow-violet-950'
                      : 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-md shadow-cyan-950'
                    : 'bg-slate-800 text-slate-600 cursor-not-allowed'
                }`}
              >
                <Send className="h-4 w-4" />
              </button>
            </form>

            {/* Disclaimer */}
            <div className="flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-400 mt-3 px-1 gap-1">
              <span>
                Connected to n8n Webhook: <code className="text-violet-400">...13b3635b.../chat</code>
              </span>
              <span>
                Session: <code className="text-slate-500">{n8nSessionId.slice(0, 14)}...</code>
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
