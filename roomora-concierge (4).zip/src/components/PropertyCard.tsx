import React, { useState } from 'react';
import { 
  ShieldCheck, 
  AlertTriangle, 
  MapPin, 
  Sparkles, 
  Calendar, 
  Heart, 
  ChevronRight, 
  Info,
  Check,
  Scale,
  ExternalLink,
  Phone,
  Lock
} from 'lucide-react';
import { Property } from '../types';
import { isMessListing, getMessDisplayName } from '../utils/messUtils';

interface PropertyCardProps {
  property: Property;
  onSelect: (prop: Property) => void;
  onScheduleVisit: (prop: Property) => void;
  onAskConcierge: (prop: Property) => void;
  isSaved?: boolean;
  onToggleSave?: (propId: string) => void;
  isCompared?: boolean;
  onToggleCompare?: (propId: string) => void;
  onOpenMessAdminLogin?: (prop: Property) => void;
}

export const PropertyCard: React.FC<PropertyCardProps> = ({
  property,
  onSelect,
  onScheduleVisit,
  onAskConcierge,
  isSaved = false,
  onToggleSave,
  isCompared = false,
  onToggleCompare,
  onOpenMessAdminLogin
}) => {
  const [activeImageIdx, setActiveImageIdx] = useState(0);

  const getVerificationBadge = () => {
    switch (property.verificationStatus) {
      case 'verified_by_platform':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-500/90 text-white backdrop-blur-md shadow-xs">
            <ShieldCheck className="w-3.5 h-3.5" />
            Verified Stay
          </span>
        );
      case 'information_incomplete':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-500/90 text-white backdrop-blur-md shadow-xs">
            <AlertTriangle className="w-3.5 h-3.5" />
            Incomplete Info
          </span>
        );
      case 'report_under_review':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-red-500/90 text-white backdrop-blur-md shadow-xs">
            <AlertTriangle className="w-3.5 h-3.5" />
            Under Review
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-slate-700/80 text-white backdrop-blur-md">
            Verification Pending
          </span>
        );
    }
  };

  const primaryCampus = property.distanceToCampus[0] || {
    campusName: 'KIIT Deemed to be University',
    distanceKm: 0.8,
    walkingTimeMin: 10
  };

  return (
    <div className="group rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 shadow-sm hover:shadow-xl hover:border-slate-300 dark:hover:border-slate-700 transition-all duration-300 flex flex-col overflow-hidden relative">
      
      {/* Image container */}
      <div className="relative aspect-16/10 w-full overflow-hidden bg-slate-100 dark:bg-slate-800">
        <img
          src={property.images[activeImageIdx] || property.images[0]}
          alt={property.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
          onError={(e) => {
            (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=800&q=80';
          }}
        />

        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-black/30 pointer-events-none" />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 flex flex-wrap items-center gap-1.5 z-10">
          {getVerificationBadge()}
          {property.gmapUrl && (
            <a
              href={property.gmapUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()}
              title="Open in Google Maps"
              className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-600/90 hover:bg-blue-500 text-white border border-blue-400/40 backdrop-blur-md shadow-xs flex items-center gap-1 transition-all"
            >
              <MapPin className="w-3 h-3 text-red-300" />
              <span>G-Map Verified</span>
            </a>
          )}
          {property.demoListing && (
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-900/80 text-amber-300 border border-amber-400/30 backdrop-blur-md">
              DEMO LISTING
            </span>
          )}
        </div>

        {/* Save button & Compare checkbox */}
        <div className="absolute top-3 right-3 flex items-center gap-2 z-10">
          {onToggleCompare && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleCompare(property.id);
              }}
              title="Compare side-by-side"
              className={`p-1.5 rounded-full backdrop-blur-md transition-all text-xs flex items-center gap-1 font-semibold ${
                isCompared
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'bg-black/40 text-white hover:bg-black/60'
              }`}
            >
              <Scale className="w-3.5 h-3.5" />
            </button>
          )}

          {onToggleSave && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleSave(property.id);
              }}
              className={`p-2 rounded-full backdrop-blur-md transition-colors ${
                isSaved
                  ? 'bg-red-500 text-white'
                  : 'bg-black/40 text-white hover:bg-black/60'
              }`}
              aria-label="Save listing"
            >
              <Heart className={`w-3.5 h-3.5 ${isSaved ? 'fill-current' : ''}`} />
            </button>
          )}
        </div>

        {/* Bottom image overlay: Price & Bed Availability */}
        <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between text-white z-10">
          <div>
            <div className="flex items-baseline gap-1">
              <span className="text-xl font-extrabold font-heading tracking-tight">
                ₹{property.monthlyRent.toLocaleString('en-IN')}
              </span>
              <span className="text-xs text-slate-300 font-normal">/month</span>
            </div>
            <p className="text-[11px] text-slate-300">
              Deposit: ₹{property.deposit.toLocaleString('en-IN')}
            </p>
          </div>

          <div className="text-right">
            <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${
              property.availableBeds > 0
                ? 'bg-emerald-500/90 text-white'
                : 'bg-red-500/90 text-white'
            }`}>
              {property.availableBeds > 0 ? `${property.availableBeds} beds left` : 'Occupied'}
            </span>
          </div>
        </div>

        {/* Thumbnail indicators */}
        {property.images.length > 1 && (
          <div className="absolute bottom-1 left-1/2 -translate-x-1/2 flex gap-1 z-10">
            {property.images.map((_, idx) => (
              <button
                key={idx}
                onClick={(e) => {
                  e.stopPropagation();
                  setActiveImageIdx(idx);
                }}
                className={`w-1.5 h-1.5 rounded-full transition-all ${
                  activeImageIdx === idx ? 'bg-white w-3' : 'bg-white/50'
                }`}
              />
            ))}
          </div>
        )}
      </div>

      {/* Content details */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
        <div>
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-1">
            <span className="font-semibold text-slate-700 dark:text-slate-300 capitalize">
              {property.roomType.replace(/_/g, ' ')} • {property.genderPreference}
            </span>
            <span className="capitalize">{property.furnished.replace(/_/g, ' ')}</span>
          </div>

          <h3 
            onClick={() => onSelect(property)}
            className="font-bold text-base text-slate-900 dark:text-white line-clamp-1 hover:text-amber-600 dark:hover:text-amber-400 cursor-pointer font-heading transition-colors"
          >
            {property.title}
          </h3>

          <div className="flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400 mt-1">
            <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span className="truncate">{property.locality}, {property.city}</span>
          </div>

          {/* Dedicated Mess Box if available */}
          {property.messName && (
            <div className="mt-2.5 p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs flex items-center justify-between text-slate-700 dark:text-slate-200">
              <div className="flex items-center gap-1.5 min-w-0">
                <span className="font-bold text-amber-600 dark:text-amber-400 shrink-0 text-[11px]">🍱 Mess:</span>
                <span className="font-medium truncate text-[11px]">{property.messName}</span>
              </div>
              {(property.messPhone || property.hostPhone) && (
                <a
                  href={`tel:${property.messPhone || property.hostPhone}`}
                  onClick={(e) => e.stopPropagation()}
                  className="text-[11px] font-mono text-cyan-600 dark:text-cyan-400 hover:underline shrink-0 ml-1.5 flex items-center gap-0.5"
                  title="Call Mess Provider"
                >
                  <Phone className="w-3 h-3" />
                  <span>{property.messPhone || property.hostPhone}</span>
                </a>
              )}
            </div>
          )}

          {/* Commute to campus indicator */}
          <div className="mt-2.5 p-2 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs flex items-center justify-between text-slate-600 dark:text-slate-300">
            <span className="truncate text-[11px] font-medium">{primaryCampus.campusName}</span>
            <span className="font-bold text-slate-900 dark:text-white whitespace-nowrap text-[11px] ml-1">
              {primaryCampus.distanceKm} km ({primaryCampus.walkingTimeMin}m walk)
            </span>
          </div>

          {/* Fair Rent comparison pill */}
          <div className="mt-2 text-[11px] flex items-center gap-1.5">
            <span className={`px-1.5 py-0.5 rounded font-bold ${
              property.fairRentScore.status === 'fair'
                ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800'
                : property.fairRentScore.status === 'below_average'
                ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-400 border border-blue-200 dark:border-blue-800'
                : 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400 border border-amber-200 dark:border-amber-800'
            }`}>
              Fair-Rent: {property.fairRentScore.differencePercentage <= 0 ? `${Math.abs(property.fairRentScore.differencePercentage)}% below avg` : `${property.fairRentScore.differencePercentage}% above avg`}
            </span>
          </div>

          {/* Key amenities tags */}
          <div className="mt-2.5 flex flex-wrap gap-1">
            {property.amenities.slice(0, 3).map((amenity, i) => (
              <span
                key={i}
                className="px-2 py-0.5 rounded-md text-[10px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"
              >
                {amenity}
              </span>
            ))}
            {property.amenities.length > 3 && (
              <span className="text-[10px] text-slate-400 py-0.5">
                +{property.amenities.length - 3} more
              </span>
            )}
          </div>
        </div>

        {/* For all mess listings: Visit on G-Map & Call Now (same as Fooding tab) */}
        {isMessListing(property) && (
          <div className="pt-2">
            <div className="grid grid-cols-2 gap-2">
              {/* Direct Visit Button to Google Maps */}
              <a
                href={
                  property.gmapUrl ||
                  `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                    `${property.title} ${property.address || property.locality} ${property.city || 'Odisha'}`
                  )}`
                }
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => e.stopPropagation()}
                className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#881337] to-[#be123c] hover:from-[#700f2b] hover:to-[#9f1239] text-white font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all hover:shadow-md ring-1 ring-rose-400/30"
                title="Directly open location in Google Maps"
              >
                <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                <span>Visit on G-Map</span>
              </a>

              {/* Direct Phone Call - Call Now */}
              <a
                href={`tel:${(property.messPhone || property.hostPhone || '+91 94372 81904').replace(/[^0-9+]/g, '')}`}
                onClick={(e) => e.stopPropagation()}
                className="py-2.5 px-3 rounded-xl bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/60 dark:hover:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300 font-bold text-xs flex items-center justify-center gap-1.5 border border-emerald-200 dark:border-emerald-800 transition-colors"
                title={`Call ${getMessDisplayName(property)}: ${property.messPhone || property.hostPhone}`}
              >
                <Phone className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <span>Call Now</span>
              </a>
            </div>
          </div>
        )}

        {/* Mess Admin Login for all identified mess listings */}
        {isMessListing(property) && onOpenMessAdminLogin && (
          <div className="pt-2">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onOpenMessAdminLogin(property);
              }}
              className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-[#4c0519] via-[#881337] to-[#4c0519] hover:from-[#5c0720] hover:to-[#70102e] text-amber-200 hover:text-white border border-amber-400/50 text-xs font-black shadow-md flex items-center justify-center gap-2 transition-all group/btn"
              title={`Authorized Administrator login for ${getMessDisplayName(property)}`}
            >
              <Lock className="w-3.5 h-3.5 text-amber-400 group-hover/btn:scale-110 transition-transform" />
              <span>Mess Admin Login</span>
              <span className="text-[10px] text-amber-300/80 font-normal hidden sm:inline">({getMessDisplayName(property)})</span>
            </button>
          </div>
        )}

        {/* Action buttons */}
        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-1.5">
          {/* Direct Google Maps Visit Button for non-mess stays (mess stays have dedicated buttons above) */}
          {!isMessListing(property) && property.gmapUrl && (
            <a
              href={property.gmapUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()}
              className="flex-1 min-w-[100px] py-2 px-2.5 text-xs font-bold rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white transition-all flex items-center justify-center gap-1 shadow-xs"
              title="Directly open location in Google Maps"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Visit G-Map</span>
            </a>
          )}

          <button
            onClick={() => onScheduleVisit(property)}
            className={`${property.gmapUrl ? 'px-2.5' : 'flex-1'} py-2 text-xs font-bold rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 transition-colors flex items-center justify-center gap-1`}
            title="Schedule in-person physical tour"
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Tour</span>
          </button>

          <button
            onClick={() => onAskConcierge(property)}
            title="Ask AI Concierge to evaluate and handle this stay"
            className="py-2 px-2.5 text-xs font-bold rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 transition-colors flex items-center justify-center gap-1 shadow-xs"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Concierge</span>
          </button>

          <button
            onClick={() => onSelect(property)}
            className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors"
            title="View full specs"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

      </div>

    </div>
  );
};
