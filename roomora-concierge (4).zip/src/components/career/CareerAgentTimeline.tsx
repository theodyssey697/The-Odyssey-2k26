import React from 'react';
import { CareerAgentEvent } from '../../types/career';
import { CheckCircle2, Loader2, AlertCircle, Clock } from 'lucide-react';

interface CareerAgentTimelineProps {
  events: CareerAgentEvent[];
  activeStageName?: string;
  isRunning: boolean;
}

const STAGES = [
  { id: 'validation', label: '1. Profile Validation Agent', desc: 'Validates completeness and consistency' },
  { id: 'discovery', label: '2. Career Discovery Agent', desc: 'Generates strongest fit, adjacent & stretch paths' },
  { id: 'skill_gap', label: '3. Skill Gap & Roadmap Agent', desc: 'Maps current skills against target competencies' },
  { id: 'resource_selection', label: '4. Resource Selection Agent', desc: 'Curates SWAYAM, NPTEL & AICTE portals' },
  { id: 'review', label: '5. Career Plan Review Agent', desc: 'Ensures consistency, realism & high provenance' },
];

export const CareerAgentTimeline: React.FC<CareerAgentTimelineProps> = ({ events, activeStageName, isRunning }) => {
  return (
    <div className="bg-[#fff5f6] border border-rose-200/80 rounded-2xl p-6 shadow-sm">
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-rose-200">
        <div>
          <h3 className="text-sm font-extrabold text-[#4c0519] font-heading flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#be123c] animate-pulse"></span>
            Agentic AI Orchestration Pipeline
          </h3>
          <p className="text-xs text-[#881337]/80">Backend multi-stage autonomous reasoning & validation</p>
        </div>
        {isRunning && (
          <div className="flex items-center gap-2 px-3 py-1 bg-rose-100 text-[#881337] rounded-full text-xs font-bold animate-pulse">
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
            Running Pipeline...
          </div>
        )}
      </div>

      <div className="space-y-3">
        {STAGES.map((stage, idx) => {
          // Find matching event
          const event = events.find(e => e.stageName === stage.id);
          const status = event ? event.status : isRunning ? 'pending' : 'pending';
          const isActive = activeStageName === stage.id || (isRunning && !event && idx === 0);

          return (
            <div key={stage.id} className={`flex items-start gap-3 p-3 rounded-xl border transition-all ${
              status === 'completed'
                ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
                : status === 'in_progress' || isActive
                ? 'bg-rose-100/80 border-rose-300 text-[#4c0519] shadow-xs'
                : status === 'failed'
                ? 'bg-red-50 border-red-200 text-red-950'
                : 'bg-white/60 border-rose-100 text-slate-500 opacity-70'
            }`}>
              <div className="mt-0.5 shrink-0">
                {status === 'completed' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                ) : status === 'in_progress' || isActive ? (
                  <Loader2 className="w-4 h-4 text-[#be123c] animate-spin" />
                ) : status === 'failed' ? (
                  <AlertCircle className="w-4 h-4 text-red-600" />
                ) : (
                  <Clock className="w-4 h-4 text-slate-400" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold font-heading">{stage.label}</h4>
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md bg-white/80">
                    {status}
                  </span>
                </div>
                <p className="text-[11px] mt-0.5 opacity-90">{event ? event.message : stage.desc}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
