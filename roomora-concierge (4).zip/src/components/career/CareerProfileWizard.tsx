import React, { useState, useEffect } from 'react';
import { CareerProfile } from '/src/types/career';
import { CAREER_QUESTIONS } from '/src/data/careerQuestions';
import { CareerQuestionPage } from './CareerQuestionPage';
import { Sparkles, Edit3, Save } from 'lucide-react';

interface CareerProfileWizardProps {
  initialProfile?: CareerProfile | null;
  onSaveDraft: (profile: Partial<CareerProfile>) => void;
  onGeneratePlan: (profile: CareerProfile) => void;
  isLoading: boolean;
}

export const CareerProfileWizard: React.FC<CareerProfileWizardProps> = ({
  initialProfile,
  onSaveDraft,
  onGeneratePlan,
  isLoading
}) => {
  const getQuestionIdFromHash = () => {
    const hash = window.location.hash;
    const match = hash.match(/\/assessment\/([^/]+)/);
    return match ? match[1] : null;
  };

  const [answers, setAnswers] = useState<Record<string, any>>(initialProfile ? {
      'education-stage': initialProfile.education.currentYear,
      'course-specialisation': initialProfile.education.branch,
      'study-stage': initialProfile.education.currentYear,
      'subject-interests': initialProfile.education.enjoyedSubjects,
      'project-achievement': initialProfile.skills.projectsCertifications,
      'practical-experience': initialProfile.skills.practicalExperience,
      'career-interests': initialProfile.interests.domains,
      'near-term-goals': initialProfile.interests.shortTermGoals,
      'work-preferences': initialProfile.interests.preferredLocation,
      'weekly-learning-time': initialProfile.constraints.weeklyHoursAvailable.toString(),
      'learning-budget': initialProfile.constraints.learningBudget === 'free' ? 'Free resources only' : 'Flexible',
      'learning-style': initialProfile.constraints.preferredFormats,
      'practical-considerations': initialProfile.constraints.voluntaryConstraints
  } : {});

  const [currentQId, setCurrentQId] = useState<string | null>(getQuestionIdFromHash() || CAREER_QUESTIONS[0].id);

  useEffect(() => {
    if (currentQId) {
      window.location.hash = `/student/profile/career-counselling/assessment/${currentQId}`;
    }
  }, [currentQId]);

  useEffect(() => {
    const handleHashChange = () => {
      const qId = getQuestionIdFromHash();
      if (qId) setCurrentQId(qId);
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const currentIndex = CAREER_QUESTIONS.findIndex(q => q.id === currentQId);
  const totalQuestions = CAREER_QUESTIONS.length;

  const handleAnswerChange = (val: any) => {
    if (currentQId) {
      setAnswers(prev => ({ ...prev, [currentQId]: val }));
    }
  };

  const buildProfileFromAnswers = (): CareerProfile => {
    return {
      uid: initialProfile?.uid || 'current-user',
      email: initialProfile?.email || 'student@roomora.in',
      fullName: initialProfile?.fullName || 'Aryan Sharma',
      education: {
        collegeName: answers['course-specialisation'] || 'KIIT University',
        degree: 'B.Tech',
        branch: answers['course-specialisation'] || 'Computer Science',
        currentYear: answers['study-stage'] || '3rd Year',
        semester: '6th',
        expectedGraduationYear: '2027',
        enjoyedSubjects: Array.isArray(answers['subject-interests']) ? answers['subject-interests'] : ['Computer Science'],
        cgpa: '8.8'
      },
      skills: {
        technicalSkills: Array.isArray(answers['skills-proficiency']) ? answers['skills-proficiency'] : ['JavaScript'],
        softSkills: Array.isArray(answers['personal-strengths']) ? answers['personal-strengths'] : ['Communication'],
        skillProficiency: { 'JavaScript': 'advanced' },
        projectsCertifications: answers['project-achievement'] || 'Roomora Project',
        practicalExperience: answers['practical-experience'] || 'Student projects'
      },
      interests: {
        domains: Array.isArray(answers['career-interests']) ? answers['career-interests'] : ['Software Engineering'],
        roles: Array.isArray(answers['career-interests']) ? answers['career-interests'] : ['Software Engineer'],
        enjoyedActivities: Array.isArray(answers['enjoyable-activities']) ? answers['enjoyable-activities'] : ['building'],
        preferredOutcome: 'job',
        shortTermGoals: answers['near-term-goals'] || 'Secure internship',
        longTermGoals: 'Become Lead Tech Architect',
        preferredLocation: answers['work-preferences'] || 'Remote'
      },
      constraints: {
        weeklyHoursAvailable: parseInt(answers['weekly-learning-time']) || 15,
        learningBudget: answers['learning-budget'] === 'Free resources only' ? 'free' : 'flexible',
        preferredFormats: Array.isArray(answers['learning-style']) ? answers['learning-style'] : ['hands-on projects'],
        learningLanguages: ['English'],
        voluntaryConstraints: answers['practical-considerations'] || ''
      },
      draftSaved: true,
      updatedAt: new Date().toISOString()
    };
  };

  const handleSaveDraftAction = () => {
    onSaveDraft(buildProfileFromAnswers());
  };

  if (currentQId === 'review') {
    return (
      <div className="bg-white border border-rose-200/90 rounded-3xl p-6 sm:p-10 shadow-sm max-w-3xl mx-auto animate-in fade-in duration-200 space-y-8">
        <h2 className="text-xl font-extrabold text-[#4c0519]">Review Your Assessment</h2>
        <div className="space-y-4">
          {CAREER_QUESTIONS.map((q) => (
            <div key={q.id} className="p-4 rounded-2xl border border-rose-200/70 bg-rose-50/20 flex items-start justify-between">
              <div>
                <h4 className="text-sm font-bold text-[#4c0519]">{q.title}</h4>
                <p className="text-xs text-slate-700">{JSON.stringify(answers[q.id] || 'Not answered')}</p>
              </div>
              <button onClick={() => setCurrentQId(q.id)} className="text-[#881337]"><Edit3 className="w-4 h-4" /></button>
            </div>
          ))}
        </div>
        <button
          onClick={() => onGeneratePlan(buildProfileFromAnswers())}
          disabled={isLoading}
          className="w-full py-3 rounded-2xl bg-[#881337] text-white font-bold"
        >
          {isLoading ? 'Generating Plan...' : 'Generate My Career Plan'}
        </button>
      </div>
    );
  }

  const currentQuestion = CAREER_QUESTIONS[currentIndex];
  if (!currentQuestion) return null;

  return (
    <CareerQuestionPage
      stepNumber={currentIndex + 1}
      totalSteps={totalQuestions}
      questionId={currentQuestion.id}
      questionText={currentQuestion.title}
      whyUseful={currentQuestion.description}
      inputType={currentQuestion.inputType}
      options={currentQuestion.options}
      value={answers[currentQuestion.id]}
      onChange={(val) => setAnswers(prev => ({ ...prev, [currentQuestion.id]: val }))}
      onSaveDraft={handleSaveDraftAction}
      onPrev={() => currentIndex > 0 && setCurrentQId(CAREER_QUESTIONS[currentIndex - 1].id)}
      onNext={() => currentIndex < totalQuestions - 1 ? setCurrentQId(CAREER_QUESTIONS[currentIndex + 1].id) : setCurrentQId('review')}
      isOptional={currentQuestion.isOptional}
    />
  );
};
