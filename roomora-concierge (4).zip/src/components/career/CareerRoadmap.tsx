import React from 'react';
import { CareerRoadmap, CareerMilestone } from '../../types/career';
import { CheckSquare, Square, Clock, Award, Target, Calendar } from 'lucide-react';

interface CareerRoadmapProps {
  roadmap: CareerRoadmap;
  onToggleMilestone: (milestoneId: string) => void;
}

export const CareerRoadmapComponent: React.FC<CareerRoadmapProps> = ({ roadmap, onToggleMilestone }) => {
  const phases = [
    { title: roadmap.phase30Days.phaseTitle, days: 30, milestones: roadmap.phase30Days.milestones },
    { title: roadmap.phase60Days.phaseTitle, days: 60, milestones: roadmap.phase60Days.milestones },
    { title: roadmap.phase90Days.phaseTitle, days: 90, milestones: roadmap.phase90Days.milestones },
  ];

  // Calculate total progress
  const allMilestones = phases.flatMap(p => p.milestones);
  const completedCount = allMilestones.filter(m => m.completed).length;
  const progressPercent = allMilestones.length ? Math.round((completedCount / allMilestones.length) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Overview Progress Card */}
      <div className="bg-gradient-to-r from-[#1a040b] to-[#4c0519] text-[#ffe4e6] rounded-3xl p-6 sm:p-8 shadow-md">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <span className="text-[10px] uppercase font-extrabold tracking-widest px-2.5 py-1 rounded-md bg-[#881337] text-white">
              Personalised 90-Day Execution Plan
            </span>
            <h2 className="text-xl sm:text-2xl font-extrabold font-heading text-white mt-2">
              Your Career Progression Roadmap
            </h2>
            <p className="text-xs text-rose-200/80 mt-1">Track weekly milestones, estimated hours, and verifiable deliverables.</p>
          </div>
          <div className="bg-rose-950/80 border border-rose-800/80 px-5 py-3 rounded-2xl text-right">
            <span className="text-xs text-rose-300 font-bold block">Overall Progress</span>
            <span className="text-2xl font-extrabold text-white font-heading">{progressPercent}%</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-rose-950/60 h-3 rounded-full overflow-hidden p-0.5 border border-rose-900">
          <div 
            className="bg-gradient-to-r from-amber-400 to-rose-400 h-full rounded-full transition-all duration-500" 
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Roadmap Phases */}
      {phases.map((phase, phaseIdx) => (
        <div key={phaseIdx} className="bg-white border border-rose-200/80 rounded-3xl p-6 sm:p-8 shadow-sm">
          <div className="flex items-center gap-3 mb-6 pb-4 border-b border-rose-100">
            <div className="w-10 h-10 rounded-xl bg-rose-100 text-[#881337] flex items-center justify-center font-extrabold text-sm font-heading">
              {phase.days}D
            </div>
            <div>
              <h3 className="text-base font-extrabold text-[#4c0519] font-heading">{phase.title}</h3>
              <p className="text-xs text-slate-500">Milestones and weekly deliverables</p>
            </div>
          </div>

          <div className="space-y-4">
            {phase.milestones.map((m) => (
              <div 
                key={m.id}
                onClick={() => onToggleMilestone(m.id)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-4 ${
                  m.completed 
                    ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950' 
                    : 'bg-rose-50/30 border-rose-200/70 hover:border-rose-300 text-slate-800'
                }`}
              >
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleMilestone(m.id);
                  }}
                  className="mt-1 text-[#881337] hover:scale-110 transition-transform"
                >
                  {m.completed ? (
                    <CheckSquare className="w-5 h-5 text-emerald-600 fill-emerald-100" />
                  ) : (
                    <Square className="w-5 h-5 text-rose-300" />
                  )}
                </button>

                <div className="flex-1 min-w-0">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-1">
                    <h4 className={`text-sm font-bold font-heading ${m.completed ? 'line-through opacity-80' : 'text-[#4c0519]'}`}>
                      Week {m.weekNumber}: {m.title}
                    </h4>
                    <div className="flex items-center gap-3 text-[11px] text-slate-500">
                      <span className="flex items-center gap-1 font-semibold">
                        <Clock className="w-3.5 h-3.5 text-amber-600" />
                        {m.estimatedHours} hrs/week
                      </span>
                    </div>
                  </div>

                  <p className={`text-xs mb-2 ${m.completed ? 'opacity-70' : 'text-slate-600'}`}>{m.description}</p>

                  <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white border border-rose-200/80 text-[11px] font-semibold text-[#881337]">
                    <Target className="w-3.5 h-3.5 text-[#be123c]" />
                    <span>Deliverable: {m.deliverable}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};
