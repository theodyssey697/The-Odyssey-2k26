import React, { useState } from 'react';
import { Save, ChevronLeft, ChevronRight, CheckCircle2, Sparkles } from 'lucide-react';

interface CareerQuestionPageProps {
  stepNumber: number;
  totalSteps: number;
  questionId: string;
  questionText: string;
  whyUseful: string;
  inputType: 'radio' | 'checkbox' | 'text' | 'textarea' | 'select' | 'skills_grid';
  options?: string[];
  value: any;
  onChange: (val: any) => void;
  onSaveDraft: () => void;
  onPrev: () => void;
  onNext: () => void;
  isOptional?: boolean;
}

export const CareerQuestionPage: React.FC<CareerQuestionPageProps> = ({
  stepNumber,
  totalSteps,
  questionId,
  questionText,
  whyUseful,
  inputType,
  options = [],
  value,
  onChange,
  onSaveDraft,
  onPrev,
  onNext,
  isOptional = false
}) => {
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const percentage = Math.round((stepNumber / totalSteps) * 100);

  const handleNextClick = () => {
    if (!isOptional) {
      if (value === undefined || value === null || value === '' || (Array.isArray(value) && value.length === 0)) {
        setErrorMsg('Please select or provide an answer to continue.');
        return;
      }
      if ((inputType === 'text' || inputType === 'textarea') && typeof value === 'string' && value.trim().length < 5) {
        setErrorMsg('Please provide a more detailed response (minimum 5 characters).');
        return;
      }
    }
    setErrorMsg(null);
    onNext();
  };

  return (
    <div className="bg-white border border-rose-200/90 rounded-3xl p-6 sm:p-10 shadow-sm max-w-3xl mx-auto animate-in fade-in duration-200">
      {/* Top Header & Progress */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-xl bg-rose-100 text-[#881337] font-extrabold text-xs">
              Question {stepNumber} of {totalSteps}
            </span>
            {isOptional && (
              <span className="px-2.5 py-1 rounded-xl bg-slate-100 text-slate-600 font-semibold text-[11px]">
                Optional
              </span>
            )}
          </div>
          <button
            onClick={onSaveDraft}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-rose-200 bg-rose-50/70 text-[#881337] hover:bg-rose-100 font-bold text-xs transition-all shadow-2xs"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save Draft</span>
          </button>
        </div>

        {/* Progress bar */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-[11px] font-bold text-slate-500">
            <span>Assessment Progress</span>
            <span>{percentage}% Completed</span>
          </div>
          <div className="w-full h-2.5 bg-rose-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#881337] to-[#be123c] transition-all duration-300"
              style={{ width: `${percentage}%` }}
            />
          </div>
        </div>
      </div>

      {/* Question Heading */}
      <div className="mb-6">
        <h2 className="text-lg sm:text-xl font-extrabold text-[#4c0519] font-heading leading-snug mb-2">
          {questionText}
        </h2>
        <p className="text-xs sm:text-sm text-slate-600 bg-rose-50/60 border border-rose-100 rounded-2xl p-3.5 flex items-start gap-2.5">
          <Sparkles className="w-4 h-4 text-[#be123c] shrink-0 mt-0.5" />
          <span><strong>Why this is useful:</strong> {whyUseful}</span>
        </p>
      </div>

      {/* Answer Control */}
      <div className="mb-8">
        {inputType === 'radio' && (
          <div className="space-y-2.5">
            {options.map((opt, idx) => {
              const selected = value === opt;
              return (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    onChange(opt);
                    setErrorMsg(null);
                  }}
                  className={`w-full text-left p-4 rounded-2xl border transition-all flex items-center justify-between text-xs sm:text-sm font-semibold ${
                    selected
                      ? 'border-[#881337] bg-rose-50/80 text-[#881337] shadow-xs ring-1 ring-[#881337]'
                      : 'border-rose-200/80 bg-white hover:bg-rose-50/30 text-slate-800'
                  }`}
                >
                  <span>{opt}</span>
                  <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                    selected ? 'border-[#881337] bg-[#881337] text-white' : 'border-slate-300'
                  }`}>
                    {selected && <div className="w-2 h-2 rounded-full bg-white" />}
                  </div>
                </button>
              );
            })}
          </div>
        )}

        {inputType === 'checkbox' && (
          <div className="space-y-2.5">
            {options.map((opt, idx) => {
              const currentList = Array.isArray(value) ? value : [];
              const checked = currentList.includes(opt);
              return (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    if (checked) {
                      onChange(currentList.filter((item: string) => item !== opt));
                    } else {
                      onChange([...currentList, opt]);
                    }
                    setErrorMsg(null);
                  }}
                  className={`w-full text-left p-4 rounded-2xl border transition-all flex items-center justify-between text-xs sm:text-sm font-semibold ${
                    checked
                      ? 'border-[#881337] bg-rose-50/80 text-[#881337] shadow-xs ring-1 ring-[#881337]'
                      : 'border-rose-200/80 bg-white hover:bg-rose-50/30 text-slate-800'
                  }`}
                >
                  <span>{opt}</span>
                  <div className={`w-5 h-5 rounded-lg border flex items-center justify-center ${
                    checked ? 'border-[#881337] bg-[#881337] text-white' : 'border-slate-300'
                  }`}>
                    {checked && <CheckCircle2 className="w-3.5 h-3.5 text-white" />}
                  </div>
                </button>
              );
            })}
          </div>
        )}

        {inputType === 'text' && (
          <div>
            <input
              type="text"
              value={value || ''}
              onChange={e => {
                onChange(e.target.value);
                setErrorMsg(null);
              }}
              placeholder="Type your answer here..."
              className="w-full px-4 py-3.5 rounded-2xl border border-rose-200 bg-rose-50/30 text-xs sm:text-sm text-slate-800 focus:ring-2 focus:ring-[#881337] outline-none shadow-2xs"
            />
          </div>
        )}

        {inputType === 'textarea' && (
          <div>
            <textarea
              rows={4}
              value={value || ''}
              onChange={e => {
                onChange(e.target.value);
                setErrorMsg(null);
              }}
              placeholder="Provide details or paste your response..."
              className="w-full px-4 py-3.5 rounded-2xl border border-rose-200 bg-rose-50/30 text-xs sm:text-sm text-slate-800 focus:ring-2 focus:ring-[#881337] outline-none shadow-2xs"
            />
          </div>
        )}

        {errorMsg && (
          <p className="mt-2 text-xs font-bold text-red-600 animate-in fade-in">{errorMsg}</p>
        )}
      </div>

      {/* Navigation Footer */}
      <div className="flex items-center justify-between pt-6 border-t border-rose-100">
        <button
          onClick={onPrev}
          disabled={stepNumber === 1}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-rose-200 text-[#4c0519] hover:bg-rose-50 font-bold text-xs transition-all disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Previous</span>
        </button>

        <button
          onClick={handleNextClick}
          className="flex items-center gap-1.5 px-6 py-3 rounded-xl bg-[#881337] hover:bg-[#9f1239] text-white font-bold text-xs shadow-md transition-all"
        >
          <span>{stepNumber === totalSteps ? 'Review Answers' : 'Next Question'}</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
