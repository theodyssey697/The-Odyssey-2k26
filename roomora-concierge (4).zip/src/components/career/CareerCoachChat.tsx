import React, { useState, useRef, useEffect } from 'react';
import { CareerChatMessage } from '../../types/career';
import { MessageSquare, Send, Sparkles, User, Bot, Check } from 'lucide-react';

interface CareerCoachChatProps {
  messages: CareerChatMessage[];
  onSendMessage: (text: string) => void;
  isLoading: boolean;
  onApplyChanges?: (proposedChanges: any) => void;
}

export const CareerCoachChat: React.FC<CareerCoachChatProps> = ({
  messages,
  onSendMessage,
  isLoading,
  onApplyChanges
}) => {
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isLoading) return;
    onSendMessage(inputText);
    setInputText('');
  };

  const samplePrompts = [
    "Why was this pathway recommended?",
    "What if I am weak at programming?",
    "Which project should I do first?",
    "How should I adapt this plan to my semester schedule?",
    "Can you revise my roadmap for free resources only?"
  ];

  return (
    <div className="bg-white border border-rose-200/90 rounded-3xl flex flex-col h-[650px] shadow-sm overflow-hidden">
      {/* Header */}
      <div className="p-4 sm:p-6 bg-gradient-to-r from-[#1a040b] to-[#4c0519] text-[#ffe4e6] flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#881337] to-[#e11d48] text-white flex items-center justify-center shadow-md">
            <Sparkles className="w-5 h-5 text-amber-300" />
          </div>
          <div>
            <h3 className="font-extrabold text-sm sm:text-base font-heading text-white">AI Career Coach & Mentor</h3>
            <p className="text-[11px] text-rose-200/80">Context-aware guidance based on your profile & roadmap</p>
          </div>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-rose-50/20">
        {messages.length === 0 && (
          <div className="text-center py-12 px-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-[#881337] flex items-center justify-center mx-auto mb-3 shadow-2xs">
              <MessageSquare className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-[#4c0519] mb-1">Ask your AI Career Coach anything</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mb-6">Get personalized answers about your pathway, skill gaps, projects, or weekly study schedule.</p>
            
            <div className="flex flex-wrap gap-2 justify-center max-w-lg mx-auto">
              {samplePrompts.map((prompt, idx) => (
                <button
                  key={idx}
                  onClick={() => onSendMessage(prompt)}
                  className="px-3 py-1.5 rounded-xl bg-white border border-rose-200 text-[#4c0519] hover:bg-rose-50 text-xs font-semibold transition-all shadow-2xs"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg) => (
          <div key={msg.id} className={`flex items-start gap-3 ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}>
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 font-bold text-xs ${
              msg.sender === 'user'
                ? 'bg-[#881337] text-white shadow-xs'
                : 'bg-rose-100 text-[#881337] border border-rose-200'
            }`}>
              {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>

            <div className={`max-w-[80%] rounded-2xl p-4 text-xs leading-relaxed shadow-xs ${
              msg.sender === 'user'
                ? 'bg-[#881337] text-white rounded-tr-none'
                : 'bg-white border border-rose-200 text-slate-800 rounded-tl-none'
            }`}>
              <p className="whitespace-pre-wrap">{msg.text}</p>

              {msg.proposedChanges && onApplyChanges && (
                <div className="mt-3 pt-3 border-t border-rose-100 flex items-center justify-between">
                  <span className="text-[11px] font-bold text-[#881337]">Coach suggested plan updates</span>
                  <button
                    onClick={() => onApplyChanges(msg.proposedChanges)}
                    className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-[11px] shadow-2xs transition-all"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Apply Changes</span>
                  </button>
                </div>
              )}
              
              <span className={`block text-[10px] mt-2 opacity-70 ${msg.sender === 'user' ? 'text-rose-200 text-right' : 'text-slate-400'}`}>
                {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Form */}
      <form onSubmit={handleSubmit} className="p-4 bg-white border-t border-rose-200/80 flex items-center gap-2 shrink-0">
        <input
          type="text"
          value={inputText}
          onChange={e => setInputText(e.target.value)}
          placeholder="Ask a question about your career plan..."
          className="flex-1 px-4 py-3 rounded-2xl border border-rose-200 bg-rose-50/40 text-xs text-slate-800 focus:ring-2 focus:ring-[#881337] outline-none"
        />
        <button
          type="submit"
          disabled={isLoading || !inputText.trim()}
          className="px-5 py-3 rounded-2xl bg-[#881337] hover:bg-[#9f1239] text-white font-bold text-xs shadow-md transition-all disabled:opacity-50 flex items-center gap-1.5 shrink-0"
        >
          <span>Send</span>
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
};
