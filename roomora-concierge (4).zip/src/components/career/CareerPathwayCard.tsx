import React, { useState } from 'react';
import { CareerPathway } from '../../types/career';
import { Compass, CheckCircle2, AlertTriangle, Lightbulb, ArrowUpRight, Layers } from 'lucide-react';

interface CareerPathwayCardProps {
  pathway: CareerPathway;
  badgeLabel: string;
  badgeColor?: string;
  onSelect?: () => void;
  isSelected?: boolean;
}

export const CareerPathwayCard: React.FC<CareerPathwayCardProps> = ({
  pathway,
  badgeLabel,
  badgeColor = 'bg-rose-100 text-[#881337]',
  onSelect,
  isSelected
}) => {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className={`bg-white border rounded-2xl p-6 transition-all shadow-sm flex flex-col justify-between ${
      isSelected ? 'ring-2 ring-[#be123c] border-[#be123c]' : 'border-rose-200/80 hover:border-rose-300'
    }`}>
      <div>
        {/* Header & Badge */}
        <div className="flex items-center justify-between mb-3">
          <span className={`text-[10px] uppercase font-extrabold tracking-widest px-2.5 py-1 rounded-lg ${badgeColor}`}>
            {badgeLabel}
          </span>
          <div className="w-8 h-8 rounded-xl bg-rose-50 text-[#881337] flex items-center justify-center font-bold">
            <Compass className="w-4 h-4" />
          </div>
        </div>

        <h3 className="text-base font-extrabold text-[#4c0519] font-heading mb-1.5">{pathway.title}</h3>
        <p className="text-xs text-slate-600 mb-4 leading-relaxed">{pathway.shortExplanation}</p>

        {/* Why it fits */}
        <div className="bg-rose-50/60 border border-rose-100 rounded-xl p-3 mb-4">
          <h4 className="text-[11px] font-bold text-[#881337] uppercase tracking-wider mb-1 flex items-center gap-1.5">
            <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
            Why it fits your profile
          </h4>
          <p className="text-xs text-slate-700">{pathway.whyItFits}</p>
        </div>

        {/* Entry Roles & Essential Skills */}
        <div className="space-y-3 mb-4 text-xs">
          <div>
            <span className="font-bold text-[#4c0519]">Entry-Level Roles: </span>
            <span className="text-slate-700">{pathway.entryRoles.join(', ')}</span>
          </div>
          <div>
            <span className="font-bold text-[#4c0519]">Essential Skills: </span>
            <div className="flex flex-wrap gap-1.5 mt-1">
              {pathway.essentialSkills.map((skill, idx) => (
                <span key={idx} className="px-2 py-0.5 bg-slate-100 text-slate-800 rounded-md text-[11px] font-semibold">
                  {skill}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Expandable Trade-offs & Try before commit */}
        {expanded && (
          <div className="space-y-3 pt-3 border-t border-rose-100 text-xs animate-in fade-in duration-150">
            <div>
              <h5 className="font-bold text-red-700 flex items-center gap-1 mb-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                Trade-offs & Considerations
              </h5>
              <ul className="list-disc pl-4 space-y-1 text-slate-600">
                {pathway.tradeOffs.map((t, i) => (
                  <li key={i}>{t}</li>
                ))}
              </ul>
            </div>
            <div>
              <h5 className="font-bold text-[#881337] flex items-center gap-1 mb-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                Try Before Committing
              </h5>
              <p className="text-slate-600">{pathway.tryBeforeCommit}</p>
            </div>
          </div>
        )}
      </div>

      <div className="flex items-center justify-between pt-4 border-t border-rose-100 mt-4">
        <button
          onClick={() => setExpanded(!expanded)}
          className="text-xs font-bold text-[#881337] hover:underline"
        >
          {expanded ? 'Show Less' : 'View Details & Trade-offs'}
        </button>

        {onSelect && (
          <button
            onClick={onSelect}
            className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all ${
              isSelected ? 'bg-emerald-600 text-white shadow-xs' : 'bg-[#881337] hover:bg-[#9f1239] text-white'
            }`}
          >
            {isSelected ? 'Selected Pathway' : 'Select Pathway'}
          </button>
        )}
      </div>
    </div>
  );
};
