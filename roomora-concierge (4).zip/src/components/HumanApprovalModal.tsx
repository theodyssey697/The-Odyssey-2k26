import React, { useState } from 'react';
import { 
  ShieldAlert, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Lock, 
  IndianRupee, 
  Building, 
  FileText 
} from 'lucide-react';
import { SubTask } from '../types';

interface HumanApprovalModalProps {
  task: SubTask;
  sessionId: string;
  onApprove: (taskId: string) => Promise<void>;
  onReject: (taskId: string, reason: string) => Promise<void>;
  onClose: () => void;
}

export const HumanApprovalModal: React.FC<HumanApprovalModalProps> = ({
  task,
  sessionId,
  onApprove,
  onReject,
  onClose
}) => {
  const [rejectReason, setRejectReason] = useState<string>('');
  const [isRejecting, setIsRejecting] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  const approvalData = task.approvalData || {
    actionType: 'Sensitive Operation',
    details: task.description,
    amount: undefined,
    recipient: 'Authorized Service Provider',
    terms: 'Escrow protected under Roomora Consumer Safety guidelines.',
    consequences: 'This action initiates a binding request and notifies the provider.'
  };

  const handleConfirm = async () => {
    setLoading(true);
    try {
      await onApprove(task.id);
    } finally {
      setLoading(false);
    }
  };

  const handleDecline = async () => {
    setLoading(true);
    try {
      await onReject(task.id, rejectReason || 'Declined by student');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="w-full max-w-lg rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden transition-all animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header: Human Approval Barrier */}
        <div className="px-6 py-4 bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border-b border-amber-200/50 dark:border-amber-900/30 flex items-start gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/30 shrink-0">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase font-extrabold tracking-wider text-amber-700 dark:text-amber-400">
                Security Barrier
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-800">
                Human Approval Gate
              </span>
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white font-heading mt-0.5">
              Explicit Authorization Required
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              The autonomous agent has paused execution. Irreversible financial or booking actions require your explicit sign-off.
            </p>
          </div>
        </div>

        {/* Action Details Body */}
        <div className="p-6 space-y-4 text-sm">
          
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-200 dark:border-slate-800">
              <span className="text-slate-500 dark:text-slate-400">Requested Action</span>
              <span className="font-mono font-bold text-slate-800 dark:text-slate-200 uppercase">
                {approvalData.actionType}
              </span>
            </div>

            <div>
              <span className="text-xs text-slate-500 dark:text-slate-400 block mb-0.5">Details</span>
              <p className="font-semibold text-slate-900 dark:text-white">
                {approvalData.details}
              </p>
            </div>

            {approvalData.amount !== undefined && (
              <div className="flex items-center justify-between py-2 px-3 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50">
                <span className="text-xs text-amber-800 dark:text-amber-300 font-medium">
                  Total Financial Obligation
                </span>
                <span className="text-lg font-extrabold text-amber-700 dark:text-amber-400 font-heading">
                  ₹{approvalData.amount.toLocaleString('en-IN')}
                </span>
              </div>
            )}

            {approvalData.recipient && (
              <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
                <Building className="w-3.5 h-3.5 text-slate-400" />
                <span>Recipient: <strong>{approvalData.recipient}</strong></span>
              </div>
            )}

            {approvalData.terms && (
              <div className="text-[11px] text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-900 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800">
                <strong>Safety Terms:</strong> {approvalData.terms}
              </div>
            )}
          </div>

          {/* Consequences warning banner */}
          <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900/40 flex items-start gap-2.5 text-xs text-red-800 dark:text-red-300">
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-red-600 dark:text-red-400" />
            <div>
              <p className="font-semibold">Irreversible Consequence Notice</p>
              <p className="text-[11px] text-red-700 dark:text-red-400 mt-0.5">
                {approvalData.consequences} The LLM agent cannot bypass this checkpoint.
              </p>
            </div>
          </div>

          {/* Rejection reason input if rejecting */}
          {isRejecting && (
            <div className="space-y-1.5 animate-in fade-in">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Reason for Rejection (Optional)
              </label>
              <textarea
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="e.g., Price too high, prefer visiting first, or changed preferences..."
                rows={2}
                className="w-full text-xs p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 outline-hidden"
              />
            </div>
          )}

        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
          {!isRejecting ? (
            <>
              <button
                type="button"
                onClick={() => setIsRejecting(true)}
                disabled={loading}
                className="px-4 py-2 text-xs font-bold rounded-xl border border-red-300 dark:border-red-800 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50 transition-colors"
              >
                Reject & Abort Action
              </button>
              
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  disabled={loading}
                  className="px-3 py-2 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirm}
                  disabled={loading}
                  className="px-5 py-2.5 text-xs font-bold rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white shadow-md shadow-emerald-700/20 flex items-center gap-1.5 transition-all"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{loading ? 'Authorizing...' : 'Explicitly Approve Action'}</span>
                </button>
              </div>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={() => setIsRejecting(false)}
                className="px-3 py-2 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900"
              >
                Back to Review
              </button>
              <button
                type="button"
                onClick={handleDecline}
                disabled={loading}
                className="px-5 py-2 text-xs font-bold rounded-xl bg-red-600 hover:bg-red-700 text-white shadow-md shadow-red-600/20 flex items-center gap-1.5 transition-all"
              >
                <XCircle className="w-4 h-4" />
                <span>{loading ? 'Aborting...' : 'Confirm Rejection'}</span>
              </button>
            </>
          )}
        </div>

      </div>
    </div>
  );
};
