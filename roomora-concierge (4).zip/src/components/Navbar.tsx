import React, { useState, useRef, useEffect } from 'react';
import { User, LogOut, ChevronDown } from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  userRole: 'student' | 'owner' | 'admin';
  userName: string;
  onLogout: () => void;
  onViewProfile: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  userRole,
  userName,
  onLogout,
  onViewProfile
}) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className={`sticky top-0 z-40 w-full golden-striped-bottom px-4 sm:px-6 py-3 flex items-center justify-between shadow-xs transition-colors ${
      userRole === 'admin'
        ? 'bg-[#1a040b] border-b border-rose-950/90 text-rose-100'
        : 'bg-[#fff5f6] border-b border-rose-200/90 text-[#4c0519]'
    }`}>
      <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => setCurrentTab('landing')}>
        <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#9f1239] to-[#e11d48] flex items-center justify-center font-bold text-white text-base font-heading shadow-xs">
          R
        </div>
        <span className={`font-extrabold text-sm font-heading ${
          userRole === 'admin' ? 'text-white' : 'text-[#4c0519]'
        }`}>
          Roomora <span className="text-[#be123c]">Concierge</span>
        </span>
      </div>

      {/* User Profile Open Button with Dropdown (View profile & Logout) */}
      <div className="relative" ref={dropdownRef}>
        <button
          onClick={() => setDropdownOpen(!dropdownOpen)}
          className={`flex items-center gap-2.5 px-3 py-1.5 rounded-xl border text-xs shadow-xs transition-all glass-click-anim ${
            userRole === 'admin'
              ? 'bg-[#280711] border-rose-900/80 hover:border-rose-700 text-rose-100'
              : 'bg-white border-rose-200 hover:border-rose-400 text-[#4c0519]'
          }`}
        >
          <div className="w-6 h-6 rounded-full bg-[#881337] text-white font-bold flex items-center justify-center text-[11px] shadow-xs">
            {userName.charAt(0)}
          </div>
          <div className="text-left hidden sm:block">
            <p className="font-bold leading-tight">{userName}</p>
            <p className="text-[10px] text-[#e11d48] capitalize font-semibold">{userRole}</p>
          </div>
          <ChevronDown className={`w-3.5 h-3.5 text-rose-400 transition-transform ${dropdownOpen ? 'rotate-180' : ''}`} />
        </button>

        {/* Dropdown Menu */}
        {dropdownOpen && (
          <div className={`absolute right-0 mt-2 w-48 rounded-2xl border shadow-xl py-1.5 text-xs z-50 animate-in fade-in slide-in-from-top-2 duration-150 ${
            userRole === 'admin'
              ? 'bg-[#20050d] border-rose-900/90 text-rose-100'
              : 'bg-white border-rose-200 text-slate-800'
          }`}>
            <div className={`px-4 py-2 border-b sm:hidden ${userRole === 'admin' ? 'border-rose-950' : 'border-rose-100'}`}>
              <p className="font-bold">{userName}</p>
              <p className="text-[10px] text-rose-500 capitalize">{userRole}</p>
            </div>
            
            <button
              onClick={() => {
                setDropdownOpen(false);
                onViewProfile();
              }}
              className={`w-full text-left px-4 py-2.5 flex items-center gap-2 font-medium transition-colors ${
                userRole === 'admin'
                  ? 'hover:bg-rose-950/80 text-rose-200 hover:text-white'
                  : 'hover:bg-rose-50 text-slate-800'
              }`}
            >
              <User className="w-3.5 h-3.5 text-[#be123c]" />
              <span>1. View profile</span>
            </button>

            <button
              onClick={() => {
                setDropdownOpen(false);
                onLogout();
              }}
              className={`w-full text-left px-4 py-2.5 flex items-center gap-2 font-semibold text-red-500 hover:text-red-400 transition-colors border-t ${
                userRole === 'admin'
                  ? 'border-rose-950 hover:bg-red-950/40'
                  : 'border-rose-100 hover:bg-red-50'
              }`}
            >
              <LogOut className="w-3.5 h-3.5 text-red-500" />
              <span>2. Logout</span>
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
