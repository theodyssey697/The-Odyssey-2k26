import React, { useState } from 'react';
import { X, Flag, AlertTriangle, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { Property } from '../types';

interface ReportModalProps {
  property: Property;
  onClose: () => void;
  onSuccess: (propertyId: string) => void;
}

export const ReportModal: React.FC<ReportModalProps> = ({ property, onClose, onSuccess }) => {
  const [category, setCategory] = useState<'fake_photos' | 'wrong_rent' | 'fake_verification' | 'harassment' | 'stale_availability' | 'other'>('wrong_rent');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch(`/api/properties/${property.id}/report`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ category, description })
      });
      const data = await res.json();
      if (data.success) {
        setSubmitted(true);
        setTimeout(() => {
          onSuccess(property.id);
          onClose();
        }, 1800);
      }
    } catch {
      // fallback
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 text-xs">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/80 dark:bg-slate-950/60">
          <div className="flex items-center gap-2 text-red-600 dark:text-red-400">
            <Flag className="w-5 h-5" />
            <h3 className="text-base font-bold text-slate-900 dark:text-white font-heading">
              Report Suspicious Listing
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="p-8 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 mx-auto flex items-center justify-center">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <h4 className="text-base font-bold text-slate-900 dark:text-white font-heading">
              Report Forwarded to Trust & Safety
            </h4>
            <p className="text-slate-500 dark:text-slate-400">
              Listing marked as “Under Review”. Our campus field agent will inspect this claim within 24 hours.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800">
              <p className="font-bold text-slate-900 dark:text-white">{property.title}</p>
              <p className="text-slate-500 dark:text-slate-400">{property.locality} • Rent ₹{property.monthlyRent}</p>
            </div>

            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Reason for Report
              </label>
              <select
                value={category}
                onChange={(e: any) => setCategory(e.target.value)}
                className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 outline-hidden"
              >
                <option value="wrong_rent">Discrepancy in Rent / Hidden Deposit Demand</option>
                <option value="fake_photos">Misleading or Fake Property Photos</option>
                <option value="stale_availability">No Vacancy Exists (Stale Availability)</option>
                <option value="fake_verification">Suspicious Host Identity / Impersonation</option>
                <option value="harassment">Unprofessional or Harassing Behavior</option>
                <option value="other">Other Violation</option>
              </select>
            </div>

            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Provide Evidence or Specific Details
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
                rows={3}
                placeholder="e.g., Host Biswajit requested an offline cash deposit before allowing viewing, contrary to Roomora escrow rules."
                className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 outline-hidden"
              />
            </div>

            <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/40 text-[11px] text-amber-800 dark:text-amber-300 leading-relaxed">
              <strong>Fair-Rent Ethics:</strong> Reports undergo verification by Roomora Admin before any listing is suspended.
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 font-bold rounded-xl bg-red-600 hover:bg-red-700 text-white transition-all shadow-md flex items-center justify-center gap-2"
              >
                <Flag className="w-4 h-4" />
                <span>{loading ? 'Submitting to Trust Team...' : 'Submit Incident Report'}</span>
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
