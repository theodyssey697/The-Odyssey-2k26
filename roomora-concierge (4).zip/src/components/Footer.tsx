import React from 'react';
import { ShieldCheck, PhoneCall, HeartHandshake, AlertCircle, Sparkles } from 'lucide-react';

export const Footer: React.FC<{ onNavigate: (tab: string) => void }> = ({ onNavigate }) => {
  return (
    <footer className="w-full bg-[#20040a] text-rose-200 border-t border-[#881337]/50 transition-colors">
      {/* Minimal clean footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">

        {/* Bottom Credits & Legal */}
        <div className="mt-8 pt-6 border-t border-[#881337]/30 text-xs text-rose-300/70 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© 2026 Roomora Concierge. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <span className="hover:text-rose-100 cursor-pointer">Privacy Policy</span>
            <span className="hover:text-rose-100 cursor-pointer">Terms of Service</span>
            <span className="hover:text-rose-100 cursor-pointer">Fair-Rent Charter</span>
            <span className="hover:text-rose-100 cursor-pointer">Emergency Protocol</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
