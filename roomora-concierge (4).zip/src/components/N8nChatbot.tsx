import React, { useState, useEffect, useRef } from 'react';
import { 
  Bot, 
  Send, 
  RotateCcw, 
  AlertCircle, 
  CheckCircle2, 
  ExternalLink, 
  Loader2, 
  RefreshCw, 
  Sparkles, 
  Copy, 
  Check, 
  Maximize2,
  Minimize2,
  Radio,
  SlidersHorizontal,
  Info
} from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  time: string;
  isError?: boolean;
}

export const N8N_CHAT_WEBHOOK_URL = 'https://punitbehera.app.n8n.cloud/webhook/13b3635b-45d2-4454-8d06-e6fabdf1184a/chat';

interface N8nChatbotProps {
  onSwitchToGemini?: () => void;
  className?: string;
}

export const N8nChatbot: React.FC<N8nChatbotProps> = ({ onSwitchToGemini, className = '' }) => {
  // Mode: 'interactive' (Custom React UI connected to n8n) | 'iframe' (Embedded n8n Webhook Iframe)
  const [viewMode, setViewMode] = useState<'interactive' | 'iframe'>('interactive');
  
  // Chat state
  const [sessionId, setSessionId] = useState<string>(() => {
    const saved = sessionStorage.getItem('roomora_n8n_session_id');
    if (saved) return saved;
    const newId = `roomora_sess_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    sessionStorage.setItem('roomora_n8n_session_id', newId);
    return newId;
  });

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-welcome-1',
      role: 'assistant',
      content: "Hi there! 👋 I'm **Roomora Concierge** powered by your **n8n Cloud AI workflow**.\n\nHow can I assist you today with student accommodations, mess dining, fooding, or campus living?",
      time: 'Just now'
    }
  ]);

  const [input, setInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [lastFailedMessage, setLastFailedMessage] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<'idle' | 'checking' | 'connected' | 'error'>('idle');

  // Iframe states
  const [iframeLoading, setIframeLoading] = useState<boolean>(true);
  const [iframeError, setIframeError] = useState<boolean>(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (viewMode === 'interactive') {
      scrollToBottom();
    }
  }, [messages, isLoading, errorMessage, viewMode]);

  // Check n8n health on initial mount
  useEffect(() => {
    const checkHealth = async () => {
      setConnectionStatus('checking');
      try {
        const res = await fetch('/api/n8n/health');
        const data = await res.json();
        if (data.online) {
          setConnectionStatus('connected');
        } else {
          setConnectionStatus('error');
        }
      } catch {
        setConnectionStatus('error');
      }
    };
    checkHealth();
  }, []);

  const handleCopyMessage = (text: string, id: string) => {
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || input).trim();
    if (!text || isLoading) return;

    const userMessage: ChatMessage = {
      id: `usr_${Date.now()}`,
      role: 'user',
      content: text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    setErrorMessage(null);
    setLastFailedMessage(null);

    try {
      // First try calling through the backend proxy /api/n8n/chat (robust, no CORS blockers, buffered 45s)
      let replyText = '';
      let isSuccess = false;

      try {
        const proxyRes = await fetch('/api/n8n/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chatInput: text,
            action: 'sendMessage',
            sessionId: sessionId
          })
        });

        const proxyData = await proxyRes.json();
        if (proxyRes.ok && proxyData.success) {
          replyText = proxyData.output;
          isSuccess = true;
        } else {
          throw new Error(proxyData.error || 'Proxy returned an error');
        }
      } catch (proxyErr: any) {
        // Fallback: try calling n8n Cloud directly if proxy experienced an issue
        console.warn('Backend proxy failed, attempting direct n8n webhook fetch:', proxyErr.message);
        
        const directRes = await fetch(N8N_CHAT_WEBHOOK_URL, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Instance-Id': 'd70f1f0ca3899125dc77338b7c4b9adea0e21ea8061c2071ef92425af384628e'
          },
          body: JSON.stringify({
            chatInput: text,
            action: 'sendMessage',
            sessionId: sessionId
          })
        });

        const rawDirectText = await directRes.text();
        let directData: any;
        try {
          directData = JSON.parse(rawDirectText);
        } catch {
          directData = { output: rawDirectText };
        }

        if (directData?.message === 'Error in workflow') {
          throw new Error('Your n8n workflow returned "Error in workflow". Please check node executions in n8n Cloud.');
        }

        const extracted = directData?.output || directData?.text || directData?.message || directData?.response || rawDirectText;
        replyText = String(extracted);
        isSuccess = true;
      }

      if (isSuccess && replyText) {
        setConnectionStatus('connected');
        setMessages((prev) => [
          ...prev,
          {
            id: `asst_${Date.now()}`,
            role: 'assistant',
            content: replyText,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
      } else {
        throw new Error('No valid response received from n8n workflow.');
      }
    } catch (err: any) {
      console.error('Error communicating with n8n:', err);
      const errMsg = err.message || 'Connection to n8n Cloud workflow failed.';
      setErrorMessage(errMsg);
      setLastFailedMessage(text);
      setConnectionStatus('error');
      
      setMessages((prev) => [
        ...prev,
        {
          id: `err_${Date.now()}`,
          role: 'assistant',
          content: `⚠️ **Connection Notice:** Could not get response from n8n Cloud workflow.\n\n*Error details:* ${errMsg}`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isError: true
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRetry = () => {
    if (lastFailedMessage) {
      handleSendMessage(lastFailedMessage);
    }
  };

  const handleResetSession = () => {
    const newId = `roomora_sess_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    setSessionId(newId);
    sessionStorage.setItem('roomora_n8n_session_id', newId);
    setMessages([
      {
        id: `msg-welcome-${Date.now()}`,
        role: 'assistant',
        content: "Session refreshed! 👋 I'm ready for new inquiries with clean context.",
        time: 'Just now'
      }
    ]);
    setErrorMessage(null);
    setLastFailedMessage(null);
  };

  const quickPrompts = [
    'Find me student stays near Balasore with mess included under ₹3,000.',
    'What verified messes and dining options are available?',
    'How do I schedule an in-person physical stay visit?',
    'Check 24x7 healthcare and student emergency services.'
  ];

  return (
    <div className={`bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/90 dark:border-slate-800 shadow-md flex flex-col overflow-hidden ${className}`}>
      
      {/* Top Header Bar */}
      <div className="px-5 py-3.5 bg-slate-50 dark:bg-slate-950/70 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#881337] to-[#be123c] text-white flex items-center justify-center shadow-xs">
            <Bot className="w-5 h-5 text-amber-300" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-white font-heading">
                Roomora n8n Concierge
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-100 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300 border border-rose-300 dark:border-rose-800">
                n8n Cloud
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
              <span className={`w-2 h-2 rounded-full ${
                connectionStatus === 'connected' 
                  ? 'bg-emerald-500 animate-pulse' 
                  : connectionStatus === 'checking'
                  ? 'bg-amber-400 animate-pulse'
                  : 'bg-rose-500'
              }`} />
              <span className="font-mono text-[10px]">
                {connectionStatus === 'connected' ? 'Webhook Live' : connectionStatus === 'checking' ? 'Checking Link...' : 'Connection Notice'}
              </span>
              <span>•</span>
              <span className="font-mono text-[10px] truncate max-w-[170px]" title={N8N_CHAT_WEBHOOK_URL}>
                ...webhook/13b3635b.../chat
              </span>
            </div>
          </div>
        </div>

        {/* View Switcher: Interactive Chat vs Iframe */}
        <div className="flex items-center gap-2">
          <div className="flex items-center p-1 rounded-xl bg-slate-200/70 dark:bg-slate-800 border border-slate-300/70 dark:border-slate-700 text-xs">
            <button
              type="button"
              onClick={() => setViewMode('interactive')}
              className={`px-3 py-1.5 rounded-lg font-bold text-xs transition-all ${
                viewMode === 'interactive'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Interactive Chat
            </button>
            <button
              type="button"
              onClick={() => setViewMode('iframe')}
              className={`px-3 py-1.5 rounded-lg font-bold text-xs transition-all ${
                viewMode === 'iframe'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Webhook Iframe
            </button>
          </div>

          <a
            href={N8N_CHAT_WEBHOOK_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Open n8n Webhook Chat in new window"
          >
            <ExternalLink className="w-4 h-4" />
          </a>

          <button
            type="button"
            onClick={handleResetSession}
            className="p-2 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Clear Chat & Refresh Session ID"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Body */}
      {viewMode === 'interactive' ? (
        <div className="flex-1 flex flex-col h-[600px] min-h-[500px]">
          
          {/* Messages Scroll Area */}
          <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 max-w-[88%] ${
                  msg.role === 'user' ? 'ml-auto flex-row-reverse' : 'mr-auto'
                }`}
              >
                {/* Avatar */}
                <div className={`w-8 h-8 rounded-full shrink-0 flex items-center justify-center text-xs font-bold shadow-xs ${
                  msg.role === 'user'
                    ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900'
                    : msg.isError
                    ? 'bg-rose-600 text-white'
                    : 'bg-gradient-to-tr from-[#881337] to-[#be123c] text-amber-300'
                }`}>
                  {msg.role === 'user' ? 'You' : <Bot className="w-4 h-4" />}
                </div>

                {/* Message Bubble */}
                <div className="space-y-1">
                  <div className={`p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-rose-900 text-white rounded-tr-xs shadow-xs'
                      : msg.isError
                      ? 'bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-900 dark:text-rose-200 rounded-tl-xs'
                      : 'bg-slate-100 dark:bg-slate-800/80 border border-slate-200/60 dark:border-slate-700/60 text-slate-900 dark:text-slate-100 rounded-tl-xs shadow-xs'
                  }`}>
                    <div className="whitespace-pre-wrap font-sans">
                      {msg.content}
                    </div>
                  </div>

                  <div className={`flex items-center gap-2 px-1 text-[10px] text-slate-400 ${
                    msg.role === 'user' ? 'justify-end' : 'justify-start'
                  }`}>
                    <span>{msg.time}</span>
                    <button
                      onClick={() => handleCopyMessage(msg.content, msg.id)}
                      className="hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
                      title="Copy response"
                    >
                      {copiedId === msg.id ? (
                        <Check className="w-3 h-3 text-emerald-500" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                    </button>
                  </div>
                </div>
              </div>
            ))}

            {/* Loading Indicator */}
            {isLoading && (
              <div className="flex gap-3 max-w-[88%] mr-auto items-center animate-in fade-in duration-150">
                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#881337] to-[#be123c] text-amber-300 flex items-center justify-center shrink-0 shadow-xs">
                  <Bot className="w-4 h-4" />
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-tl-xs flex items-center gap-2.5 text-xs text-slate-600 dark:text-slate-300">
                  <Loader2 className="w-4 h-4 text-rose-600 animate-spin" />
                  <span>Connecting to n8n Cloud AI workflow...</span>
                </div>
              </div>
            )}

            {/* Error & Retry Banner */}
            {errorMessage && (
              <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800/60 text-xs text-amber-900 dark:text-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">Workflow Notice:</span>
                    <p className="text-[11px] text-amber-800 dark:text-amber-300 mt-0.5">
                      {errorMessage}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {lastFailedMessage && (
                    <button
                      type="button"
                      onClick={handleRetry}
                      disabled={isLoading}
                      className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-xs transition-colors disabled:opacity-50"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Retry Message</span>
                    </button>
                  )}
                  {onSwitchToGemini && (
                    <button
                      type="button"
                      onClick={onSwitchToGemini}
                      className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors"
                    >
                      Use Gemini AI
                    </button>
                  )}
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Prompt Suggestions */}
          <div className="px-4 py-2 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/30 overflow-x-auto">
            <div className="flex items-center gap-2 min-w-max">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-500" />
                <span>Suggestions:</span>
              </span>
              {quickPrompts.map((q, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleSendMessage(q)}
                  disabled={isLoading}
                  className="px-2.5 py-1 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-rose-400 hover:text-rose-700 dark:hover:text-rose-300 text-xs transition-all shadow-2xs truncate max-w-xs disabled:opacity-50"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          {/* Chat Input Bar */}
          <div className="p-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center gap-2"
            >
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask n8n Concierge about student stays, mess dining, or booking..."
                disabled={isLoading}
                className="flex-1 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder-slate-400 text-xs sm:text-sm outline-hidden focus:ring-2 focus:ring-rose-500/40"
              />

              <button
                type="submit"
                disabled={isLoading || !input.trim()}
                className="px-5 py-3 rounded-xl bg-gradient-to-r from-[#881337] to-[#be123c] hover:from-[#700f2b] hover:to-[#9f1239] text-white font-bold text-xs sm:text-sm shadow-md transition-all flex items-center justify-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed shrink-0"
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin text-amber-300" />
                ) : (
                  <Send className="w-4 h-4 text-amber-300" />
                )}
                <span>Send</span>
              </button>
            </form>
          </div>

        </div>
      ) : (
        /* Iframe Mode with Loading State and Security Fallback */
        <div className="relative flex-1 h-[600px] min-h-[500px] bg-slate-900">
          
          {iframeLoading && (
            <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-slate-950/80 backdrop-blur-xs text-white space-y-3">
              <Loader2 className="w-8 h-8 text-rose-500 animate-spin" />
              <p className="text-xs font-semibold">Connecting to n8n Cloud Chatbot...</p>
              <p className="text-[11px] text-slate-400 font-mono">
                {N8N_CHAT_WEBHOOK_URL}
              </p>
            </div>
          )}

          <iframe
            src={N8N_CHAT_WEBHOOK_URL}
            className="w-full h-full border-0"
            title="n8n Webhook Chatbot"
            onLoad={() => setIframeLoading(false)}
            onError={() => {
              setIframeLoading(false);
              setIframeError(true);
            }}
          />

          {/* Iframe Notice Overlay */}
          <div className="absolute bottom-3 left-4 right-4 z-20 pointer-events-none flex justify-center">
            <div className="pointer-events-auto p-2.5 rounded-xl bg-slate-950/80 backdrop-blur-sm border border-slate-700/80 text-[11px] text-slate-300 flex items-center gap-3 shadow-lg">
              <Info className="w-4 h-4 text-amber-400 shrink-0" />
              <span>If your browser prevents embedding via X-Frame-Options, use the Interactive Chat tab or open directly:</span>
              <a
                href={N8N_CHAT_WEBHOOK_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="font-bold text-amber-300 hover:underline flex items-center gap-1 shrink-0"
              >
                <span>Direct Window</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
