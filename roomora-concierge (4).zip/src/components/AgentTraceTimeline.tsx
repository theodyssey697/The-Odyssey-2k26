import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  ChevronDown, 
  ChevronUp, 
  Cpu, 
  ShieldAlert, 
  ArrowRight,
  Terminal,
  Activity,
  Layers
} from 'lucide-react';
import { AgentEvent } from '../types';

interface AgentTraceTimelineProps {
  events: AgentEvent[];
  isStreaming?: boolean;
}

export const AgentTraceTimeline: React.FC<AgentTraceTimelineProps> = ({ events, isStreaming }) => {
  const [expanded, setExpanded] = useState<boolean>(true);
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);

  if (!events || events.length === 0) {
    return (
      <div className="p-4 rounded-xl border border-dashed border-slate-300 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/30 text-center text-xs text-slate-500">
        No active execution trace yet. Submit a goal to watch the autonomous agent loop in real-time.
      </div>
    );
  }

  const getStatusBadge = (status: AgentEvent['status']) => {
    switch (status) {
      case 'running':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 border border-amber-300 dark:border-amber-800">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping"></span>
            Executing
          </span>
        );
      case 'success':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-800">
            <CheckCircle2 className="w-2.5 h-2.5" />
            Success
          </span>
        );
      case 'warning':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 border border-amber-300 dark:border-amber-800">
            <ShieldAlert className="w-2.5 h-2.5" />
            Approval Required
          </span>
        );
      case 'error':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-100 dark:bg-red-950/60 text-red-700 dark:text-red-400 border border-red-300 dark:border-red-800">
            <AlertCircle className="w-2.5 h-2.5" />
            Failure / Fallback
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
            <Activity className="w-2.5 h-2.5 text-slate-400" />
            Logged
          </span>
        );
    }
  };

  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm overflow-hidden transition-all">
      {/* Header bar */}
      <div 
        onClick={() => setExpanded(!expanded)} 
        className="px-4 py-3 bg-slate-50 dark:bg-slate-950/60 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between cursor-pointer hover:bg-slate-100/70 dark:hover:bg-slate-900/80 transition-colors"
      >
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
            <Terminal className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider font-heading">
                Live Agent Trace
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                {events.length} Backend Events
              </span>
              {isStreaming && (
                <span className="flex items-center gap-1 text-[10px] text-amber-600 dark:text-amber-400 font-semibold animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                  Active Loop
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Deterministic tool execution, parameter extraction, and human approval checkpoints
            </p>
          </div>
        </div>
        <button 
          className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
          aria-label="Toggle agent trace"
        >
          {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
      </div>

      {/* Events timeline body */}
      {expanded && (
        <div className="p-4 max-h-[380px] overflow-y-auto space-y-3 font-sans">
          {events.map((evt, idx) => {
            const isSelected = selectedEventId === evt.id;
            const timeFormatted = new Date(evt.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

            return (
              <div 
                key={evt.id || idx}
                onClick={() => setSelectedEventId(isSelected ? null : evt.id)}
                className={`relative pl-6 pb-2 border-l-2 transition-all cursor-pointer ${
                  evt.status === 'success' 
                    ? 'border-emerald-500/50' 
                    : evt.status === 'running' 
                    ? 'border-amber-500' 
                    : evt.status === 'warning'
                    ? 'border-amber-400'
                    : evt.status === 'error'
                    ? 'border-red-500'
                    : 'border-slate-200 dark:border-slate-800'
                }`}
              >
                {/* Node dot on line */}
                <div 
                  className={`absolute -left-[7px] top-1 w-3 h-3 rounded-full border-2 bg-white dark:bg-slate-900 ${
                    evt.status === 'success' 
                      ? 'border-emerald-500 bg-emerald-500' 
                      : evt.status === 'running' 
                      ? 'border-amber-500 bg-amber-400 animate-ping' 
                      : evt.status === 'warning'
                      ? 'border-amber-500 bg-amber-400'
                      : evt.status === 'error'
                      ? 'border-red-500 bg-red-500'
                      : 'border-slate-400 bg-slate-300 dark:bg-slate-700'
                  }`}
                />

                <div className={`p-2.5 rounded-lg border text-xs transition-colors ${
                  isSelected 
                    ? 'bg-slate-100/90 dark:bg-slate-800/90 border-slate-300 dark:border-slate-700 shadow-xs' 
                    : 'bg-slate-50/60 dark:bg-slate-950/40 border-slate-200/70 dark:border-slate-800/70 hover:bg-slate-100/60 dark:hover:bg-slate-800/40'
                }`}>
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 dark:text-white font-heading">
                        {evt.actionName}
                      </span>
                      {evt.toolName && (
                        <span className="px-1.5 py-0.2 rounded font-mono text-[10px] bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                          tool: {evt.toolName}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusBadge(evt.status)}
                      <span className="text-[10px] text-slate-400 font-mono">
                        {timeFormatted}
                      </span>
                    </div>
                  </div>

                  <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-[11px]">
                    {evt.explanation}
                  </p>

                  {/* Outcome if available */}
                  {evt.outcome && (
                    <div className="mt-1.5 pt-1.5 border-t border-slate-200/60 dark:border-slate-800/60 text-[11px] text-emerald-700 dark:text-emerald-400 flex items-start gap-1.5">
                      <ArrowRight className="w-3 h-3 mt-0.5 shrink-0 text-emerald-600 dark:text-emerald-400" />
                      <span>{evt.outcome}</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
