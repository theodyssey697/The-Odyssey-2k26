import React, { useState, useEffect } from 'react';
import { 
  Lock, 
  Mail, 
  ShieldCheck, 
  AlertCircle, 
  X, 
  ArrowRight, 
  CookingPot, 
  Key, 
  Info,
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import { auth } from '../firebaseConfig';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';

interface MessAdminAuthModalProps {
  messId: string;
  messName: string;
  isOpen: boolean;
  onClose: () => void;
  onSuccessLogin: (authorizedMess: any, adminEmail: string) => void;
}

export const MessAdminAuthModal: React.FC<MessAdminAuthModalProps> = ({
  messId,
  messName,
  isOpen,
  onClose,
  onSuccessLogin
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [assignedAdminEmail, setAssignedAdminEmail] = useState<string>('');
  const [loadingInfo, setLoadingInfo] = useState(true);

  // Fetch mess details and current assigned administrator email
  useEffect(() => {
    if (!isOpen || !messId) return;
    setErrorMsg(null);
    setLoadingInfo(true);

    fetch(`/api/mess-admin/${messId}`)
      .then(res => res.json())
      .then(data => {
        if (data.ownership?.assignedAdminEmail) {
          setAssignedAdminEmail(data.ownership.assignedAdminEmail);
          setEmail(data.ownership.assignedAdminEmail);
          setPassword('RoomoraMess@2026');
        }
      })
      .catch(err => {
        console.error('Error fetching mess admin info:', err);
      })
      .finally(() => {
        setLoadingInfo(false);
      });
  }, [isOpen, messId]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setLoading(true);

    try {
      // 1. Firebase Authentication
      let userCredential;
      try {
        if (isRegistering) {
          userCredential = await createUserWithEmailAndPassword(auth, email.trim(), password);
        } else {
          userCredential = await signInWithEmailAndPassword(auth, email.trim(), password);
        }
      } catch (authErr: any) {
        // If login failed because user doesn't exist yet, auto-attempt registration if it's the assigned admin
        if (authErr.code === 'auth/user-not-found' || authErr.code === 'auth/invalid-credential') {
          try {
            // Attempt auto-provisioning for demo / default assigned admin
            userCredential = await createUserWithEmailAndPassword(auth, email.trim(), password);
          } catch (createErr: any) {
            if (createErr.code === 'auth/email-already-in-use') {
              setErrorMsg('Email or password is incorrect. Please check your credentials.');
            } else if (createErr.code === 'auth/weak-password') {
              setErrorMsg('Password should be at least 6 characters.');
            } else {
              setErrorMsg('Authentication failed: Email or password is incorrect');
            }
            setLoading(false);
            return;
          }
        } else if (authErr.code === 'auth/email-already-in-use') {
          setErrorMsg('User already exists with this email. Please sign in instead.');
          setLoading(false);
          return;
        } else {
          setErrorMsg('Authentication failed: Email or password is incorrect');
          setLoading(false);
          return;
        }
      }

      // 2. Authorization Verification for this specific mess
      const userEmail = userCredential.user.email || email.trim();
      const verifyRes = await fetch('/api/mess-admin/verify-access', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messId,
          email: userEmail
        })
      });

      const verifyData = await verifyRes.json();

      if (!verifyRes.ok || !verifyData.authorized) {
        setErrorMsg(
          verifyData.error || 
          `Access Denied: Your account (${userEmail}) is not authorized to manage "${messName}". Only the assigned administrator (${verifyData.assignedEmail || assignedAdminEmail}) can access this mess dashboard.`
        );
        setLoading(false);
        return;
      }

      // 3. Success - Open the dedicated Mess Admin Dashboard
      onSuccessLogin(verifyData.mess, userEmail);
      onClose();
    } catch (err: any) {
      console.error('Mess admin login error:', err);
      setErrorMsg(err.message || 'An error occurred during authentication. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleUseAssignedEmail = () => {
    if (assignedAdminEmail) {
      setEmail(assignedAdminEmail);
      setPassword('RoomoraMess@2026');
      setErrorMsg(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-lg rounded-3xl bg-[#20050d] border border-rose-800/60 p-6 sm:p-8 shadow-2xl relative text-rose-100 overflow-hidden">
        
        {/* Glow ambient background */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-rose-950/80 border border-rose-900/60 text-rose-300 hover:text-white hover:bg-rose-900 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="text-center space-y-2 relative z-10 pb-2">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500/20 to-rose-600/20 text-amber-300 border border-amber-500/40 flex items-center justify-center mx-auto shadow-inner">
            <CookingPot className="w-7 h-7 text-amber-400" />
          </div>
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
            <Key className="w-3 h-3" />
            <span>MESS ADMINISTRATOR PORTAL</span>
          </div>
          <h2 className="text-2xl font-black text-white font-heading tracking-tight">
            {messName}
          </h2>
          <p className="text-xs text-rose-200/80 max-w-sm mx-auto">
            Authorized management for menus, daily meal plans, prices, and student food reservations.
          </p>
        </div>

        {/* Error message */}
        {errorMsg && (
          <div className="p-3.5 rounded-xl bg-red-950/80 border border-red-800 text-xs text-red-200 flex items-start gap-2.5 relative z-10 animate-in fade-in">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <div className="leading-relaxed">{errorMsg}</div>
          </div>
        )}

        {/* Assigned Admin Authorization Banner */}
        <div className="p-3 rounded-2xl bg-[#2c0813] border border-rose-900/70 text-xs space-y-1.5 relative z-10">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-rose-300 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>Assigned Administrator Account:</span>
            </span>
            <button
              type="button"
              onClick={handleUseAssignedEmail}
              className="text-[11px] font-bold text-amber-400 hover:text-amber-300 hover:underline flex items-center gap-0.5"
            >
              <Sparkles className="w-3 h-3" />
              <span>Fill Credentials</span>
            </button>
          </div>
          <div className="font-mono text-amber-200 bg-black/40 px-2.5 py-1.5 rounded-lg border border-rose-950 truncate text-[11px]">
            {loadingInfo ? 'Verifying registry...' : (assignedAdminEmail || 'Loading assigned admin...')}
          </div>
          <p className="text-[10px] text-rose-300/70">
            Note: Administrators are securely restricted to their assigned mess only. Cross-mess access is blocked.
          </p>
        </div>

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs relative z-10 pt-1">
          <div>
            <label className="font-semibold text-rose-200 block mb-1">Administrator Email</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-rose-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="administrator@roomora.in"
                required
                className="w-full p-3 pl-9 rounded-xl border border-rose-800/80 bg-[#160309] text-white focus:ring-2 focus:ring-amber-500 outline-hidden font-mono"
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="font-semibold text-rose-200">Security Password</label>
              <span className="text-[10px] text-rose-400">Firebase Auth Encrypted</span>
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-rose-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full p-3 pl-9 rounded-xl border border-rose-800/80 bg-[#160309] text-white focus:ring-2 focus:ring-amber-500 outline-hidden font-mono"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 via-rose-600 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold text-xs sm:text-sm shadow-lg shadow-amber-950/40 flex items-center justify-center gap-2 transition-all disabled:opacity-50"
          >
            {loading ? (
              <span className="flex items-center gap-2 text-white">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Verifying Authorization...</span>
              </span>
            ) : (
              <>
                <span>{isRegistering ? 'Register & Verify Mess Admin' : 'Sign In as Mess Administrator'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Toggle Register vs Login */}
        <div className="text-center pt-2 text-xs text-rose-300/80 relative z-10 flex items-center justify-center gap-2">
          <span>{isRegistering ? 'Already have this administrator account?' : 'Need to initialize credentials?'}</span>
          <button
            type="button"
            onClick={() => {
              setIsRegistering(!isRegistering);
              setErrorMsg(null);
            }}
            className="text-amber-400 hover:text-amber-300 font-bold hover:underline"
          >
            {isRegistering ? 'Sign In' : 'Register Account'}
          </button>
        </div>

      </div>
    </div>
  );
};
