import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  Lock, 
  CreditCard, 
  Calendar, 
  IndianRupee, 
  Receipt, 
  Download,
  ArrowRight
} from 'lucide-react';
import { Property, Booking } from '../types';

interface BookingModalProps {
  property: Property;
  onClose: () => void;
  onBookingSuccess: (booking: Booking) => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({ property, onClose, onBookingSuccess }) => {
  // Booking lifecycle steps:
  // 1: Availability & Terms Review
  // 2: Student Explicit Approval Gate
  // 3: Payment Checkout (Simulated Razorpay / UPI Escrow)
  // 4: Confirmation Receipt & Stay Pass
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [moveInDate, setMoveInDate] = useState('2026-11-01');
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'netbanking'>('upi');
  const [upiId, setUpiId] = useState('student@oksbi');
  const [createdBooking, setCreatedBooking] = useState<Booking | null>(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const rent = property.monthlyRent;
  const deposit = property.deposit;
  const maintenance = property.maintenanceCharges;
  const totalPayable = rent + deposit;

  // Step 1 -> 2: Draft booking on backend
  const handleProceedToApproval = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          propertyId: property.id,
          moveInDate
        })
      });
      const data = await res.json();
      if (data.error) {
        setErrorMsg(data.error);
        return;
      }
      setCreatedBooking(data.booking);
      setStep(2);
    } catch (err: any) {
      setErrorMsg('Failed to create booking draft.');
    } finally {
      setLoading(false);
    }
  };

  // Step 2 -> 3: Student explicitly approves
  const handleApproveCommitment = () => {
    setStep(3);
  };

  // Step 3 -> 4: Complete simulated payment
  const handleExecutePayment = async () => {
    if (!createdBooking) return;
    setLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetch(`/api/bookings/${createdBooking.id}/pay`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await res.json();
      if (data.success && data.booking) {
        setCreatedBooking(data.booking);
        setStep(4);
        onBookingSuccess(data.booking);
      }
    } catch {
      setErrorMsg('Payment verification failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
      <div className="w-full max-w-lg rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150 text-xs">
        
        {/* Step Indicator Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-950/60 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 font-heading">
              Secure Accommodation Escrow
            </span>
            <h3 className="text-base font-bold text-slate-900 dark:text-white font-heading mt-0.5">
              {step === 1 && 'Step 1 of 4: Availability & Financial Audit'}
              {step === 2 && 'Step 2 of 4: Human Approval Checkpoint'}
              {step === 3 && 'Step 3 of 4: Simulated Escrow Checkout'}
              {step === 4 && 'Step 4 of 4: Stay Pass & Receipt'}
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress bar */}
        <div className="w-full bg-slate-100 dark:bg-slate-800 h-1">
          <div 
            className="bg-amber-500 h-1 transition-all duration-300"
            style={{ width: `${(step / 4) * 100}%` }}
          />
        </div>

        {errorMsg && (
          <div className="mx-6 mt-4 p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300">
            {errorMsg}
          </div>
        )}

        {/* Step 1: Availability & Terms Review */}
        {step === 1 && (
          <div className="p-6 space-y-4">
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800">
              <p className="font-bold text-slate-900 dark:text-white text-sm">{property.title}</p>
              <p className="text-slate-500 dark:text-slate-400">{property.locality} • {property.roomType.replace(/_/g, ' ')}</p>
              <div className="mt-2 flex items-center gap-2">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400">
                  {property.availableBeds} beds available
                </span>
                <span className="text-slate-400">Host: {property.hostName}</span>
              </div>
            </div>

            {/* Financial table */}
            <div className="space-y-2 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5">
              <span className="font-bold text-slate-900 dark:text-white block font-heading">
                Transparent Cost Breakdown
              </span>
              <div className="flex justify-between text-slate-600 dark:text-slate-300 py-1 border-b border-slate-100 dark:border-slate-800">
                <span>1st Month Advance Rent</span>
                <span className="font-mono">₹{rent.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between text-slate-600 dark:text-slate-300 py-1 border-b border-slate-100 dark:border-slate-800">
                <span>Refundable Security Deposit</span>
                <span className="font-mono">₹{deposit.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between text-slate-600 dark:text-slate-300 py-1 border-b border-slate-100 dark:border-slate-800">
                <span>Roomora Platform Guarantee Fee</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-bold">₹0 (Free for Odyssey 2K26)</span>
              </div>
              <div className="flex justify-between text-slate-900 dark:text-white pt-2 font-bold text-sm">
                <span>Total Escrow Deposit</span>
                <span className="text-amber-600 dark:text-amber-400 font-heading">
                  ₹{totalPayable.toLocaleString('en-IN')}
                </span>
              </div>
            </div>

            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Target Move-In Date
              </label>
              <input
                type="date"
                value={moveInDate}
                onChange={(e) => setMoveInDate(e.target.value)}
                className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
              />
            </div>

            <div className="pt-2">
              <button
                onClick={handleProceedToApproval}
                disabled={loading}
                className="w-full py-2.5 text-xs font-bold rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-950 transition-all shadow-md flex items-center justify-center gap-2"
              >
                <span>{loading ? 'Validating Availability...' : 'Proceed to Security Approval'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Human Approval Gate */}
        {step === 2 && (
          <div className="p-6 space-y-4">
            <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-300 dark:border-amber-900/60 flex items-start gap-3">
              <ShieldCheck className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-amber-900 dark:text-amber-300">
                  Explicit Student Authorization Barrier
                </p>
                <p className="text-amber-800 dark:text-amber-400 text-[11px] mt-0.5 leading-relaxed">
                  Roomora requires explicit consent before any funds are moved. The autonomous agent cannot authorize bookings on your behalf.
                </p>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-500">Booking Target:</span>
                <span className="font-bold text-slate-900 dark:text-white">{property.title}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Payable Amount:</span>
                <span className="font-extrabold text-slate-900 dark:text-white text-sm font-heading">
                  ₹{totalPayable.toLocaleString('en-IN')}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Planned Move-In:</span>
                <span className="font-mono text-slate-800 dark:text-slate-200">{moveInDate}</span>
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-200 dark:border-slate-800">
                <strong>Refund Policy:</strong> 100% refundable if cancelled at least 48 hours before {moveInDate}.
              </div>
            </div>

            <div className="pt-2 flex items-center gap-3">
              <button
                onClick={() => setStep(1)}
                className="flex-1 py-2.5 font-bold rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300"
              >
                Back / Edit
              </button>
              <button
                onClick={handleApproveCommitment}
                className="flex-2 py-2.5 font-bold rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white shadow-md flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>I Approve & Authorize</span>
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Payment Checkout (Simulated Razorpay / UPI) */}
        {step === 3 && (
          <div className="p-6 space-y-4">
            <div className="p-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900/50 flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold text-indigo-700 dark:text-indigo-400">Demo Escrow Sandbox</span>
                <p className="font-bold text-slate-900 dark:text-white">Amount Due: ₹{totalPayable.toLocaleString('en-IN')}</p>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-indigo-200 dark:bg-indigo-900 text-indigo-800 dark:text-indigo-200">
                ODYSSEY TESTNET
              </span>
            </div>

            {/* Payment options */}
            <div className="space-y-2">
              <label className="font-semibold text-slate-700 dark:text-slate-300 block">
                Select Test Payment Gateway
              </label>
              
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('upi')}
                  className={`p-2.5 rounded-xl border font-bold text-center transition-all ${
                    paymentMethod === 'upi'
                      ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  UPI (GPay / PhonePe)
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`p-2.5 rounded-xl border font-bold text-center transition-all ${
                    paymentMethod === 'card'
                      ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  Debit / Credit Card
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('netbanking')}
                  className={`p-2.5 rounded-xl border font-bold text-center transition-all ${
                    paymentMethod === 'netbanking'
                      ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  NetBanking
                </button>
              </div>
            </div>

            {paymentMethod === 'upi' && (
              <div>
                <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Virtual Payment Address (VPA)
                </label>
                <input
                  type="text"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                />
              </div>
            )}

            <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 leading-relaxed">
              <strong>Honest Demo Notice:</strong> No actual money is deducted. This simulates Razorpay webhook verification and locks the host calendar.
            </div>

            <div className="pt-2">
              <button
                onClick={handleExecutePayment}
                disabled={loading}
                className="w-full py-2.5 font-bold rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-950 shadow-md flex items-center justify-center gap-2"
              >
                <Lock className="w-4 h-4" />
                <span>{loading ? 'Processing Escrow Verification...' : `Complete Test Payment (₹${totalPayable})`}</span>
              </button>
            </div>
          </div>
        )}

        {/* Step 4: Confirmation Receipt & Stay Pass */}
        {step === 4 && createdBooking && (
          <div className="p-6 space-y-4 text-center">
            <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 mx-auto flex items-center justify-center">
              <CheckCircle2 className="w-7 h-7" />
            </div>

            <div>
              <h4 className="text-lg font-bold text-slate-900 dark:text-white font-heading">
                Booking Confirmed & Bed Reserved!
              </h4>
              <p className="text-slate-500 dark:text-slate-400 text-xs mt-0.5">
                Roomora Stay Pass generated for {property.title}
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 text-left space-y-2 font-mono text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-500">Pass / Booking ID:</span>
                <span className="font-bold text-slate-900 dark:text-white">{createdBooking.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Transaction ID:</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-bold">{createdBooking.paymentTransactionId || 'TXN_ESCROW_OK'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Payment Status:</span>
                <span className="text-emerald-600 dark:text-emerald-400 uppercase font-bold">Successful</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Move-In Date:</span>
                <span className="text-slate-900 dark:text-white">{createdBooking.moveInDate}</span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-full py-2.5 font-bold rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-950 transition-all shadow-md"
            >
              Done / Return to Dashboard
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
