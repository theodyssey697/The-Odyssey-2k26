import React, { useState } from 'react';
import { X, Calendar, Clock, User, Phone, CheckCircle2, Building, MessageSquare } from 'lucide-react';
import { Property, VisitRequest } from '../types';

interface VisitModalProps {
  property: Property;
  onClose: () => void;
  onSuccess: (visit: VisitRequest) => void;
}

export const VisitModal: React.FC<VisitModalProps> = ({ property, onClose, onSuccess }) => {
  const [date, setDate] = useState('2026-10-17');
  const [timeSlot, setTimeSlot] = useState('Saturday, 4:00 PM - 5:00 PM');
  const [studentName, setStudentName] = useState('Aryan Sharma');
  const [studentPhone, setStudentPhone] = useState('+91 98765 43210');
  const [notes, setNotes] = useState('Would like to inspect attached washroom, study table, and Wi-Fi speed.');
  const [loading, setLoading] = useState(false);
  const [confirmed, setConfirmed] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch('/api/visits', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          propertyId: property.id,
          requestedDate: date,
          requestedTimeSlot: timeSlot,
          studentName,
          studentPhone,
          notes
        })
      });
      const data = await res.json();
      if (data.visit) {
        setConfirmed(true);
        setTimeout(() => {
          onSuccess(data.visit);
          onClose();
        }, 1800);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/80 dark:bg-slate-950/60">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-amber-500" />
            <h3 className="text-base font-bold text-slate-900 dark:text-white font-heading">
              Schedule Property Visit
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        {confirmed ? (
          <div className="p-8 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 mx-auto flex items-center justify-center">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <h4 className="text-lg font-bold text-slate-900 dark:text-white font-heading">
              Visit Request Confirmed!
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Host {property.hostName} alerted on WhatsApp. Visit pass saved in your Student Hub.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
            
            {/* Property summary */}
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <p className="font-bold text-slate-900 dark:text-white">{property.title}</p>
                <p className="text-slate-500 dark:text-slate-400">{property.locality} • Rent ₹{property.monthlyRent}/mo</p>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400">
                Verified Host
              </span>
            </div>

            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Preferred Visit Date
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
                className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500 outline-hidden font-mono"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Time Slot
              </label>
              <select
                value={timeSlot}
                onChange={(e) => setTimeSlot(e.target.value)}
                className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500 outline-hidden"
              >
                <option value="Saturday, 3:00 PM - 4:00 PM">Saturday, 3:00 PM - 4:00 PM (After classes)</option>
                <option value="Saturday, 4:00 PM - 5:00 PM">Saturday, 4:00 PM - 5:00 PM (Recommended)</option>
                <option value="Saturday, 5:00 PM - 6:00 PM">Saturday, 5:00 PM - 6:00 PM</option>
                <option value="Sunday, 11:00 AM - 12:00 PM">Sunday, 11:00 AM - 12:00 PM (Morning)</option>
                <option value="Sunday, 4:00 PM - 5:00 PM">Sunday, 4:00 PM - 5:00 PM</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Student Name
                </label>
                <input
                  type="text"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  required
                  className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500 outline-hidden"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Phone / WhatsApp
                </label>
                <input
                  type="text"
                  value={studentPhone}
                  onChange={(e) => setStudentPhone(e.target.value)}
                  required
                  className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500 outline-hidden font-mono"
                />
              </div>
            </div>

            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Special Inspection Notes (Optional)
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={2}
                className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500 outline-hidden"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 text-xs font-bold rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-950 transition-all shadow-md flex items-center justify-center gap-2"
              >
                <Calendar className="w-4 h-4" />
                <span>{loading ? 'Confirming with Host...' : 'Confirm Visit Appointment'}</span>
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
