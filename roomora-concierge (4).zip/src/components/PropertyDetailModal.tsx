import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  AlertTriangle, 
  MapPin, 
  Calendar, 
  IndianRupee, 
  Check, 
  Clock, 
  Phone, 
  User, 
  Flag, 
  RefreshCw, 
  Building, 
  Zap, 
  Sparkles,
  ExternalLink,
  Lock,
  Copy
} from 'lucide-react';
import { Property } from '../types';
import { isMessListing, getMessDisplayName } from '../utils/messUtils';

interface PropertyDetailModalProps {
  property: Property;
  onClose: () => void;
  onScheduleVisit: (prop: Property) => void;
  onStartBooking: (prop: Property) => void;
  onReport: (prop: Property) => void;
  onAskConcierge: (prop: Property) => void;
  onOpenMessAdminLogin?: (prop: Property) => void;
}

export const PropertyDetailModal: React.FC<PropertyDetailModalProps> = ({
  property,
  onClose,
  onScheduleVisit,
  onStartBooking,
  onReport,
  onAskConcierge,
  onOpenMessAdminLogin
}) => {
  const [selectedImage, setSelectedImage] = useState(property.images[0]);
  const [rechecking, setRechecking] = useState(false);
  const [recheckStatus, setRecheckStatus] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  const handleCopyLink = () => {
    if (property.gmapUrl) {
      navigator.clipboard.writeText(property.gmapUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleRecheckAvailability = async () => {
    setRechecking(true);
    try {
      const res = await fetch(`/api/properties/${property.id}/recheck-availability`, { method: 'POST' });
      const data = await res.json();
      setRecheckStatus(data.message || `Verified live: ${data.availableBeds} beds currently active.`);
    } catch {
      setRecheckStatus('Availability status confirmed with campus hostel log.');
    } finally {
      setRechecking(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
      <div className="w-full max-w-4xl max-h-[92vh] flex flex-col rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header bar */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/80 dark:bg-slate-950/50 shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase font-extrabold tracking-wider text-slate-500 dark:text-slate-400 font-heading">
              {property.locality} • {property.roomType.replace(/_/g, ' ').toUpperCase()}
            </span>
            {property.verificationStatus === 'verified_by_platform' ? (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-800">
                <ShieldCheck className="w-3.5 h-3.5" />
                Verified by Roomora
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-400 border border-amber-300 dark:border-amber-800">
                <AlertTriangle className="w-3.5 h-3.5" />
                Verification Incomplete
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onReport(property)}
              className="text-xs text-red-600 dark:text-red-400 hover:text-red-700 flex items-center gap-1 px-2 py-1 rounded-lg border border-red-200 dark:border-red-900/60 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
            >
              <Flag className="w-3 h-3" />
              <span>Report Listing</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable details body */}
        <div className="p-6 overflow-y-auto space-y-6">
          
          {/* Title & Location */}
          <div>
            <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white font-heading">
              {property.title}
            </h2>
            <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400 mt-1">
              <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
              <span>{property.address}</span>
            </div>
          </div>

          {/* Image Gallery */}
          <div className="space-y-3">
            <div className="w-full aspect-16/9 rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800 shadow-inner">
              <img
                src={selectedImage}
                alt={property.title}
                className="w-full h-full object-cover"
              />
            </div>
            {property.images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-1">
                {property.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedImage(img)}
                    className={`w-20 aspect-16/10 rounded-lg overflow-hidden border-2 shrink-0 transition-all ${
                      selectedImage === img
                        ? 'border-amber-500 shadow-md ring-2 ring-amber-500/20'
                        : 'border-transparent opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="Thumb" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Financial Breakdown Card */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800">
            <div>
              <span className="text-xs text-slate-500 dark:text-slate-400">Monthly Rent</span>
              <p className="text-xl font-extrabold text-slate-900 dark:text-white font-heading mt-0.5">
                ₹{property.monthlyRent.toLocaleString('en-IN')}
              </p>
            </div>
            <div>
              <span className="text-xs text-slate-500 dark:text-slate-400">Security Deposit</span>
              <p className="text-lg font-bold text-slate-800 dark:text-slate-200 font-heading mt-0.5">
                ₹{property.deposit.toLocaleString('en-IN')}
              </p>
            </div>
            <div>
              <span className="text-xs text-slate-500 dark:text-slate-400">Maintenance</span>
              <p className="text-base font-semibold text-slate-700 dark:text-slate-300 mt-0.5">
                ₹{property.maintenanceCharges}/mo
              </p>
            </div>
            <div>
              <span className="text-xs text-slate-500 dark:text-slate-400">Electricity</span>
              <p className="text-base font-semibold text-slate-700 dark:text-slate-300 mt-0.5">
                {property.electricityCharges}
              </p>
            </div>
          </div>

          {/* Live Availability & Recheck Section */}
          <div className="p-4 rounded-xl bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-900/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-700 dark:text-indigo-400">
                  Availability Engine
                </span>
                <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-500 text-white">
                  {property.availableBeds} bed(s) available
                </span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                Last checked: {new Date(property.lastAvailabilityCheck).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}
              </p>
              {recheckStatus && (
                <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 mt-1 animate-in fade-in">
                  ✓ {recheckStatus}
                </p>
              )}
            </div>

            <button
              onClick={handleRecheckAvailability}
              disabled={rechecking}
              className="px-4 py-2 text-xs font-bold rounded-xl bg-white dark:bg-slate-900 border border-indigo-300 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-50 dark:hover:bg-indigo-900/40 transition-colors flex items-center gap-1.5 shadow-xs"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${rechecking ? 'animate-spin' : ''}`} />
              <span>{rechecking ? 'Querying Host API...' : 'Recheck Availability'}</span>
            </button>
          </div>

          {/* Description */}
          <div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider font-heading mb-2">
              Property Overview
            </h4>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              {property.description}
            </p>
          </div>

          {/* Campus Proximity Table */}
          <div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider font-heading mb-3">
              Commute to Educational Campuses
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {property.distanceToCampus.map((c, i) => (
                <div key={i} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 text-xs">
                  <p className="font-bold text-slate-900 dark:text-white truncate">{c.campusName}</p>
                  <div className="flex items-center justify-between text-slate-600 dark:text-slate-300 mt-1.5 font-mono">
                    <span>{c.distanceKm} km</span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-semibold">{c.walkingTimeMin} min walk</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Amenities & Rules */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3 font-heading">
                Verified Amenities
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {property.amenities.map((a, i) => (
                  <div key={i} className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                    <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>{a}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3 font-heading">
                House Rules & Policies
              </h4>
              <div className="space-y-2 text-xs">
                {property.houseRules.map((rule, i) => (
                  <div key={i} className="flex items-start gap-2 text-slate-600 dark:text-slate-300">
                    <span className="text-amber-500 font-bold">•</span>
                    <span>{rule}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Fair Rent & Scam Guard Evaluation */}
          <div className="p-4 rounded-xl bg-amber-50/40 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-extrabold uppercase tracking-wider text-amber-800 dark:text-amber-400 font-heading">
                Fair-Rent & Trust Audit
              </span>
              <span className="text-xs font-mono font-bold text-amber-700 dark:text-amber-300">
                Audited Locality Avg: ₹{property.fairRentScore.averageLocalityRent}/mo
              </span>
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
              {property.fairRentScore.assessmentNotes}
            </p>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 pt-1 border-t border-amber-200/50 dark:border-amber-900/30">
              <strong>Verification Trail:</strong> {property.verificationMethod} (Timestamp: {new Date(property.verificationTimestamp).toLocaleDateString()})
            </div>
          </div>

          {/* Host Contact Preview */}
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center font-bold text-slate-700 dark:text-slate-200">
                {property.hostName.charAt(0)}
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-sm text-slate-900 dark:text-white">
                    {property.hostName}
                  </span>
                  {property.hostVerified && (
                    <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400">
                      ID Verified
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">Property Host & Coordinator</p>
              </div>
            </div>
            <span className="text-xs font-mono text-slate-600 dark:text-slate-400">
              {property.hostPhone}
            </span>
          </div>

          {/* Dedicated Mess Facility Card if available */}
          {property.messName && (
            <div className="p-4 rounded-xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="text-base">🍱</span>
                  <div>
                    <h4 className="text-xs font-extrabold uppercase tracking-wider text-amber-800 dark:text-amber-400 font-heading">
                      Mess & Fooding Details
                    </h4>
                    <p className="text-sm font-bold text-slate-900 dark:text-white">
                      {property.messName}
                    </p>
                  </div>
                </div>
                {(property.messPhone || property.hostPhone) && (
                  <a
                    href={`tel:${property.messPhone || property.hostPhone}`}
                    className="px-3 py-1.5 text-xs font-mono font-bold rounded-lg bg-amber-500/20 text-amber-850 dark:text-amber-300 hover:bg-amber-500/30 flex items-center gap-1.5 transition-colors"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>{property.messPhone || property.hostPhone}</span>
                  </a>
                )}
              </div>
              {property.mealPlan && (
                <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed pt-1">
                  <strong>Meal Plan:</strong> {property.mealPlan}
                </p>
              )}
              <div className="text-[11px] text-slate-500 dark:text-slate-400 pt-1.5 border-t border-amber-200/50 dark:border-amber-900/30 flex items-center justify-between">
                <span>Operating Timings: 7:00 AM - 10:00 PM</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-semibold">Fresh Odia Cuisine</span>
              </div>
            </div>
          )}

          {/* Google Maps Location & Direct Navigation Card */}
          {property.gmapUrl && (
            <div className="p-4 rounded-xl bg-cyan-50/60 dark:bg-cyan-950/20 border border-cyan-200 dark:border-cyan-800/40 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-cyan-600 text-white">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-900 dark:text-cyan-300 font-heading">
                      Google Maps Verified Stay
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-400 truncate max-w-md font-mono">
                      {property.gmapUrl}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopyLink}
                    className="px-3 py-1.5 text-xs font-bold rounded-lg border border-cyan-300 dark:border-cyan-800 bg-white dark:bg-slate-900 text-cyan-800 dark:text-cyan-300 hover:bg-cyan-100 dark:hover:bg-cyan-900/40 transition-colors flex items-center gap-1.5 shadow-xs"
                    title="Copy Google Maps link to clipboard"
                  >
                    {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedLink ? 'Link Copied!' : 'Copy Link'}</span>
                  </button>

                  <a
                    href={property.gmapUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3.5 py-1.5 text-xs font-bold rounded-lg bg-cyan-600 hover:bg-cyan-700 text-white transition-colors flex items-center gap-1.5 shadow-xs"
                    title="Open directly in Google Maps"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Visit on Google Maps ↗</span>
                  </a>
                </div>
              </div>

              {/* Embedded Google Map Preview */}
              <div className="w-full h-44 rounded-lg overflow-hidden border border-cyan-200/80 dark:border-cyan-800/50 bg-slate-100 dark:bg-slate-800">
                <iframe
                  title="Google Map Location Preview"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  loading="lazy"
                  src={`https://maps.google.com/maps?q=${property.coordinates?.lat || 21.51},${property.coordinates?.lng || 86.90}&z=16&output=embed`}
                />
              </div>
            </div>
          )}

        </div>

        {/* Action Buttons Footer */}
        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <button
            onClick={() => {
              onClose();
              onAskConcierge(property);
            }}
            className="px-4 py-2.5 text-xs font-bold rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 shadow-md shadow-amber-500/20 flex items-center gap-1.5 transition-all"
          >
            <Sparkles className="w-4 h-4" />
            <span>Ask Concierge to Handle</span>
          </button>

          <div className="flex flex-wrap items-center gap-2">
            {isMessListing(property) && onOpenMessAdminLogin && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenMessAdminLogin(property);
                }}
                className="px-4 py-2.5 text-xs font-black rounded-xl bg-gradient-to-r from-[#4c0519] via-[#881337] to-[#4c0519] hover:from-[#5c0720] hover:to-[#70102e] text-amber-200 hover:text-white border border-amber-400/50 shadow-md flex items-center gap-1.5 transition-all"
                title={`Authorized Mess Administrator login for ${getMessDisplayName(property)}`}
              >
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                <span>Mess Admin Login ({getMessDisplayName(property)})</span>
              </button>
            )}

            {/* For all mess listings: Visit on G-Map & Call Now (same as Fooding tab) */}
            {isMessListing(property) ? (
              <>
                <a
                  href={
                    property.gmapUrl ||
                    `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                      `${property.title} ${property.address || property.locality} ${property.city || 'Odisha'}`
                    )}`
                  }
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2.5 text-xs font-extrabold rounded-xl bg-gradient-to-r from-[#881337] to-[#be123c] hover:from-[#700f2b] hover:to-[#9f1239] text-white shadow-md ring-1 ring-rose-400/30 flex items-center gap-1.5 transition-all hover:shadow-lg"
                  title="Directly open in Google Maps"
                >
                  <ExternalLink className="w-4 h-4 shrink-0" />
                  <span>Visit on G-Map</span>
                </a>

                <a
                  href={`tel:${(property.messPhone || property.hostPhone || '+91 94372 81904').replace(/[^0-9+]/g, '')}`}
                  className="px-4 py-2.5 text-xs font-bold rounded-xl bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/60 dark:hover:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 shadow-sm flex items-center gap-1.5 transition-colors"
                  title={`Call ${getMessDisplayName(property)}: ${property.messPhone || property.hostPhone}`}
                >
                  <Phone className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  <span>Call Now</span>
                </a>
              </>
            ) : (
              property.gmapUrl && (
                <a
                  href={property.gmapUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2.5 text-xs font-bold rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white shadow-md flex items-center gap-1.5 transition-all"
                  title="Directly visit Google Maps link"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Visit Google Maps ↗</span>
                </a>
              )
            )}

            <button
              onClick={() => onScheduleVisit(property)}
              className="px-4 py-2.5 text-xs font-bold rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 transition-colors flex items-center gap-1.5"
            >
              <Calendar className="w-4 h-4 text-slate-500" />
              <span>Schedule Physical Visit</span>
            </button>

            <button
              onClick={() => onStartBooking(property)}
              className="px-5 py-2.5 text-xs font-bold rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-950 shadow-md flex items-center gap-1.5 transition-all"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Book via AI Escrow</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
