import React from 'react';
import { 
  Home, 
  Compass, 
  Sparkles, 
  UtensilsCrossed, 
  CookingPot,
  UserCheck, 
  PhoneCall, 
  ShieldCheck, 
  Building,
  Activity,
  Flag,
  GraduationCap
} from 'lucide-react';

interface SidebarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  userRole: 'student' | 'owner' | 'admin';
}

interface NavItem {
  id: string;
  label: string;
  icon: any;
  highlight?: boolean;
  danger?: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  setCurrentTab,
  userRole
}) => {
  const studentNavItems: NavItem[] = [
    { id: 'landing', label: 'Home Entrance', icon: Home },
    { id: 'student_profile', label: 'My Profile', icon: GraduationCap },
    { id: 'search', label: 'Explore Stays', icon: Compass },
    { id: 'concierge', label: 'AI Concierge', icon: Sparkles, highlight: true },
    { id: 'fooding', label: 'Fooding', icon: UtensilsCrossed },
    { id: 'mess', label: 'Mess', icon: CookingPot },
    { id: 'dashboard', label: 'Student Hub', icon: UserCheck },
    { id: 'emergency', label: 'Healthcare & SOS', icon: PhoneCall, danger: true },
  ];

  const adminNavItems: NavItem[] = [
    { id: 'admin', label: 'Admin Overview', icon: ShieldCheck },
    { id: 'admin_verification', label: 'Property Management', icon: Building },
    { id: 'admin_reports', label: 'Reports & Complaints', icon: Flag },
    { id: 'admin_logs', label: 'AI Agent Monitoring', icon: Activity },
    { id: 'landing', label: 'Return to Home', icon: Home },
  ];

  const navItems = userRole === 'admin' ? adminNavItems : studentNavItems;

  return (
    <aside className={`w-64 golden-striped-right flex flex-col justify-between shrink-0 hidden md:flex sticky top-0 h-screen overflow-y-auto shadow-md transition-colors ${
      userRole === 'admin'
        ? 'bg-[#1a040b] text-[#ffe4e6] border-r border-rose-950/80'
        : 'bg-[#fff5f6] text-[#4c0519] border-r border-rose-200/80'
    }`}>
      
      {/* Top Branding & Navigation */}
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-3 cursor-pointer group" onClick={() => setCurrentTab('landing')}>
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#9f1239] to-[#e11d48] flex items-center justify-center font-bold text-white text-xl font-heading shadow-md group-hover:scale-105 transition-transform">
            R
          </div>
          <div>
            <h2 className={`font-extrabold text-sm tracking-tight font-heading ${
              userRole === 'admin' ? 'text-white' : 'text-[#4c0519]'
            }`}>
              Roomora <span className="text-[#be123c]">Concierge</span>
            </h2>
            <span className="text-[10px] uppercase font-bold tracking-widest text-[#e11d48]">
              {userRole === 'admin' ? 'Admin Portal' : 'Student Portal'}
            </span>
          </div>
        </div>

        {/* Navigation List on the Left Side */}
        <nav className="space-y-2 pt-4">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id || (userRole === 'admin' && item.id.startsWith('admin') && item.id !== 'landing');

            if (item.highlight) {
              return (
                <button
                  key={item.id}
                  onClick={() => setCurrentTab(item.id)}
                  className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-xl text-xs font-extrabold transition-all glass-click-anim golden-concierge-tab text-slate-950 shadow-md ${
                    isActive ? 'ring-2 ring-amber-300' : 'opacity-95 hover:opacity-100'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0 text-slate-950" />
                  <span className="truncate tracking-wide">{item.label}</span>
                </button>
              );
            }

            return (
              <button
                key={item.id}
                onClick={() => setCurrentTab(item.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all glass-click-anim ${
                  isActive
                    ? item.danger
                      ? 'bg-red-600 text-white shadow-md shadow-red-600/30'
                      : 'bg-[#881337] text-white shadow-md ring-1 ring-rose-400/40'
                    : item.danger
                    ? userRole === 'admin' ? 'text-rose-400 hover:bg-rose-950/60' : 'text-red-700 hover:bg-rose-100/70'
                    : userRole === 'admin'
                    ? 'text-rose-200/90 hover:text-white hover:bg-rose-950/70'
                    : 'text-[#4c0519] hover:text-[#881337] hover:bg-rose-100/80'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      <div className={`p-4 border-t text-[11px] text-center font-semibold ${
        userRole === 'admin'
          ? 'border-rose-950 text-rose-300/80 bg-rose-950/40'
          : 'border-rose-200/70 text-rose-900/90 bg-rose-100/50'
      }`}>
        Roomora Security v2.4 • Wine Edition
      </div>

    </aside>
  );
};
