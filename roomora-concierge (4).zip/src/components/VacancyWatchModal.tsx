import React, { useState } from 'react';
import { X, Bell, Sparkles, CheckCircle2, ShieldCheck } from 'lucide-react';
import { VacancyWatch } from '../types';

interface VacancyWatchModalProps {
  onClose: () => void;
  onSuccess: (watch: VacancyWatch) => void;
}

export const VacancyWatchModal: React.FC<VacancyWatchModalProps> = ({ onClose, onSuccess }) => {
  const [locality, setLocality] = useState('Patia');
  const [maxRent, setMaxRent] = useState(3500);
  const [roomType, setRoomType] = useState('double_sharing');
  const [frequency, setFrequency] = useState<'immediate' | 'daily_digest'>('immediate');
  const [wifi, setWifi] = useState(true);
  const [attachedBath, setAttachedBath] = useState(true);
  const [loading, setLoading] = useState(false);
  const [created, setCreated] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const requiredAmenities = [];
    if (wifi) requiredAmenities.push('High-speed Wi-Fi');
    if (attachedBath) requiredAmenities.push('Attached Bathroom');

    try {
      const res = await fetch('/api/vacancy-watches', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          locality,
          maxMonthlyRent: maxRent,
          roomType,
          requiredAmenities,
          notificationFrequency: frequency
        })
      });
      const data = await res.json();
      if (data.watch) {
        setCreated(true);
        setTimeout(() => {
          onSuccess(data.watch);
          onClose();
        }, 1500);
      }
    } catch {
      // fallback
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 text-xs">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/80 dark:bg-slate-950/60">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-amber-500" />
            <h3 className="text-base font-bold text-slate-900 dark:text-white font-heading">
              Deploy Vacancy Watch Agent
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        {created ? (
          <div className="p-8 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 mx-auto flex items-center justify-center">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <h4 className="text-base font-bold text-slate-900 dark:text-white font-heading">
              Watcher Agent Active!
            </h4>
            <p className="text-slate-500 dark:text-slate-400">
              Roomora background workers will monitor Patia & Bhubaneswar hostel networks for vacancies under ₹{maxRent}/mo.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Target Locality / Campus Hub
              </label>
              <select
                value={locality}
                onChange={(e) => setLocality(e.target.value)}
                className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              >
                <option value="Patia">Patia (KIIT Deemed University Hub)</option>
                <option value="Khandagiri">Khandagiri (ITER / SOA University Hub)</option>
                <option value="Chandrasekharpur">Chandrasekharpur (Infocity / Tech Corridor)</option>
              </select>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">
                  Maximum Monthly Budget
                </label>
                <span className="font-extrabold text-amber-600 dark:text-amber-400 font-heading">
                  ₹{maxRent.toLocaleString('en-IN')}/mo
                </span>
              </div>
              <input
                type="range"
                min="2000"
                max="8000"
                step="250"
                value={maxRent}
                onChange={(e) => setMaxRent(Number(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Room Sharing Type
              </label>
              <select
                value={roomType}
                onChange={(e) => setRoomType(e.target.value)}
                className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              >
                <option value="double_sharing">Double Sharing Room</option>
                <option value="triple_sharing">Triple Sharing (Budget)</option>
                <option value="single_private">Single Private Room</option>
              </select>
            </div>

            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                Must-Have Amenities
              </label>
              <div className="flex gap-4">
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={wifi}
                    onChange={(e) => setWifi(e.target.checked)}
                    className="accent-amber-500 rounded"
                  />
                  <span>High-speed Wi-Fi</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={attachedBath}
                    onChange={(e) => setAttachedBath(e.target.checked)}
                    className="accent-amber-500 rounded"
                  />
                  <span>Attached Bathroom</span>
                </label>
              </div>
            </div>

            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Notification Cadence
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setFrequency('immediate')}
                  className={`p-2 rounded-lg border font-bold text-center ${
                    frequency === 'immediate'
                      ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  Instant Push & SMS
                </button>
                <button
                  type="button"
                  onClick={() => setFrequency('daily_digest')}
                  className={`p-2 rounded-lg border font-bold text-center ${
                    frequency === 'daily_digest'
                      ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  Daily 8 PM Digest
                </button>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 font-bold rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-950 transition-all shadow-md flex items-center justify-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>{loading ? 'Activating Agent...' : 'Activate Background Vacancy Monitor'}</span>
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
