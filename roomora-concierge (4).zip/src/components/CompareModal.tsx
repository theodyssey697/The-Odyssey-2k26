import React from 'react';
import { X, Check, Scale, Sparkles, ShieldCheck, MapPin } from 'lucide-react';
import { Property } from '../types';

interface CompareModalProps {
  properties: Property[];
  onClose: () => void;
  onSelectProperty: (prop: Property) => void;
  onAskConcierge: (props: Property[]) => void;
}

export const CompareModal: React.FC<CompareModalProps> = ({
  properties,
  onClose,
  onSelectProperty,
  onAskConcierge
}) => {
  if (properties.length === 0) return null;

  // Best value computation
  const bestValueProp = properties.reduce((prev, curr) => 
    (curr.monthlyRent < prev.monthlyRent ? curr : prev), properties[0]
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
      <div className="w-full max-w-5xl rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/80 dark:bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white font-heading">
                Side-by-Side Accommodation Matrix
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Evaluating rent, amenities, walking distance to campus, and Fair-Rent verification
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* AI Recommendation Banner */}
        <div className="px-6 py-3 bg-amber-500/10 border-b border-amber-200 dark:border-amber-900/30 flex items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
            <span className="text-slate-800 dark:text-slate-200">
              <strong>Concierge Value Verdict:</strong> {bestValueProp.title} offers the optimal monthly cost-to-amenity ratio with verified platform inspection.
            </span>
          </div>
          <button
            onClick={() => {
              onClose();
              onAskConcierge(properties);
            }}
            className="px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold whitespace-nowrap shadow-xs"
          >
            Ask AI to Rank
          </button>
        </div>

        {/* Comparison Grid Table */}
        <div className="p-6 overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800">
                <th className="py-3 px-4 font-bold text-slate-400 uppercase w-48 font-heading">Metric</th>
                {properties.map((p) => (
                  <th key={p.id} className="py-3 px-4 font-bold text-slate-900 dark:text-white min-w-56 font-heading">
                    <div className="flex items-center justify-between mb-1">
                      <span className="truncate">{p.title}</span>
                      {p.id === bestValueProp.id && (
                        <span className="px-1.5 py-0.5 rounded bg-emerald-500 text-white text-[10px]">Best Value</span>
                      )}
                    </div>
                    <span className="text-lg font-extrabold text-amber-600 dark:text-amber-400 font-heading">
                      ₹{p.monthlyRent.toLocaleString('en-IN')}<span className="text-xs font-normal text-slate-400">/mo</span>
                    </span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              <tr>
                <td className="py-3 px-4 font-medium text-slate-500 dark:text-slate-400">Locality</td>
                {properties.map(p => (
                  <td key={p.id} className="py-3 px-4 font-semibold text-slate-800 dark:text-slate-200">{p.locality}</td>
                ))}
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-500 dark:text-slate-400">Security Deposit</td>
                {properties.map(p => (
                  <td key={p.id} className="py-3 px-4 text-slate-800 dark:text-slate-200 font-mono">₹{p.deposit.toLocaleString('en-IN')}</td>
                ))}
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-500 dark:text-slate-400">Room Type</td>
                {properties.map(p => (
                  <td key={p.id} className="py-3 px-4 capitalize text-slate-800 dark:text-slate-200">{p.roomType.replace(/_/g, ' ')}</td>
                ))}
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-500 dark:text-slate-400">Commute to KIIT</td>
                {properties.map(p => {
                  const d = p.distanceToCampus[0] || { distanceKm: 1, walkingTimeMin: 12 };
                  return (
                    <td key={p.id} className="py-3 px-4 text-slate-800 dark:text-slate-200">
                      <strong>{d.distanceKm} km</strong> ({d.walkingTimeMin} min walk)
                    </td>
                  );
                })}
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-500 dark:text-slate-400">Verification Status</td>
                {properties.map(p => (
                  <td key={p.id} className="py-3 px-4">
                    {p.verificationStatus === 'verified_by_platform' ? (
                      <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5" /> Verified by Platform
                      </span>
                    ) : (
                      <span className="text-amber-600 dark:text-amber-400 font-bold">Pending Recheck</span>
                    )}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-500 dark:text-slate-400">Fair-Rent Score</td>
                {properties.map(p => (
                  <td key={p.id} className="py-3 px-4 text-slate-700 dark:text-slate-300">
                    {p.fairRentScore.differencePercentage <= 0 ? `${Math.abs(p.fairRentScore.differencePercentage)}% below locality avg` : `${p.fairRentScore.differencePercentage}% above avg`}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-500 dark:text-slate-400">Key Amenities</td>
                {properties.map(p => (
                  <td key={p.id} className="py-3 px-4 space-y-1">
                    {p.amenities.slice(0, 4).map((a, i) => (
                      <div key={i} className="flex items-center gap-1 text-[11px] text-slate-600 dark:text-slate-400">
                        <Check className="w-3 h-3 text-emerald-500 shrink-0" />
                        <span>{a}</span>
                      </div>
                    ))}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-500 dark:text-slate-400">Action</td>
                {properties.map(p => (
                  <td key={p.id} className="py-3 px-4">
                    <button
                      onClick={() => {
                        onClose();
                        onSelectProperty(p);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-slate-900 text-white dark:bg-white dark:text-slate-900 font-bold hover:opacity-90 transition-opacity"
                    >
                      Inspect Property
                    </button>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>

      </div>
    </div>
  );
};
