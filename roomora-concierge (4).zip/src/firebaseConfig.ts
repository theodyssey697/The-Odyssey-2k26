import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyDtxmkbIpynTuNtkvQDyEv8H5xD7EqaZc4",
  authDomain: "roomora-9ef5f.firebaseapp.com",
  projectId: "roomora-9ef5f",
  storageBucket: "roomora-9ef5f.firebasestorage.app",
  messagingSenderId: "1097578930143",
  appId: "1:1097578930143:web:8a1fd3822042c1f87aee6a",
  measurementId: "G-TLBVGK7822"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
