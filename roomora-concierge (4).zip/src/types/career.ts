/**
 * Career Counselling & Student Profile Types
 */

export interface CareerEducation {
  collegeName: string;
  degree: string;
  branch: string;
  currentYear: string;
  semester: string;
  expectedGraduationYear: string;
  enjoyedSubjects: string[];
  cgpa?: string;
}

export interface CareerSkills {
  technicalSkills: string[];
  softSkills: string[];
  skillProficiency: Record<string, 'beginner' | 'intermediate' | 'advanced'>;
  projectsCertifications: string;
  practicalExperience: string;
}

export interface CareerInterests {
  domains: string[];
  roles: string[];
  enjoyedActivities: string[];
  preferredOutcome: 'job' | 'internship' | 'research' | 'higher_studies' | 'entrepreneurship' | 'exploration';
  shortTermGoals: string;
  longTermGoals: string;
  preferredLocation?: string;
}

export interface CareerConstraints {
  weeklyHoursAvailable: number;
  learningBudget: 'free' | 'low_cost' | 'flexible';
  preferredFormats: string[];
  learningLanguages: string[];
  voluntaryConstraints: string;
}

export interface CareerProfile {
  uid: string;
  email: string;
  fullName: string;
  education: CareerEducation;
  skills: CareerSkills;
  interests: CareerInterests;
  constraints: CareerConstraints;
  draftSaved: boolean;
  updatedAt: string;
}

export interface CareerPathway {
  id: string;
  title: string;
  shortExplanation: string;
  whyItFits: string;
  supportEvidence: string[];
  entryRoles: string[];
  essentialSkills: string[];
  tradeOffs: string[];
  tryBeforeCommit: string;
}

export interface SkillGap {
  skillName: string;
  currentLevel: 'none' | 'beginner' | 'intermediate';
  targetLevel: 'intermediate' | 'advanced';
  priority: 'high' | 'medium' | 'low';
  suggestedFirstStep: string;
}

export interface CareerMilestone {
  id: string;
  weekNumber: number;
  title: string;
  description: string;
  estimatedHours: number;
  deliverable: string;
  completed: boolean;
}

export interface CareerRoadmapPhase {
  phaseTitle: string; // e.g. "30-Day Foundation & Skill Building"
  durationDays: number;
  milestones: CareerMilestone[];
}

export interface CareerRoadmap {
  phase30Days: CareerRoadmapPhase;
  phase60Days: CareerRoadmapPhase;
  phase90Days: CareerRoadmapPhase;
}

export interface CareerResource {
  title: string;
  provider: string;
  outcome: string;
  resourceType: 'course' | 'internship' | 'portal' | 'certification';
  link: string;
  reason: string;
}

export interface CareerPlan {
  id: string;
  uid: string;
  profile: CareerProfile;
  recommendations: {
    strongestFit: CareerPathway;
    adjacentOption: CareerPathway;
    stretchOption: CareerPathway;
  };
  pathways: CareerPathway[];
  skillGaps: SkillGap[];
  roadmap: CareerRoadmap;
  resources: CareerResource[];
  resumeTips: string[];
  projectIdeas: string[];
  updatedAt: string;
}

export interface CareerAgentEvent {
  stageName: 'validation' | 'discovery' | 'skill_gap' | 'roadmap' | 'resource_selection' | 'review';
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  message: string;
  timestamp: string;
}

export interface CareerChatMessage {
  id: string;
  sender: 'user' | 'coach';
  text: string;
  timestamp: string;
  proposedChanges?: Partial<CareerRoadmap>;
}
