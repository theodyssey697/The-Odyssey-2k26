export type RoomType = 'single_private' | 'double_sharing' | 'triple_sharing' | 'pg' | 'hostel' | 'apartment';

export type VerificationStatus = 
  | 'verified_by_platform' 
  | 'verification_pending' 
  | 'information_incomplete' 
  | 'availability_needs_rechecking' 
  | 'report_under_review';

export type AvailabilityStatus = 'available' | 'few_beds_left' | 'waiting_list' | 'occupied' | 'unknown' | 'availability_needs_rechecking';

export interface Property {
  id: string;
  title: string;
  description: string;
  city: string;
  locality: string;
  address: string;
  landmark: string;
  monthlyRent: number;
  deposit: number;
  maintenanceCharges: number;
  electricityCharges: string; // e.g. "₹9/unit" or "Included"
  roomType: RoomType;
  genderPreference: 'boys' | 'girls' | 'unisex';
  furnished: 'fully_furnished' | 'semi_furnished' | 'unfurnished';
  amenities: string[];
  houseRules: string[];
  hostId: string;
  hostName: string;
  hostPhone: string;
  hostVerified: boolean;
  verificationStatus: VerificationStatus;
  verificationMethod: string;
  verificationTimestamp: string;
  availabilityStatus: AvailabilityStatus;
  availableBeds: number;
  lastAvailabilityCheck: string;
  images: string[];
  distanceToCampus: {
    campusName: string;
    distanceKm: number;
    walkingTimeMin: number;
  }[];
  fairRentScore: {
    status: 'fair' | 'below_average' | 'above_average';
    averageLocalityRent: number;
    differencePercentage: number;
    assessmentNotes: string;
  };
  demoListing?: boolean;
  gmapUrl?: string;
  messName?: string;
  messPhone?: string;
  mealPlan?: string;
  coordinates?: {
    lat: number;
    lng: number;
  };
}

export interface MessService {
  id: string;
  name: string;
  locality: string;
  city: string;
  address: string;
  phone: string;
  gmapUrl?: string;
  foodType: 'pure_veg' | 'non_veg' | 'veg_and_nonveg';
  monthlyPrice: number;
  singleMealPrice: number;
  mealPlans: {
    id: string;
    title: string;
    description: string;
    mealsPerDay: number;
    pricePerMonth: number;
    includesBreakfast: boolean;
  }[];
  sampleMenu: {
    day: string;
    lunch: string;
    dinner: string;
  }[];
  deliveryAvailable: boolean;
  operatingHours: string;
  hygieneRating?: string;
  verifiedStatus?: boolean;
  distanceToPatiaKiitKm: number;
  category?: 'restaurant' | 'mess' | 'tiffin' | 'dhaba' | 'cafe' | 'fast_food';
  cuisine?: string;
  imageUrl?: string;
  images?: string[];
  priceRange?: string;
  rating?: number;
  reviewCount?: number;
  highlights?: string[];
  isGoogleMapsVerified?: boolean;
  coordinates?: {
    lat: number;
    lng: number;
  };
  demoData?: boolean;
}

export interface FoodingPlace {
  id: string;
  name: string;
  locality: string;
  city: string;
  address: string;
  phone: string;
  gmapUrl: string;
  category: 'restaurant' | 'dhaba' | 'cafe' | 'fast_food' | 'homestyle_dining';
  cuisine: string;
  foodType: 'pure_veg' | 'non_veg' | 'veg_and_nonveg';
  rating: number;
  reviewCount: number;
  priceRange: string;
  isGoogleMapsVerified: boolean;
  imageUrl: string;
  images: string[];
  highlights: string[];
  operatingHours: string;
  deliveryAvailable: boolean;
  hygieneRating?: string;
  coordinates?: {
    lat: number;
    lng: number;
  };
}

export type TaskStatus = 'pending' | 'running' | 'waiting_for_approval' | 'completed' | 'failed' | 'cancelled';

export interface SubTask {
  id: string;
  description: string;
  tool: string;
  input: Record<string, any>;
  status: TaskStatus;
  dependencies: string[];
  requiresApproval: boolean;
  approvalData?: {
    actionType: string;
    amount?: number;
    recipient?: string;
    details: string;
    terms?: string;
    consequences: string;
  };
  resultSummary?: string;
  resultData?: any;
  errorDetails?: string;
}

export interface AgentEvent {
  id: string;
  taskId: string;
  timestamp: string;
  eventType: 
    | 'goal_received'
    | 'intent_extracted'
    | 'plan_created'
    | 'tool_selected'
    | 'tool_request_initiated'
    | 'tool_result_received'
    | 'availability_rechecked'
    | 'approval_requested'
    | 'user_approved'
    | 'user_rejected'
    | 'retry_attempted'
    | 'fallback_selected'
    | 'task_completed'
    | 'task_failed';
  actionName: string;
  explanation: string;
  toolName?: string;
  outcome?: string;
  status: 'info' | 'running' | 'success' | 'warning' | 'error';
}

export interface AgentTaskSession {
  id: string;
  userId: string;
  originalGoal: string;
  extractedGoal: {
    location?: string;
    maxBudget?: number;
    roomType?: string;
    genderPreference?: string;
    amenities?: string[];
    deadlineOrVisitDate?: string;
    messRequired?: boolean;
    collegesNearby?: string;
  };
  plan: SubTask[];
  events: AgentEvent[];
  status: TaskStatus;
  finalSummary?: string;
  createdAt: string;
  updatedAt: string;
}

export interface VisitRequest {
  id: string;
  userId: string;
  studentName: string;
  studentPhone: string;
  propertyId: string;
  propertyTitle: string;
  propertyLocality: string;
  requestedDate: string;
  requestedTimeSlot: string;
  ownerConfirmationStatus: 'pending' | 'confirmed' | 'reschedule_requested' | 'rejected';
  studentConfirmationStatus: 'requested' | 'confirmed' | 'cancelled';
  status: 'scheduled' | 'completed' | 'cancelled';
  notes?: string;
  createdAt: string;
}

export interface Booking {
  id: string;
  userId: string;
  propertyId: string;
  propertyTitle: string;
  locality: string;
  rentAmount: number;
  depositAmount: number;
  totalInitialPayable: number;
  paymentStatus: 'not_initiated' | 'pending' | 'successful' | 'failed' | 'refund_pending' | 'refunded';
  bookingStatus: 'draft' | 'awaiting_student_approval' | 'awaiting_payment' | 'awaiting_owner_confirmation' | 'confirmed' | 'rejected' | 'cancelled';
  paymentTransactionId?: string;
  moveInDate: string;
  studentApprovalTimestamp?: string;
  ownerConfirmedTimestamp?: string;
  createdAt: string;
}

export interface VacancyWatch {
  id: string;
  userId: string;
  city: string;
  locality: string;
  maxMonthlyRent: number;
  roomType: string;
  requiredAmenities: string[];
  preferredAvailabilityDate: string;
  notificationFrequency: 'immediate' | 'daily_digest';
  active: boolean;
  matchCount: number;
  lastCheckedAt: string;
  createdAt: string;
}

export interface Pharmacy {
  id: string;
  name: string;
  locality: string;
  address: string;
  phone: string;
  isOpen24Hours: boolean;
  distanceKm: number;
  verifiedStudentPartner: boolean;
  services: string[];
}

export interface ListingReport {
  id: string;
  userId: string;
  propertyId: string;
  propertyTitle: string;
  category: 'fake_photos' | 'wrong_rent' | 'fake_verification' | 'harassment' | 'stale_availability' | 'other';
  description: string;
  status: 'under_review' | 'resolved' | 'dismissed';
  createdAt: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'student' | 'owner' | 'admin';
  college?: string;
  preferredCity: string;
  budgetCap: number;
  savedPropertyIds: string[];
}

export interface MessOrder {
  orderId: string;
  messId: string;
  messName: string;
  studentName: string;
  studentEmail?: string;
  phone: string;
  deliveryAddress: string;
  planTitle: string;
  amount: number;
  orderType: 'monthly_plan' | 'single_trial';
  status: 'order_confirmed' | 'preparing' | 'out_for_delivery' | 'delivered' | 'cancelled';
  createdAt: string;
  deliveryTimeEstimate?: string;
  specialNotes?: string;
  adminNotes?: string;
}

export interface MessOwnership {
  messId: string;
  messName: string;
  assignedAdminEmail: string;
  assignedAt: string;
  assignedBy: string;
}

