export function isMessListing(property: {
  id?: string;
  title?: string;
  messName?: string;
  amenities?: string[];
  description?: string;
}): boolean {
  if (property.messName && property.messName.trim().length > 0) return true;
  if (property.id && property.id.toLowerCase().includes('mess')) return true;
  if (property.title && property.title.toLowerCase().includes('mess')) return true;
  if (property.amenities && property.amenities.some(a => a.toLowerCase().includes('mess') || a.toLowerCase().includes('tiffin'))) return true;
  return false;
}

export function getMessDisplayName(property: {
  id?: string;
  title?: string;
  messName?: string;
}): string {
  if (property.messName && property.messName.trim().length > 0) {
    return property.messName;
  }
  return property.title || 'Student Mess';
}
