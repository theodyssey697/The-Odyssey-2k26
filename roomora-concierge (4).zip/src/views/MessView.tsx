import React, { useState, useEffect } from 'react';
import { 
  CookingPot, 
  MapPin, 
  Phone, 
  Clock, 
  ShieldCheck, 
  Check, 
  Sparkles, 
  CheckCircle2,
  Star,
  Search,
  ChevronLeft,
  ChevronRight,
  Info,
  X,
  Calendar,
  Truck,
  ExternalLink,
  Lock
} from 'lucide-react';
import { MessService } from '../types';

interface MessViewProps {
  onOpenMessAdminLogin?: (mess: { id: string; name: string }) => void;
}

export const MessView: React.FC<MessViewProps> = ({ onOpenMessAdminLogin }) => {
  const [messServices, setMessServices] = useState<MessService[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [foodTypeFilter, setFoodTypeFilter] = useState<'all' | 'pure_veg' | 'veg_and_nonveg'>('all');
  const [deliveryOnlyFilter, setDeliveryOnlyFilter] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedMess, setSelectedMess] = useState<MessService | null>(null);
  const [activeImageIndices, setActiveImageIndices] = useState<Record<string, number>>({});

  // Ordering / Subscription Modal
  const [orderModalOpen, setOrderModalOpen] = useState<boolean>(false);
  const [orderType, setOrderType] = useState<'monthly_plan' | 'single_trial'>('monthly_plan');
  const [selectedPlanId, setSelectedPlanId] = useState<string>('');
  const [studentName, setStudentName] = useState<string>('Aryan Sharma');
  const [studentPhone, setStudentPhone] = useState<string>('+91 98765 43210');
  const [deliveryAddress, setDeliveryAddress] = useState<string>('FM College Hostel / Sidheswar Colony, Balasore');
  const [orderLoading, setOrderLoading] = useState<boolean>(false);
  const [orderConfirmedData, setOrderConfirmedData] = useState<any | null>(null);

  const fetchMessServices = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (foodTypeFilter !== 'all') params.set('foodType', foodTypeFilter);
      if (searchQuery.trim()) params.set('q', searchQuery.trim());
      // Request purely mess category or exclude restaurants
      params.set('category', 'mess');
      const res = await fetch(`/api/mess-services?${params.toString()}`);
      const data = await res.json();
      
      // Filter out any restaurant items so mess section is strictly student messes
      const onlyMesses = (data.messServices || []).filter((m: MessService) => {
        return m.id.startsWith('mess-') || m.category === 'mess' || m.category === 'tiffin' || !m.category;
      });
      setMessServices(onlyMesses);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMessServices();
  }, [foodTypeFilter, searchQuery]);

  const handlePrevImage = (id: string, totalImages: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveImageIndices(prev => {
      const current = prev[id] || 0;
      return { ...prev, [id]: (current - 1 + totalImages) % totalImages };
    });
  };

  const handleNextImage = (id: string, totalImages: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveImageIndices(prev => {
      const current = prev[id] || 0;
      return { ...prev, [id]: (current + 1) % totalImages };
    });
  };

  const handleOpenOrder = (mess: MessService) => {
    setSelectedMess(mess);
    setSelectedPlanId(mess.mealPlans?.[0]?.id || '');
    setOrderConfirmedData(null);
    setOrderModalOpen(true);
  };

  const handleConfirmOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMess) return;
    setOrderLoading(true);
    try {
      const res = await fetch(`/api/mess-services/${selectedMess.id}/order`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mealPlanId: selectedPlanId,
          studentName,
          deliveryAddress,
          phone: studentPhone,
          orderType
        })
      });
      const data = await res.json();
      if (data.success) {
        setOrderConfirmedData(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setOrderLoading(false);
    }
  };

  const filteredMesses = messServices.filter(item => {
    if (deliveryOnlyFilter && !item.deliveryAvailable) return false;
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 font-sans">
      
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#4c0519] via-[#881337] to-[#1e050c] text-white p-6 sm:p-8 shadow-xl border border-rose-800/40">
        <div className="absolute top-0 right-0 w-96 h-96 bg-rose-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/20 text-rose-200 border border-rose-400/30 text-xs font-bold tracking-wide uppercase">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Student Dining & Meal Subscriptions</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight font-heading text-white">
              Student Mess & Daily Tiffin Services
            </h1>
            <p className="text-sm sm:text-base text-rose-100/90 leading-relaxed">
              Wholesome, home-style daily student meals, weekly rotating menus, and affordable monthly subscriptions with hygienic kitchen verification and doorstep delivery to PGs & Hostels.
            </p>
          </div>

          <div className="flex sm:flex-col gap-2 shrink-0">
            <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 text-center min-w-[125px]">
              <span className="block text-2xl font-black text-amber-300 font-heading">
                {messServices.length}
              </span>
              <span className="text-[11px] font-bold text-rose-200">Verified Messes</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 text-center min-w-[125px]">
              <span className="block text-2xl font-black text-emerald-300 font-heading">
                ₹2,400
              </span>
              <span className="text-[11px] font-bold text-rose-200">Avg Monthly Sub</span>
            </div>
          </div>
        </div>
      </div>

      {/* Control Filters & Search Bar */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-rose-100 space-y-4">
        
        {/* Search bar */}
        <div className="relative">
          <Search className="w-5 h-5 text-teal-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search student messes by name (Annapurna, Satvik, Bhojohori, Pradhan...), locality or dish..."
            className="w-full pl-11 pr-10 py-3 rounded-xl bg-slate-50 border border-slate-200 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Dietary & Delivery Filters */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2 border-t border-slate-100">
          
          <div className="flex items-center gap-2 text-xs shrink-0 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setFoodTypeFilter('all')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                foodTypeFilter === 'all'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Meal Types
            </button>
            <button
              onClick={() => setFoodTypeFilter('pure_veg')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-colors flex items-center gap-1.5 ${
                foodTypeFilter === 'pure_veg'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-emerald-700 hover:text-emerald-800'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              Pure Veg Messes
            </button>
            <button
              onClick={() => setFoodTypeFilter('veg_and_nonveg')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-colors flex items-center gap-1.5 ${
                foodTypeFilter === 'veg_and_nonveg'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-amber-700 hover:text-amber-800'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-amber-400"></span>
              Veg & Non-Veg Messes
            </button>
          </div>

          <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={deliveryOnlyFilter}
              onChange={(e) => setDeliveryOnlyFilter(e.target.checked)}
              className="w-4 h-4 text-teal-600 rounded-md border-slate-300 focus:ring-teal-500"
            />
            <Truck className="w-4 h-4 text-teal-600" />
            <span>Doorstep Hostel Delivery Available Only</span>
          </label>
        </div>
      </div>

      {/* Mess Cards Grid */}
      {loading ? (
        <div className="text-center py-16 space-y-3">
          <div className="w-10 h-10 border-4 border-teal-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-sm font-semibold text-slate-600">Loading student mess services...</p>
        </div>
      ) : filteredMesses.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center max-w-md mx-auto border border-sky-100 space-y-3">
          <CookingPot className="w-12 h-12 text-slate-400 mx-auto" />
          <h3 className="text-lg font-bold text-slate-900 font-heading">No student messes found</h3>
          <p className="text-xs text-slate-500">Try adjusting your filters or search terms.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMesses.map((mess) => {
            const currentImgIndex = activeImageIndices[mess.id] || 0;
            const displayImages = mess.images && mess.images.length > 0 
              ? mess.images 
              : [mess.imageUrl || 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80'];

            return (
              <div
                key={mess.id}
                className="bg-white rounded-3xl border border-sky-100 shadow-sm hover:shadow-lg transition-all duration-200 flex flex-col overflow-hidden group"
              >
                {/* Photo Carousel Container */}
                <div className="relative aspect-video w-full bg-slate-900 overflow-hidden select-none">
                  <img
                    src={displayImages[currentImgIndex]}
                    alt={mess.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />

                  {displayImages.length > 1 && (
                    <>
                      <button
                        onClick={(e) => handlePrevImage(mess.id, displayImages.length, e)}
                        className="absolute left-2.5 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/60 hover:bg-black/80 text-white flex items-center justify-center backdrop-blur-xs transition-colors z-10"
                      >
                        <ChevronLeft className="w-4 h-4" />
                      </button>
                      <button
                        onClick={(e) => handleNextImage(mess.id, displayImages.length, e)}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/60 hover:bg-black/80 text-white flex items-center justify-center backdrop-blur-xs transition-colors z-10"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </>
                  )}

                  {/* Badges */}
                  <div className="absolute top-3 left-3 flex flex-wrap items-center gap-1.5 z-10">
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-teal-600/90 text-white text-[11px] font-bold backdrop-blur-xs shadow-xs">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Verified Kitchen</span>
                    </span>
                    {mess.foodType === 'pure_veg' && (
                      <span className="px-2.5 py-1 rounded-full bg-emerald-600/90 text-white text-[11px] font-bold backdrop-blur-xs">
                        Pure Veg
                      </span>
                    )}
                  </div>

                  <div className="absolute bottom-3 right-3 z-10">
                    <span className="px-2.5 py-1 rounded-full bg-slate-950/80 text-amber-300 text-xs font-bold backdrop-blur-xs flex items-center gap-1">
                      <Star className="w-3.5 h-3.5 fill-amber-300" />
                      <span>{mess.rating || 4.5}</span>
                    </span>
                  </div>
                </div>

                {/* Card Body */}
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <h3 className="text-lg font-bold text-slate-900 group-hover:text-teal-700 transition-colors font-heading leading-snug">
                      {mess.name}
                    </h3>

                    {/* Locality & Address */}
                    <div className="flex items-center gap-1.5 text-xs text-slate-600">
                      <MapPin className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                      <span className="font-semibold text-slate-800">{mess.locality}</span>
                      <span className="text-slate-400">•</span>
                      <span>{mess.city}</span>
                    </div>

                    <p className="text-xs text-slate-500 line-clamp-1">
                      {mess.address}
                    </p>

                    {/* Pricing */}
                    <div className="pt-2 flex items-baseline justify-between border-t border-slate-100">
                      <div>
                        <span className="text-xl font-extrabold text-slate-900 font-heading">
                          ₹{mess.monthlyPrice.toLocaleString()}
                        </span>
                        <span className="text-xs text-slate-500"> / month</span>
                      </div>
                      <span className="text-xs font-semibold text-teal-700 bg-teal-50 px-2 py-0.5 rounded-md">
                        Trial Meal: ₹{mess.singleMealPrice}
                      </span>
                    </div>

                    {/* Hygiene & Delivery */}
                    <div className="pt-1 flex items-center justify-between text-[11px] text-slate-600">
                      <span>{mess.hygieneRating || 'FSSAI Grade A (4.6/5)'}</span>
                      {mess.deliveryAvailable && (
                        <span className="text-emerald-700 font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Hostel Delivery Free
                        </span>
                      )}
                    </div>

                    {/* Meal Plans count */}
                    {mess.mealPlans && mess.mealPlans.length > 0 && (
                      <div className="pt-2">
                        <span className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                          Available Plans:
                        </span>
                        <div className="space-y-1">
                          {mess.mealPlans.slice(0, 2).map((plan) => (
                            <div key={plan.id} className="p-2 rounded-xl bg-slate-50 border border-slate-100 text-xs flex justify-between items-center">
                              <span className="font-semibold text-slate-800 line-clamp-1">{plan.title}</span>
                              <span className="font-bold text-teal-700 shrink-0">₹{plan.pricePerMonth}/mo</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="pt-3 border-t border-slate-100 space-y-2">
                    {/* Default Visit G-Map Button */}
                    {(() => {
                      const gmapLink = mess.gmapUrl || `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${mess.name} ${mess.address || mess.locality} ${mess.city || 'Odisha'}`)}`;
                      return (
                        <a
                          href={gmapLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-teal-600 via-sky-600 to-indigo-600 hover:from-teal-700 hover:to-sky-700 text-white font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-all hover:shadow-md"
                          title="Directly view and navigate to mess on Google Maps"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                          <span>Visit on G-Map</span>
                        </a>
                      );
                    })()}

                    <div className="grid grid-cols-2 gap-2">
                      <a
                        href={`tel:${mess.phone.replace(/[^0-9+]/g, '')}`}
                        className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                      >
                        <Phone className="w-3.5 h-3.5 text-slate-600" />
                        <span>Call Mess</span>
                      </a>

                      <button
                        onClick={() => handleOpenOrder(mess)}
                        className="py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-all"
                      >
                        <CookingPot className="w-3.5 h-3.5 text-amber-400" />
                        <span>Subscribe Plan</span>
                      </button>
                    </div>

                    {onOpenMessAdminLogin && (
                      <button
                        type="button"
                        onClick={() => onOpenMessAdminLogin({ id: mess.id, name: mess.name })}
                        className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-[#4c0519] via-[#881337] to-[#4c0519] hover:from-[#5c0720] hover:to-[#70102e] text-amber-200 hover:text-white border border-amber-400/50 text-xs font-black shadow-md flex items-center justify-center gap-1.5 transition-all"
                        title={`Administrator login for ${mess.name}`}
                      >
                        <Lock className="w-3.5 h-3.5 text-amber-400" />
                        <span>Mess Admin Login</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Subscription / Order Modal */}
      {orderModalOpen && selectedMess && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="w-full max-w-lg rounded-3xl bg-white border border-teal-200 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 p-6 space-y-5 text-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <CookingPot className="w-5 h-5 text-teal-600" />
                <h3 className="text-lg font-bold font-heading">
                  Student Mess Subscription
                </h3>
              </div>
              <button onClick={() => setOrderModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            {orderConfirmedData ? (
              <div className="py-6 text-center space-y-4">
                <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center">
                  <Check className="w-8 h-8 stroke-[2.5]" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-xl font-bold font-heading text-slate-900">
                    Subscription Confirmed!
                  </h4>
                  <p className="text-sm text-slate-600 max-w-sm mx-auto">
                    {orderConfirmedData.message}
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-teal-50 border border-teal-100 text-xs text-left space-y-1.5 font-medium text-slate-700">
                  <p><strong>Order ID:</strong> {orderConfirmedData.orderId}</p>
                  <p><strong>Mess:</strong> {orderConfirmedData.messName}</p>
                  <p><strong>Plan:</strong> {orderConfirmedData.planTitle}</p>
                  <p><strong>Amount:</strong> ₹{orderConfirmedData.amount}</p>
                  <p><strong>Estimated Delivery:</strong> {orderConfirmedData.deliveryTimeEstimate}</p>
                </div>

                <button
                  onClick={() => setOrderModalOpen(false)}
                  className="w-full py-3 font-bold rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs transition-colors"
                >
                  Done
                </button>
              </div>
            ) : (
              <form onSubmit={handleConfirmOrder} className="space-y-4 text-xs">
                <div className="p-3.5 rounded-2xl bg-teal-50 border border-teal-100 flex items-center gap-3">
                  <div>
                    <h4 className="font-bold text-sm text-slate-900">{selectedMess.name}</h4>
                    <p className="text-slate-600">{selectedMess.locality}, {selectedMess.city}</p>
                    <p className="text-teal-700 font-semibold">{selectedMess.phone}</p>
                  </div>
                </div>

                {/* Type Selection */}
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setOrderType('monthly_plan')}
                    className={`p-3 rounded-xl border text-center transition-all ${
                      orderType === 'monthly_plan'
                        ? 'border-teal-500 bg-teal-50 text-teal-900 font-bold'
                        : 'border-slate-200 bg-slate-50 text-slate-700'
                    }`}
                  >
                    Monthly Subscription
                  </button>
                  <button
                    type="button"
                    onClick={() => setOrderType('single_trial')}
                    className={`p-3 rounded-xl border text-center transition-all ${
                      orderType === 'single_trial'
                        ? 'border-teal-500 bg-teal-50 text-teal-900 font-bold'
                        : 'border-slate-200 bg-slate-50 text-slate-700'
                    }`}
                  >
                    1-Day Trial Meal (₹{selectedMess.singleMealPrice})
                  </button>
                </div>

                {orderType === 'monthly_plan' && selectedMess.mealPlans && (
                  <div className="space-y-1.5">
                    <label className="font-bold text-slate-700">Choose Meal Plan</label>
                    <div className="space-y-2">
                      {selectedMess.mealPlans.map((plan) => (
                        <label
                          key={plan.id}
                          className={`flex items-start justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                            selectedPlanId === plan.id
                              ? 'border-teal-500 bg-teal-50'
                              : 'border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          <div className="flex items-start gap-2">
                            <input
                              type="radio"
                              name="mealPlan"
                              checked={selectedPlanId === plan.id}
                              onChange={() => setSelectedPlanId(plan.id)}
                              className="mt-0.5 text-teal-600 focus:ring-teal-500"
                            />
                            <div>
                              <p className="font-bold text-slate-900">{plan.title}</p>
                              <p className="text-[11px] text-slate-500">{plan.description}</p>
                            </div>
                          </div>
                          <span className="font-bold text-teal-700 shrink-0 ml-2">₹{plan.pricePerMonth}/mo</span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="font-bold text-slate-700">Student Name</label>
                    <input
                      type="text"
                      value={studentName}
                      onChange={(e) => setStudentName(e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500 font-medium"
                      required
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="font-bold text-slate-700">Phone Number</label>
                    <input
                      type="tel"
                      value={studentPhone}
                      onChange={(e) => setStudentPhone(e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500 font-medium"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Hostel / PG Delivery Address</label>
                  <input
                    type="text"
                    value={deliveryAddress}
                    onChange={(e) => setDeliveryAddress(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500 font-medium"
                    required
                  />
                </div>

                <div className="pt-2 flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setOrderModalOpen(false)}
                    className="flex-1 py-3 font-bold rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={orderLoading}
                    className="flex-1 py-3 font-bold rounded-xl bg-gradient-to-r from-teal-600 to-sky-600 hover:from-teal-700 hover:to-sky-700 text-white shadow-md transition-all disabled:opacity-50"
                  >
                    {orderLoading ? 'Processing...' : 'Confirm Subscription'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
