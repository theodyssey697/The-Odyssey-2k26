import React, { useState, useEffect } from 'react';
import { 
  UserCheck, 
  Calendar, 
  Lock, 
  Heart, 
  Bell, 
  Building, 
  MapPin, 
  Clock, 
  Phone, 
  ExternalLink, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles,
  Trash2,
  Play,
  Pause
} from 'lucide-react';
import { VisitRequest, Booking, VacancyWatch, Property } from '../types';

interface DashboardViewProps {
  onSelectProperty: (prop: Property) => void;
  onNavigateToTab: (tab: string) => void;
  onDeployWatch: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onSelectProperty,
  onNavigateToTab,
  onDeployWatch
}) => {
  const [visits, setVisits] = useState<VisitRequest[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [watches, setWatches] = useState<VacancyWatch[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const [vRes, bRes, wRes] = await Promise.all([
        fetch('/api/visits'),
        fetch('/api/bookings'),
        fetch('/api/vacancy-watches')
      ]);
      const [vData, bData, wData] = await Promise.all([
        vRes.json(),
        bRes.json(),
        wRes.json()
      ]);
      setVisits(vData || []);
      setBookings(bData || []);
      setWatches(wData || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const handleToggleWatch = async (id: string) => {
    try {
      await fetch(`/api/vacancy-watches/${id}/toggle`, { method: 'PATCH' });
      fetchDashboardData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteWatch = async (id: string) => {
    try {
      await fetch(`/api/vacancy-watches/${id}`, { method: 'DELETE' });
      fetchDashboardData();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 font-sans relative">
      
      {/* Floating Particles Animation */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-2xl">
        {[...Array(10)].map((_, i) => {
          const size = Math.random() * 6 + 4;
          const top = Math.random() * 100;
          const left = Math.random() * 100;
          const duration = Math.random() * 6 + 6;
          const delay = Math.random() * 3;
          return (
            <div
              key={i}
              className="particle bg-rose-500/20"
              style={{
                width: `${size}px`,
                height: `${size}px`,
                top: `${top}%`,
                left: `${left}%`,
                animationDuration: `${duration}s`,
                animationDelay: `${delay}s`,
              }}
            />
          );
        })}
      </div>

      <div className="p-6 rounded-2xl bg-gradient-to-r from-[#24040c] via-[#5c1023] to-[#24040c] text-white border border-[#be123c]/50 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center font-bold text-xl text-amber-400 font-heading">
            AS
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-extrabold font-heading text-white">
                Aryan Sharma
              </h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-400 text-slate-950">
                Verified Student
              </span>
            </div>
            <p className="text-xs text-rose-200 mt-0.5">
              KIIT Deemed to be University, Bhubaneswar • Roll #2205101
            </p>
            <p className="text-[11px] text-rose-300">
              Target locality: <strong className="text-white">Patia / Infocity</strong> • Budget cap: <strong className="text-amber-300">₹4,000/month</strong>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          <button
            onClick={() => onNavigateToTab('concierge')}
            className="flex-1 md:flex-none px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition-all flex items-center justify-center gap-1.5"
          >
            <Sparkles className="w-4 h-4" />
            <span>Launch AI Concierge</span>
          </button>
          <button
            onClick={onDeployWatch}
            className="flex-1 md:flex-none px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition-all flex items-center justify-center gap-1.5"
          >
            <Bell className="w-4 h-4" />
            <span>Set Vacancy Watch</span>
          </button>
        </div>
      </div>

      {/* Grid: Scheduled Visits & Active Bookings */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Scheduled Property Visits */}
        <div className="p-5 rounded-2xl bg-[#26050e]/95 border border-[#881337]/60 shadow-xl space-y-4 text-rose-100">
          <div className="flex items-center justify-between pb-2 border-b border-[#881337]/40">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-emerald-400" />
              <h2 className="text-sm font-bold text-white font-heading">
                Scheduled Property Visits ({visits.length})
              </h2>
            </div>
            <span className="text-[11px] text-rose-300/80">Host coordination logged</span>
          </div>

          {visits.length === 0 ? (
            <p className="text-xs text-rose-300/70 py-4 text-center">No scheduled visits yet.</p>
          ) : (
            <div className="space-y-3">
              {visits.map((vis) => (
                <div key={vis.id} className="p-3.5 rounded-xl bg-[#360714]/90 border border-[#9f1239]/50 text-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white font-heading">
                      {vis.propertyTitle}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800/60">
                      Host Confirmed
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-rose-200 text-[11px]">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-rose-400" />
                      {vis.requestedTimeSlot} ({vis.requestedDate})
                    </span>
                    <span className="text-rose-300">{vis.propertyLocality}</span>
                  </div>

                  {vis.notes && (
                    <p className="text-[11px] text-rose-200 bg-[#22040b] p-2 rounded-lg border border-[#881337]/40">
                      <strong className="text-amber-300">Host Note:</strong> {vis.notes}
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Accommodation Bookings & Escrow Passes */}
        <div className="p-5 rounded-2xl bg-[#26050e]/95 border border-[#881337]/60 shadow-xl space-y-4 text-rose-100">
          <div className="flex items-center justify-between pb-2 border-b border-[#881337]/40">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-amber-400" />
              <h2 className="text-sm font-bold text-white font-heading">
                Escrow Bookings & Stay Passes ({bookings.length})
              </h2>
            </div>
            <span className="text-[11px] text-rose-300/80">Protected deposits</span>
          </div>

          {bookings.length === 0 ? (
            <p className="text-xs text-rose-300/70 py-4 text-center">No active bookings.</p>
          ) : (
            <div className="space-y-3">
              {bookings.map((bk) => (
                <div key={bk.id} className="p-3.5 rounded-xl bg-[#360714]/90 border border-[#9f1239]/50 text-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white font-heading">
                      {bk.propertyTitle}
                    </span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      bk.bookingStatus === 'confirmed'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/60'
                        : 'bg-amber-950 text-amber-300 border border-amber-800/60'
                    }`}>
                      {bk.bookingStatus.replace(/_/g, ' ').toUpperCase()}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-rose-200 text-[11px] font-mono">
                    <span>Deposit: ₹{bk.totalInitialPayable.toLocaleString('en-IN')}</span>
                    <span>Move-In: {bk.moveInDate}</span>
                  </div>

                  {bk.paymentTransactionId && (
                    <div className="text-[10px] font-mono text-emerald-300 flex items-center justify-between">
                      <span>Receipt: {bk.paymentTransactionId}</span>
                      <span className="font-bold text-amber-300">Roomora Stay Pass Active</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

      </div>

      {/* Section 7 Vacancy Watch Agent Background Monitors */}
      <div className="p-5 rounded-2xl bg-[#26050e]/95 border border-[#881337]/60 shadow-xl space-y-4 text-rose-100">
        <div className="flex items-center justify-between pb-2 border-b border-[#881337]/40">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-rose-400" />
            <div>
              <h2 className="text-sm font-bold text-white font-heading">
                Active Vacancy Watch Monitors ({watches.length})
              </h2>
              <p className="text-[11px] text-rose-300/80">
                Autonomous background agents scanning Patia accommodation feeds
              </p>
            </div>
          </div>
          <button
            onClick={onDeployWatch}
            className="px-3 py-1.5 rounded-lg bg-[#be123c] hover:bg-[#9f1239] text-white font-bold text-xs shadow-md transition-colors"
          >
            + New Monitor
          </button>
        </div>

        {watches.length === 0 ? (
          <p className="text-xs text-rose-300/70 py-4 text-center">No active vacancy monitors configured.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            {watches.map((w) => (
              <div key={w.id} className="p-3.5 rounded-xl bg-[#360714]/90 border border-[#9f1239]/50 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 font-bold text-white font-heading">
                    <span>{w.locality}</span>
                    <span>•</span>
                    <span className="text-amber-300 font-mono">Under ₹{w.maxMonthlyRent}/mo</span>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    w.active ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/60' : 'bg-rose-950 text-rose-300 border border-rose-800/60'
                  }`}>
                    {w.active ? 'Scanning Live' : 'Paused'}
                  </span>
                </div>

                <p className="text-rose-200 text-[11px]">
                  Room: {w.roomType.replace(/_/g, ' ')} • Frequency: {w.notificationFrequency}
                </p>

                <div className="flex items-center justify-between pt-1 border-t border-[#881337]/40 text-[10px] text-rose-300/70">
                  <span>Last checked: {new Date(w.lastCheckedAt).toLocaleTimeString()}</span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleToggleWatch(w.id)}
                      className="text-amber-400 hover:text-amber-300 hover:underline font-bold"
                    >
                      {w.active ? 'Pause' : 'Resume'}
                    </button>
                    <button
                      onClick={() => handleDeleteWatch(w.id)}
                      className="text-red-400 hover:text-red-300"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
