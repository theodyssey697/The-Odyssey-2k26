import React, { useState, useEffect } from 'react';
import { 
  CookingPot, 
  Clock, 
  MapPin, 
  Phone, 
  Calendar, 
  IndianRupee, 
  CheckCircle2, 
  AlertCircle, 
  Plus, 
  Trash2, 
  Save, 
  RefreshCw, 
  ArrowLeft, 
  LogOut, 
  ShieldCheck, 
  Users, 
  ShoppingBag, 
  Truck, 
  Utensils, 
  ExternalLink,
  Sparkles,
  Edit3
} from 'lucide-react';
import { MessService, MessOrder } from '../types';

interface MessAdminDashboardViewProps {
  messId: string;
  adminEmail: string;
  onBackToExplore: () => void;
  onLogout: () => void;
  onMessUpdated?: () => void;
}

export const MessAdminDashboardView: React.FC<MessAdminDashboardViewProps> = ({
  messId,
  adminEmail,
  onBackToExplore,
  onLogout,
  onMessUpdated
}) => {
  const [activeTab, setActiveTab] = useState<'orders' | 'menu' | 'pricing' | 'profile' | 'preview'>('orders');
  const [mess, setMess] = useState<MessService | null>(null);
  const [orders, setOrders] = useState<MessOrder[]>([]);
  const [ownership, setOwnership] = useState<any | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Editable Form States
  const [messName, setMessName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [address, setAddress] = useState<string>('');
  const [operatingHours, setOperatingHours] = useState<string>('');
  const [monthlyPrice, setMonthlyPrice] = useState<number>(2400);
  const [singleMealPrice, setSingleMealPrice] = useState<number>(65);
  const [foodType, setFoodType] = useState<'pure_veg' | 'non_veg' | 'veg_and_nonveg'>('veg_and_nonveg');
  const [deliveryAvailable, setDeliveryAvailable] = useState<boolean>(true);
  const [mealPlans, setMealPlans] = useState<any[]>([]);
  const [sampleMenu, setSampleMenu] = useState<{ day: string; lunch: string; dinner: string }[]>([]);

  // Load mess details and orders from backend
  const fetchMessData = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetch(`/api/mess-admin/${messId}`);
      if (!res.ok) {
        throw new Error('Could not load mess details. Please verify your administrator authorization.');
      }
      const data = await res.json();
      setMess(data.mess);
      setOrders(data.orders || []);
      setOwnership(data.ownership);

      // Populate editable fields
      if (data.mess) {
        setMessName(data.mess.name || '');
        setPhone(data.mess.phone || '');
        setAddress(data.mess.address || '');
        setOperatingHours(data.mess.operatingHours || '7:00 AM - 10:30 PM');
        setMonthlyPrice(data.mess.monthlyPrice || 2400);
        setSingleMealPrice(data.mess.singleMealPrice || 65);
        setFoodType(data.mess.foodType || 'veg_and_nonveg');
        setDeliveryAvailable(data.mess.deliveryAvailable ?? true);
        setMealPlans(data.mess.mealPlans || []);
        setSampleMenu(data.mess.sampleMenu || []);
      }
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Error loading mess dashboard.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMessData();
  }, [messId]);

  const notifySaved = (msg: string) => {
    setSaveSuccessMsg(msg);
    setTimeout(() => {
      setSaveSuccessMsg(null);
    }, 4000);
  };

  // Save changes to backend database
  const handleSaveChanges = async (customPayload?: Partial<MessService>) => {
    setSaving(true);
    setErrorMsg(null);
    try {
      const payload: Partial<MessService> = {
        name: messName,
        phone,
        address,
        operatingHours,
        monthlyPrice: Number(monthlyPrice),
        singleMealPrice: Number(singleMealPrice),
        foodType,
        deliveryAvailable,
        mealPlans,
        sampleMenu,
        ...customPayload
      };

      const res = await fetch(`/api/mess-admin/${messId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const resData = await res.json();
      if (!res.ok) {
        throw new Error(resData.error || 'Failed to update mess in database');
      }

      setMess(resData.mess);
      notifySaved('Changes saved to Roomora persistent database & updated on student-facing listings!');
      if (onMessUpdated) onMessUpdated();
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Error saving changes to database.');
    } finally {
      setSaving(false);
    }
  };

  // Update order status
  const handleUpdateOrderStatus = async (orderId: string, newStatus: string, adminNotes?: string) => {
    try {
      const res = await fetch(`/api/mess-admin/${messId}/orders/${orderId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus, adminNotes })
      });
      const data = await res.json();
      if (res.ok) {
        setOrders(prev => prev.map(o => o.orderId === orderId ? { ...o, status: newStatus as any, adminNotes: adminNotes ?? o.adminNotes } : o));
        notifySaved(`Order #${orderId.slice(-6)} updated to ${newStatus.replace(/_/g, ' ')}`);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Menu item helper
  const handleMenuChange = (dayIndex: number, field: 'lunch' | 'dinner', value: string) => {
    const updated = [...sampleMenu];
    updated[dayIndex] = { ...updated[dayIndex], [field]: value };
    setSampleMenu(updated);
  };

  // Meal Plan helper
  const handlePlanChange = (planIndex: number, field: string, value: any) => {
    const updated = [...mealPlans];
    updated[planIndex] = { ...updated[planIndex], [field]: value };
    setMealPlans(updated);
  };

  const handleAddPlan = () => {
    const newPlan = {
      id: `plan-${Date.now()}`,
      title: 'New Student Meal Plan',
      description: 'Unlimited Rice, Roti, Dal, Sabzi with daily salad.',
      mealsPerDay: 2,
      pricePerMonth: 2500,
      includesBreakfast: false
    };
    setMealPlans([...mealPlans, newPlan]);
  };

  const handleRemovePlan = (idx: number) => {
    setMealPlans(mealPlans.filter((_, i) => i !== idx));
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#24050d] text-rose-100 flex items-center justify-center p-6">
        <div className="text-center space-y-4">
          <div className="w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <h2 className="text-xl font-bold font-heading">Authorizing Mess Administrator...</h2>
          <p className="text-xs text-rose-300">Checking credentials against Roomora Security Gateway</p>
        </div>
      </div>
    );
  }

  const activeOrdersCount = orders.filter(o => o.status !== 'delivered' && o.status !== 'cancelled').length;

  return (
    <div className="min-h-screen bg-[#24050d] text-rose-100 font-sans pb-16">
      
      {/* Top Banner Navigation */}
      <header className="bg-[#180309] border-b border-rose-900/60 sticky top-0 z-30 shadow-xl backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
          
          <div className="flex items-center gap-3">
            <button
              onClick={onBackToExplore}
              className="px-3 py-1.5 rounded-xl bg-rose-950/80 hover:bg-rose-900 border border-rose-800/60 text-xs font-bold text-rose-200 hover:text-white flex items-center gap-1.5 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Explore Stays</span>
            </button>

            <div className="h-6 w-px bg-rose-900/60 hidden sm:block" />

            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 flex items-center justify-center font-bold">
                <CookingPot className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-base sm:text-lg font-black text-white font-heading truncate max-w-xs sm:max-w-md">
                    {messName || mess?.name}
                  </h1>
                  <span className="hidden md:inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                    <ShieldCheck className="w-3 h-3" />
                    Authorized Mess
                  </span>
                </div>
                <div className="text-[11px] text-rose-300/80 truncate max-w-xs sm:max-w-md">
                  Admin: <strong className="text-amber-300 font-mono">{adminEmail}</strong> • Assigned Mess Clearance
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={fetchMessData}
              title="Refresh Live Data"
              className="p-2 rounded-xl bg-rose-950/80 hover:bg-rose-900 border border-rose-900/60 text-rose-300 hover:text-white transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            <button
              onClick={onLogout}
              className="px-3.5 py-1.5 rounded-xl bg-rose-900/60 hover:bg-rose-800 text-rose-100 hover:text-white border border-rose-700/60 text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out</span>
            </button>
          </div>

        </div>
      </header>

      {/* Main Content Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        
        {/* Success / Error notification */}
        {saveSuccessMsg && (
          <div className="p-3.5 rounded-2xl bg-emerald-950/80 border border-emerald-500 text-xs text-emerald-200 flex items-center gap-2 shadow-lg animate-in slide-in-from-top">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="font-semibold">{saveSuccessMsg}</span>
          </div>
        )}

        {errorMsg && (
          <div className="p-3.5 rounded-2xl bg-red-950/80 border border-red-500 text-xs text-red-200 flex items-center gap-2 shadow-lg animate-in slide-in-from-top">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span className="font-semibold">{errorMsg}</span>
          </div>
        )}

        {/* Quick Metrics Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
          <div className="p-4 rounded-2xl bg-[#1c040b] border border-rose-900/60 shadow-md">
            <div className="flex items-center justify-between text-rose-400 text-xs">
              <span>Active Orders</span>
              <ShoppingBag className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-black text-white mt-1.5 font-heading">
              {activeOrdersCount}
            </div>
            <div className="text-[11px] text-rose-300/70 mt-0.5">
              {orders.length} total recorded
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-[#1c040b] border border-rose-900/60 shadow-md">
            <div className="flex items-center justify-between text-rose-400 text-xs">
              <span>Monthly Package</span>
              <IndianRupee className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-black text-white mt-1.5 font-heading">
              ₹{monthlyPrice}
            </div>
            <div className="text-[11px] text-rose-300/70 mt-0.5">
              Standard student price
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-[#1c040b] border border-rose-900/60 shadow-md">
            <div className="flex items-center justify-between text-rose-400 text-xs">
              <span>Trial / Thali Rate</span>
              <Utensils className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-black text-white mt-1.5 font-heading">
              ₹{singleMealPrice}
            </div>
            <div className="text-[11px] text-rose-300/70 mt-0.5">
              Single meal price
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-[#1c040b] border border-rose-900/60 shadow-md">
            <div className="flex items-center justify-between text-rose-400 text-xs">
              <span>Delivery Status</span>
              <Truck className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-sm font-black text-emerald-300 mt-2 font-heading flex items-center gap-1.5">
              <span className={`w-2.5 h-2.5 rounded-full ${deliveryAvailable ? 'bg-emerald-400 animate-pulse' : 'bg-red-400'}`} />
              <span>{deliveryAvailable ? 'Campus Delivery Active' : 'Dine-In Only'}</span>
            </div>
            <div className="text-[11px] text-rose-300/70 mt-0.5 truncate">
              {operatingHours}
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap items-center gap-2 border-b border-rose-900/60 pb-2">
          <button
            onClick={() => setActiveTab('orders')}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all ${
              activeTab === 'orders'
                ? 'bg-gradient-to-r from-amber-500 to-rose-600 text-slate-950 shadow-md font-black'
                : 'bg-rose-950/60 hover:bg-rose-900/60 text-rose-200'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Live Food Orders & Reservations ({orders.length})</span>
            {activeOrdersCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-slate-950 text-amber-300 text-[10px] font-black flex items-center justify-center">
                {activeOrdersCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('menu')}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all ${
              activeTab === 'menu'
                ? 'bg-gradient-to-r from-amber-500 to-rose-600 text-slate-950 shadow-md font-black'
                : 'bg-rose-950/60 hover:bg-rose-900/60 text-rose-200'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>Weekly Menu Schedule</span>
          </button>

          <button
            onClick={() => setActiveTab('pricing')}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all ${
              activeTab === 'pricing'
                ? 'bg-gradient-to-r from-amber-500 to-rose-600 text-slate-950 shadow-md font-black'
                : 'bg-rose-950/60 hover:bg-rose-900/60 text-rose-200'
            }`}
          >
            <IndianRupee className="w-4 h-4" />
            <span>Meal Plans & Pricing</span>
          </button>

          <button
            onClick={() => setActiveTab('profile')}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all ${
              activeTab === 'profile'
                ? 'bg-gradient-to-r from-amber-500 to-rose-600 text-slate-950 shadow-md font-black'
                : 'bg-rose-950/60 hover:bg-rose-900/60 text-rose-200'
            }`}
          >
            <Edit3 className="w-4 h-4" />
            <span>Mess Information & Availability</span>
          </button>

          <button
            onClick={() => setActiveTab('preview')}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all ${
              activeTab === 'preview'
                ? 'bg-gradient-to-r from-amber-500 to-rose-600 text-slate-950 shadow-md font-black'
                : 'bg-rose-950/60 hover:bg-rose-900/60 text-rose-200'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Student View Preview</span>
          </button>
        </div>

        {/* TAB 1: LIVE ORDERS & RESERVATIONS */}
        {activeTab === 'orders' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
              <div>
                <h2 className="text-lg font-black text-white font-heading">
                  Student Orders & Tiffin Subscriptions
                </h2>
                <p className="text-xs text-rose-300/80">
                  Manage incoming student food orders, update delivery status, and respond to special dietary requests.
                </p>
              </div>
              <div className="text-xs font-semibold text-rose-300">
                Total: <strong className="text-amber-300">{orders.length} orders</strong>
              </div>
            </div>

            {orders.length === 0 ? (
              <div className="p-8 rounded-3xl bg-[#1c040b] border border-rose-900/60 text-center space-y-3">
                <Utensils className="w-10 h-10 text-rose-400 mx-auto opacity-50" />
                <h3 className="text-base font-bold text-white">No Student Orders Placed Yet</h3>
                <p className="text-xs text-rose-300/80 max-w-md mx-auto">
                  When students order meal plans or trial thalis from the Mess portal, orders will appear here in real-time.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-3.5">
                {orders.map((order) => {
                  return (
                    <div
                      key={order.orderId}
                      className="p-5 rounded-2xl bg-[#1c040b] border border-rose-900/60 shadow-lg space-y-3"
                    >
                      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-rose-900/40 pb-2.5">
                        <div className="flex items-center gap-2.5">
                          <span className="font-mono text-xs font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-lg border border-amber-500/20">
                            #{order.orderId.slice(-8)}
                          </span>
                          <span className="font-bold text-white text-sm">
                            {order.studentName}
                          </span>
                          <span className="text-xs text-rose-300">
                            ({order.phone})
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-amber-300 bg-black/40 px-2.5 py-1 rounded-lg border border-rose-900">
                            ₹{order.amount} ({order.orderType === 'monthly_plan' ? 'Monthly Plan' : 'Single Trial'})
                          </span>

                          <select
                            value={order.status}
                            onChange={(e) => handleUpdateOrderStatus(order.orderId, e.target.value)}
                            className="bg-[#2a0712] border border-rose-700 text-xs font-bold text-amber-200 rounded-xl px-2.5 py-1 outline-hidden"
                          >
                            <option value="order_confirmed">Confirmed</option>
                            <option value="preparing">Preparing</option>
                            <option value="out_for_delivery">Out for Delivery</option>
                            <option value="delivered">Delivered</option>
                            <option value="cancelled">Cancelled</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                        <div>
                          <span className="text-rose-400 block font-semibold text-[11px]">Selected Meal Plan:</span>
                          <span className="font-bold text-white">{order.planTitle}</span>
                        </div>
                        <div>
                          <span className="text-rose-400 block font-semibold text-[11px]">Hostel / Delivery Address:</span>
                          <span className="text-rose-200">{order.deliveryAddress}</span>
                        </div>
                        <div>
                          <span className="text-rose-400 block font-semibold text-[11px]">Timestamp:</span>
                          <span className="text-rose-300 font-mono text-[11px]">
                            {new Date(order.createdAt).toLocaleString()}
                          </span>
                        </div>
                      </div>

                      {order.specialNotes && (
                        <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200 flex items-start gap-2">
                          <span className="font-bold text-amber-400 shrink-0">Student Special Request:</span>
                          <span>"{order.specialNotes}"</span>
                        </div>
                      )}

                      {/* Admin Notes & Quick actions */}
                      <div className="flex flex-col sm:flex-row items-center gap-2 pt-1 border-t border-rose-900/30">
                        <input
                          type="text"
                          defaultValue={order.adminNotes || ''}
                          placeholder="Admin note / ETA (e.g., 'Arriving in 25 min with boy Raju')"
                          onBlur={(e) => {
                            if (e.target.value !== order.adminNotes) {
                              handleUpdateOrderStatus(order.orderId, order.status, e.target.value);
                            }
                          }}
                          className="w-full sm:flex-1 p-2 rounded-xl bg-[#120207] border border-rose-900 text-xs text-rose-200 placeholder:text-rose-500 outline-hidden"
                        />
                        <button
                          type="button"
                          onClick={() => handleUpdateOrderStatus(order.orderId, 'delivered')}
                          className="w-full sm:w-auto px-3 py-2 rounded-xl bg-emerald-600/80 hover:bg-emerald-600 text-white font-bold text-xs flex items-center justify-center gap-1 transition-colors"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Mark Delivered</span>
                        </button>
                      </div>

                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: WEEKLY MENU MANAGEMENT */}
        {activeTab === 'menu' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-black text-white font-heading">
                  Weekly Menu Schedule (Monday - Sunday)
                </h2>
                <p className="text-xs text-rose-300/80">
                  Update your daily lunch and dinner items. Changes reflect instantly on the student mess page and stay cards.
                </p>
              </div>

              <button
                onClick={() => handleSaveChanges({ sampleMenu })}
                disabled={saving}
                className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs flex items-center gap-2 shadow-lg transition-all disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                <span>{saving ? 'Saving Menu...' : 'Save Weekly Menu to Database'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {sampleMenu.map((item, idx) => (
                <div
                  key={item.day}
                  className="p-4 rounded-2xl bg-[#1c040b] border border-rose-900/60 shadow-md space-y-3"
                >
                  <div className="flex items-center justify-between border-b border-rose-900/40 pb-2">
                    <span className="font-black text-amber-300 text-sm font-heading flex items-center gap-1.5">
                      <Calendar className="w-4 h-4" />
                      <span>{item.day}</span>
                    </span>
                    <span className="text-[10px] uppercase tracking-wider text-rose-400 font-bold">
                      Day {idx + 1}
                    </span>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div>
                      <label className="font-semibold text-rose-300 block mb-1">Lunch Dishes:</label>
                      <textarea
                        rows={2}
                        value={item.lunch}
                        onChange={(e) => handleMenuChange(idx, 'lunch', e.target.value)}
                        placeholder="Rice, Roti, Dal, Sabzi, Salad..."
                        className="w-full p-2.5 rounded-xl bg-[#120207] border border-rose-800 text-rose-100 text-xs focus:ring-1 focus:ring-amber-500 outline-hidden"
                      />
                    </div>

                    <div>
                      <label className="font-semibold text-rose-300 block mb-1">Dinner Dishes:</label>
                      <textarea
                        rows={2}
                        value={item.dinner}
                        onChange={(e) => handleMenuChange(idx, 'dinner', e.target.value)}
                        placeholder="Roti, Paneer/Chicken, Dal Tadka, Sweet..."
                        className="w-full p-2.5 rounded-xl bg-[#120207] border border-rose-800 text-rose-100 text-xs focus:ring-1 focus:ring-amber-500 outline-hidden"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="text-right pt-2">
              <button
                onClick={() => handleSaveChanges({ sampleMenu })}
                disabled={saving}
                className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs inline-flex items-center gap-2 shadow-lg transition-all disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                <span>{saving ? 'Saving...' : 'Save Weekly Menu to Database'}</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 3: MEAL PLANS & PRICING */}
        {activeTab === 'pricing' && (
          <div className="space-y-5">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-black text-white font-heading">
                  Student Meal Plans & Rates
                </h2>
                <p className="text-xs text-rose-300/80">
                  Configure packages (e.g. 2 meals daily, 3 meals full board) and individual trial meal rates.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleAddPlan}
                  className="px-3 py-2 rounded-xl bg-rose-900/60 hover:bg-rose-800 text-rose-200 border border-rose-700 text-xs font-bold flex items-center gap-1.5 transition-colors"
                >
                  <Plus className="w-4 h-4 text-amber-400" />
                  <span>Add Meal Plan</span>
                </button>

                <button
                  onClick={() => handleSaveChanges({ mealPlans, monthlyPrice, singleMealPrice })}
                  disabled={saving}
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs flex items-center gap-2 shadow-lg transition-all disabled:opacity-50"
                >
                  <Save className="w-4 h-4" />
                  <span>{saving ? 'Saving...' : 'Save Plans to Database'}</span>
                </button>
              </div>
            </div>

            {/* General Price Overview */}
            <div className="p-4 rounded-2xl bg-[#1c040b] border border-rose-900/60 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="font-semibold text-rose-200 block text-xs mb-1">
                  Primary Monthly Subscription Rate (₹/month)
                </label>
                <div className="relative">
                  <IndianRupee className="w-4 h-4 text-amber-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="number"
                    value={monthlyPrice}
                    onChange={(e) => setMonthlyPrice(Number(e.target.value))}
                    className="w-full p-2.5 pl-9 rounded-xl bg-[#120207] border border-rose-800 text-white font-bold text-xs focus:ring-1 focus:ring-amber-500 outline-hidden font-mono"
                  />
                </div>
                <span className="text-[10px] text-rose-400 mt-1 block">
                  Displayed as starting price on Explore Stays and Search listings.
                </span>
              </div>

              <div>
                <label className="font-semibold text-rose-200 block text-xs mb-1">
                  Single Trial Thali / One-Off Rate (₹/meal)
                </label>
                <div className="relative">
                  <IndianRupee className="w-4 h-4 text-amber-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="number"
                    value={singleMealPrice}
                    onChange={(e) => setSingleMealPrice(Number(e.target.value))}
                    className="w-full p-2.5 pl-9 rounded-xl bg-[#120207] border border-rose-800 text-white font-bold text-xs focus:ring-1 focus:ring-amber-500 outline-hidden font-mono"
                  />
                </div>
                <span className="text-[10px] text-rose-400 mt-1 block">
                  Price charged when students select "Single Trial Meal" option.
                </span>
              </div>
            </div>

            {/* Individual Plans List */}
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-white font-heading">
                Active Meal Packages ({mealPlans.length})
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {mealPlans.map((plan, idx) => (
                  <div
                    key={plan.id || idx}
                    className="p-4 rounded-2xl bg-[#1c040b] border border-rose-900/60 shadow-md space-y-3 relative"
                  >
                    <div className="flex items-center justify-between border-b border-rose-900/40 pb-2">
                      <span className="text-xs font-black text-amber-300 font-heading">
                        Plan #{idx + 1}
                      </span>
                      <button
                        onClick={() => handleRemovePlan(idx)}
                        className="text-red-400 hover:text-red-300 p-1 rounded-lg hover:bg-red-950/50"
                        title="Remove plan"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="space-y-2 text-xs">
                      <div>
                        <label className="font-semibold text-rose-300 block mb-1">Plan Title:</label>
                        <input
                          type="text"
                          value={plan.title}
                          onChange={(e) => handlePlanChange(idx, 'title', e.target.value)}
                          className="w-full p-2 rounded-xl bg-[#120207] border border-rose-800 text-white text-xs outline-hidden"
                        />
                      </div>

                      <div>
                        <label className="font-semibold text-rose-300 block mb-1">Description & Items:</label>
                        <textarea
                          rows={2}
                          value={plan.description}
                          onChange={(e) => handlePlanChange(idx, 'description', e.target.value)}
                          className="w-full p-2 rounded-xl bg-[#120207] border border-rose-800 text-rose-100 text-xs outline-hidden"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="font-semibold text-rose-300 block mb-1">Monthly Price (₹):</label>
                          <input
                            type="number"
                            value={plan.pricePerMonth}
                            onChange={(e) => handlePlanChange(idx, 'pricePerMonth', Number(e.target.value))}
                            className="w-full p-2 rounded-xl bg-[#120207] border border-rose-800 text-amber-300 font-bold text-xs outline-hidden font-mono"
                          />
                        </div>

                        <div>
                          <label className="font-semibold text-rose-300 block mb-1">Meals Per Day:</label>
                          <select
                            value={plan.mealsPerDay}
                            onChange={(e) => handlePlanChange(idx, 'mealsPerDay', Number(e.target.value))}
                            className="w-full p-2 rounded-xl bg-[#120207] border border-rose-800 text-rose-100 text-xs outline-hidden"
                          >
                            <option value={1}>1 Meal Daily</option>
                            <option value={2}>2 Meals (Lunch + Dinner)</option>
                            <option value={3}>3 Meals (Breakfast + Lunch + Dinner)</option>
                          </select>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 pt-1">
                        <input
                          type="checkbox"
                          id={`bf-${idx}`}
                          checked={Boolean(plan.includesBreakfast)}
                          onChange={(e) => handlePlanChange(idx, 'includesBreakfast', e.target.checked)}
                          className="rounded border-rose-700 text-amber-500"
                        />
                        <label htmlFor={`bf-${idx}`} className="text-rose-200 text-xs font-semibold cursor-pointer">
                          Includes Morning Student Breakfast
                        </label>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="text-right pt-2">
              <button
                onClick={() => handleSaveChanges({ mealPlans, monthlyPrice, singleMealPrice })}
                disabled={saving}
                className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs inline-flex items-center gap-2 shadow-lg transition-all disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                <span>{saving ? 'Saving...' : 'Save Meal Plans & Pricing to Database'}</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 4: MESS PROFILE & AVAILABILITY */}
        {activeTab === 'profile' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-black text-white font-heading">
                  Mess Information & Operating Specs
                </h2>
                <p className="text-xs text-rose-300/80">
                  Update location, contact details, operating hours, and kitchen dietary classification.
                </p>
              </div>

              <button
                onClick={() => handleSaveChanges()}
                disabled={saving}
                className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs flex items-center gap-2 shadow-lg transition-all disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                <span>{saving ? 'Saving Profile...' : 'Save Profile to Database'}</span>
              </button>
            </div>

            <div className="p-6 rounded-3xl bg-[#1c040b] border border-rose-900/60 shadow-xl space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="font-semibold text-rose-200 block mb-1">Mess Name</label>
                  <input
                    type="text"
                    value={messName}
                    onChange={(e) => setMessName(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-[#120207] border border-rose-800 text-white font-bold text-xs outline-hidden"
                  />
                  <span className="text-[10px] text-rose-400 mt-1 block">
                    This name will appear on both Explore Stays and Mess cards.
                  </span>
                </div>

                <div>
                  <label className="font-semibold text-rose-200 block mb-1">Direct Provider Phone</label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-[#120207] border border-rose-800 text-amber-300 font-mono text-xs outline-hidden"
                  />
                  <span className="text-[10px] text-rose-400 mt-1 block">
                    Used for student phone calls & WhatsApp ordering alerts.
                  </span>
                </div>

                <div className="sm:col-span-2">
                  <label className="font-semibold text-rose-200 block mb-1">Physical Kitchen Address</label>
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-[#120207] border border-rose-800 text-white text-xs outline-hidden"
                  />
                </div>

                <div>
                  <label className="font-semibold text-rose-200 block mb-1">Operating Hours</label>
                  <input
                    type="text"
                    value={operatingHours}
                    onChange={(e) => setOperatingHours(e.target.value)}
                    placeholder="e.g. 7:00 AM - 10:30 PM"
                    className="w-full p-2.5 rounded-xl bg-[#120207] border border-rose-800 text-white text-xs outline-hidden"
                  />
                </div>

                <div>
                  <label className="font-semibold text-rose-200 block mb-1">Dietary Specialization</label>
                  <select
                    value={foodType}
                    onChange={(e) => setFoodType(e.target.value as any)}
                    className="w-full p-2.5 rounded-xl bg-[#120207] border border-rose-800 text-white text-xs outline-hidden"
                  >
                    <option value="veg_and_nonveg">Veg & Non-Veg Kitchen</option>
                    <option value="pure_veg">100% Pure Veg (Satvik / No Non-Veg)</option>
                    <option value="non_veg">Non-Veg Special</option>
                  </select>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-[#120207] border border-rose-900/80 flex items-center justify-between">
                <div>
                  <span className="font-bold text-white text-xs block">Student Hostels & PG Delivery</span>
                  <span className="text-[11px] text-rose-300">
                    Enable or disable daily door-to-door meal delivery to campus hostels.
                  </span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={deliveryAvailable}
                    onChange={(e) => setDeliveryAvailable(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-rose-950 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-rose-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
                </label>
              </div>

              <div className="text-right pt-2">
                <button
                  onClick={() => handleSaveChanges()}
                  disabled={saving}
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs inline-flex items-center gap-2 shadow-lg transition-all disabled:opacity-50"
                >
                  <Save className="w-4 h-4" />
                  <span>{saving ? 'Saving...' : 'Save Profile to Database'}</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: STUDENT VIEW PREVIEW */}
        {activeTab === 'preview' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-black text-white font-heading">
                  Student-Facing Listing Preview
                </h2>
                <p className="text-xs text-rose-300/80">
                  This preview renders exactly what KIIT and Balasore students see when browsing stays and messes.
                </p>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                Live Database Synchronized
              </span>
            </div>

            <div className="max-w-2xl mx-auto p-6 rounded-3xl bg-[#1c040b] border border-rose-800 shadow-2xl space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-xl font-black text-white font-heading">{messName}</h3>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Verified Mess
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-rose-300 mt-1">
                    <MapPin className="w-3.5 h-3.5 text-rose-400" />
                    <span>{address}</span>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-xl font-black text-amber-400 font-heading">₹{monthlyPrice}/mo</div>
                  <div className="text-[10px] text-rose-400">Single meal: ₹{singleMealPrice}</div>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-rose-900 text-xs flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-400" />
                  <span className="text-rose-200">Hours: {operatingHours}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-emerald-400" />
                  <span className="font-mono text-emerald-300 font-bold">{phone}</span>
                </div>
              </div>

              {/* Sample meal plans preview */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-rose-200 uppercase tracking-wider">Available Meal Packages:</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {mealPlans.map((p, i) => (
                    <div key={i} className="p-2.5 rounded-xl bg-[#2a0712] border border-rose-900/60 text-xs">
                      <div className="font-bold text-white flex justify-between">
                        <span>{p.title}</span>
                        <span className="text-amber-300">₹{p.pricePerMonth}</span>
                      </div>
                      <p className="text-[11px] text-rose-300/80 mt-1 line-clamp-2">{p.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-300 text-center font-bold">
                🍱 Students can book this mess directly from Explore Stays & Student Mess portal
              </div>
            </div>
          </div>
        )}

      </main>

    </div>
  );
};
