import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Send, 
  ArrowRight, 
  CheckCircle2, 
  Clock, 
  ShieldAlert, 
  AlertCircle, 
  Terminal, 
  RotateCcw, 
  Compass, 
  Building, 
  UtensilsCrossed, 
  Calendar, 
  Lock, 
  ChevronRight,
  UserCheck,
  Bot,
  MessageSquare,
  Loader2,
  HelpCircle
} from 'lucide-react';
import { AgentTaskSession, SubTask, AgentEvent, Property } from '../types';
import { AgentTraceTimeline } from '../components/AgentTraceTimeline';
import { HumanApprovalModal } from '../components/HumanApprovalModal';
import { N8nChatbot } from '../components/N8nChatbot';

interface ConciergeViewProps {
  initialGoal?: string;
  onSelectProperty: (prop: Property) => void;
  onScheduleVisit: (prop: Property) => void;
  onNavigateToTab: (tab: string) => void;
}

export const ConciergeView: React.FC<ConciergeViewProps> = ({
  initialGoal = '',
  onSelectProperty,
  onScheduleVisit,
  onNavigateToTab
}) => {
  const [goalInput, setGoalInput] = useState<string>(initialGoal || 'Find me a verified sharing room in Patia, Bhubaneswar, under ₹3,500 per month, arrange a visit on Saturday, and show nearby mess services.');
  const [activeSession, setActiveSession] = useState<AgentTaskSession | null>(null);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [approvalModalTask, setApprovalModalTask] = useState<SubTask | null>(null);

  // Concierge Sub-Tab: 'n8n_chat' (n8n Cloud Chatbot) | 'gemini_chat' (Roomora Gemini AI) | 'agent' (Multi-Step Task Planner)
  const [activeSubTab, setActiveSubTab] = useState<'n8n_chat' | 'gemini_chat' | 'agent'>('n8n_chat');

  // Roomora AI Chatbot State (Gemini 3.8 Flash)
  const [chatMessages, setChatMessages] = useState<Array<{ role: 'user' | 'assistant'; content: string; time: string }>>([
    {
      role: 'assistant',
      content: 'Hello! I am **Roomora AI**, your 24x7 intelligent student living assistant powered by Gemini. Ask me anything about student accommodations in Patia or Khandagiri, budget sharing stays, Balasore messes & fooding spots with Google Maps, 24x7 ambulance booking, or OTC medicine buying!',
      time: 'Just now'
    }
  ]);
  const [chatInput, setChatInput] = useState<string>('');
  const [isChatLoading, setIsChatLoading] = useState<boolean>(false);

  const handleSendChat = async (textToSend?: string) => {
    const text = (textToSend || chatInput).trim();
    if (!text || isChatLoading) return;

    const userMsg = {
      role: 'user' as const,
      content: text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const newMessages = [...chatMessages, userMsg];
    setChatMessages(newMessages);
    setChatInput('');
    setIsChatLoading(true);

    try {
      const res = await fetch('/api/chat/roomora', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages.map(m => ({ role: m.role, content: m.content }))
        })
      });
      const data = await res.json();
      const reply = data.reply || "I'm having trouble connecting right now. Please try again or explore our Stays & Mess tabs.";
      setChatMessages(prev => [
        ...prev,
        {
          role: 'assistant',
          content: reply,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } catch (err) {
      console.error(err);
      setChatMessages(prev => [
        ...prev,
        {
          role: 'assistant',
          content: "Sorry, I ran into a network error while answering. Please feel free to ask again!",
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setIsChatLoading(false);
    }
  };

  // Example prompts
  const samplePrompts = [
    'Find me a verified sharing room in Patia, Bhubaneswar, under ₹3,500 per month, arrange a visit on Saturday, and show nearby mess services.',
    'Find a furnished girls PG within 2 km of KIIT Campus 6 under ₹4,500 with meals included.',
    'Compare the top 3 accommodation listings and recommend the best value stay.',
    'Create an active Vacancy Watch alert for rooms under ₹3,500 in Patia.'
  ];

  const runGoal = async (goalToRun: string) => {
    if (!goalToRun.trim()) return;
    setIsRunning(true);
    try {
      const res = await fetch('/api/agent/run-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ goal: goalToRun })
      });
      const data = await res.json();
      if (data.session) {
        setActiveSession(data.session);

        // Check if any subtask is waiting for approval
        const gatedTask = data.session.plan.find((t: SubTask) => t.status === 'waiting_for_approval');
        if (gatedTask) {
          setApprovalModalTask(gatedTask);
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsRunning(false);
    }
  };

  useEffect(() => {
    if (initialGoal) {
      runGoal(initialGoal);
    }
  }, [initialGoal]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    runGoal(goalInput);
  };

  const handleApprove = async (taskId: string) => {
    if (!activeSession) return;
    try {
      const res = await fetch(`/api/agent/sessions/${activeSession.id}/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ taskId, approved: true })
      });
      const data = await res.json();
      if (data.session) {
        setActiveSession(data.session);
        setApprovalModalTask(null);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleReject = async (taskId: string, reason: string) => {
    if (!activeSession) return;
    try {
      const res = await fetch(`/api/agent/sessions/${activeSession.id}/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ taskId, approved: false, reason })
      });
      const data = await res.json();
      if (data.session) {
        setActiveSession(data.session);
        setApprovalModalTask(null);
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 font-sans">
      
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-heading">
              Autonomous AI Concierge
            </h1>
            <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-400 border border-amber-300 dark:border-amber-800">
              Live Loop
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Deterministic goal-driven agent with real tool calling and human safety barriers
          </p>
        </div>

        <button
          onClick={() => {
            setActiveSession(null);
            setGoalInput('');
          }}
          className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-1.5"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>New Session</span>
        </button>
      </div>

      {/* Concierge Navigation Switcher */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-1.5 rounded-2xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/60">
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveSubTab('n8n_chat')}
            className={`flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
              activeSubTab === 'n8n_chat'
                ? 'bg-gradient-to-r from-[#881337] to-[#be123c] text-white shadow-md'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Bot className="w-4 h-4 text-amber-300" />
            <span>n8n Cloud Chatbot</span>
            <span className="px-1.5 py-0.5 rounded-md text-[10px] font-extrabold bg-amber-400 text-slate-950 uppercase tracking-wider">
              n8n
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('gemini_chat')}
            className={`flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
              activeSubTab === 'gemini_chat'
                ? 'bg-indigo-900 text-white shadow-md dark:bg-indigo-950'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Sparkles className="w-4 h-4 text-cyan-300" />
            <span>Gemini AI Chat</span>
            <span className="px-1.5 py-0.5 rounded-md text-[10px] font-extrabold bg-cyan-400 text-slate-950 uppercase tracking-wider">
              Flash
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('agent')}
            className={`flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
              activeSubTab === 'agent'
                ? 'bg-slate-900 text-white shadow-md dark:bg-slate-950'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Terminal className="w-4 h-4 text-amber-400" />
            <span>Multi-Step Planner Agent</span>
          </button>
        </div>

        <div className="hidden sm:flex items-center gap-2 px-3 text-xs text-slate-500 dark:text-slate-400">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>Roomora Intelligent Engine Active</span>
        </div>
      </div>

      {/* SubTab 1: n8n Cloud Workflow Chatbot */}
      {activeSubTab === 'n8n_chat' && (
        <N8nChatbot onSwitchToGemini={() => setActiveSubTab('gemini_chat')} />
      )}

      {/* SubTab 2: Roomora Gemini 3.8 Flash Chat (Preserved) */}
      {activeSubTab === 'gemini_chat' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/90 dark:border-slate-800 shadow-md flex flex-col h-[600px] overflow-hidden">
          {/* Header */}
          <div className="px-5 py-3.5 bg-slate-50 dark:bg-slate-950/70 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
                <Sparkles className="w-4 h-4 text-cyan-300" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Roomora Gemini AI
                  </h3>
                  <span className="px-1.5 py-0.5 rounded-md text-[10px] font-bold bg-cyan-100 dark:bg-cyan-950 text-cyan-700 dark:text-cyan-300 border border-cyan-300 dark:border-cyan-800">
                    Gemini 3.8 Flash
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Direct server-side Google GenAI SDK integration
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setActiveSubTab('n8n_chat')}
              className="px-3 py-1.5 rounded-xl border border-rose-300 dark:border-rose-800 text-rose-700 dark:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Bot className="w-3.5 h-3.5" />
              <span>Switch to n8n Cloud</span>
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4">
            {chatMessages.map((msg, i) => (
              <div
                key={i}
                className={`flex gap-3 max-w-[88%] ${
                  msg.role === 'user' ? 'ml-auto flex-row-reverse' : 'mr-auto'
                }`}
              >
                <div className={`w-8 h-8 rounded-full shrink-0 flex items-center justify-center text-xs font-bold shadow-xs ${
                  msg.role === 'user'
                    ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900'
                    : 'bg-indigo-600 text-white'
                }`}>
                  {msg.role === 'user' ? 'You' : <Sparkles className="w-4 h-4 text-cyan-300" />}
                </div>

                <div className="space-y-1">
                  <div className={`p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-indigo-600 text-white rounded-tr-xs shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-800/80 border border-slate-200/60 dark:border-slate-700/60 text-slate-900 dark:text-slate-100 rounded-tl-xs shadow-xs'
                  }`}>
                    <div className="whitespace-pre-wrap font-sans">
                      {msg.content}
                    </div>
                  </div>
                  <span className={`block text-[10px] text-slate-400 px-1 ${
                    msg.role === 'user' ? 'text-right' : 'text-left'
                  }`}>
                    {msg.time}
                  </span>
                </div>
              </div>
            ))}

            {isChatLoading && (
              <div className="flex gap-3 max-w-[88%] mr-auto items-center">
                <div className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center shrink-0">
                  <Sparkles className="w-4 h-4 text-cyan-300" />
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-tl-xs flex items-center gap-2.5 text-xs text-slate-600 dark:text-slate-300">
                  <Loader2 className="w-4 h-4 text-indigo-600 animate-spin" />
                  <span>Thinking with Gemini 3.8 Flash...</span>
                </div>
              </div>
            )}
          </div>

          {/* Quick Prompts */}
          <div className="px-4 py-2 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/30 overflow-x-auto">
            <div className="flex items-center gap-2 min-w-max">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Quick:</span>
              {samplePrompts.slice(0, 2).map((p, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleSendChat(p)}
                  disabled={isChatLoading}
                  className="px-2.5 py-1 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-indigo-400 text-xs transition-colors truncate max-w-xs"
                >
                  "{p.slice(0, 40)}..."
                </button>
              ))}
            </div>
          </div>

          {/* Input Form */}
          <div className="p-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendChat();
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Ask Gemini AI about college proximity, rent fairness, amenities..."
                disabled={isChatLoading}
                className="flex-1 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder-slate-400 text-xs sm:text-sm outline-hidden focus:ring-2 focus:ring-indigo-500/40"
              />
              <button
                type="submit"
                disabled={isChatLoading || !chatInput.trim()}
                className="px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all flex items-center justify-center gap-1.5 disabled:opacity-50"
              >
                <Send className="w-4 h-4 text-cyan-300" />
                <span>Send</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* SubTab 2: Multi-Step Planner Agent */}
      {activeSubTab === 'agent' && (
        <div className="space-y-6 animate-in fade-in duration-150">
          {/* Goal Input Card */}
          <div className="p-4 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 shadow-sm space-y-4">
            <form onSubmit={handleSubmit} className="space-y-3">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block font-heading uppercase tracking-wider">
                Express Student Accommodation Goal
              </label>
              <div className="relative">
                <textarea
                  value={goalInput}
                  onChange={(e) => setGoalInput(e.target.value)}
                  rows={3}
                  placeholder="Tell Roomora Concierge what you want: locality, budget, dates, visits, or mess services..."
                  className="w-full p-3.5 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950/60 text-slate-900 dark:text-white outline-hidden focus:ring-2 focus:ring-amber-500/50 leading-relaxed font-sans"
                />
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-1">
                <div className="flex flex-wrap gap-1.5 text-xs">
                  <span className="text-[11px] text-slate-400 self-center">Quick prompt:</span>
                  {samplePrompts.slice(0, 2).map((p, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => {
                        setGoalInput(p);
                        runGoal(p);
                      }}
                      className="px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-amber-50 dark:hover:bg-amber-950/40 hover:text-amber-700 dark:hover:text-amber-400 text-[11px] transition-colors truncate max-w-xs"
                    >
                      "{p.slice(0, 36)}..."
                    </button>
                  ))}
                </div>

                <button
                  type="submit"
                  disabled={isRunning || !goalInput.trim()}
                  className="px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-950 font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 shrink-0 disabled:opacity-50"
                >
                  <Sparkles className={`w-4 h-4 text-amber-400 ${isRunning ? 'animate-spin' : ''}`} />
                  <span>{isRunning ? 'Autonomous Agent Running...' : 'Execute Multi-Step Plan'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Active Session Display */}
      {activeSession && (
        <div className="space-y-6 animate-in fade-in duration-200">
          
          {/* Goal & Status Summary Card */}
          <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase font-extrabold tracking-wider text-slate-500 font-heading">
                  Active Task Session
                </span>
                <span className="font-mono text-xs text-slate-400">({activeSession.id})</span>
              </div>
              <div>
                {activeSession.status === 'completed' && (
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-800 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Autonomous Goal Completed
                  </span>
                )}
                {activeSession.status === 'waiting_for_approval' && (
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-400 border border-amber-300 dark:border-amber-800 flex items-center gap-1">
                    <ShieldAlert className="w-3.5 h-3.5" />
                    Paused: Awaiting Human Approval
                  </span>
                )}
                {activeSession.status === 'running' && (
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-400 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 animate-spin" />
                    Executing Tools
                  </span>
                )}
                {activeSession.status === 'cancelled' && (
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                    Action Denied / Cancelled
                  </span>
                )}
              </div>
            </div>

            {/* Extracted Constraints Pill Strip */}
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-medium">
                Locality: <strong>{activeSession.extractedGoal.location}</strong>
              </span>
              <span className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-medium">
                Max Budget: <strong>₹{activeSession.extractedGoal.maxBudget?.toLocaleString('en-IN')}/mo</strong>
              </span>
              <span className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-medium capitalize">
                Type: <strong>{activeSession.extractedGoal.roomType?.replace(/_/g, ' ')}</strong>
              </span>
              {activeSession.extractedGoal.deadlineOrVisitDate && (
                <span className="px-2.5 py-1 rounded-lg bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300 font-medium">
                  Visit Target: <strong>{activeSession.extractedGoal.deadlineOrVisitDate}</strong>
                </span>
              )}
            </div>

            {/* Final Outcome Summary if completed */}
            {activeSession.finalSummary && (
              <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60 text-xs text-emerald-800 dark:text-emerald-300 leading-relaxed">
                <strong>Execution Summary:</strong> {activeSession.finalSummary}
              </div>
            )}
          </div>

          {/* Inline Human Approval Gate Banner (If active) */}
          {activeSession.status === 'waiting_for_approval' && (
            <div className="p-5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border-2 border-amber-400 dark:border-amber-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-5 h-5 text-amber-600 dark:text-amber-400" />
                  <h3 className="font-bold text-sm text-amber-900 dark:text-amber-200 font-heading">
                    Human Authorization Required Before Proceeding
                  </h3>
                </div>
                <button
                  onClick={() => {
                    const task = activeSession.plan.find(t => t.status === 'waiting_for_approval');
                    if (task) setApprovalModalTask(task);
                  }}
                  className="px-4 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-xs"
                >
                  Review Details & Sign Off
                </button>
              </div>
              <p className="text-xs text-amber-800 dark:text-amber-300 leading-relaxed">
                The agent has identified a verified stay matching your budget and is ready to place a reservation hold. As per application safety guidelines, an explicit authorization is required.
              </p>
            </div>
          )}

          {/* Subtask Execution Pipeline Tree */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 font-heading">
              Subtask Execution Tree ({activeSession.plan.length} Steps)
            </h3>

            <div className="space-y-2.5">
              {activeSession.plan.map((task, idx) => (
                <div 
                  key={task.id}
                  className={`p-4 rounded-xl border transition-all text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                    task.status === 'completed'
                      ? 'bg-white dark:bg-slate-900 border-emerald-200 dark:border-emerald-900/50 shadow-xs'
                      : task.status === 'waiting_for_approval'
                      ? 'bg-amber-50/80 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800'
                      : task.status === 'running'
                      ? 'bg-indigo-50/50 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-800'
                      : 'bg-slate-50/70 dark:bg-slate-900/30 border-slate-200 dark:border-slate-800 opacity-80'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-slate-100 dark:bg-slate-800 font-mono text-[10px] font-bold flex items-center justify-center text-slate-700 dark:text-slate-300">
                        {idx + 1}
                      </span>
                      <span className="font-bold text-slate-900 dark:text-white font-heading">
                        {task.description}
                      </span>
                      <span className="px-1.5 py-0.5 rounded font-mono text-[10px] bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                        tool: {task.tool}
                      </span>
                    </div>

                    {task.resultSummary && (
                      <p className="text-emerald-700 dark:text-emerald-400 text-[11px] pl-7">
                        ✓ {task.resultSummary}
                      </p>
                    )}
                  </div>

                  <div className="sm:shrink-0 flex items-center gap-2">
                    {task.status === 'completed' && (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Completed
                      </span>
                    )}

                    {task.status === 'waiting_for_approval' && (
                      <button
                        onClick={() => setApprovalModalTask(task)}
                        className="px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs"
                      >
                        Action Pending Approval
                      </button>
                    )}

                    {task.status === 'pending' && (
                      <span className="text-[11px] text-slate-400">
                        Pending
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Interactive Outcome Widgets (Stays, Visits, Mess) */}
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 font-heading">
              Agent Outcome Widgets
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              
              {/* Widget 1: Primary Verified Match */}
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="flex items-center gap-2 text-slate-900 dark:text-white font-bold font-heading">
                  <Building className="w-4 h-4 text-amber-500" />
                  <span>Top Verified Stay</span>
                </div>
                <p className="text-slate-700 dark:text-slate-300 font-semibold">
                  Shree Krishna Executive Student Living
                </p>
                <p className="text-slate-500 dark:text-slate-400 text-[11px]">
                  Patia, 600m from KIIT Campus 6 • Rent ₹3,400/mo
                </p>
                <div className="pt-2 flex items-center gap-2">
                  <button
                    onClick={() => onNavigateToTab('search')}
                    className="text-amber-600 dark:text-amber-400 hover:underline font-bold text-[11px] flex items-center gap-1"
                  >
                    <span>View Property Page</span>
                    <ChevronRight className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* Widget 2: Scheduled Visit */}
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="flex items-center gap-2 text-slate-900 dark:text-white font-bold font-heading">
                  <Calendar className="w-4 h-4 text-emerald-500" />
                  <span>Scheduled Visit</span>
                </div>
                <p className="text-slate-700 dark:text-slate-300 font-semibold">
                  Saturday, 4:00 PM Slot
                </p>
                <p className="text-slate-500 dark:text-slate-400 text-[11px]">
                  Host Biswajit confirmed via WhatsApp coordination
                </p>
                <div className="pt-2">
                  <button
                    onClick={() => onNavigateToTab('dashboard')}
                    className="text-emerald-600 dark:text-emerald-400 hover:underline font-bold text-[11px] flex items-center gap-1"
                  >
                    <span>Check Student Hub Pass</span>
                    <ChevronRight className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* Widget 3: Nearby Mess */}
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="flex items-center gap-2 text-slate-900 dark:text-white font-bold font-heading">
                  <UtensilsCrossed className="w-4 h-4 text-indigo-500" />
                  <span>Nearby Student Mess</span>
                </div>
                <p className="text-slate-700 dark:text-slate-300 font-semibold">
                  Maa Annapurna Student Tiffin
                </p>
                <p className="text-slate-500 dark:text-slate-400 text-[11px]">
                  Two Meals Daily (Lunch + Dinner) • ₹2,400/month
                </p>
                <div className="pt-2">
                  <button
                    onClick={() => onNavigateToTab('mess')}
                    className="text-indigo-600 dark:text-indigo-400 hover:underline font-bold text-[11px] flex items-center gap-1"
                  >
                    <span>Explore Meal Plans</span>
                    <ChevronRight className="w-3 h-3" />
                  </button>
                </div>
              </div>

            </div>
          </div>

          {/* Section 5 Live Agent Trace Timeline */}
          <AgentTraceTimeline events={activeSession.events} isStreaming={isRunning} />

        </div>
      )}

      {/* Human Approval Gate Modal */}
      {approvalModalTask && activeSession && (
        <HumanApprovalModal
          task={approvalModalTask}
          sessionId={activeSession.id}
          onApprove={handleApprove}
          onReject={handleReject}
          onClose={() => setApprovalModalTask(null)}
        />
      )}

    </div>
  );
};
