import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  AlertTriangle, 
  Building, 
  Users, 
  Calendar, 
  Lock, 
  Activity, 
  CheckCircle2, 
  Flag, 
  Check, 
  X,
  FileText,
  Terminal,
  CookingPot,
  Key,
  Edit2
} from 'lucide-react';
import { ListingReport, Property } from '../types';

export const AdminView: React.FC<{ onInspectProperty: (prop: Property) => void }> = ({ onInspectProperty }) => {
  const [stats, setStats] = useState<any | null>(null);
  const [reports, setReports] = useState<ListingReport[]>([]);
  const [properties, setProperties] = useState<Property[]>([]);
  const [messes, setMesses] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'verification' | 'reports' | 'logs' | 'mess_ownership'>('overview');
  
  // Mess delegation state
  const [editingMessId, setEditingMessId] = useState<string | null>(null);
  const [targetAdminEmail, setTargetAdminEmail] = useState<string>('');
  const [delegationMsg, setDelegationMsg] = useState<string | null>(null);

  const fetchAdminData = async () => {
    setLoading(true);
    try {
      const [sRes, rRes, pRes, mRes] = await Promise.all([
        fetch('/api/admin/stats'),
        fetch('/api/admin/reports'),
        fetch('/api/properties'),
        fetch('/api/mess-admin/all-messes')
      ]);
      const [sData, rData, pData, mData] = await Promise.all([
        sRes.json(),
        rRes.json(),
        pRes.json(),
        mRes.json()
      ]);
      setStats(sData);
      setReports(rData || []);
      setProperties(pData.properties || []);
      setMesses(mData.messes || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleAssignMessOwnership = async (messId: string) => {
    if (!targetAdminEmail.trim()) return;
    try {
      const res = await fetch('/api/mess-admin/assign-ownership', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messId,
          newAdminEmail: targetAdminEmail.trim(),
          assignedBy: 'Roomora Platform Superadmin'
        })
      });
      const data = await res.json();
      if (res.ok) {
        setDelegationMsg(data.message || 'Mess administrator ownership successfully updated!');
        setEditingMessId(null);
        setTargetAdminEmail('');
        fetchAdminData();
        setTimeout(() => setDelegationMsg(null), 4000);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  const handleVerifyProperty = async (propId: string) => {
    try {
      await fetch(`/api/admin/properties/${propId}/verify`, { method: 'PATCH' });
      fetchAdminData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleResolveReport = async (reportId: string) => {
    try {
      await fetch(`/api/admin/reports/${reportId}/resolve`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'resolved' })
      });
      fetchAdminData();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 font-sans">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-rose-900/60">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-rose-500" />
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-heading">
              Roomora Trust & Admin Operations
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-rose-200/80 mt-1">
            Trust & Safety Verification Queue, Scam Guard reports, and AI Agent Audit Logs • <span className="text-rose-400 font-semibold">Wine Red Administrator Panel</span>
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-1 p-1 rounded-xl bg-[#280711] border border-rose-900/60 text-xs">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
              activeTab === 'overview'
                ? 'bg-[#881337] text-white shadow-md ring-1 ring-rose-400/50'
                : 'text-rose-300 hover:text-white hover:bg-rose-950/60'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('verification')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
              activeTab === 'verification'
                ? 'bg-[#881337] text-white shadow-md ring-1 ring-rose-400/50'
                : 'text-rose-300 hover:text-white hover:bg-rose-950/60'
            }`}
          >
            Verification Queue
          </button>
          <button
            onClick={() => setActiveTab('reports')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all relative ${
              activeTab === 'reports'
                ? 'bg-[#881337] text-white shadow-md ring-1 ring-rose-400/50'
                : 'text-rose-300 hover:text-white hover:bg-rose-950/60'
            }`}
          >
            Scam Reports ({reports.filter(r => r.status === 'under_review').length})
          </button>
          <button
            onClick={() => setActiveTab('logs')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
              activeTab === 'logs'
                ? 'bg-[#881337] text-white shadow-md ring-1 ring-rose-400/50'
                : 'text-rose-300 hover:text-white hover:bg-rose-950/60'
            }`}
          >
            Audit Logs
          </button>
          <button
            onClick={() => setActiveTab('mess_ownership')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'mess_ownership'
                ? 'bg-[#881337] text-white shadow-md ring-1 ring-rose-400/50'
                : 'text-rose-300 hover:text-white hover:bg-rose-950/60'
            }`}
          >
            <CookingPot className="w-3.5 h-3.5 text-amber-400" />
            <span>Mess Ownership ({messes.length})</span>
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-[#22060e] border border-rose-900/80 shadow-md space-y-1">
            <span className="text-rose-300 font-semibold text-[11px]">Listings</span>
            <p className="text-xl font-extrabold text-white font-heading">{stats.totalProperties}</p>
          </div>
          <div className="p-4 rounded-xl bg-[#22060e] border border-rose-900/80 shadow-md space-y-1">
            <span className="text-rose-300 font-semibold text-[11px]">Verified Stays</span>
            <p className="text-xl font-extrabold text-emerald-400 font-heading">{stats.verifiedProperties}</p>
          </div>
          <div className="p-4 rounded-xl bg-[#22060e] border border-rose-900/80 shadow-md space-y-1">
            <span className="text-rose-300 font-semibold text-[11px]">Visits Coordinated</span>
            <p className="text-xl font-extrabold text-white font-heading">{stats.totalVisits}</p>
          </div>
          <div className="p-4 rounded-xl bg-[#22060e] border border-rose-900/80 shadow-md space-y-1">
            <span className="text-rose-300 font-semibold text-[11px]">Escrow Bookings</span>
            <p className="text-xl font-extrabold text-rose-300 font-heading">{stats.totalBookings}</p>
          </div>
          <div className="p-4 rounded-xl bg-[#22060e] border border-rose-900/80 shadow-md space-y-1">
            <span className="text-rose-300 font-semibold text-[11px]">Active Watchers</span>
            <p className="text-xl font-extrabold text-amber-400 font-heading">{stats.activeVacancyWatches}</p>
          </div>
          <div className="p-4 rounded-xl bg-[#22060e] border border-rose-900/80 shadow-md space-y-1">
            <span className="text-rose-300 font-semibold text-[11px]">Flagged Reports</span>
            <p className="text-xl font-extrabold text-red-400 font-heading">{stats.pendingReports}</p>
          </div>
        </div>
      )}

      {/* Tab 1: Overview */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
          <div className="p-5 rounded-2xl bg-[#22060e] border border-rose-900/80 shadow-md space-y-3">
            <h3 className="font-bold text-sm text-white font-heading">
              Platform Verification Standards
            </h3>
            <p className="text-rose-200/90 leading-relaxed">
              Every accommodation approved on Roomora passes an on-site field checklist:
            </p>
            <ul className="space-y-1.5 text-rose-200/90">
              <li>✓ Host Aadhaar & Title deed KYC</li>
              <li>✓ Physical room size & box-spring mattress check</li>
              <li>✓ Water purifier (RO) and electric sub-meter rate audit</li>
              <li>✓ Safety lock & warden contact check</li>
            </ul>
          </div>

          <div className="p-5 rounded-2xl bg-[#22060e] border border-rose-900/80 shadow-md space-y-3">
            <h3 className="font-bold text-sm text-white font-heading">
              Autonomous Agent Safety Guardrails
            </h3>
            <p className="text-rose-200/90 leading-relaxed">
              The AI engine enforces strict bounded retries (max 3), idempotent payment execution, and persistent audit logging. LLM reasoning cannot bypass Human Approval Gates.
            </p>
          </div>
        </div>
      )}

      {/* Tab 2: Verification Queue */}
      {activeTab === 'verification' && (
        <div className="p-5 rounded-2xl bg-[#22060e] border border-rose-900/80 shadow-md space-y-4 text-xs">
          <h3 className="font-bold text-sm text-white font-heading">
            Pending Property Verification Audits
          </h3>

          <div className="space-y-3">
            {properties.map((p) => (
              <div key={p.id} className="p-4 rounded-xl bg-[#2b0813] border border-rose-900/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white font-heading">{p.title}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      p.verificationStatus === 'verified_by_platform'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : 'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}>
                      {p.verificationStatus.replace(/_/g, ' ').toUpperCase()}
                    </span>
                  </div>
                  <p className="text-rose-200/70 text-[11px]">{p.locality} • Host: {p.hostName} ({p.hostPhone})</p>
                  <p className="text-[11px] text-rose-300/60">Method: {p.verificationMethod}</p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {p.verificationStatus !== 'verified_by_platform' ? (
                    <button
                      onClick={() => handleVerifyProperty(p.id)}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center gap-1 shadow-xs"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Approve On-Site KYC</span>
                    </button>
                  ) : (
                    <span className="text-emerald-400 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4" />
                      Verified
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Scam Guard Community Reports */}
      {activeTab === 'reports' && (
        <div className="p-5 rounded-2xl bg-[#22060e] border border-rose-900/80 shadow-md space-y-4 text-xs">
          <h3 className="font-bold text-sm text-white font-heading">
            Scam Guard Community Flag Queue
          </h3>

          {reports.length === 0 ? (
            <p className="text-rose-300/70 py-4 text-center">No reported listings in review queue.</p>
          ) : (
            <div className="space-y-3">
              {reports.map((rep) => (
                <div key={rep.id} className="p-4 rounded-xl bg-[#2b0813] border border-rose-900/70 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Flag className="w-4 h-4 text-rose-400" />
                      <span className="font-bold text-white font-heading">{rep.propertyTitle}</span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-rose-950 text-rose-300 border border-rose-800 uppercase">
                        {rep.category.replace(/_/g, ' ')}
                      </span>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      rep.status === 'resolved' ? 'bg-emerald-950 text-emerald-300' : 'bg-amber-950 text-amber-300'
                    }`}>
                      {rep.status.toUpperCase()}
                    </span>
                  </div>

                  <p className="text-rose-200 text-[11px] bg-[#1a040b] p-2.5 rounded-lg border border-rose-950">
                    <strong className="text-rose-100">Report Details:</strong> {rep.description}
                  </p>

                  <div className="flex items-center justify-between pt-1 text-[11px] text-rose-300/70">
                    <span>Logged: {new Date(rep.createdAt).toLocaleString()}</span>
                    {rep.status !== 'resolved' && (
                      <button
                        onClick={() => handleResolveReport(rep.id)}
                        className="px-3 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold"
                      >
                        Resolve & Mark Clear
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Agent Audit Logs */}
      {activeTab === 'logs' && (
        <div className="p-5 rounded-2xl bg-[#22060e] border border-rose-900/80 shadow-md space-y-4 text-xs font-mono">
          <div className="flex items-center justify-between pb-2 border-b border-rose-950">
            <span className="font-bold text-white">Deterministic Execution Trail</span>
            <span className="text-rose-300/70 text-[11px]">Real-time backend events</span>
          </div>

          <div className="space-y-2 max-h-96 overflow-y-auto">
            {stats?.recentAuditLogs?.map((log: any, i: number) => (
              <div key={i} className="p-2.5 rounded-lg bg-[#2b0813] border border-rose-900/60 text-[11px] flex justify-between gap-4">
                <span className="text-rose-300/70 shrink-0">{new Date(log.timestamp).toLocaleTimeString()}</span>
                <span className="font-bold text-white">{log.actionName}</span>
                <span className="text-rose-200/80 truncate">{log.explanation}</span>
                <span className={`px-1.5 rounded font-bold uppercase shrink-0 ${
                  log.status === 'success' ? 'text-emerald-400' : log.status === 'warning' ? 'text-amber-400' : 'text-rose-300'
                }`}>
                  {log.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 5: Mess Ownership & Access Delegation */}
      {activeTab === 'mess_ownership' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-black text-white font-heading flex items-center gap-2">
                <CookingPot className="w-5 h-5 text-amber-400" />
                <span>Mess Administrator Ownership & Access Delegation</span>
              </h2>
              <p className="text-xs text-rose-300/80">
                Security Policy: Only trusted platform administrators can assign mess ownership. Administrators are strictly isolated to their own mess.
              </p>
            </div>
            <span className="text-xs font-bold text-amber-300 bg-[#2b0813] px-3 py-1.5 rounded-xl border border-rose-900">
              {messes.length} Active Mess Providers
            </span>
          </div>

          {delegationMsg && (
            <div className="p-3.5 rounded-xl bg-emerald-950/80 border border-emerald-500 text-xs text-emerald-200 font-bold flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400" />
              <span>{delegationMsg}</span>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {messes.map((messItem) => (
              <div
                key={messItem.id}
                className="p-5 rounded-2xl bg-[#22060e] border border-rose-900/80 shadow-lg space-y-3"
              >
                <div className="flex items-start justify-between gap-2 border-b border-rose-900/50 pb-2.5">
                  <div>
                    <h3 className="font-bold text-white text-base font-heading">
                      {messItem.name}
                    </h3>
                    <div className="text-[11px] text-rose-300 flex items-center gap-1 mt-0.5">
                      <span>{messItem.locality}, {messItem.city}</span>
                      <span>•</span>
                      <span className="font-mono text-amber-300">{messItem.phone}</span>
                    </div>
                  </div>

                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    ₹{messItem.monthlyPrice}/mo
                  </span>
                </div>

                {/* Assigned Administrator Info */}
                <div className="p-3 rounded-xl bg-[#140308] border border-rose-950 space-y-1 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-rose-400 text-[11px] font-semibold flex items-center gap-1">
                      <Key className="w-3.5 h-3.5 text-amber-400" />
                      <span>Authorized Admin Account:</span>
                    </span>
                    <span className="text-[10px] text-rose-400">
                      By {messItem.assignedBy}
                    </span>
                  </div>
                  <div className="font-mono text-amber-200 text-xs font-bold truncate">
                    {messItem.assignedAdminEmail}
                  </div>
                </div>

                {/* Reassignment Form / Button */}
                {editingMessId === messItem.id ? (
                  <div className="p-3 rounded-xl bg-[#2b0813] border border-rose-800 space-y-2 text-xs">
                    <label className="font-semibold text-rose-200 block text-[11px]">
                      Enter New Authorized Admin Email:
                    </label>
                    <input
                      type="email"
                      value={targetAdminEmail}
                      onChange={(e) => setTargetAdminEmail(e.target.value)}
                      placeholder="newadmin@roomora.in"
                      className="w-full p-2 rounded-lg bg-[#140308] border border-rose-700 text-white font-mono text-xs outline-hidden"
                    />
                    <div className="flex items-center justify-end gap-2 pt-1">
                      <button
                        onClick={() => {
                          setEditingMessId(null);
                          setTargetAdminEmail('');
                        }}
                        className="px-3 py-1.5 rounded-lg text-rose-300 hover:text-white text-xs font-semibold"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => handleAssignMessOwnership(messItem.id)}
                        className="px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs shadow-md transition-colors"
                      >
                        Save Assignment
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[11px] text-rose-400">
                      Active Orders: <strong className="text-white">{messItem.activeOrdersCount || 0}</strong>
                    </span>
                    <button
                      onClick={() => {
                        setEditingMessId(messItem.id);
                        setTargetAdminEmail(messItem.assignedAdminEmail);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-rose-900/60 hover:bg-rose-800 text-rose-200 hover:text-white border border-rose-700/60 text-xs font-bold flex items-center gap-1 transition-colors"
                    >
                      <Edit2 className="w-3 h-3 text-amber-400" />
                      <span>Reassign Admin</span>
                    </button>
                  </div>
                )}

              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
