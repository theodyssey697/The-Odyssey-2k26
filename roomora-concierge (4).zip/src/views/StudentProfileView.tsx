import React, { useState, useEffect } from 'react';
import { CareerProfile, CareerPlan, CareerAgentEvent, CareerChatMessage } from '../types/career';
import { fetchStudentCareerData, saveCareerProfileDraft, analyzeCareerProfile, sendCareerCoachMessage } from '../services/careerService';
import { CareerProfileWizard } from '../components/career/CareerProfileWizard';
import { CareerAgentTimeline } from '../components/career/CareerAgentTimeline';
import { CareerPathwayCard } from '../components/career/CareerPathwayCard';
import { CareerRoadmapComponent } from '../components/career/CareerRoadmap';
import { CareerCoachChat } from '../components/career/CareerCoachChat';
import { User, GraduationCap, Compass, BookOpen, Sparkles, CheckCircle2, AlertCircle, FileText, ArrowRight, ShieldCheck } from 'lucide-react';
import { auth } from '../firebaseConfig';

interface StudentProfileViewProps {
  userName: string;
  showToast: (msg: string) => void;
}

export const StudentProfileView: React.FC<StudentProfileViewProps> = ({ userName, showToast }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'counselling' | 'plan'>('overview');
  const [profile, setProfile] = useState<CareerProfile | null>(null);
  const [plan, setPlan] = useState<CareerPlan | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [agentEvents, setAgentEvents] = useState<CareerAgentEvent[]>([]);
  const [activeStage, setActiveStage] = useState<string>('');
  const [chatMessages, setChatMessages] = useState<CareerChatMessage[]>([]);
  const [selectedPathwayId, setSelectedPathwayId] = useState<string>('pathway-1');

  const currentUser = auth.currentUser;

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const data = await fetchStudentCareerData();
      if (data.profile) setProfile(data.profile);
      if (data.plan) {
        setPlan(data.plan);
        if (data.plan.recommendations?.strongestFit?.id) {
          setSelectedPathwayId(data.plan.recommendations.strongestFit.id);
        }
      }
    } catch (error) {
      console.error('Failed to load career data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveDraft = async (draftProfile: Partial<CareerProfile>) => {
    try {
      const res = await saveCareerProfileDraft(draftProfile);
      setProfile(res.profile);
      showToast('Career profile draft saved successfully.');
    } catch (error: any) {
      showToast(error.message || 'Failed to save profile draft.');
    }
  };

  const handleGeneratePlan = async (fullProfile: CareerProfile) => {
    setIsAnalyzing(true);
    setAgentEvents([]);
    try {
      const eventsList: CareerAgentEvent[] = [];
      const result = await analyzeCareerProfile(fullProfile, (ev) => {
        eventsList.push(ev);
        setAgentEvents([...eventsList]);
        setActiveStage(ev.stageName);
      });

      setPlan(result.plan);
      if (result.plan.recommendations?.strongestFit?.id) {
        setSelectedPathwayId(result.plan.recommendations.strongestFit.id);
      }
      showToast('AI Career Plan generated successfully!');
      setActiveTab('plan');
    } catch (error: any) {
      showToast(error.message || 'Career plan generation failed.');
    } finally {
      setIsAnalyzing(false);
      setActiveStage('');
    }
  };

  const handleToggleMilestone = (milestoneId: string) => {
    if (!plan) return;
    const updatedPhases = ['phase30Days', 'phase60Days', 'phase90Days'].reduce((acc: any, key) => {
      const phase = (plan.roadmap as any)[key];
      acc[key] = {
        ...phase,
        milestones: phase.milestones.map((m: any) => 
          m.id === milestoneId ? { ...m, completed: !m.completed } : m
        )
      };
      return acc;
    }, {});

    setPlan({
      ...plan,
      roadmap: updatedPhases
    });
    showToast('Milestone progress updated.');
  };

  const handleSendMessage = async (text: string) => {
    const userMsg: CareerChatMessage = {
      id: `msg-${Date.now()}-user`,
      sender: 'user',
      text,
      timestamp: new Date().toISOString()
    };
    setChatMessages(prev => [...prev, userMsg]);

    try {
      const coachMsg = await sendCareerCoachMessage(text, plan?.id);
      setChatMessages(prev => [...prev, coachMsg]);
    } catch (error: any) {
      showToast(error.message || 'Failed to get response from career coach.');
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-[#1a040b] via-[#4c0519] to-[#881337] text-white rounded-3xl p-6 sm:p-8 shadow-lg">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#9f1239] to-[#e11d48] flex items-center justify-center font-bold text-white text-2xl font-heading shadow-md">
              {userName.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-extrabold font-heading">{userName}</h1>
                <span className="px-2.5 py-0.5 rounded-full bg-rose-950 text-rose-200 text-[10px] uppercase font-bold tracking-widest border border-rose-800">
                  Student Account
                </span>
              </div>
              <p className="text-xs text-rose-200/80 mt-1">
                {currentUser?.email || 'Verified Student Portal'} • Secure AI Career Counselling & Student Profile
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 bg-rose-950/80 border border-rose-900 px-4 py-2.5 rounded-2xl">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-bold text-rose-100">Firebase Verified UID</span>
          </div>
        </div>

        {/* Navigation Tabs inside Student Profile */}
        <div className="flex flex-wrap gap-2 mt-8 pt-6 border-t border-rose-900/60">
          <button
            onClick={() => setActiveTab('overview')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition-all ${
              activeTab === 'overview'
                ? 'bg-white text-[#4c0519] shadow-md'
                : 'bg-rose-950/60 text-rose-200 hover:bg-rose-900/80 hover:text-white'
            }`}
          >
            <User className="w-4 h-4" />
            <span>A. Profile Overview</span>
          </button>

          <button
            onClick={() => setActiveTab('counselling')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition-all ${
              activeTab === 'counselling'
                ? 'bg-white text-[#4c0519] shadow-md'
                : 'bg-rose-950/60 text-rose-200 hover:bg-rose-900/80 hover:text-white'
            }`}
          >
            <Compass className="w-4 h-4" />
            <span>B. Career Counselling & Wizard</span>
          </button>

          <button
            onClick={() => setActiveTab('plan')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition-all ${
              activeTab === 'plan'
                ? 'bg-white text-[#4c0519] shadow-md'
                : 'bg-rose-950/60 text-rose-200 hover:bg-rose-900/80 hover:text-white'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>C. My Career Plan & Coach</span>
          </button>
        </div>
      </div>

      {/* TAB A: PROFILE OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Account Information Card */}
            <div className="bg-white border border-rose-200/90 rounded-3xl p-6 shadow-sm">
              <h3 className="text-sm font-extrabold text-[#4c0519] font-heading mb-4 flex items-center gap-2">
                <User className="w-4 h-4 text-[#be123c]" />
                Account Details
              </h3>
              <div className="space-y-3 text-xs">
                <div>
                  <span className="text-slate-500 block">Full Name</span>
                  <span className="font-bold text-slate-800">{userName}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Email Address</span>
                  <span className="font-bold text-slate-800">{currentUser?.email || profile?.email || 'Not provided'}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Email Verified</span>
                  <span className={`inline-flex items-center gap-1 font-bold ${currentUser?.emailVerified ? 'text-emerald-600' : 'text-amber-600'}`}>
                    {currentUser?.emailVerified ? <CheckCircle2 className="w-3.5 h-3.5" /> : <AlertCircle className="w-3.5 h-3.5" />}
                    {currentUser?.emailVerified ? 'Verified via Firebase' : 'Verification Pending'}
                  </span>
                </div>
              </div>
            </div>

            {/* Career Profile Completion Status */}
            <div className="bg-white border border-rose-200/90 rounded-3xl p-6 shadow-sm">
              <h3 className="text-sm font-extrabold text-[#4c0519] font-heading mb-4 flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-[#be123c]" />
                Career Profile Status
              </h3>
              <div className="space-y-3 text-xs">
                <div>
                  <span className="text-slate-500 block">College / Programme</span>
                  <span className="font-bold text-slate-800">{profile?.education?.collegeName || 'Not provided'} ({profile?.education?.degree || 'Degree not specified'})</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Current Goal</span>
                  <span className="font-bold text-slate-800">{profile?.interests?.shortTermGoals || 'Not specified'}</span>
                </div>
                <button
                  onClick={() => setActiveTab('counselling')}
                  className="w-full mt-2 px-4 py-2.5 rounded-xl bg-rose-50 text-[#881337] hover:bg-rose-100 font-bold flex items-center justify-center gap-1.5 transition-all"
                >
                  <span>Edit Career Profile</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setActiveTab('counselling')}
                  className="w-full mt-1.5 px-4 py-2.5 rounded-xl bg-[#881337] text-white hover:bg-[#9f1239] font-bold flex items-center justify-center gap-1.5 transition-all shadow-sm"
                >
                  <Compass className="w-3.5 h-3.5" />
                  <span>Continue Assessment (21 Steps)</span>
                </button>
              </div>
            </div>

            {/* Saved Career Plan Summary */}
            <div className="bg-white border border-rose-200/90 rounded-3xl p-6 shadow-sm">
              <h3 className="text-sm font-extrabold text-[#4c0519] font-heading mb-4 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-500" />
                Saved Career Plan Summary
              </h3>
              <div className="space-y-3 text-xs">
                <div>
                  <span className="text-slate-500 block">Selected Pathway</span>
                  <span className="font-bold text-[#881337]">{plan?.recommendations?.strongestFit?.title || 'No plan generated yet'}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Plan Status</span>
                  <span className="font-bold text-emerald-600">{plan ? 'Active & Up-to-Date' : 'Pending Generation'}</span>
                </div>
                <button
                  onClick={() => setActiveTab('plan')}
                  className="w-full mt-2 px-4 py-2.5 rounded-xl bg-[#881337] text-white hover:bg-[#9f1239] font-bold flex items-center justify-center gap-1.5 transition-all"
                >
                  <span>View Career Plan</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB B: CAREER COUNSELLING & WIZARD */}
      {activeTab === 'counselling' && (
        <div className="space-y-8 animate-in fade-in duration-200">
          <CareerProfileWizard
            initialProfile={profile}
            onSaveDraft={handleSaveDraft}
            onGeneratePlan={handleGeneratePlan}
            isLoading={isAnalyzing}
          />

          {isAnalyzing && (
            <CareerAgentTimeline
              events={agentEvents}
              activeStageName={activeStage}
              isRunning={isAnalyzing}
            />
          )}
        </div>
      )}

      {/* TAB C: MY CAREER PLAN & COACH */}
      {activeTab === 'plan' && (
        <div className="space-y-8 animate-in fade-in duration-200">
          {!plan ? (
            <div className="bg-white border border-rose-200/90 rounded-3xl p-12 text-center shadow-sm">
              <div className="w-16 h-16 rounded-3xl bg-rose-100 text-[#881337] flex items-center justify-center mx-auto mb-4">
                <Compass className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-extrabold text-[#4c0519] font-heading mb-2">No Career Plan Generated Yet</h3>
              <p className="text-xs text-slate-600 max-w-md mx-auto mb-6">Complete your student career profile in the counselling tab and run the multi-stage agentic pipeline to create your personalized roadmap.</p>
              <button
                onClick={() => setActiveTab('counselling')}
                className="px-6 py-3 rounded-xl bg-[#881337] text-white font-bold text-xs shadow-md hover:bg-[#9f1239]"
              >
                Go to Career Counselling Wizard
              </button>
            </div>
          ) : (
            <div className="space-y-8">
              {/* Recommended Pathways Grid */}
              <div>
                <h3 className="text-base font-extrabold text-[#4c0519] font-heading mb-4">Recommended Career Pathways</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <CareerPathwayCard
                    pathway={plan.recommendations.strongestFit}
                    badgeLabel="Strongest Fit"
                    badgeColor="bg-emerald-100 text-emerald-800"
                    onSelect={() => setSelectedPathwayId(plan.recommendations.strongestFit.id)}
                    isSelected={selectedPathwayId === plan.recommendations.strongestFit.id}
                  />
                  <CareerPathwayCard
                    pathway={plan.recommendations.adjacentOption}
                    badgeLabel="Adjacent Option"
                    badgeColor="bg-sky-100 text-sky-800"
                    onSelect={() => setSelectedPathwayId(plan.recommendations.adjacentOption.id)}
                    isSelected={selectedPathwayId === plan.recommendations.adjacentOption.id}
                  />
                  <CareerPathwayCard
                    pathway={plan.recommendations.stretchOption}
                    badgeLabel="Stretch Option"
                    badgeColor="bg-amber-100 text-amber-800"
                    onSelect={() => setSelectedPathwayId(plan.recommendations.stretchOption.id)}
                    isSelected={selectedPathwayId === plan.recommendations.stretchOption.id}
                  />
                </div>
              </div>

              {/* Roadmap & Milestones */}
              <CareerRoadmapComponent
                roadmap={plan.roadmap}
                onToggleMilestone={handleToggleMilestone}
              />

              {/* Verified Resources & Portals */}
              <div className="bg-white border border-rose-200/90 rounded-3xl p-6 sm:p-8 shadow-sm">
                <h3 className="text-base font-extrabold text-[#4c0519] font-heading mb-4 flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-[#be123c]" />
                  Verified Learning Resources & Portals (SWAYAM, NPTEL, AICTE)
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {plan.resources.map((res, idx) => (
                    <div key={idx} className="p-4 rounded-2xl border border-rose-200/70 bg-rose-50/30 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[10px] uppercase font-bold px-2 py-0.5 bg-rose-100 text-[#881337] rounded-md">
                            {res.provider}
                          </span>
                          <span className="text-[11px] font-semibold text-slate-500">{res.resourceType}</span>
                        </div>
                        <h4 className="text-sm font-bold text-[#4c0519] font-heading mb-1">{res.title}</h4>
                        <p className="text-xs text-slate-600 mb-2">{res.reason}</p>
                      </div>
                      <a
                        href={res.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 text-xs font-bold text-[#881337] hover:underline"
                      >
                        <span>Access Official Directory</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  ))}
                </div>
              </div>

              {/* AI Career Coach Chat Panel */}
              <CareerCoachChat
                messages={chatMessages}
                onSendMessage={handleSendMessage}
                isLoading={isLoading}
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
};
