import React from 'react';
import { Sparkles, ShieldCheck, GraduationCap, ArrowRight, Lock, Building } from 'lucide-react';

interface EntranceViewProps {
  onSelectStudent: () => void;
  onSelectAdmin: () => void;
}

export const EntranceView: React.FC<EntranceViewProps> = ({ onSelectStudent, onSelectAdmin }) => {
  return (
    <div className="min-h-screen w-full navy-gradient flex flex-col items-center justify-center p-4 sm:p-6 relative overflow-hidden">
      
      {/* Decorative background glow blobs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-indigo-600/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-4xl w-full mx-auto text-center space-y-8 relative z-10">
        
        {/* Logo & Branding */}
        <div className="space-y-3">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-600 flex items-center justify-center shadow-xl shadow-amber-500/20 text-slate-950 font-bold text-3xl font-heading mx-auto ring-2 ring-amber-400/30">
            R
          </div>
          <div className="space-y-1">
            <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight font-heading mt-2">
              Welcome to Roomora Concierge
            </h1>
            <p className="text-sm sm:text-base text-slate-300 max-w-lg mx-auto leading-relaxed">
              Your trusted AI-powered companion for student living. Roomora finds stays. Roomora Concierge finishes the job.
            </p>
          </div>
        </div>

        {/* Two Glassmorphism Role Selection Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
          
          {/* Student Card */}
          <div className="group rounded-3xl p-8 bg-slate-900/80 backdrop-blur-xl border border-slate-700/80 hover:border-amber-500/60 shadow-2xl transition-all duration-300 flex flex-col justify-between text-left relative overflow-hidden glass-hover">
            <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl group-hover:bg-amber-500/10 transition-colors" />

            <div className="space-y-4 relative z-10">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-bold">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white font-heading">
                  I'm a Student
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
                  Find accommodation, compare living costs, connect with verified properties, and use your AI Concierge for visits and mess ordering.
                </p>
              </div>
            </div>

            <div className="pt-8 relative z-10">
              <button
                onClick={onSelectStudent}
                className="w-full py-3.5 px-5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 transition-all transform group-hover:scale-[1.01]"
              >
                <span>Continue as Student</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Administrator Card */}
          <div className="group rounded-3xl p-8 bg-slate-900/80 backdrop-blur-xl border border-slate-700/80 hover:border-indigo-500/60 shadow-2xl transition-all duration-300 flex flex-col justify-between text-left relative overflow-hidden glass-hover">
            <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-2xl group-hover:bg-indigo-500/10 transition-colors" />

            <div className="space-y-4 relative z-10">
              <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center font-bold">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white font-heading">
                  I'm an Administrator
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
                  Manage properties, verification requests, bookings, Scam Guard reports, and AI agent monitoring operations.
                </p>
              </div>
            </div>

            <div className="pt-8 relative z-10">
              <button
                onClick={onSelectAdmin}
                className="w-full py-3.5 px-5 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-400 border border-indigo-500/40 font-bold text-sm shadow-lg flex items-center justify-center gap-2 transition-all transform group-hover:scale-[1.01]"
              >
                <Lock className="w-4 h-4" />
                <span>Administrator Login</span>
              </button>
            </div>
          </div>

        </div>

        {/* Footer info */}
        <p className="text-xs text-slate-400 pt-4">
          Protected by Roomora Escrow & Scam Guard Architecture. Secure Firebase Auth integrated.
        </p>

      </div>
    </div>
  );
};
