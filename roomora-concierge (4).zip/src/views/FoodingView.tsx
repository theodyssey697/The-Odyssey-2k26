import React, { useState } from 'react';
import { 
  UtensilsCrossed, 
  MapPin, 
  Phone, 
  Clock, 
  ShieldCheck, 
  Check, 
  Sparkles, 
  ExternalLink,
  Copy,
  Star,
  Search,
  ChevronLeft,
  ChevronRight,
  Flame,
  X,
  Compass,
  Calendar,
  Users
} from 'lucide-react';
import { BALASORE_RESTAURANTS } from '../data/foodingData';
import { FoodingPlace } from '../types';

export const FoodingView: React.FC = () => {
  const [restaurants] = useState<FoodingPlace[]>(BALASORE_RESTAURANTS);
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<'all' | 'multicuisine' | 'biryani_nonveg' | 'fast_food' | 'dhaba_odia' | 'pure_veg'>('all');
  const [foodTypeFilter, setFoodTypeFilter] = useState<'all' | 'pure_veg' | 'veg_and_nonveg'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeImageIndices, setActiveImageIndices] = useState<Record<string, number>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Table reservation & inquiry modal
  const [selectedPlace, setSelectedPlace] = useState<FoodingPlace | null>(null);
  const [reserveModalOpen, setReserveModalOpen] = useState<boolean>(false);
  const [guestCount, setGuestCount] = useState<number>(2);
  const [reserveDate, setReserveDate] = useState<string>('Today, Lunch (1:30 PM)');
  const [guestName, setGuestName] = useState<string>('Aryan Sharma');
  const [guestPhone, setGuestPhone] = useState<string>('+91 98765 43210');
  const [reserveConfirmed, setReserveConfirmed] = useState<boolean>(false);

  const handleCopyLink = (url: string, id: string) => {
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(url);
    }
    setCopiedId(id);
    setTimeout(() => {
      setCopiedId(null);
    }, 2500);
  };

  const handlePrevImage = (id: string, totalImages: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveImageIndices(prev => {
      const current = prev[id] || 0;
      return { ...prev, [id]: (current - 1 + totalImages) % totalImages };
    });
  };

  const handleNextImage = (id: string, totalImages: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveImageIndices(prev => {
      const current = prev[id] || 0;
      return { ...prev, [id]: (current + 1) % totalImages };
    });
  };

  const handleOpenReservation = (place: FoodingPlace) => {
    setSelectedPlace(place);
    setReserveConfirmed(false);
    setReserveModalOpen(true);
  };

  const handleConfirmReservation = (e: React.FormEvent) => {
    e.preventDefault();
    setReserveConfirmed(true);
  };

  // Filter logic - ONLY restaurants & eateries, zero mess options
  const filteredRestaurants = restaurants.filter(item => {
    // Dietary filter
    if (foodTypeFilter === 'pure_veg' && item.foodType !== 'pure_veg') return false;
    if (foodTypeFilter === 'veg_and_nonveg' && item.foodType !== 'veg_and_nonveg') return false;

    // Search query filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = item.name.toLowerCase().includes(q);
      const matchCuisine = item.cuisine.toLowerCase().includes(q);
      const matchLocality = item.locality.toLowerCase().includes(q);
      const matchAddress = item.address.toLowerCase().includes(q);
      const matchHighlights = item.highlights.some(h => h.toLowerCase().includes(q));
      if (!matchName && !matchCuisine && !matchLocality && !matchAddress && !matchHighlights) {
        return false;
      }
    }

    // Category filter
    if (activeCategoryFilter === 'multicuisine') {
      return item.category === 'restaurant' && (item.cuisine.toLowerCase().includes('multi') || item.cuisine.toLowerCase().includes('chinese') || item.cuisine.toLowerCase().includes('indian'));
    }
    if (activeCategoryFilter === 'biryani_nonveg') {
      return item.name.toLowerCase().includes('mutton') || item.name.toLowerCase().includes('bowl') || item.cuisine.toLowerCase().includes('biryani') || item.cuisine.toLowerCase().includes('mutton');
    }
    if (activeCategoryFilter === 'fast_food') {
      return item.category === 'fast_food' || item.category === 'cafe';
    }
    if (activeCategoryFilter === 'dhaba_odia') {
      return item.category === 'dhaba' || item.name.toLowerCase().includes('odianee') || item.cuisine.toLowerCase().includes('odia');
    }
    if (activeCategoryFilter === 'pure_veg') {
      return item.foodType === 'pure_veg';
    }

    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 font-sans">
      
      {/* Header Banner - Wine Red & Rose Aesthetic */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#4c0519] via-[#881337] to-[#1e050c] text-white p-6 sm:p-8 shadow-xl border border-rose-800/40">
        <div className="absolute top-0 right-0 w-96 h-96 bg-rose-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/20 text-rose-200 border border-rose-400/30 text-xs font-bold tracking-wide uppercase">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Fooding & Restaurant Directory</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight font-heading text-white">
              Balasore Dining & Eateries Explorer
            </h1>
            <p className="text-sm sm:text-base text-rose-100/90 leading-relaxed">
              Discover verified restaurants, dhabas, cafes, and dining spots across Balasore with photos uploaded directly to Google Maps, contact numbers, and 1-click <strong className="text-amber-300 font-bold">Visit</strong> links to Google Maps.
            </p>
          </div>

          <div className="flex sm:flex-col gap-2 shrink-0">
            <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 text-center min-w-[125px]">
              <span className="block text-2xl font-black text-amber-300 font-heading">
                {restaurants.length}
              </span>
              <span className="text-[11px] font-bold text-rose-200">G-Map Restaurants</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 text-center min-w-[125px]">
              <span className="block text-2xl font-black text-emerald-300 font-heading">
                100%
              </span>
              <span className="text-[11px] font-bold text-rose-200">Direct Visit Links</span>
            </div>
          </div>
        </div>
      </div>

      {/* Control Filters & Search Bar */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-rose-100 space-y-4">
        
        {/* Search bar */}
        <div className="relative">
          <Search className="w-5 h-5 text-[#881337] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search Balasore restaurants (The Big Bowl, Julian, Domino's, ODIANEE, Mutton Darbar...), cuisines or dishes..."
            className="w-full pl-11 pr-10 py-3 rounded-xl bg-rose-50/50 border border-rose-200 text-sm text-[#4c0519] placeholder:text-rose-300 focus:outline-none focus:ring-2 focus:ring-[#881337] focus:bg-white transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-[#881337]"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Category Tabs & Dietary Filter - Pure fooding, NO mess options */}
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3 pt-2 border-t border-slate-100">
          
          {/* Main Category Tabs */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <button
              onClick={() => setActiveCategoryFilter('all')}
              className={`px-3.5 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 ${
                activeCategoryFilter === 'all'
                  ? 'bg-[#881337] text-white shadow-xs'
                  : 'bg-rose-50 text-[#881337] hover:bg-rose-100'
              }`}
            >
              <UtensilsCrossed className="w-3.5 h-3.5" />
              <span>All Restaurants ({restaurants.length})</span>
            </button>

            <button
              onClick={() => setActiveCategoryFilter('multicuisine')}
              className={`px-3.5 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 ${
                activeCategoryFilter === 'multicuisine'
                  ? 'bg-[#be123c] text-white shadow-xs'
                  : 'bg-rose-50 text-[#881337] border border-rose-200 hover:bg-rose-100'
              }`}
            >
              <span>Multi-Cuisine & Family Dining</span>
            </button>

            <button
              onClick={() => setActiveCategoryFilter('biryani_nonveg')}
              className={`px-3.5 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 ${
                activeCategoryFilter === 'biryani_nonveg'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100'
              }`}
            >
              <Flame className="w-3.5 h-3.5 text-amber-500" />
              <span>Biryani & Non-Veg Special</span>
            </button>

            <button
              onClick={() => setActiveCategoryFilter('fast_food')}
              className={`px-3.5 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 ${
                activeCategoryFilter === 'fast_food'
                  ? 'bg-[#9f1239] text-white shadow-xs'
                  : 'bg-rose-50 text-[#881337] hover:bg-rose-100'
              }`}
            >
              <span>Pizza, Cafes & Fast Food</span>
            </button>

            <button
              onClick={() => setActiveCategoryFilter('dhaba_odia')}
              className={`px-3.5 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 ${
                activeCategoryFilter === 'dhaba_odia'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-emerald-50 text-emerald-900 border border-emerald-200 hover:bg-emerald-100'
              }`}
            >
              <span>Highway Dhabas & Odia Thalis</span>
            </button>
          </div>

          {/* Dietary Filter */}
          <div className="flex items-center gap-2 text-xs shrink-0 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setFoodTypeFilter('all')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                foodTypeFilter === 'all'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Diets
            </button>
            <button
              onClick={() => setFoodTypeFilter('pure_veg')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-colors flex items-center gap-1.5 ${
                foodTypeFilter === 'pure_veg'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-emerald-700 hover:text-emerald-800'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              Pure Veg
            </button>
            <button
              onClick={() => setFoodTypeFilter('veg_and_nonveg')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-colors flex items-center gap-1.5 ${
                foodTypeFilter === 'veg_and_nonveg'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-amber-700 hover:text-amber-800'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-amber-400"></span>
              Veg & Non-Veg
            </button>
          </div>
        </div>
      </div>

      {/* Restaurant Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredRestaurants.map((place) => {
          const currentImgIndex = activeImageIndices[place.id] || 0;
          const displayImages = place.images && place.images.length > 0 ? place.images : [place.imageUrl];

          return (
            <div
              key={place.id}
              className="bg-white rounded-3xl border border-sky-100 shadow-sm hover:shadow-lg transition-all duration-200 flex flex-col overflow-hidden group"
            >
              {/* Photo Carousel Container */}
              <div className="relative aspect-video w-full bg-slate-900 overflow-hidden select-none">
                <img
                  src={displayImages[currentImgIndex]}
                  alt={place.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />

                {/* Prev / Next Arrows */}
                {displayImages.length > 1 && (
                  <>
                    <button
                      onClick={(e) => handlePrevImage(place.id, displayImages.length, e)}
                      className="absolute left-2.5 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/60 hover:bg-black/80 text-white flex items-center justify-center backdrop-blur-xs transition-colors z-10"
                      title="Previous photo"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <button
                      onClick={(e) => handleNextImage(place.id, displayImages.length, e)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/60 hover:bg-black/80 text-white flex items-center justify-center backdrop-blur-xs transition-colors z-10"
                      title="Next photo"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </>
                )}

                {/* Top Badges */}
                <div className="absolute top-3 left-3 flex flex-wrap items-center gap-1.5 z-10">
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/90 text-white text-[11px] font-bold backdrop-blur-xs shadow-xs">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Google Maps Verified</span>
                  </span>
                  {place.foodType === 'pure_veg' && (
                    <span className="px-2.5 py-1 rounded-full bg-emerald-600/90 text-white text-[11px] font-bold backdrop-blur-xs">
                      Pure Veg
                    </span>
                  )}
                </div>

                {/* Bottom Slide Indicators & Rating */}
                <div className="absolute bottom-3 inset-x-3 flex items-center justify-between z-10">
                  <div className="flex items-center gap-1 bg-black/50 px-2 py-0.5 rounded-full backdrop-blur-xs">
                    {displayImages.map((_, idx) => (
                      <span
                        key={idx}
                        className={`w-1.5 h-1.5 rounded-full transition-all ${
                          idx === currentImgIndex ? 'bg-amber-400 w-3' : 'bg-white/60'
                        }`}
                      />
                    ))}
                  </div>

                  <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-950/80 text-amber-300 text-xs font-bold backdrop-blur-xs">
                    <Star className="w-3.5 h-3.5 fill-amber-300" />
                    <span>{place.rating}</span>
                    <span className="text-slate-300 text-[10px]">({place.reviewCount})</span>
                  </div>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="text-lg font-bold text-slate-900 group-hover:text-sky-600 transition-colors font-heading leading-snug">
                      {place.name}
                    </h3>
                  </div>

                  {/* Locality & Address */}
                  <div className="flex items-center gap-1.5 text-xs text-slate-600">
                    <MapPin className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                    <span className="font-semibold text-slate-800">{place.locality}</span>
                    <span className="text-slate-400">•</span>
                    <span>{place.city}</span>
                  </div>

                  <p className="text-xs text-slate-500 line-clamp-1">
                    {place.address}
                  </p>

                  {/* Cuisine & Price */}
                  <div className="pt-1 flex flex-wrap items-center justify-between gap-2 text-xs">
                    <span className="px-2.5 py-1 rounded-lg bg-sky-50 text-sky-800 font-semibold border border-sky-100 line-clamp-1 max-w-[200px]">
                      {place.cuisine}
                    </span>
                    <span className="font-bold text-slate-900">
                      {place.priceRange}
                    </span>
                  </div>

                  {/* Hours & Phone info */}
                  <div className="pt-2 grid grid-cols-2 gap-2 text-[11px] text-slate-600 border-t border-slate-100">
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">{place.operatingHours}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <a 
                        href={`tel:${place.phone.replace(/[^0-9+]/g, '')}`} 
                        className="truncate font-semibold text-emerald-700 hover:underline"
                        title="Call restaurant"
                      >
                        {place.phone}
                      </a>
                    </div>
                  </div>

                  {/* Popular Dishes / Highlights */}
                  {place.highlights && place.highlights.length > 0 && (
                    <div className="pt-2">
                      <span className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                        Popular Specialties:
                      </span>
                      <div className="flex flex-wrap gap-1">
                        {place.highlights.slice(0, 3).map((item, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[11px] font-medium"
                          >
                            {item}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Action Buttons: Direct Visit & Copy Link & Call */}
                <div className="pt-4 border-t border-slate-100 space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    {/* Direct Visit Button to Google Maps */}
                    <a
                      href={place.gmapUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#881337] to-[#be123c] hover:from-[#700f2b] hover:to-[#9f1239] text-white font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all hover:shadow-md ring-1 ring-rose-400/30"
                      title="Open directly in Google Maps"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Visit on G-Map</span>
                    </a>

                    {/* Copy Link Button */}
                    <button
                      onClick={() => handleCopyLink(place.gmapUrl, place.id)}
                      className={`py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all border ${
                        copiedId === place.id
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                      }`}
                      title="Copy Google Maps Shortlink"
                    >
                      {copiedId === place.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-slate-500" />
                          <span>Copy Link</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    {/* Direct Phone Call */}
                    <a
                      href={`tel:${place.phone.replace(/[^0-9+]/g, '')}`}
                      className="py-2 px-3 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-semibold text-xs flex items-center justify-center gap-1.5 border border-emerald-200 transition-colors"
                    >
                      <Phone className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Call Now</span>
                    </a>

                    {/* Reserve / Inquire Button */}
                    <button
                      onClick={() => handleOpenReservation(place)}
                      className="py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <Compass className="w-3.5 h-3.5 text-slate-600" />
                      <span>Table / Inquire</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Reservation / Inquiry Modal */}
      {reserveModalOpen && selectedPlace && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="w-full max-w-lg rounded-3xl bg-white border border-sky-200 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 p-6 space-y-5 text-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <UtensilsCrossed className="w-5 h-5 text-sky-600" />
                <h3 className="text-lg font-bold font-heading">
                  Table Reservation & Inquiry
                </h3>
              </div>
              <button onClick={() => setReserveModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            {reserveConfirmed ? (
              <div className="py-6 text-center space-y-4">
                <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center">
                  <Check className="w-8 h-8 stroke-[2.5]" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-xl font-bold font-heading text-slate-900">
                    Reservation Requested!
                  </h4>
                  <p className="text-sm text-slate-600 max-w-sm mx-auto">
                    Your table request at <strong className="text-sky-700">{selectedPlace.name}</strong> has been logged. You can also connect directly via phone.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-sky-50 border border-sky-100 text-xs text-left space-y-1.5 font-medium text-slate-700">
                  <p><strong>Restaurant:</strong> {selectedPlace.name}</p>
                  <p><strong>Location:</strong> {selectedPlace.address}</p>
                  <p><strong>Direct Contact:</strong> {selectedPlace.phone}</p>
                  <p><strong>Slot:</strong> {reserveDate} ({guestCount} Guests)</p>
                </div>

                <div className="flex gap-3">
                  <a
                    href={selectedPlace.gmapUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 py-3 font-bold rounded-xl bg-gradient-to-r from-sky-600 to-cyan-600 text-white text-xs flex items-center justify-center gap-2"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>Open in Google Maps</span>
                  </a>
                  <button
                    onClick={() => setReserveModalOpen(false)}
                    className="flex-1 py-3 font-bold rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs"
                  >
                    Done
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleConfirmReservation} className="space-y-4 text-xs">
                <div className="p-3.5 rounded-2xl bg-sky-50 border border-sky-100 flex items-center gap-3">
                  <img
                    src={selectedPlace.imageUrl}
                    alt={selectedPlace.name}
                    className="w-12 h-12 rounded-xl object-cover"
                  />
                  <div>
                    <h4 className="font-bold text-sm text-slate-900">{selectedPlace.name}</h4>
                    <p className="text-slate-600">{selectedPlace.locality}, {selectedPlace.city}</p>
                    <p className="text-emerald-700 font-semibold">{selectedPlace.operatingHours}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="font-bold text-slate-700 flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-sky-600" />
                      Number of Guests
                    </label>
                    <select
                      value={guestCount}
                      onChange={(e) => setGuestCount(Number(e.target.value))}
                      className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500 font-medium"
                    >
                      {[1, 2, 3, 4, 5, 6, 8, 10].map(n => (
                        <option key={n} value={n}>{n} {n === 1 ? 'Guest' : 'Guests'}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="font-bold text-slate-700 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-sky-600" />
                      Date & Preferred Slot
                    </label>
                    <input
                      type="text"
                      value={reserveDate}
                      onChange={(e) => setReserveDate(e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500 font-medium"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Contact Name</label>
                  <input
                    type="text"
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500 font-medium"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Contact Phone</label>
                  <input
                    type="tel"
                    value={guestPhone}
                    onChange={(e) => setGuestPhone(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500 font-medium"
                    required
                  />
                </div>

                <div className="pt-2 flex items-center gap-3">
                  <a
                    href={selectedPlace.gmapUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 py-3 font-bold rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-center flex items-center justify-center gap-1.5"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>View on Maps</span>
                  </a>
                  <button
                    type="submit"
                    className="flex-1 py-3 font-bold rounded-xl bg-gradient-to-r from-sky-600 to-cyan-600 hover:from-sky-700 hover:to-cyan-700 text-white shadow-md transition-all"
                  >
                    Confirm Table Request
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
