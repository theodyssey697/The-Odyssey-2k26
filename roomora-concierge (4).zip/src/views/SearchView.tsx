import React, { useState, useEffect } from 'react';
import { 
  Search, 
  SlidersHorizontal, 
  RotateCcw, 
  MapPin, 
  Building, 
  IndianRupee, 
  Check, 
  Sparkles, 
  Scale, 
  ArrowUpDown,
  Filter
} from 'lucide-react';
import { Property } from '../types';
import { PropertyCard } from '../components/PropertyCard';

interface SearchViewProps {
  onSelectProperty: (prop: Property) => void;
  onScheduleVisit: (prop: Property) => void;
  onAskConcierge: (prop: Property) => void;
  savedPropertyIds: string[];
  onToggleSaveProperty: (id: string) => void;
  onOpenCompare: (props: Property[]) => void;
  onOpenMessAdminLogin?: (prop: Property) => void;
}

export const SearchView: React.FC<SearchViewProps> = ({
  onSelectProperty,
  onScheduleVisit,
  onAskConcierge,
  savedPropertyIds,
  onToggleSaveProperty,
  onOpenCompare,
  onOpenMessAdminLogin
}) => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  
  // Filter States
  const [searchQuery, setSearchQuery] = useState('');
  const [locality, setLocality] = useState('all');
  const [roomType, setRoomType] = useState('all');
  const [gender, setGender] = useState('all');
  const [furnished, setFurnished] = useState('all');
  const [maxPrice, setMaxPrice] = useState(8000);
  const [verifiedOnly, setVerifiedOnly] = useState(false);
  const [attachedBath, setAttachedBath] = useState(false);
  const [wifi, setWifi] = useState(false);
  const [meals, setMeals] = useState(false);
  const [sortBy, setSortBy] = useState<'relevance' | 'price_asc' | 'price_desc' | 'distance' | 'availability'>('relevance');

  // Compare Tray State (up to 3 properties)
  const [comparedIds, setComparedIds] = useState<string[]>([]);
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  // Fetch properties from backend
  const fetchProperties = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (searchQuery) params.set('search', searchQuery);
      if (locality !== 'all') params.set('locality', locality);
      if (roomType !== 'all') params.set('roomType', roomType);
      if (gender !== 'all') params.set('gender', gender);
      if (furnished !== 'all') params.set('furnished', furnished);
      if (maxPrice < 8000) params.set('maxPrice', maxPrice.toString());
      if (verifiedOnly) params.set('verifiedOnly', 'true');
      if (attachedBath) params.set('attachedBath', 'true');
      if (wifi) params.set('wifi', 'true');
      if (meals) params.set('meals', 'true');
      if (sortBy !== 'relevance') params.set('sortBy', sortBy);

      const res = await fetch(`/api/properties?${params.toString()}`);
      const data = await res.json();
      setProperties(data.properties || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProperties();
  }, [locality, roomType, gender, furnished, maxPrice, verifiedOnly, attachedBath, wifi, meals, sortBy]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchProperties();
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setLocality('all');
    setRoomType('all');
    setGender('all');
    setFurnished('all');
    setMaxPrice(8000);
    setVerifiedOnly(false);
    setAttachedBath(false);
    setWifi(false);
    setMeals(false);
    setSortBy('relevance');
  };

  const handleToggleCompare = (id: string) => {
    if (comparedIds.includes(id)) {
      setComparedIds(comparedIds.filter(i => i !== id));
    } else {
      if (comparedIds.length >= 3) {
        alert('You can compare a maximum of 3 properties side-by-side.');
        return;
      }
      setComparedIds([...comparedIds, id]);
    }
  };

  const selectedForCompare = properties.filter(p => comparedIds.includes(p.id));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Top Banner & Quick Search */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-heading">
            Student Accommodations Discovery
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            Verified PGs, student messes, and hostels in Bhubaneswar & Balasore with direct Google Maps links and real-time bed tracking
          </p>
        </div>

        {/* Search input form */}
        <form onSubmit={handleSearchSubmit} className="flex items-center gap-2 max-w-md w-full">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by PG name, mess, Balasore, or locality..."
              className="w-full text-xs py-2.5 pl-9 pr-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-hidden focus:ring-2 focus:ring-amber-500/50"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2.5 text-xs font-bold rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 hover:opacity-90 shrink-0"
          >
            Search
          </button>
          <button
            type="button"
            onClick={() => setMobileFilterOpen(!mobileFilterOpen)}
            className="lg:hidden p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200"
          >
            <Filter className="w-4 h-4" />
          </button>
        </form>
      </div>



      {/* Main Grid: Sidebar Filters + Property Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 items-start">
        
        {/* Desktop Sidebar Filters */}
        <aside className={`lg:block ${mobileFilterOpen ? 'block' : 'hidden'} lg:col-span-1 p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 shadow-sm space-y-6 text-xs sticky top-20`}>
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2 font-bold text-slate-900 dark:text-white font-heading">
              <SlidersHorizontal className="w-4 h-4 text-amber-500" />
              <span>Filter Accommodations</span>
            </div>
            <button
              onClick={handleResetFilters}
              className="text-[11px] text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1 font-medium"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset</span>
            </button>
          </div>

          {/* Locality */}
          <div>
            <label className="font-bold text-slate-800 dark:text-slate-200 block mb-1.5">Locality / City</label>
            <select
              value={locality}
              onChange={(e) => setLocality(e.target.value)}
              className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
            >
              <option value="all">All Locations (All Cities)</option>
              <optgroup label="📍 Balasore (17 Google Maps Verified Messes)">
                <option value="Balasore">All Balasore Messes (17 Places)</option>
                <option value="Bhimpura">Balasore - Bhimpura (Pradhan Ladies Mess)</option>
                <option value="Sidheswar Colony">Balasore - Sidheswar Colony (Freedom Mess)</option>
                <option value="Sahadevkhunta">Balasore - Sahadevkhunta (SAHU MESS)</option>
                <option value="Near ITI Square">Balasore - ITI Square (Mohapatra mess)</option>
                <option value="Station Road">Balasore - Station Road (Sai Krishna mess)</option>
                <option value="Januganj">Balasore - Januganj (Krishna Boys, Sunrise, Satyabadi)</option>
                <option value="Gopalbindha">Balasore - Gopalbindha (Best Mess, Panda, Pradhan)</option>
                <option value="Purusottampur">Balasore - Purusottampur (Annapurna mess)</option>
                <option value="Motiganj">Balasore - Motiganj (Discipline Boys, Trishakti)</option>
                <option value="Mallikashpur">Balasore - Mallikashpur (Student Zone Boys)</option>
                <option value="Remuna">Balasore - Remuna (Aadarsh Boys Mess)</option>
                <option value="Sergarh">Balasore - Sergarh / BCET (Engineering Boys Mess)</option>
              </optgroup>
              <optgroup label="🏛️ Bhubaneswar Student Areas">
                <option value="Bhubaneswar">All Bhubaneswar PGs</option>
                <option value="Patia">Patia (KIIT Campuses 1-15)</option>
                <option value="Khandagiri">Khandagiri (ITER / SOA University)</option>
                <option value="Chandrasekharpur">Chandrasekharpur (Infocity / CS Pur)</option>
              </optgroup>
            </select>
          </div>

          {/* Monthly Budget Range */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="font-bold text-slate-800 dark:text-slate-200">Max Monthly Rent</label>
              <span className="font-extrabold text-amber-600 dark:text-amber-400 font-heading">
                ₹{maxPrice.toLocaleString('en-IN')}
              </span>
            </div>
            <input
              type="range"
              min="2000"
              max="8000"
              step="250"
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              className="w-full accent-amber-500"
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-0.5">
              <span>₹2,000</span>
              <span>₹8,000+</span>
            </div>
          </div>

          {/* Room Type */}
          <div>
            <label className="font-bold text-slate-800 dark:text-slate-200 block mb-1.5">Room Sharing Type</label>
            <select
              value={roomType}
              onChange={(e) => setRoomType(e.target.value)}
              className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
            >
              <option value="all">Any Room Configuration</option>
              <option value="double_sharing">Double Sharing (Standard)</option>
              <option value="triple_sharing">Triple Sharing (Budget)</option>
              <option value="single_private">Single Private Room (Studio)</option>
            </select>
          </div>

          {/* Gender Preference */}
          <div>
            <label className="font-bold text-slate-800 dark:text-slate-200 block mb-1.5">Gender Preference</label>
            <div className="grid grid-cols-3 gap-1.5">
              {(['all', 'boys', 'girls'] as const).map((g) => (
                <button
                  key={g}
                  type="button"
                  onClick={() => setGender(g)}
                  className={`py-1.5 rounded-lg border font-semibold capitalize text-center ${
                    gender === g
                      ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>

          {/* Furnishing */}
          <div>
            <label className="font-bold text-slate-800 dark:text-slate-200 block mb-1.5">Furnishing</label>
            <select
              value={furnished}
              onChange={(e) => setFurnished(e.target.value)}
              className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
            >
              <option value="all">Any Furnishing</option>
              <option value="fully_furnished">Fully Furnished</option>
              <option value="semi_furnished">Semi Furnished</option>
            </select>
          </div>

          {/* Must-Have Amenities Toggles */}
          <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <label className="font-bold text-slate-800 dark:text-slate-200 block">Must-Have Amenities</label>
            
            <label className="flex items-center gap-2 cursor-pointer text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={attachedBath}
                onChange={(e) => setAttachedBath(e.target.checked)}
                className="accent-amber-500 rounded"
              />
              <span>Attached Washroom</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={wifi}
                onChange={(e) => setWifi(e.target.checked)}
                className="accent-amber-500 rounded"
              />
              <span>High-speed Wi-Fi</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={meals}
                onChange={(e) => setMeals(e.target.checked)}
                className="accent-amber-500 rounded"
              />
              <span>Food / Meals Included</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={verifiedOnly}
                onChange={(e) => setVerifiedOnly(e.target.checked)}
                className="accent-emerald-500 rounded"
              />
              <span className="font-semibold text-emerald-700 dark:text-emerald-400">Platform Verified Only</span>
            </label>
          </div>

        </aside>

        {/* Properties Results Section */}
        <div className="lg:col-span-3 space-y-5">
          
          {/* Sorting & Result Count Bar */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 text-xs">
            <span className="font-bold text-slate-900 dark:text-white">
              Showing {properties.length} Available Stays
            </span>

            <div className="flex items-center gap-2">
              <span className="text-slate-500 dark:text-slate-400">Sort by:</span>
              <select
                value={sortBy}
                onChange={(e: any) => setSortBy(e.target.value)}
                className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-medium"
              >
                <option value="relevance">Relevance & Fair-Rent</option>
                <option value="price_asc">Price: Low to High</option>
                <option value="price_desc">Price: High to Low</option>
                <option value="distance">Proximity to Campus</option>
                <option value="availability">Immediate Vacancy</option>
              </select>
            </div>
          </div>

          {/* Properties Grid */}
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[1, 2, 3, 4].map((n) => (
                <div key={n} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-4 animate-pulse">
                  <div className="aspect-16/10 bg-slate-200 dark:bg-slate-800 rounded-xl" />
                  <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded w-3/4" />
                  <div className="h-3 bg-slate-200 dark:bg-slate-800 rounded w-1/2" />
                  <div className="h-8 bg-slate-200 dark:bg-slate-800 rounded" />
                </div>
              ))}
            </div>
          ) : properties.length === 0 ? (
            <div className="p-12 text-center rounded-2xl border border-dashed border-slate-300 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3">
              <Building className="w-10 h-10 text-slate-400 mx-auto" />
              <h3 className="text-base font-bold text-slate-900 dark:text-white font-heading">
                No matching accommodations found
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
                Try widening your monthly budget or adjusting locality filters. Or ask the AI Concierge to scour unlisted options.
              </p>
              <button
                onClick={handleResetFilters}
                className="px-4 py-2 text-xs font-bold rounded-xl bg-slate-900 text-white dark:bg-white dark:text-slate-900"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {properties.map((prop) => (
                <PropertyCard
                  key={prop.id}
                  property={prop}
                  onSelect={onSelectProperty}
                  onScheduleVisit={onScheduleVisit}
                  onAskConcierge={onAskConcierge}
                  isSaved={savedPropertyIds.includes(prop.id)}
                  onToggleSave={onToggleSaveProperty}
                  isCompared={comparedIds.includes(prop.id)}
                  onToggleCompare={handleToggleCompare}
                  onOpenMessAdminLogin={onOpenMessAdminLogin}
                />
              ))}
            </div>
          )}

        </div>

      </div>

      {/* Floating Compare Tray (when 1 or more are selected) */}
      {comparedIds.length > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 bg-slate-900 text-white dark:bg-white dark:text-slate-950 px-5 py-3 rounded-2xl shadow-2xl border border-slate-700 dark:border-slate-200 flex items-center gap-4 text-xs animate-in slide-in-from-bottom duration-200">
          <div className="flex items-center gap-2">
            <Scale className="w-4 h-4 text-amber-400" />
            <span className="font-bold">
              Comparing {comparedIds.length}/3 stays
            </span>
          </div>

          <button
            onClick={() => onOpenCompare(selectedForCompare)}
            className="px-4 py-1.5 font-bold rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 transition-colors shadow-sm"
          >
            Open Matrix
          </button>

          <button
            onClick={() => setComparedIds([])}
            className="text-[11px] text-slate-400 hover:text-white dark:hover:text-slate-900 underline"
          >
            Clear
          </button>
        </div>
      )}

    </div>
  );
};
