import React, { useState } from 'react';
import { Lock, Mail, ArrowRight, ArrowLeft, ShieldCheck, AlertCircle } from 'lucide-react';

interface AdminAuthViewProps {
  onSuccessAdminLogin: () => void;
  onBackToEntrance: () => void;
}

export const AdminAuthView: React.FC<AdminAuthViewProps> = ({ onSuccessAdminLogin, onBackToEntrance }) => {
  const [email, setEmail] = useState('admin@roomora.concierge');
  const [password, setPassword] = useState('odyssey2026');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    // Verify authorized admin credentials
    if (email === 'admin@roomora.concierge' && password === 'odyssey2026') {
      onSuccessAdminLogin();
    } else {
      setErrorMsg('Unauthorized credentials. Only authorized platform administrators may access this portal.');
    }
  };

  return (
    <div className="min-h-screen w-full navy-gradient flex flex-col items-center justify-center p-4 sm:p-6 relative">
      
      {/* Back button */}
      <button
        onClick={onBackToEntrance}
        className="absolute top-6 left-6 text-xs font-bold text-slate-300 hover:text-white flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Role Selection</span>
      </button>

      <div className="max-w-md w-full rounded-3xl bg-slate-900/90 backdrop-blur-xl border border-indigo-500/40 p-8 shadow-2xl space-y-6 relative overflow-hidden">
        
        <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="text-center space-y-2 relative z-10">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center mx-auto font-bold">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-black text-white font-heading">
            Administrator Portal
          </h2>
          <p className="text-xs text-slate-400">
            Secure admin clearance required. Property verification, bookings, reports, and agent monitoring.
          </p>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-red-500/20 border border-red-500/40 text-xs text-red-300 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleAdminLogin} className="space-y-4 text-xs relative z-10">
          <div>
            <label className="font-semibold text-slate-300 block mb-1">Admin Email</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@roomora.concierge"
                required
                className="w-full p-3 pl-9 rounded-xl border border-slate-700 bg-slate-950 text-white focus:ring-2 focus:ring-indigo-500 outline-hidden font-mono"
              />
            </div>
          </div>

          <div>
            <label className="font-semibold text-slate-300 block mb-1">Security Passcode</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full p-3 pl-9 rounded-xl border border-slate-700 bg-slate-950 text-white focus:ring-2 focus:ring-indigo-500 outline-hidden font-mono"
              />
            </div>
          </div>

          <div className="p-3 rounded-xl bg-indigo-950/40 border border-indigo-900/60 text-[11px] text-indigo-300">
            <strong>Security Notice:</strong> Student accounts cannot access this portal. All administrative actions are audit-logged.
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all"
          >
            <span>Authenticate as Administrator</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

      </div>
    </div>
  );
};
