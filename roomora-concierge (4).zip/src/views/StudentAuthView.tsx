import React, { useState } from 'react';
import { 
  Mail, 
  Lock, 
  User, 
  ArrowRight, 
  Sparkles, 
  ArrowLeft, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  LogOut, 
  ShieldCheck, 
  Send
} from 'lucide-react';
import { auth } from '../firebaseConfig';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  sendEmailVerification, 
  sendPasswordResetEmail,
  signOut,
  updateProfile
} from 'firebase/auth';

interface StudentAuthViewProps {
  onSuccessLogin: (userData: { name: string; email: string }) => void;
  onBackToEntrance: () => void;
}

export const StudentAuthView: React.FC<StudentAuthViewProps> = ({ onSuccessLogin, onBackToEntrance }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [isForgot, setIsForgot] = useState(false);

  // Verification Pending Screen state
  const [isVerificationPending, setIsVerificationPending] = useState(false);
  const [pendingEmail, setPendingEmail] = useState('');
  const [pendingName, setPendingName] = useState('');

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);

  const startCooldown = () => {
    setResendCooldown(60);
    const timer = setInterval(() => {
      setResendCooldown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);
    setLoading(true);

    if (isForgot) {
      try {
        await sendPasswordResetEmail(auth, email.trim());
        setSuccessMsg(`Password reset link sent to ${email.trim()}. Please check your inbox.`);
        setIsForgot(false);
      } catch (err: any) {
        setErrorMsg('Could not send reset email. Please ensure the email address is registered.');
      } finally {
        setLoading(false);
      }
      return;
    }

    try {
      if (isRegister) {
        // Real Student Registration with Gmail/Password
        const userCredential = await createUserWithEmailAndPassword(auth, email.trim(), password);
        
        // Update display name if provided
        if (name.trim()) {
          try {
            await updateProfile(userCredential.user, { displayName: name.trim() });
          } catch (pErr) {
            console.error('Error updating student profile name:', pErr);
          }
        }

        // Send real Firebase email verification
        await sendEmailVerification(userCredential.user);
        
        setPendingEmail(email.trim());
        setPendingName(name.trim() || 'Student');
        setIsVerificationPending(true);
        startCooldown();
        setSuccessMsg(`A verification link has been sent to ${email.trim()}. Please verify your email before accessing student features.`);
      } else {
        // Sign In
        const userCredential = await signInWithEmailAndPassword(auth, email.trim(), password);
        
        // Strict verification check: Allow access only after email verification
        if (!userCredential.user.emailVerified) {
          setPendingEmail(userCredential.user.email || email.trim());
          setPendingName(userCredential.user.displayName || 'Student');
          setIsVerificationPending(true);
          setErrorMsg('Your email is not verified yet. Please verify your Gmail to access protected student features.');
          setLoading(false);
          return;
        }

        // Successful verified login
        onSuccessLogin({ 
          name: userCredential.user.displayName || name || 'Student', 
          email: userCredential.user.email || email.trim() 
        });
      }
    } catch (error: any) {
      console.error('Firebase Auth Error:', error);
      if (error.code === 'auth/user-already-exists' || error.code === 'auth/email-already-in-use') {
        setErrorMsg('User already exists. Please sign in');
      } else if (error.code === 'auth/weak-password') {
        setErrorMsg('Password should be at least 6 characters.');
      } else if (error.code === 'auth/invalid-email') {
        setErrorMsg('Please enter a valid Gmail or student email address.');
      } else {
        setErrorMsg('Email or password is incorrect');
      }
    } finally {
      setLoading(false);
    }
  };

  // Handle checking verification status
  const handleCheckVerification = async () => {
    setErrorMsg(null);
    setSuccessMsg(null);
    setLoading(true);

    try {
      if (!auth.currentUser) {
        setErrorMsg('Session expired. Please sign in again.');
        setIsVerificationPending(false);
        setLoading(false);
        return;
      }

      // Reload user from Firebase Auth to get the freshest emailVerified state
      await auth.currentUser.reload();

      if (auth.currentUser.emailVerified) {
        setSuccessMsg('Email verified successfully! Welcome to Roomora Concierge.');
        setTimeout(() => {
          onSuccessLogin({
            name: auth.currentUser?.displayName || pendingName || 'Student',
            email: auth.currentUser?.email || pendingEmail
          });
        }, 800);
      } else {
        setErrorMsg(
          'Email not verified yet. Please open the link sent by Firebase in your email inbox or spam folder, then click this button again.'
        );
      }
    } catch (err: any) {
      console.error('Error reloading user status:', err);
      setErrorMsg(err.message || 'Error checking verification status.');
    } finally {
      setLoading(false);
    }
  };

  // Handle resending verification email
  const handleResendVerification = async () => {
    if (resendCooldown > 0) return;
    setErrorMsg(null);
    setSuccessMsg(null);
    setLoading(true);

    try {
      if (!auth.currentUser) {
        setErrorMsg('Please sign in first to resend verification.');
        setIsVerificationPending(false);
        setLoading(false);
        return;
      }

      await sendEmailVerification(auth.currentUser);
      setSuccessMsg(`Verification email resent to ${auth.currentUser.email}! Please check your inbox and spam folder.`);
      startCooldown();
    } catch (err: any) {
      console.error('Resend error:', err);
      if (err.code === 'auth/too-many-requests') {
        setErrorMsg('Too many requests. Please wait a minute before requesting another verification email.');
      } else {
        setErrorMsg('Failed to send verification email. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  // Handle sign out from verification screen
  const handleCancelAndSignOut = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.error(err);
    }
    setIsVerificationPending(false);
    setEmail('');
    setPassword('');
    setErrorMsg(null);
    setSuccessMsg(null);
  };

  // Render Verification Pending Screen
  if (isVerificationPending) {
    return (
      <div className="min-h-screen w-full navy-gradient flex flex-col items-center justify-center p-4 sm:p-6 relative">
        <div className="max-w-md w-full rounded-3xl bg-slate-900/95 backdrop-blur-xl border border-amber-500/40 p-8 shadow-2xl space-y-6 text-center">
          
          <div className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center mx-auto shadow-inner">
            <Mail className="w-7 h-7 text-amber-400 animate-bounce" />
          </div>

          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1 px-3 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
              <ShieldCheck className="w-3 h-3" />
              <span>GMAIL VERIFICATION REQUIRED</span>
            </div>
            <h2 className="text-2xl font-black text-white font-heading">
              Verify Your Email Address
            </h2>
            <p className="text-xs text-slate-300 max-w-sm mx-auto">
              We sent a real verification link to:
            </p>
            <div className="font-mono text-sm font-bold text-amber-300 bg-slate-950/80 p-2.5 rounded-xl border border-slate-800 break-all">
              {pendingEmail || auth.currentUser?.email}
            </div>
          </div>

          <p className="text-[11px] text-slate-400 leading-relaxed">
            To prevent fraud and guarantee verified student accommodations, access to protected features (stay bookings, AI Concierge, meal orders) is granted only after email verification.
          </p>

          {successMsg && (
            <div className="p-3.5 rounded-xl bg-emerald-950/80 border border-emerald-500/60 text-xs text-emerald-200 flex items-start gap-2 text-left">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>{successMsg}</span>
            </div>
          )}

          {errorMsg && (
            <div className="p-3.5 rounded-xl bg-red-950/80 border border-red-500/60 text-xs text-red-200 flex items-start gap-2 text-left">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div className="space-y-3 pt-2">
            <button
              onClick={handleCheckVerification}
              disabled={loading}
              className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs sm:text-sm shadow-lg flex items-center justify-center gap-2 transition-all disabled:opacity-50"
            >
              {loading ? (
                <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
              ) : (
                <RefreshCw className="w-4 h-4" />
              )}
              <span>I've Verified My Email (Check Status)</span>
            </button>

            <button
              onClick={handleResendVerification}
              disabled={resendCooldown > 0 || loading}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
            >
              <Send className="w-3.5 h-3.5 text-amber-400" />
              <span>
                {resendCooldown > 0 ? `Resend Email in ${resendCooldown}s` : 'Resend Verification Email'}
              </span>
            </button>

            <button
              onClick={handleCancelAndSignOut}
              className="w-full py-2 text-xs font-semibold text-slate-400 hover:text-white flex items-center justify-center gap-1.5 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out / Use Different Email</span>
            </button>
          </div>

        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full navy-gradient flex flex-col items-center justify-center p-4 sm:p-6 relative">
      
      {/* Back button */}
      <button
        onClick={onBackToEntrance}
        className="absolute top-6 left-6 text-xs font-bold text-slate-300 hover:text-white flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Role Selection</span>
      </button>

      <div className="max-w-md w-full rounded-3xl bg-slate-900/90 backdrop-blur-xl border border-slate-700 p-8 shadow-2xl space-y-6">
        
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center mx-auto font-bold">
            🎓
          </div>
          <h2 className="text-2xl font-black text-white font-heading">
            {isForgot ? 'Reset Student Password' : isRegister ? 'Student Registration' : 'Student Portal Login'}
          </h2>
          <p className="text-xs text-slate-400">
            {isForgot
              ? 'Enter your student Gmail to receive password reset link.'
              : isRegister
              ? 'Register with Gmail & password. A real verification email will be sent.'
              : 'Sign in to access AI Concierge, saved stays, and visits.'}
          </p>
        </div>

        {successMsg && (
          <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-xs text-emerald-300 flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>{successMsg}</span>
          </div>
        )}

        {errorMsg && (
          <div className="p-3 rounded-xl bg-red-500/20 border border-red-500/40 text-xs text-red-300 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          
          {isRegister && (
            <div>
              <label className="font-semibold text-slate-300 block mb-1">Full Name</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g., Aryan Sharma"
                  required
                  className="w-full p-3 pl-9 rounded-xl border border-slate-700 bg-slate-950 text-white focus:ring-2 focus:ring-amber-500 outline-hidden"
                />
              </div>
            </div>
          )}

          <div>
            <label className="font-semibold text-slate-300 block mb-1">Student Gmail / Institutional Email</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="student@gmail.com"
                required
                className="w-full p-3 pl-9 rounded-xl border border-slate-700 bg-slate-950 text-white focus:ring-2 focus:ring-amber-500 outline-hidden font-mono"
              />
            </div>
          </div>

          {!isForgot && (
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="font-semibold text-slate-300">Password</label>
                {!isRegister && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsForgot(true);
                      setErrorMsg(null);
                      setSuccessMsg(null);
                    }}
                    className="text-[11px] text-amber-400 hover:underline"
                  >
                    Forgot password?
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="w-full p-3 pl-9 rounded-xl border border-slate-700 bg-slate-950 text-white focus:ring-2 focus:ring-amber-500 outline-hidden"
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs sm:text-sm shadow-md transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading ? (
              <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <span>{isForgot ? 'Send Recovery Link' : isRegister ? 'Create Account & Verify Gmail' : 'Sign In to Student Portal'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Toggle Register / Login / Back */}
        <div className="text-center pt-2 text-xs text-slate-400">
          {isForgot ? (
            <button 
              onClick={() => {
                setIsForgot(false);
                setErrorMsg(null);
                setSuccessMsg(null);
              }} 
              className="text-amber-400 hover:underline font-semibold"
            >
              Remembered password? Sign In
            </button>
          ) : isRegister ? (
            <span>
              Already have a student account?{' '}
              <button 
                onClick={() => {
                  setIsRegister(false);
                  setErrorMsg(null);
                  setSuccessMsg(null);
                }} 
                className="text-amber-400 hover:underline font-semibold"
              >
                Sign In
              </button>
            </span>
          ) : (
            <span>
              New student scholar?{' '}
              <button 
                onClick={() => {
                  setIsRegister(true);
                  setErrorMsg(null);
                  setSuccessMsg(null);
                }} 
                className="text-amber-400 hover:underline font-semibold"
              >
                Register here
              </button>
            </span>
          )}
        </div>

      </div>
    </div>
  );
};
