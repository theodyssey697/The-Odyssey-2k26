import React, { useState } from 'react';
import { 
  Sparkles, 
  ArrowRight, 
  ShieldCheck, 
  MapPin, 
  Calendar, 
  CheckCircle2, 
  HelpCircle, 
  Users, 
  Building2, 
  HeartHandshake, 
  UtensilsCrossed,
  Search,
  Check,
  ChevronDown,
  Layers,
  Cpu
} from 'lucide-react';
import { Property } from '../types';
import { PropertyCard } from '../components/PropertyCard';

interface LandingViewProps {
  onSearchGoal: (goal: string) => void;
  featuredProperties: Property[];
  onSelectProperty: (prop: Property) => void;
  onScheduleVisit: (prop: Property) => void;
  onAskConcierge: (prop: Property) => void;
  onNavigate: (tab: string) => void;
  onOpenMessAdminLogin?: (prop: Property) => void;
}

export const LandingView: React.FC<LandingViewProps> = ({
  onSearchGoal,
  featuredProperties,
  onSelectProperty,
  onScheduleVisit,
  onAskConcierge,
  onNavigate,
  onOpenMessAdminLogin
}) => {
  const [inputGoal, setInputGoal] = useState('');
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  const samplePrompts = [
    'Find me a verified sharing room in Patia, Bhubaneswar, under ₹3,500 per month, arrange a visit on Saturday, and show nearby mess services.',
    'Find a furnished girls PG within 2 km of KIIT Campus with food included under ₹4,500.',
    'Compare top 3 budget rooms in Patia and tell me which has best Wi-Fi and power backup.',
    'Monitor rooms under ₹4,000 in Patia and alert me when a vacancy appears.'
  ];

  const handlePromptSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputGoal.trim()) {
      onSearchGoal(inputGoal.trim());
    }
  };

  const handleChipClick = (prompt: string) => {
    setInputGoal(prompt);
    onSearchGoal(prompt);
  };

  const faqs = [
    {
      q: 'How does Roomora Concierge differ from standard rental portals like 99acres or MagicBricks?',
      a: 'Traditional portals just give you endless phone numbers to call. Roomora Concierge is an autonomous execution agent. You give it a natural-language goal (e.g., "Find room under ₹3,500, check availability, book a visit for Saturday, and find tiffin"), and it breaks down the tasks, calls backend tools, verifies live availability, and schedules the visit for you.'
    },
    {
      q: 'Will the AI make payments or share my documents without my permission?',
      a: 'Never. Roomora implements strict Human Approval Gates. Whenever an action involves money, booking commitments, or personal contact sharing, the agent enters a paused state and presents an explicit approval card. The LLM cannot bypass this security barrier.'
    },
    {
      q: 'What is the Fair-Rent & Scam Guard system?',
      a: 'Scam Guard audits every listing against historical rental averages in the locality (e.g., Patia, Khandagiri). If a broker lists an unrealistically low price to demand unrecorded cash deposits, or if host identity KYC is incomplete, Scam Guard flags the listing as "Information Incomplete" or "Under Review".'
    },
    {
      q: 'Which college campuses are currently mapped in Bhubaneswar?',
      a: 'Roomora currently covers KIIT Deemed University (Campuses 1-15), Silicon University, ITER / SOA University, IIIT Bhubaneswar, and AIIMS Bhubaneswar, with commute walking and transit estimates.'
    }
  ];

  return (
    <div className="space-y-20 pb-16">
      
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-8 sm:pt-14 pb-12 sm:pb-20">
        
        {/* Glow backdrop */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-amber-400/15 via-indigo-500/10 to-transparent blur-3xl pointer-events-none rounded-full" />

        {/* Floating Particles Animation */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {[...Array(15)].map((_, i) => {
            const size = Math.random() * 6 + 4;
            const top = Math.random() * 100;
            const left = Math.random() * 100;
            const duration = Math.random() * 6 + 6;
            const delay = Math.random() * 3;
            return (
              <div
                key={i}
                className="particle bg-amber-500/30 dark:bg-amber-400/30"
                style={{
                  width: `${size}px`,
                  height: `${size}px`,
                  top: `${top}%`,
                  left: `${left}%`,
                  animationDuration: `${duration}s`,
                  animationDelay: `${delay}s`,
                }}
              />
            );
          })}
        </div>

        <div className="max-w-5xl mx-auto px-4 sm:px-6 text-center space-y-6 relative z-10">
          
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800/80 shadow-xs">
            <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
            <span>Autonomous AI Student Accommodation Platform</span>
          </div>

          {/* Heading */}
          <h1 className="text-4xl sm:text-6xl font-extrabold text-slate-900 dark:text-white tracking-tight leading-tight font-heading">
            Your next stay. <br className="hidden sm:inline" />
            <span className="bg-gradient-to-r from-amber-600 via-amber-500 to-amber-700 bg-clip-text text-transparent">
              Found and handled by AI.
            </span>
          </h1>

          <p className="max-w-2xl mx-auto text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed font-normal">
            “Roomora finds stays. Roomora Concierge finishes the job.” Express your goal in plain words—our agent compares verified PGs, checks real-time beds, books visits, and finds hygienic student mess plans.
          </p>

          {/* Natural-Language Search Box */}
          <div className="max-w-3xl mx-auto pt-4">
            <form onSubmit={handlePromptSubmit} className="relative shadow-2xl rounded-2xl p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 transition-all focus-within:ring-2 focus-within:ring-amber-500/50">
              <div className="flex items-center gap-3 px-3 py-2">
                <Sparkles className="w-5 h-5 text-amber-500 shrink-0" />
                <input
                  type="text"
                  value={inputGoal}
                  onChange={(e) => setInputGoal(e.target.value)}
                  placeholder="e.g., Find me a verified sharing room in Patia under ₹3,500/mo, arrange a visit on Saturday, and show nearby mess..."
                  className="w-full text-sm sm:text-base text-slate-900 dark:text-white placeholder:text-slate-400 bg-transparent outline-hidden"
                />
                <button
                  type="submit"
                  className="px-5 py-3 rounded-xl bg-slate-950 dark:bg-white hover:bg-slate-800 dark:hover:bg-slate-100 text-white dark:text-slate-950 font-bold text-xs sm:text-sm shrink-0 flex items-center gap-1.5 transition-all shadow-md"
                >
                  <span>Engage Concierge</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>

            {/* Prompt Suggestion Chips */}
            <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-xs">
              <span className="text-slate-400 font-medium">Try asking:</span>
              {samplePrompts.map((prompt, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleChipClick(prompt)}
                  className="px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-800/80 hover:bg-amber-50 dark:hover:bg-amber-950/40 text-slate-700 dark:text-slate-300 hover:text-amber-700 dark:hover:text-amber-400 border border-slate-200 dark:border-slate-700 transition-colors text-left truncate max-w-xs sm:max-w-md"
                >
                  "{prompt.slice(0, 52)}..."
                </button>
              ))}
            </div>
          </div>

          {/* Quick Metrics Bar */}
          <div className="pt-8 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-3xl mx-auto">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800">
              <p className="text-xl font-extrabold text-slate-900 dark:text-white font-heading">100%</p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">On-Site Verified Stays</p>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800">
              <p className="text-xl font-extrabold text-slate-900 dark:text-white font-heading">₹3,400</p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">Avg Patia Student Rent</p>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800">
              <p className="text-xl font-extrabold text-slate-900 dark:text-white font-heading">&lt; 15 min</p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">Host Visit Confirmation</p>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800">
              <p className="text-xl font-extrabold text-slate-900 dark:text-white font-heading">Zero</p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">Unapproved AI Charges</p>
            </div>
          </div>

        </div>
      </section>

      {/* How the Agent Works in 3 Steps */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-xl mx-auto space-y-2 mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 font-heading">
            Autonomous Pipeline
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-heading">
            How Roomora Concierge Works
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            From natural language instruction to confirmed visits and meals
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Step 1 */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="w-12 h-12 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800 flex items-center justify-center font-bold text-lg font-heading">
              01
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white font-heading">
              Goal Understanding & Constraint Extraction
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Express anything like “Sharing room under ₹3,500 near KIIT Campus 6 for boys”. The agent extracts location, budget cap, room type, campus proximity, and food requirements into a structured task graph.
            </p>
          </div>

          {/* Step 2 */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="w-12 h-12 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 flex items-center justify-center font-bold text-lg font-heading">
              02
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white font-heading">
              Deterministic Tool Registry Execution
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              The agent sequentially calls 14 verified backend tools: searching stays, auditing Fair-Rent scores, checking real-time bed availability, calculating walking commute times, and coordinating with host visiting calendars.
            </p>
          </div>

          {/* Step 3 */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 flex items-center justify-center font-bold text-lg font-heading">
              03
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white font-heading">
              Human Approval Barrier & Resolution
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Before committing any financial deposit or booking a bed, the agent activates a Human Approval Gate. You inspect the exact breakdown and approve with one tap. Zero surprise commitments.
            </p>
          </div>

        </div>
      </section>

      {/* Featured Verified Accommodations */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 font-heading">
              Curated Student Living
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-heading mt-1">
              Verified Stays in Patia & Bhubaneswar
            </h2>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Inspected on-site with verified electric meters and Fair-Rent transparency
            </p>
          </div>
          <button
            onClick={() => onNavigate('search')}
            className="px-4 py-2 text-xs font-bold rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 hover:opacity-90 transition-opacity flex items-center gap-1.5"
          >
            <span>View All Listings</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredProperties.slice(0, 3).map((prop) => (
            <PropertyCard
              key={prop.id}
              property={prop}
              onSelect={onSelectProperty}
              onScheduleVisit={onScheduleVisit}
              onAskConcierge={onAskConcierge}
              onOpenMessAdminLogin={onOpenMessAdminLogin}
            />
          ))}
        </div>
      </section>

      {/* Benefits for Students, Parents, Hosts, and Mess Providers */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-xl mx-auto space-y-2 mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 font-heading">
            Multi-Stakeholder Architecture
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-heading">
            Value Across the Student Housing Ecosystem
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          
          <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 w-fit">
              <Users className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-sm text-slate-900 dark:text-white font-heading">For Students</h4>
            <ul className="space-y-1.5 text-slate-600 dark:text-slate-300">
              <li>• Natural language concierge finishes errands</li>
              <li>• Automated Vacancy Watch alerts</li>
              <li>• Walking distance to campus verified</li>
            </ul>
          </div>

          <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 w-fit">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-sm text-slate-900 dark:text-white font-heading">For Parents</h4>
            <ul className="space-y-1.5 text-slate-600 dark:text-slate-300">
              <li>• Biometric & warden security verification</li>
              <li>• Escrow protected deposits</li>
              <li>• 24x7 Emergency 112 & healthcare support</li>
            </ul>
          </div>

          <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 w-fit">
              <Building2 className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-sm text-slate-900 dark:text-white font-heading">For PG Owners</h4>
            <ul className="space-y-1.5 text-slate-600 dark:text-slate-300">
              <li>• Automated scheduled visit reminders</li>
              <li>• Verified student KYC profiles</li>
              <li>• High occupancy without broker cuts</li>
            </ul>
          </div>

          <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="p-2.5 rounded-xl bg-red-500/10 text-red-600 dark:text-red-400 w-fit">
              <UtensilsCrossed className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-sm text-slate-900 dark:text-white font-heading">For Mess Providers</h4>
            <ul className="space-y-1.5 text-slate-600 dark:text-slate-300">
              <li>• Direct monthly student meal subscriptions</li>
              <li>• Clean kitchen hygiene certification</li>
              <li>• Predictable meal counts</li>
            </ul>
          </div>

        </div>
      </section>

      {/* Safety & Fair-Rent Scam Guard */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="p-8 sm:p-10 rounded-3xl bg-slate-900 text-white border border-slate-800 relative overflow-hidden">
          <div className="max-w-2xl space-y-4 relative z-10">
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
              Zero Tolerance for Unethical Listings
            </span>
            <h3 className="text-2xl sm:text-3xl font-extrabold font-heading">
              Roomora Scam Guard & Trust Architecture
            </h3>
            <p className="text-sm text-slate-300 leading-relaxed">
              We distinguish <strong>Platform Verification</strong> from Government ID. Every verified stay in our network has been physically inspected by a Roomora campus agent, and electricity meter policies are audited against unfair surcharges.
            </p>
            <div className="pt-2 flex flex-wrap gap-4 text-xs text-slate-300">
              <div className="flex items-center gap-1.5">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Locality Fair-Rent Benchmark Checks</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Community Scam Reporting Queue</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>No Hidden Booking Fees</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials (Clearly labeled demo data) */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-xl mx-auto space-y-2 mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 font-heading">
            Student Feedback
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-heading">
            Loved by Campus Scholars
          </h2>
          <p className="text-xs text-slate-400 italic">
            *Sample demo testimonials reflecting user feedback trials during Odyssey 2K26 development
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
          
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
            <p className="text-slate-600 dark:text-slate-300 italic leading-relaxed">
              “I was moving to KIIT for my 2nd year and dreading broker negotiations. I typed one prompt into Roomora Concierge, it found a ₹3,400 stay in Patia, booked a visit for Saturday, and even suggested Maa Annapurna Mess for lunch!”
            </p>
            <div>
              <p className="font-bold text-slate-900 dark:text-white text-sm">Rohan Mukherjee</p>
              <p className="text-slate-400 text-[11px]">B.Tech CSE, KIIT Campus 6 (Demo Student)</p>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
            <p className="text-slate-600 dark:text-slate-300 italic leading-relaxed">
              “The Human Approval Gate gives so much peace of mind. Other AI apps try to make reservations automatically, but Roomora asks for confirmation with a clear amount breakdown first.”
            </p>
            <div>
              <p className="font-bold text-slate-900 dark:text-white text-sm">Shreya Dash</p>
              <p className="text-slate-400 text-[11px]">M.Tech, Silicon University (Demo Student)</p>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
            <p className="text-slate-600 dark:text-slate-300 italic leading-relaxed">
              “As a PG owner in Patia, managing WhatsApp messages was chaotic. Roomora coordinates visits on my calendar with verified students only. Zero time wasted.”
            </p>
            <div>
              <p className="font-bold text-slate-900 dark:text-white text-sm">Biswajit Mohanty</p>
              <p className="text-slate-400 text-[11px]">Host, Shree Krishna Living, Patia</p>
            </div>
          </div>

        </div>
      </section>

      {/* Frequently Asked Questions */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="text-center space-y-2 mb-8">
          <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white font-heading">
            Frequently Asked Questions
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Everything you need to know about Roomora Concierge's autonomous architecture
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, i) => {
            const isOpen = activeFaq === i;
            return (
              <div 
                key={i}
                className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden"
              >
                <button
                  type="button"
                  onClick={() => setActiveFaq(isOpen ? null : i)}
                  className="w-full p-4 text-left flex items-center justify-between text-xs sm:text-sm font-bold text-slate-900 dark:text-white font-heading hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
                >
                  <span>{faq.q}</span>
                  <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                </button>
                {isOpen && (
                  <div className="p-4 pt-0 text-xs text-slate-600 dark:text-slate-300 leading-relaxed border-t border-slate-100 dark:border-slate-800/60 mt-1">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* CTA Banner */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6">
        <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white text-center space-y-4 border border-slate-800 shadow-xl">
          <h3 className="text-2xl sm:text-3xl font-extrabold font-heading">
            Ready to find your ideal student stay?
          </h3>
          <p className="text-sm text-slate-300 max-w-xl mx-auto">
            Say goodbye to fake broker calls and unverified deposits. Let Roomora Concierge coordinate your stay in Bhubaneswar today.
          </p>
          <div className="pt-2 flex items-center justify-center gap-3">
            <button
              onClick={() => onNavigate('concierge')}
              className="px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs sm:text-sm shadow-md transition-all flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>Launch AI Concierge Now</span>
            </button>
            <button
              onClick={() => onNavigate('search')}
              className="px-6 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs sm:text-sm transition-all"
            >
              Browse Stays Catalog
            </button>
          </div>
        </div>
      </section>

    </div>
  );
};
