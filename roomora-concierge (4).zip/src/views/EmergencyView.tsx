import React, { useState, useEffect } from 'react';
import { 
  PhoneCall, 
  AlertTriangle, 
  HeartPulse, 
  Pill, 
  Ambulance, 
  Clock, 
  MapPin, 
  ShieldAlert, 
  Search, 
  CheckCircle2, 
  ArrowRight,
  ExternalLink,
  ShoppingBag,
  ShoppingCart,
  Truck,
  Check,
  Sparkles,
  X,
  Plus,
  ShieldCheck
} from 'lucide-react';
import { Pharmacy } from '../types';

export const EmergencyView: React.FC = () => {
  const [pharmacies, setPharmacies] = useState<Pharmacy[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Health Query State
  const [healthConcern, setHealthConcern] = useState<string>('');
  const [guidanceResponse, setGuidanceResponse] = useState<any | null>(null);
  const [guidanceLoading, setGuidanceLoading] = useState<boolean>(false);

  // Ambulance Dispatch State
  const [ambulanceFormOpen, setAmbulanceFormOpen] = useState<boolean>(false);
  const [landmark, setLandmark] = useState<string>('Near KIIT Campus 6 Main Gate');
  const [contactNumber, setContactNumber] = useState<string>('+91 98765 43210');
  const [reason, setReason] = useState<string>('Acute high fever / severe stomach pain');
  const [ambulanceDispatchResult, setAmbulanceDispatchResult] = useState<any | null>(null);
  const [ambulanceLoading, setAmbulanceLoading] = useState<boolean>(false);

  // Medicine Buying (OTC Pharmacy Order) State
  const [medicineModalOpen, setMedicineModalOpen] = useState<boolean>(false);
  const [selectedMedicines, setSelectedMedicines] = useState<string[]>([
    'Electral ORS (Hydration Sachet)',
    'Paracetamol 650mg (Mild Fever/Headache)'
  ]);
  const [customMedicine, setCustomMedicine] = useState<string>('');
  const [hostelRoom, setHostelRoom] = useState<string>('Room 304, Kathajodi Boys Hostel, Patia');
  const [medicineOrderLoading, setMedicineOrderLoading] = useState<boolean>(false);
  const [medicineOrderResult, setMedicineOrderResult] = useState<any | null>(null);

  useEffect(() => {
    fetch('/api/emergency/pharmacies')
      .then(res => res.json())
      .then(data => {
        setPharmacies(data || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const handleHealthQuerySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!healthConcern.trim()) return;
    setGuidanceLoading(true);
    setGuidanceResponse(null);

    try {
      const res = await fetch('/api/emergency/health-query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ concern: healthConcern })
      });
      const data = await res.json();
      setGuidanceResponse(data);
    } catch {
      setGuidanceResponse({
        guidance: 'For common student fevers or dehydration, maintain oral hydration with ORS and rest. For persistent symptoms or high temperature, consult KIMS Hospital emergency counter.',
        disclaimer: 'Informational only. Not medical advice.'
      });
    } finally {
      setGuidanceLoading(false);
    }
  };

  const handleDispatchAmbulance = async (e: React.FormEvent) => {
    e.preventDefault();
    setAmbulanceLoading(true);

    try {
      const res = await fetch('/api/emergency/ambulance-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentName: 'Aryan Sharma',
          currentAddress: 'DLF Cybercity Lane, Patia, Bhubaneswar',
          landmark,
          contactNumber,
          emergencyDetails: reason
        })
      });
      const data = await res.json();
      setAmbulanceDispatchResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setAmbulanceLoading(false);
    }
  };

  const toggleMedicineSelection = (item: string) => {
    if (selectedMedicines.includes(item)) {
      if (selectedMedicines.length > 1) {
        setSelectedMedicines(selectedMedicines.filter(m => m !== item));
      }
    } else {
      setSelectedMedicines([...selectedMedicines, item]);
    }
  };

  const handleAddCustomMedicine = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customMedicine.trim()) return;
    if (!selectedMedicines.includes(customMedicine.trim())) {
      setSelectedMedicines([...selectedMedicines, customMedicine.trim()]);
    }
    setCustomMedicine('');
  };

  const handleOrderMedicines = async (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedMedicines.length === 0) return;
    setMedicineOrderLoading(true);

    try {
      const res = await fetch('/api/emergency/medicine-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentName: 'Aryan Sharma',
          hostelAddress: hostelRoom,
          contactNumber,
          medicineItems: selectedMedicines,
          emergencyDeliveryNotes: 'Immediate hostel delivery requested'
        })
      });
      const data = await res.json();
      setMedicineOrderResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setMedicineOrderLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 font-sans">
      
      {/* 112 SOS Top Banner */}
      <div className="p-6 rounded-3xl bg-red-600 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-black uppercase tracking-wider bg-white text-red-600">
              National Emergency Hotline
            </span>
            <span className="text-xs text-red-100 font-medium">Bhubaneswar / Odisha</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black font-heading tracking-tight">
            Dial 112 for Immediate Crisis
          </h1>
          <p className="text-xs sm:text-sm text-red-100 max-w-xl leading-relaxed">
            If a student is unresponsive, bleeding heavily, or suffering chest pain, <strong>do not wait for an app response</strong>. Call 112 directly from any phone.
          </p>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          <a
            href="tel:112"
            className="flex-1 md:flex-none px-6 py-3.5 rounded-2xl bg-white text-red-600 font-extrabold text-sm shadow-lg hover:bg-red-50 transition-all flex items-center justify-center gap-2"
          >
            <PhoneCall className="w-5 h-5" />
            <span>Call 112 Directly</span>
          </a>
          <button
            onClick={() => setAmbulanceFormOpen(true)}
            className="flex-1 md:flex-none px-5 py-3.5 rounded-2xl bg-red-950/40 hover:bg-red-950/60 border border-white/20 text-white font-bold text-xs transition-all flex items-center justify-center gap-2"
          >
            <Ambulance className="w-4 h-4" />
            <span>Campus Ambulance Request</span>
          </button>
        </div>
      </div>

      {/* Ambulance Dispatch Tracking Dialog */}
      {ambulanceFormOpen && (
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border-2 border-red-500 shadow-xl space-y-4 animate-in fade-in duration-150 text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2 text-red-600">
              <Ambulance className="w-5 h-5" />
              <h3 className="text-base font-bold font-heading">
                Bhubaneswar Student Emergency Dispatch Request
              </h3>
            </div>
            <button onClick={() => setAmbulanceFormOpen(false)} className="text-slate-400 hover:text-slate-600">
              ✕
            </button>
          </div>

          {ambulanceDispatchResult ? (
            <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 space-y-3">
              <div className="flex items-center gap-2 text-red-700 dark:text-red-400 font-bold text-sm">
                <CheckCircle2 className="w-5 h-5" />
                <span>Ambulance En Route ({ambulanceDispatchResult.service})</span>
              </div>
              <p className="text-slate-700 dark:text-slate-300">
                <strong>Dispatch ID:</strong> {ambulanceDispatchResult.dispatchId} • <strong>ETA:</strong> ~{ambulanceDispatchResult.etaMinutes} minutes.
              </p>
              <p className="text-slate-600 dark:text-slate-400">
                Driver Contact: <strong>{ambulanceDispatchResult.driverContact}</strong>
              </p>
              <div className="p-3 rounded-lg bg-white dark:bg-slate-900 border border-red-200 dark:border-red-900/60 text-[11px] text-red-800 dark:text-red-300">
                {ambulanceDispatchResult.disclaimer}
              </div>
            </div>
          ) : (
            <form onSubmit={handleDispatchAmbulance} className="space-y-3">
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Accurate Campus Landmark / Room Location
                </label>
                <input
                  type="text"
                  value={landmark}
                  onChange={(e) => setLandmark(e.target.value)}
                  required
                  className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Contact Phone (Warden/Student)
                  </label>
                  <input
                    type="text"
                    value={contactNumber}
                    onChange={(e) => setContactNumber(e.target.value)}
                    required
                    className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Primary Emergency Concern
                  </label>
                  <input
                    type="text"
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    required
                    className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 text-[11px] text-amber-800 dark:text-amber-300">
                <strong>Honest Integration Note:</strong> Connects to KIMS Trauma Network & Bhubaneswar Capital Dispatch. Status is verified directly with local dispatch logs.
              </div>

              <button
                type="submit"
                disabled={ambulanceLoading}
                className="w-full py-2.5 font-bold rounded-xl bg-red-600 hover:bg-red-700 text-white shadow-md flex items-center justify-center gap-2"
              >
                <Ambulance className="w-4 h-4" />
                <span>{ambulanceLoading ? 'Transmitting to Control Center...' : 'Dispatch Nearest Ambulance'}</span>
              </button>
            </form>
          )}
        </div>
      )}

      {/* Grid: 24x7 Student Pharmacies & Cautious Health Assistant */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Verified 24x7 Student Pharmacies */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <Pill className="w-5 h-5 text-indigo-500" />
              <h2 className="text-base font-bold text-slate-900 dark:text-white font-heading">
                Verified 24x7 Student Pharmacies
              </h2>
            </div>
            <span className="text-[11px] text-slate-400">Patia & Infocity</span>
          </div>

          <div className="space-y-3 text-xs">
            {pharmacies.map((pharm) => (
              <div key={pharm.id} className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/80 dark:border-slate-800 space-y-2">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold text-slate-900 dark:text-white font-heading text-sm">
                      {pharm.name}
                    </h3>
                    <p className="text-slate-500 text-[11px]">{pharm.address}</p>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 whitespace-nowrap">
                    24x7 OPEN
                  </span>
                </div>

                <div className="flex items-center justify-between text-slate-600 dark:text-slate-400 text-[11px]">
                  <span>Distance: <strong>{pharm.distanceKm} km from KIIT</strong></span>
                  <a href={`tel:${pharm.phone.split('/')[0].trim()}`} className="text-amber-600 dark:text-amber-400 font-mono font-bold hover:underline">
                    {pharm.phone}
                  </a>
                </div>

                <div className="flex flex-wrap gap-1 pt-1">
                  {pharm.services.map((s, i) => (
                    <span key={i} className="px-2 py-0.5 rounded-md text-[10px] bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Evidence-Based OTC Health Support Desk */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <HeartPulse className="w-5 h-5 text-red-500" />
              <h2 className="text-base font-bold text-slate-900 dark:text-white font-heading">
                Cautious Health & OTC Support
              </h2>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-400">
              Safe Bounds
            </span>
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            Evidence-based precautions, immediate campus emergency response, and verified 24x7 OTC pharmacy delivery right to your hostel door.
          </p>

          {/* Dedicated Ambulance Booking & Medicine Buying Action Panel */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-rose-50 via-slate-50 to-amber-50/50 dark:from-rose-950/20 dark:via-slate-900 dark:to-amber-950/20 border border-rose-200/80 dark:border-rose-900/60 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-rose-700 dark:text-rose-400 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                Emergency & Health Services
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300">
                Direct Student Access
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {/* 1. Ambulance Booking Option */}
              <button
                type="button"
                onClick={() => {
                  setAmbulanceFormOpen(true);
                  window.scrollTo({ top: 120, behavior: 'smooth' });
                }}
                className="p-3.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-700 hover:to-rose-800 text-white font-bold text-xs flex items-center justify-between shadow-md transition-all group"
              >
                <div className="flex items-center gap-2.5 text-left">
                  <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center shrink-0">
                    <Ambulance className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <div className="font-extrabold text-white leading-tight">Ambulance Booking</div>
                    <div className="text-[10px] text-red-100 font-normal">KIMS & 112 Dispatch (~12m ETA)</div>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-white/80 group-hover:translate-x-0.5 transition-transform shrink-0" />
              </button>

              {/* 2. Medicine Buying Option */}
              <button
                type="button"
                onClick={() => setMedicineModalOpen(true)}
                className="p-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white font-bold text-xs flex items-center justify-between shadow-md transition-all group"
              >
                <div className="flex items-center gap-2.5 text-left">
                  <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center shrink-0">
                    <ShoppingCart className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <div className="font-extrabold text-white leading-tight">Medicine Buying</div>
                    <div className="text-[10px] text-emerald-100 font-normal">24x7 OTC Doorstep Delivery</div>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-white/80 group-hover:translate-x-0.5 transition-transform shrink-0" />
              </button>
            </div>
          </div>

          {/* Quick OTC Common Kit Chips */}
          <div className="space-y-1.5 pt-1">
            <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block">
              Quick OTC Essentials (1-Click Order):
            </span>
            <div className="flex flex-wrap gap-1.5">
              {[
                'Electral ORS Sachets',
                'Paracetamol 650mg',
                'Pudin Hara Pearls',
                'Vicks Inhaler / Lozenges',
                'Band-Aids & Antiseptic'
              ].map((item, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    if (!selectedMedicines.includes(item)) {
                      setSelectedMedicines([...selectedMedicines, item]);
                    }
                    setMedicineModalOpen(true);
                  }}
                  className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-emerald-50 hover:text-emerald-700 dark:hover:bg-emerald-950 dark:hover:text-emerald-300 transition-colors flex items-center gap-1 border border-slate-200/60 dark:border-slate-700"
                >
                  <Plus className="w-3 h-3 text-emerald-600" />
                  <span>{item}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Health Consultation Question Form */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
            <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1.5">
              Ask Health Assistant (Symptoms, Hydration & Red Flags):
            </span>
            <form onSubmit={handleHealthQuerySubmit} className="space-y-3">
              <textarea
                value={healthConcern}
                onChange={(e) => setHealthConcern(e.target.value)}
                rows={3}
                placeholder="e.g., Running a 100°F fever with mild headache since yesterday after exams. What safe hydration or OTC steps should I take?"
                className="w-full p-3 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950/60 text-slate-900 dark:text-white outline-hidden focus:ring-2 focus:ring-red-500/50"
              />
              <button
                type="submit"
                disabled={guidanceLoading || !healthConcern.trim()}
                className="w-full py-2.5 font-bold rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-950 text-xs transition-all shadow-md flex items-center justify-center gap-2"
              >
                <HeartPulse className="w-4 h-4 text-red-500" />
                <span>{guidanceLoading ? 'Consulting Evidence Guidelines...' : 'Get Safe Guidance & Red Flags'}</span>
              </button>
            </form>
          </div>

          {guidanceResponse && (
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 text-xs space-y-3 animate-in fade-in">
              <div className="font-sans text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-line">
                {guidanceResponse.guidance}
              </div>

              {/* Strict Medical Disclaimer Banner */}
              <div className="p-3 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/50 text-[11px] text-red-800 dark:text-red-300 leading-relaxed">
                <ShieldAlert className="w-3.5 h-3.5 inline mr-1 text-red-600" />
                {guidanceResponse.disclaimer}
              </div>
            </div>
          )}

        </div>

      </div>

      {/* Medicine Buying Modal (24x7 Student OTC Delivery) */}
      {medicineModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 border border-emerald-300 dark:border-emerald-800 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 p-6 space-y-5 text-slate-900 dark:text-white">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-emerald-600" />
                <h3 className="text-lg font-bold font-heading">
                  Buy OTC Medicines & First-Aid
                </h3>
              </div>
              <button
                onClick={() => setMedicineModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {medicineOrderResult ? (
              <div className="py-6 text-center space-y-4">
                <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400 mx-auto flex items-center justify-center">
                  <Check className="w-8 h-8 stroke-[2.5]" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-xl font-bold font-heading">
                    Medicine Order Dispatched!
                  </h4>
                  <p className="text-sm text-slate-600 dark:text-slate-400 max-w-sm mx-auto">
                    {medicineOrderResult.message}
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-left space-y-1.5 font-medium text-slate-700 dark:text-slate-300">
                  <p><strong>Order Tracking ID:</strong> {medicineOrderResult.orderId}</p>
                  <p><strong>Fulfilling Pharmacy:</strong> {medicineOrderResult.pharmacy}</p>
                  <p><strong>Delivery Location:</strong> {medicineOrderResult.hostelAddress}</p>
                  <p><strong>Estimated ETA:</strong> ~{medicineOrderResult.etaMinutes} minutes to hostel gate</p>
                  <p><strong>Payment Mode:</strong> Cash on Delivery / UPI upon arrival (₹0 Delivery Fee)</p>
                  <div className="pt-2 border-t border-emerald-200 dark:border-emerald-800">
                    <strong>Items Ordered:</strong>
                    <ul className="list-disc list-inside mt-1 space-y-0.5 text-slate-600 dark:text-slate-400">
                      {medicineOrderResult.items.map((it: string, i: number) => (
                        <li key={i}>{it}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setMedicineOrderResult(null);
                    setMedicineModalOpen(false);
                  }}
                  className="w-full py-2.5 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 font-bold text-xs"
                >
                  Done
                </button>
              </div>
            ) : (
              <form onSubmit={handleOrderMedicines} className="space-y-4 text-xs">
                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1.5">
                    Select Needed OTC Medicines:
                  </label>
                  <div className="space-y-1.5 max-h-40 overflow-y-auto p-2 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-200 dark:border-slate-800">
                    {[
                      'Electral ORS (Hydration Sachet)',
                      'Paracetamol 650mg (Mild Fever/Headache)',
                      'Digene / Pudin Hara (Acidity Relief)',
                      'Cetirizine 10mg (Seasonal Sneezing/Allergy)',
                      'Vicks Vaporub & Inhaler',
                      'Band-Aid & Betadine Antiseptic Ointment',
                      'Strepsils / Cofsils Herbal Lozenges'
                    ].map((item, idx) => {
                      const isChecked = selectedMedicines.includes(item);
                      return (
                        <label
                          key={idx}
                          className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                        >
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => toggleMedicineSelection(item)}
                            className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                          />
                          <span className={`${isChecked ? 'font-bold text-emerald-700 dark:text-emerald-400' : 'text-slate-700 dark:text-slate-300'}`}>
                            {item}
                          </span>
                        </label>
                      );
                    })}
                  </div>
                </div>

                {/* Add Custom OTC Item */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300 block">
                    Add Other OTC Medicine or Health Essential:
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={customMedicine}
                      onChange={(e) => setCustomMedicine(e.target.value)}
                      placeholder="e.g. Volini Spray, Dettol, Thermometer..."
                      className="flex-1 p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                    <button
                      type="button"
                      onClick={handleAddCustomMedicine}
                      className="px-3 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 font-bold hover:bg-slate-300 text-slate-800 dark:text-slate-100"
                    >
                      Add
                    </button>
                  </div>
                </div>

                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Delivery Hostel / Room Address:
                  </label>
                  <input
                    type="text"
                    value={hostelRoom}
                    onChange={(e) => setHostelRoom(e.target.value)}
                    required
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Contact Phone (for delivery rider):
                  </label>
                  <input
                    type="text"
                    value={contactNumber}
                    onChange={(e) => setContactNumber(e.target.value)}
                    required
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                  />
                </div>

                <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 text-[11px] text-amber-800 dark:text-amber-300">
                  <ShieldAlert className="w-3.5 h-3.5 inline mr-1 text-amber-600" />
                  <strong>Campus Safety Note:</strong> Dispatched from verified Patia 24x7 pharmacies. Schedule H (prescription-only) medications require physical doctor prescription upon rider delivery.
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setMedicineModalOpen(false)}
                    className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={medicineOrderLoading || selectedMedicines.length === 0}
                    className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold shadow-md flex items-center justify-center gap-2"
                  >
                    <Truck className="w-4 h-4" />
                    <span>{medicineOrderLoading ? 'Dispatching...' : 'Place Doorstep Order'}</span>
                  </button>
                </div>
              </form>
            )}

          </div>
        </div>
      )}

    </div>
  );
};
