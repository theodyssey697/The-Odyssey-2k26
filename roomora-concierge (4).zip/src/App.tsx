/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { EntranceView } from './views/EntranceView';
import { StudentAuthView } from './views/StudentAuthView';
import { AdminAuthView } from './views/AdminAuthView';

import { Sidebar } from './components/Sidebar';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';

import { LandingView } from './views/LandingView';
import { SearchView } from './views/SearchView';
import { ConciergeView } from './views/ConciergeView';
import { DashboardView } from './views/DashboardView';
import { MessView } from './views/MessView';
import { FoodingView } from './views/FoodingView';
import { EmergencyView } from './views/EmergencyView';
import { AdminView } from './views/AdminView';
import { MessAdminDashboardView } from './views/MessAdminDashboardView';
import { StudentProfileView } from './views/StudentProfileView';

import { PropertyDetailModal } from './components/PropertyDetailModal';
import { VisitModal } from './components/VisitModal';
import { BookingModal } from './components/BookingModal';
import { ReportModal } from './components/ReportModal';
import { CompareModal } from './components/CompareModal';
import { VacancyWatchModal } from './components/VacancyWatchModal';
import { MessAdminAuthModal } from './components/MessAdminAuthModal';

import { Property } from './types';
import { INITIAL_PROPERTIES } from './data/mockData';
import { User, X, ShieldCheck, GraduationCap, Mail, Phone } from 'lucide-react';
import { auth } from './firebaseConfig';

export default function App() {
  // App Stage: 'entrance' | 'student_auth' | 'admin_auth' | 'portal' | 'mess_admin_dashboard'
  const [appStage, setAppStage] = useState<'entrance' | 'student_auth' | 'admin_auth' | 'portal' | 'mess_admin_dashboard'>('entrance');
  const [currentTab, setCurrentTab] = useState<string>('landing');
  const [userRole, setUserRole] = useState<'student' | 'owner' | 'admin'>('student');
  const [userName, setUserName] = useState<string>('Aryan Sharma');
  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);

  // Mess Administrator Login Modal & Active Session
  const [messAdminModalOpen, setMessAdminModalOpen] = useState<boolean>(false);
  const [selectedMessForLogin, setSelectedMessForLogin] = useState<{ id: string; name: string } | null>(null);
  const [activeMessAdmin, setActiveMessAdmin] = useState<{ messId: string; adminEmail: string; messData: any } | null>(null);

  // Global entities state
  const [properties, setProperties] = useState<Property[]>(INITIAL_PROPERTIES);
  const [savedPropertyIds, setSavedPropertyIds] = useState<string[]>(['prop-patia-101', 'prop-patia-102']);
  
  // Modals state
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [visitProperty, setVisitProperty] = useState<Property | null>(null);
  const [bookingProperty, setBookingProperty] = useState<Property | null>(null);
  const [reportProperty, setReportProperty] = useState<Property | null>(null);
  const [compareProperties, setCompareProperties] = useState<Property[]>([]);
  const [isVacancyWatchOpen, setIsVacancyWatchOpen] = useState<boolean>(false);

  // Active goal transferred to Concierge
  const [conciergeGoal, setConciergeGoal] = useState<string>('');

  // Toast notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Load properties on initial mount
  useEffect(() => {
    fetch('/api/properties')
      .then((res) => res.json())
      .then((data) => {
        if (data.properties?.length) setProperties(data.properties);
      })
      .catch(() => {});
  }, []);

  const handleToggleSaveProperty = (id: string) => {
    if (savedPropertyIds.includes(id)) {
      setSavedPropertyIds(savedPropertyIds.filter((p) => p !== id));
      showToast('Removed from saved stays');
    } else {
      setSavedPropertyIds([...savedPropertyIds, id]);
      showToast('Saved to your Student Hub shortlist');
    }
  };

  const handleLaunchGoal = (goal: string) => {
    setConciergeGoal(goal);
    setCurrentTab('concierge');
  };

  const handleStudentLoginSuccess = (userData: { name: string; email: string }) => {
    setUserRole('student');
    setUserName(userData.name);
    setAppStage('portal');
    setCurrentTab('landing');
    showToast(`Welcome back, ${userData.name}!`);
  };

  const handleAdminLoginSuccess = () => {
    setUserRole('admin');
    setUserName('Platform Administrator');
    setAppStage('portal');
    setCurrentTab('admin');
    showToast('Authenticated as Administrator.');
  };

  const handleLogout = async () => {
    try {
      await auth.signOut();
      setActiveMessAdmin(null);
      setAppStage('entrance');
      setCurrentTab('landing');
      showToast('Signed out successfully.');
    } catch (error) {
      console.error('Error signing out:', error);
      showToast('Error signing out. Please try again.');
    }
  };

  const handleOpenMessAdminLogin = (messItem: { id: string; name?: string; title?: string; messName?: string }) => {
    const name = ('messName' in messItem && messItem.messName) || messItem.name || messItem.title || 'Student Mess';
    setSelectedMessForLogin({ id: messItem.id, name });
    setMessAdminModalOpen(true);
  };

  const handleMessAdminSuccess = (authorizedMess: any, adminEmail: string) => {
    setActiveMessAdmin({
      messId: authorizedMess.id,
      adminEmail,
      messData: authorizedMess
    });
    setAppStage('mess_admin_dashboard');
    showToast(`Authorized as Administrator for ${authorizedMess.name}`);
  };

  // Render Entrance Page
  if (appStage === 'entrance') {
    return (
      <EntranceView
        onSelectStudent={() => setAppStage('student_auth')}
        onSelectAdmin={() => setAppStage('admin_auth')}
      />
    );
  }

  // Render Student Authentication Page (with real Gmail verification)
  if (appStage === 'student_auth') {
    return (
      <StudentAuthView
        onSuccessLogin={handleStudentLoginSuccess}
        onBackToEntrance={() => setAppStage('entrance')}
      />
    );
  }

  // Render Admin Authentication Page
  if (appStage === 'admin_auth') {
    return (
      <AdminAuthView
        onSuccessAdminLogin={handleAdminLoginSuccess}
        onBackToEntrance={() => setAppStage('entrance')}
      />
    );
  }

  // Render Dedicated Mess Administrator Dashboard
  if (appStage === 'mess_admin_dashboard' && activeMessAdmin) {
    return (
      <MessAdminDashboardView
        messId={activeMessAdmin.messId}
        adminEmail={activeMessAdmin.adminEmail}
        onBackToExplore={() => {
          setAppStage('portal');
          setCurrentTab('search');
        }}
        onLogout={handleLogout}
        onMessUpdated={() => {
          fetch('/api/properties')
            .then((res) => res.json())
            .then((data) => {
              if (data.properties?.length) setProperties(data.properties);
            })
            .catch(() => {});
        }}
      />
    );
  }

  // Render Main Portal
  return (
    <div className="min-h-screen flex font-sans transition-colors duration-200 bg-[#3a0812] text-[#fff1f2]">
      
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 bg-[#881337] text-white px-4 py-2.5 rounded-xl shadow-xl border border-[#be123c] text-xs font-bold animate-in slide-in-from-top duration-200 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-amber-400"></span>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Left-Side Navigation Sidebar */}
      <Sidebar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        userRole={userRole}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 bg-[#3a0812]">
        
        {/* Upper Top Tab Header with Profile Dropdown */}
        <Navbar
          currentTab={currentTab}
          setCurrentTab={setCurrentTab}
          userRole={userRole}
          userName={userName}
          onLogout={handleLogout}
          onViewProfile={() => {
            if (userRole === 'student') {
              setCurrentTab('student_profile');
            } else {
              setIsProfileModalOpen(true);
            }
          }}
        />

        <main className="flex-1 bg-[#3a0812] text-[#fff1f2] p-4 sm:p-6 lg:p-8">
          {currentTab === 'landing' && (
            <LandingView
              onSearchGoal={handleLaunchGoal}
              featuredProperties={properties}
              onSelectProperty={(p) => setSelectedProperty(p)}
              onScheduleVisit={(p) => setVisitProperty(p)}
              onAskConcierge={(p) => {
                handleLaunchGoal(`Evaluate ${p.title} in ${p.locality} for KIIT campus proximity, check availability for Saturday, and inspect amenities.`);
              }}
              onNavigate={(tab) => setCurrentTab(tab)}
              onOpenMessAdminLogin={handleOpenMessAdminLogin}
            />
          )}

          {currentTab === 'student_profile' && (
            <StudentProfileView
              userName={userName}
              showToast={showToast}
            />
          )}

          {currentTab === 'search' && (
            <SearchView
              onSelectProperty={(p) => setSelectedProperty(p)}
              onScheduleVisit={(p) => setVisitProperty(p)}
              onAskConcierge={(p) => {
                handleLaunchGoal(`Evaluate ${p.title} in ${p.locality} for rent fairness and schedule a visit on Saturday.`);
              }}
              savedPropertyIds={savedPropertyIds}
              onToggleSaveProperty={handleToggleSaveProperty}
              onOpenCompare={(props) => setCompareProperties(props)}
              onOpenMessAdminLogin={handleOpenMessAdminLogin}
            />
          )}

          {currentTab === 'concierge' && (
            <ConciergeView
              initialGoal={conciergeGoal}
              onSelectProperty={(p) => setSelectedProperty(p)}
              onScheduleVisit={(p) => setVisitProperty(p)}
              onNavigateToTab={(tab) => setCurrentTab(tab)}
            />
          )}

          {currentTab === 'dashboard' && (
            <DashboardView
              onSelectProperty={(p) => setSelectedProperty(p)}
              onNavigateToTab={(tab) => setCurrentTab(tab)}
              onDeployWatch={() => setIsVacancyWatchOpen(true)}
            />
          )}

          {currentTab === 'fooding' && <FoodingView />}

          {currentTab === 'mess' && <MessView onOpenMessAdminLogin={handleOpenMessAdminLogin} />}

          {currentTab === 'emergency' && <EmergencyView />}

          {(currentTab === 'admin' || currentTab.startsWith('admin')) && (
            <AdminView onInspectProperty={(p) => setSelectedProperty(p)} />
          )}
        </main>

        <Footer onNavigate={(tab) => setCurrentTab(tab)} />
      </div>

      {/* View Profile Modal */}
      {isProfileModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className={`w-full max-w-md rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 p-6 space-y-4 text-xs ${
            userRole === 'admin'
              ? 'bg-[#230910] border border-rose-900/60 text-rose-100'
              : 'bg-white border border-rose-200 text-slate-900'
          }`}>
            <div className={`flex items-center justify-between pb-3 border-b ${userRole === 'admin' ? 'border-rose-950' : 'border-rose-100'}`}>
              <div className="flex items-center gap-2">
                <User className="w-5 h-5 text-rose-600" />
                <h3 className="text-base font-bold font-heading">User Profile Details</h3>
              </div>
              <button onClick={() => setIsProfileModalOpen(false)} className="text-slate-400 hover:text-rose-500">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div className={`flex items-center gap-3 p-3 rounded-xl border ${
                userRole === 'admin'
                  ? 'bg-rose-950/50 border-rose-900/80 text-rose-200'
                  : 'bg-rose-50 border-rose-100 text-rose-950'
              }`}>
                <div className="w-12 h-12 rounded-full bg-[#881337] text-white font-bold text-lg flex items-center justify-center shadow-md">
                  {userName.charAt(0)}
                </div>
                <div>
                  <h4 className="font-bold text-sm">{userName}</h4>
                  <p className="text-rose-600 dark:text-rose-400 capitalize font-medium">Role: {userRole}</p>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-slate-700 font-mono text-[11px]">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-slate-400" />
                  <span>{userRole === 'admin' ? 'admin@roomora.concierge' : 'aryan.sharma@kiit.ac.in'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-slate-400" />
                  <span>+91 98765 43210</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-sky-50 border border-sky-200 text-sky-900 text-[11px]">
                <strong>Security Status:</strong> Verified Active Session. Escrow & Scam Guard protected.
              </div>
            </div>

            <button
              onClick={() => setIsProfileModalOpen(false)}
              className="w-full py-2.5 font-bold rounded-xl bg-sky-600 hover:bg-sky-700 text-white transition-colors"
            >
              Close Profile
            </button>
          </div>
        </div>
      )}

      {/* Modals */}
      {selectedProperty && (
        <PropertyDetailModal
          property={selectedProperty}
          onClose={() => setSelectedProperty(null)}
          onScheduleVisit={(p) => {
            setSelectedProperty(null);
            setVisitProperty(p);
          }}
          onStartBooking={(p) => {
            setSelectedProperty(null);
            setBookingProperty(p);
          }}
          onReport={(p) => {
            setSelectedProperty(null);
            setReportProperty(p);
          }}
          onAskConcierge={(p) => {
            setSelectedProperty(null);
            handleLaunchGoal(`Check availability and schedule a Saturday visit for ${p.title} in ${p.locality}.`);
          }}
          onOpenMessAdminLogin={handleOpenMessAdminLogin}
        />
      )}

      {visitProperty && (
        <VisitModal
          property={visitProperty}
          onClose={() => setVisitProperty(null)}
          onSuccess={(visit) => {
            showToast(`Visit confirmed for ${visit.requestedDate} (${visit.requestedTimeSlot})!`);
          }}
        />
      )}

      {bookingProperty && (
        <BookingModal
          property={bookingProperty}
          onClose={() => setBookingProperty(null)}
          onBookingSuccess={(booking) => {
            showToast(`Stay Pass generated for ${booking.propertyTitle}!`);
          }}
        />
      )}

      {reportProperty && (
        <ReportModal
          property={reportProperty}
          onClose={() => setReportProperty(null)}
          onSuccess={() => {
            showToast('Report submitted to Roomora Trust & Safety team.');
          }}
        />
      )}

      {compareProperties.length > 0 && (
        <CompareModal
          properties={compareProperties}
          onClose={() => setCompareProperties([])}
          onSelectProperty={(p) => setSelectedProperty(p)}
          onAskConcierge={(props) => {
            const titles = props.map((p) => p.title).join(', ');
            handleLaunchGoal(`Compare these accommodations and give me the best value recommendation: ${titles}`);
          }}
        />
      )}

      {isVacancyWatchOpen && (
        <VacancyWatchModal
          onClose={() => setIsVacancyWatchOpen(false)}
          onSuccess={(watch) => {
            showToast(`Vacancy Watch active for ${watch.locality} under ₹${watch.maxMonthlyRent}/mo`);
          }}
        />
      )}

      {/* Mess Administrator Auth Modal */}
      {messAdminModalOpen && selectedMessForLogin && (
        <MessAdminAuthModal
          messId={selectedMessForLogin.id}
          messName={selectedMessForLogin.name}
          isOpen={messAdminModalOpen}
          onClose={() => {
            setMessAdminModalOpen(false);
            setSelectedMessForLogin(null);
          }}
          onSuccessLogin={handleMessAdminSuccess}
        />
      )}

    </div>
  );
}
