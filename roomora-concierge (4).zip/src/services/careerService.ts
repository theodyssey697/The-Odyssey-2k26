import { auth } from '../firebaseConfig';
import { CareerProfile, CareerPlan, CareerAgentEvent, CareerChatMessage } from '../types/career';

async function getAuthToken(): Promise<string> {
  const currentUser = auth.currentUser;
  if (!currentUser) {
    throw new Error('User not authenticated with Firebase. Please sign in to access career services.');
  }
  return await currentUser.getIdToken();
}

export async function fetchStudentCareerData(): Promise<{ profile: CareerProfile | null; plan: CareerPlan | null }> {
  try {
    const token = await getAuthToken();
    const response = await fetch('/api/career/get', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to fetch career data.');
    }
    const data = await response.json();
    return { profile: data.profile || null, plan: data.plan || null };
  } catch (error) {
    console.error('Error fetching career data:', error);
    throw error;
  }
}

export async function saveCareerProfileDraft(profileData: Partial<CareerProfile>): Promise<{ success: boolean; profile: CareerProfile }> {
  try {
    const token = await getAuthToken();
    const response = await fetch('/api/career/save-profile', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(profileData)
    });
    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to save profile draft.');
    }
    return await response.json();
  } catch (error) {
    console.error('Error saving profile draft:', error);
    throw error;
  }
}

export async function analyzeCareerProfile(profileData: CareerProfile, onEvent?: (event: CareerAgentEvent) => void): Promise<{ plan: CareerPlan; events: CareerAgentEvent[] }> {
  try {
    const token = await getAuthToken();
    const response = await fetch('/api/career/analyze', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(profileData)
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.error || 'Career analysis workflow failed.');
    }

    const data = await response.json();
    if (data.events && onEvent) {
      data.events.forEach((ev: CareerAgentEvent) => onEvent(ev));
    }
    return { plan: data.plan, events: data.events || [] };
  } catch (error) {
    console.error('Error running career analysis:', error);
    throw error;
  }
}

export async function sendCareerCoachMessage(message: string, currentPlanId?: string, proposedChanges?: any): Promise<CareerChatMessage> {
  try {
    const token = await getAuthToken();
    const response = await fetch('/api/career/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ message, currentPlanId, proposedChanges })
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.error || 'Career coach chat failed.');
    }

    const data = await response.json();
    return data.message;
  } catch (error) {
    console.error('Error in career coach chat:', error);
    throw error;
  }
}
