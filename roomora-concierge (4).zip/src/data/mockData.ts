import { Property, MessService, Pharmacy, VacancyWatch, VisitRequest, Booking, UserProfile } from '../types';

export const INITIAL_PROPERTIES: Property[] = [
{
  "id": "prop-bls-pradhan-ladies",
  "title": "Pradhan Ladies Mess",
  "description": "Safe, dedicated student ladies mess & hostel situated near Nathapani Mandir in Bhimpura, Balasore. Offers clean sharing rooms with attached washrooms, 24x7 female warden, biometric security, high-speed Wi-Fi, and 3 authentic home-style Odia meals daily included.",
  "city": "Balasore",
  "locality": "Bhimpura",
  "address": "Near Nathapani Mandir, Bhimpura, Balasore, Odisha 756001",
  "landmark": "Near Nathapani Mandir & F.M. University Old Campus link road",
  "monthlyRent": 3200,
  "deposit": 3200,
  "maintenanceCharges": 150,
  "electricityCharges": "Sub-meter \u20b98/unit",
  "roomType": "double_sharing",
  "genderPreference": "girls",
  "furnished": "fully_furnished",
  "amenities": [
    "Daily 3 Homestyle Meals",
    "High-speed Wi-Fi",
    "Attached Bathroom",
    "24x7 Female Warden",
    "CCTV Security",
    "RO Drinking Water",
    "Study Table & Chair",
    "Power Backup"
  ],
  "houseRules": [
    "Curfew 9:00 PM for student safety",
    "Visitor register at entrance",
    "Maintain silence during exam weeks"
  ],
  "hostId": "host-pradhan-ladies",
  "hostName": "Sasmita Pradhan",
  "hostPhone": "+91 94372 81904",
  "hostVerified": true,
  "verificationStatus": "verified_by_platform",
  "verificationMethod": "Google Maps Verified Place + Physical On-Site Inspection & Utility Audit",
  "verificationTimestamp": "2026-10-10T11:00:00Z",
  "availabilityStatus": "available",
  "availableBeds": 4,
  "lastAvailabilityCheck": "2026-10-12T09:00:00Z",
  "images": [
    "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=1000&q=80"
  ],
  "gmapUrl": "https://maps.app.goo.gl/LvKsy372utCd8c2f8",
  "messName": "Pradhan Ladies Mess & Dining",
  "messPhone": "+91 94372 81904",
  "mealPlan": "3 Homestyle Meals Daily Included (Breakfast, Lunch & Dinner)",
  "coordinates": {
    "lat": 21.5127895,
    "lng": 86.9027959
  },
  "distanceToCampus": [
    {
      "campusName": "Fakir Mohan Autonomous College",
      "distanceKm": 2.1,
      "walkingTimeMin": 25
    },
    {
      "campusName": "Fakir Mohan University (Old Campus)",
      "distanceKm": 1.4,
      "walkingTimeMin": 16
    },
    {
      "campusName": "Govt ITI Balasore",
      "distanceKm": 3.2,
      "walkingTimeMin": 38
    }
  ],
  "fairRentScore": {
    "status": "fair",
    "averageLocalityRent": 3400,
    "differencePercentage": -5.9,
    "assessmentNotes": "Rent \u20b93,200 includes daily breakfast, lunch, and dinner, giving unmatched student value in Balasore."
  },
  "demoListing": true
},
{
  "id": "prop-bls-freedom-mess",
  "title": "Freedom Mess",
  "description": "Popular student mess and boys dormitory in Sidheswar Colony, Balasore. Offers spacious double and triple sharing student rooms with wooden cots, study tables, high-speed Wi-Fi, and delicious daily mess dining with flexible meal coupons.",
  "city": "Balasore",
  "locality": "Sidheswar Colony",
  "address": "Sidheswar Colony, Near Remuna Golei Road, Balasore, Odisha 756019",
  "landmark": "Near Sidheswar Temple & Remuna Golei Link Road",
  "monthlyRent": 2800,
  "deposit": 2800,
  "maintenanceCharges": 100,
  "electricityCharges": "\u20b97.5 per unit",
  "roomType": "double_sharing",
  "genderPreference": "boys",
  "furnished": "semi_furnished",
  "amenities": [
    "High-speed Wi-Fi",
    "Mess Dining Facility",
    "Individual Wooden Bed",
    "Study Desk",
    "RO Purified Water",
    "Two-Wheeler Parking",
    "24x7 Water Supply"
  ],
  "houseRules": [
    "Quiet hours after 10:30 PM",
    "No smoking/alcohol on premises",
    "Self-discipline in mess hall"
  ],
  "hostId": "host-freedom",
  "hostName": "Debabrata Das",
  "hostPhone": "+91 98614 77219",
  "hostVerified": true,
  "verificationStatus": "verified_by_platform",
  "verificationMethod": "Google Maps Verified Place + Electricity Bill & Host KYC",
  "verificationTimestamp": "2026-10-09T14:20:00Z",
  "availabilityStatus": "available",
  "availableBeds": 3,
  "lastAvailabilityCheck": "2026-10-12T08:30:00Z",
  "images": [
    "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=1000&q=80"
  ],
  "gmapUrl": "https://maps.app.goo.gl/4Jn3pgLwbKiXQw9K7",
  "messName": "Freedom Mess & Food Service",
  "messPhone": "+91 98614 77219",
  "mealPlan": "Two Meals Daily (Lunch & Dinner) package available at \u20b92,200/mo",
  "coordinates": {
    "lat": 21.5106964,
    "lng": 86.8973882
  },
  "distanceToCampus": [
    {
      "campusName": "Fakir Mohan Autonomous College",
      "distanceKm": 2.4,
      "walkingTimeMin": 28
    },
    {
      "campusName": "Balasore College of Engg & Tech (BCET)",
      "distanceKm": 3.8,
      "walkingTimeMin": 44
    },
    {
      "campusName": "Govt ITI Balasore",
      "distanceKm": 2.1,
      "walkingTimeMin": 24
    }
  ],
  "fairRentScore": {
    "status": "fair",
    "averageLocalityRent": 3000,
    "differencePercentage": -6.7,
    "assessmentNotes": "Affordable student stay at \u20b92,800/month with reliable mess kitchen."
  },
  "demoListing": true
},
{
  "id": "prop-bls-sahu-mess",
  "title": "SAHU MESS",
  "description": "Established student housing complex and mess in Sahadevkhunta, Balasore. Walking distance to central bus terminus and railway link. Features furnished double-sharing rooms, ceiling fans, purified water, and an authentic kitchen providing lunch and dinner.",
  "city": "Balasore",
  "locality": "Sahadevkhunta",
  "address": "Sahadevkhunta, Near Bus Stand Road, Balasore, Odisha 756001",
  "landmark": "500m from Sahadevkhunta Central Bus Stand",
  "monthlyRent": 3000,
  "deposit": 3000,
  "maintenanceCharges": 100,
  "electricityCharges": "Fixed \u20b9250/month",
  "roomType": "double_sharing",
  "genderPreference": "boys",
  "furnished": "fully_furnished",
  "amenities": [
    "Mess Food Service",
    "Wi-Fi Access",
    "RO Water Cooler",
    "CCTV Security",
    "Two-Wheeler Parking",
    "Daily Cleaning"
  ],
  "houseRules": [
    "Main gate closed at 10 PM",
    "Student ID proof required during check-in"
  ],
  "hostId": "host-sahu",
  "hostName": "Ramesh Chandra Sahu",
  "hostPhone": "+91 94380 56321",
  "hostVerified": true,
  "verificationStatus": "verified_by_platform",
  "verificationMethod": "Google Maps Verified Place + Physical Verification by Roomora Agent",
  "verificationTimestamp": "2026-10-08T16:00:00Z",
  "availabilityStatus": "available",
  "availableBeds": 2,
  "lastAvailabilityCheck": "2026-10-12T10:15:00Z",
  "images": [
    "https://images.unsplash.com/photo-1540518614846-7ede433c4b49?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=1000&q=80"
  ],
  "gmapUrl": "https://maps.app.goo.gl/Kp9piN71n1gMyzRR8",
  "messName": "Sahu Student Mess & Tiffin",
  "messPhone": "+91 94380 56321",
  "mealPlan": "Veg & Non-Veg Lunch & Dinner with Dalma, Bhaja, and Chicken/Fish twice weekly",
  "coordinates": {
    "lat": 21.513106,
    "lng": 86.8960855
  },
  "distanceToCampus": [
    {
      "campusName": "Fakir Mohan Autonomous College",
      "distanceKm": 1.8,
      "walkingTimeMin": 21
    },
    {
      "campusName": "Govt ITI Balasore",
      "distanceKm": 2.5,
      "walkingTimeMin": 29
    },
    {
      "campusName": "BCET Balasore",
      "distanceKm": 4.2,
      "walkingTimeMin": 48
    }
  ],
  "fairRentScore": {
    "status": "fair",
    "averageLocalityRent": 3100,
    "differencePercentage": -3.2,
    "assessmentNotes": "Standard market rent with prime transport connectivity."
  },
  "demoListing": true
},
{
  "id": "prop-bls-mohapatra-mess",
  "title": "Mohapatra mess",
  "description": "Cozy student accommodation in a friendly housing society near ITI Square, Balasore. Offers double and triple-sharing rooms with good ventilation, individual study tables, peaceful study environment, and in-house mess.",
  "city": "Balasore",
  "locality": "Near ITI Square",
  "address": "Lane 3, Near ITI Square, Balasore, Odisha 756001",
  "landmark": "5 min walk from Balasore Government ITI",
  "monthlyRent": 2900,
  "deposit": 2900,
  "maintenanceCharges": 150,
  "electricityCharges": "\u20b98/unit",
  "roomType": "triple_sharing",
  "genderPreference": "boys",
  "furnished": "semi_furnished",
  "amenities": [
    "In-house Mess",
    "Fast Wi-Fi",
    "Study Table & Chair",
    "Power Inverter Backup",
    "RO Water Filter"
  ],
  "houseRules": [
    "Visitors till 8 PM",
    "Maintain silence during exam weeks"
  ],
  "hostId": "host-mohapatra",
  "hostName": "Sanjay Mohapatra",
  "hostPhone": "+91 97771 44902",
  "hostVerified": true,
  "verificationStatus": "verified_by_platform",
  "verificationMethod": "Google Maps Verified Place + Utility & Property Tax Records",
  "verificationTimestamp": "2026-10-07T12:30:00Z",
  "availabilityStatus": "available",
  "availableBeds": 5,
  "lastAvailabilityCheck": "2026-10-12T08:00:00Z",
  "images": [
    "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1000&q=80"
  ],
  "gmapUrl": "https://maps.app.goo.gl/xHvufuvhF3Enj7gq8",
  "messName": "Mohapatra Boys Mess & Bhojanalaya",
  "messPhone": "+91 97771 44902",
  "mealPlan": "Unlimited Rice, Roti, Dal, Mix Veg Tarkari + Egg/Fish option",
  "coordinates": {
    "lat": 21.5104507,
    "lng": 86.8994474
  },
  "distanceToCampus": [
    {
      "campusName": "Govt ITI Balasore",
      "distanceKm": 0.6,
      "walkingTimeMin": 7
    },
    {
      "campusName": "Fakir Mohan Autonomous College",
      "distanceKm": 2.2,
      "walkingTimeMin": 26
    },
    {
      "campusName": "F.M. University (Old Campus)",
      "distanceKm": 1.9,
      "walkingTimeMin": 22
    }
  ],
  "fairRentScore": {
    "status": "fair",
    "averageLocalityRent": 3000,
    "differencePercentage": -3.3,
    "assessmentNotes": "Perfect walking proximity to ITI Balasore."
  },
  "demoListing": true
},
{
  "id": "prop-bls-sai-krishna-mess",
  "title": "Sai Krishna mess",
  "description": "Premium student housing center and mess located on Station Road, Balasore. Offers comfortable private single and double sharing rooms, fast fiber internet, 24x7 security, and hygienic student tiffin services.",
  "city": "Balasore",
  "locality": "Station Road",
  "address": "Station Road, Near Balasore Railway Station, Balasore, Odisha 756001",
  "landmark": "600m from Balasore Main Railway Station",
  "monthlyRent": 3400,
  "deposit": 3400,
  "maintenanceCharges": 200,
  "electricityCharges": "\u20b98.5/unit",
  "roomType": "double_sharing",
  "genderPreference": "boys",
  "furnished": "fully_furnished",
  "amenities": [
    "High-speed Wi-Fi",
    "Attached Washroom",
    "In-house Mess & Tiffin",
    "CCTV Security",
    "RO Drinking Water",
    "Geyser"
  ],
  "houseRules": [
    "Quiet hours after 10 PM",
    "No smoking/alcohol allowed"
  ],
  "hostId": "host-sai-krishna",
  "hostName": "Pradeep Panda",
  "hostPhone": "+91 93375 88109",
  "hostVerified": true,
  "verificationStatus": "verified_by_platform",
  "verificationMethod": "Google Maps Verified Place + In-person Verification by Roomora Field Team",
  "verificationTimestamp": "2026-10-11T15:00:00Z",
  "availabilityStatus": "available",
  "availableBeds": 2,
  "lastAvailabilityCheck": "2026-10-12T10:00:00Z",
  "images": [
    "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1540518614846-7ede433c4b49?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=1000&q=80"
  ],
  "gmapUrl": "https://maps.app.goo.gl/98w1LMGJscsv7DhT8",
  "messName": "Sai Krishna Mess & Tiffin Center",
  "messPhone": "+91 93375 88109",
  "mealPlan": "Breakfast, Lunch, and Dinner combo plans available at \u20b92,500/month",
  "coordinates": {
    "lat": 21.5090725,
    "lng": 86.909087
  },
  "distanceToCampus": [
    {
      "campusName": "Fakir Mohan Autonomous College",
      "distanceKm": 2.0,
      "walkingTimeMin": 24
    },
    {
      "campusName": "Balasore Railway Station",
      "distanceKm": 0.6,
      "walkingTimeMin": 7
    },
    {
      "campusName": "Govt ITI Balasore",
      "distanceKm": 2.9,
      "walkingTimeMin": 34
    }
  ],
  "fairRentScore": {
    "status": "fair",
    "averageLocalityRent": 3500,
    "differencePercentage": -2.8,
    "assessmentNotes": "Strategic station-area location with excellent amenities."
  },
  "demoListing": true
},
{
  "id": "prop-bls-krishna-boys",
  "title": "Krishna Boys Mess(Balasore)",
  "description": "Popular boys hostel and mess in Januganj / Gopalbindha area. Clean double and triple occupancy rooms with box spring beds, personal cupboards, study desks, and three healthy daily meals.",
  "city": "Balasore",
  "locality": "Januganj",
  "address": "Januganj Golei, Gopalbindha, Balasore, Odisha 756019",
  "landmark": "Near Januganj Golei & NH-16 connecting flyover",
  "monthlyRent": 3100,
  "deposit": 3100,
  "maintenanceCharges": 150,
  "electricityCharges": "\u20b98/unit",
  "roomType": "double_sharing",
  "genderPreference": "boys",
  "furnished": "fully_furnished",
  "amenities": [
    "Daily 3 Meals Included",
    "High-speed Wi-Fi",
    "CCTV Security",
    "RO Purified Water",
    "Bike Parking",
    "Power Backup"
  ],
  "houseRules": [
    "Gate closes at 9:30 PM",
    "No loud music after 10 PM"
  ],
  "hostId": "host-krishna-boys",
  "hostName": "Ranjan Kumar Jena",
  "hostPhone": "+91 94376 33019",
  "hostVerified": true,
  "verificationStatus": "verified_by_platform",
  "verificationMethod": "Google Maps Verified Place + Host Aadhaar KYC",
  "verificationTimestamp": "2026-10-06T10:00:00Z",
  "availabilityStatus": "available",
  "availableBeds": 3,
  "lastAvailabilityCheck": "2026-10-12T09:40:00Z",
  "images": [
    "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=1000&q=80"
  ],
  "gmapUrl": "https://maps.app.goo.gl/Q9dzWnRFDvyeHd4PA",
  "messName": "Krishna Boys Mess & Dining",
  "messPhone": "+91 94376 33019",
  "mealPlan": "Full board: Morning breakfast + tea, homestyle lunch, and hot dinner",
  "coordinates": {
    "lat": 21.4863569,
    "lng": 86.9328238
  },
  "distanceToCampus": [
    {
      "campusName": "Fakir Mohan Autonomous College",
      "distanceKm": 1.6,
      "walkingTimeMin": 19
    },
    {
      "campusName": "BCET Balasore",
      "distanceKm": 4.5,
      "walkingTimeMin": 52
    },
    {
      "campusName": "Govt ITI Balasore",
      "distanceKm": 3.1,
      "walkingTimeMin": 36
    }
  ],
  "fairRentScore": {
    "status": "fair",
    "averageLocalityRent": 3300,
    "differencePercentage": -6.0,
    "assessmentNotes": "Highly rated by local college students for food quality."
  },
  "demoListing": true
},
{
  "id": "prop-bls-engg-mess",
  "title": "Engineering Boys Mess",
  "description": "Specialized boys hostel and mess tailored for engineering students near BCET, Balasore. High-speed optical fiber for programming/assignments, late-night study lounge, power backup, and wholesome meals.",
  "city": "Balasore",
  "locality": "Sergarh",
  "address": "Sergarh, Remuna Road, Near BCET Campus, Balasore, Odisha 756060",
  "landmark": "Near Balasore College of Engineering & Technology (BCET)",
  "monthlyRent": 3500,
  "deposit": 3500,
  "maintenanceCharges": 200,
  "electricityCharges": "\u20b98/unit",
  "roomType": "double_sharing",
  "genderPreference": "boys",
  "furnished": "fully_furnished",
  "amenities": [
    "High-speed 100 Mbps Wi-Fi",
    "Late Night Study Hall",
    "Mess Dining",
    "Inverter Power Backup",
    "RO Water",
    "CCTV Security"
  ],
  "houseRules": [
    "Late night study allowed in hall",
    "Respect roommate study hours"
  ],
  "hostId": "host-engg-mess",
  "hostName": "Er. Alok Patra",
  "hostPhone": "+91 98532 99014",
  "hostVerified": true,
  "verificationStatus": "verified_by_platform",
  "verificationMethod": "Google Maps Verified Place + BCET Student Community Endorsed",
  "verificationTimestamp": "2026-10-05T14:00:00Z",
  "availabilityStatus": "available",
  "availableBeds": 4,
  "lastAvailabilityCheck": "2026-10-12T07:50:00Z",
  "images": [
    "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1540518614846-7ede433c4b49?auto=format&fit=crop&w=1000&q=80"
  ],
  "gmapUrl": "https://maps.app.goo.gl/bS7TfodDZMXmKgPeA",
  "messName": "Engineering Boys Mess & Canteen",
  "messPhone": "+91 98532 99014",
  "mealPlan": "Two heavy meals + Evening tea and snacks included",
  "coordinates": {
    "lat": 21.4962987,
    "lng": 86.8663298
  },
  "distanceToCampus": [
    {
      "campusName": "BCET Balasore",
      "distanceKm": 0.8,
      "walkingTimeMin": 9
    },
    {
      "campusName": "Fakir Mohan Autonomous College",
      "distanceKm": 5.2,
      "walkingTimeMin": 60
    },
    {
      "campusName": "Govt ITI Balasore",
      "distanceKm": 4.8,
      "walkingTimeMin": 55
    }
  ],
  "fairRentScore": {
    "status": "fair",
    "averageLocalityRent": 3700,
    "differencePercentage": -5.4,
    "assessmentNotes": "Prime choice for BCET students with high internet speed."
  },
  "demoListing": true
},
{
  "id": "prop-bls-best-mess",
  "title": "Best Mess",
  "description": "Top-rated student dormitory and mess in Gopalbindha, Balasore. Offers well-maintained double sharing rooms with ceiling fans, wooden cots, clean shared bathrooms, and reliable daily food services.",
  "city": "Balasore",
  "locality": "Gopalbindha",
  "address": "Gopalbindha Main Road, Balasore, Odisha 756019",
  "landmark": "Near Gopalbindha High School Road",
  "monthlyRent": 2950,
  "deposit": 2950,
  "maintenanceCharges": 100,
  "electricityCharges": "\u20b97.5/unit",
  "roomType": "double_sharing",
  "genderPreference": "boys",
  "furnished": "semi_furnished",
  "amenities": [
    "Mess Food Available",
    "Wi-Fi Access",
    "RO Drinking Water",
    "Two-Wheeler Parking",
    "Daily Cleaning"
  ],
  "houseRules": [
    "Curfew 10 PM",
    "No unauthorized guests in dorm rooms"
  ],
  "hostId": "host-best-mess",
  "hostName": "Bhabani Shankar Behera",
  "hostPhone": "+91 99381 20491",
  "hostVerified": true,
  "verificationStatus": "verified_by_platform",
  "verificationMethod": "Google Maps Verified Place + Physical Property Audit",
  "verificationTimestamp": "2026-10-07T11:00:00Z",
  "availabilityStatus": "available",
  "availableBeds": 2,
  "lastAvailabilityCheck": "2026-10-12T09:10:00Z",
  "images": [
    "https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1000&q=80"
  ],
  "gmapUrl": "https://maps.app.goo.gl/kymnZ6zPTfrE36Es9",
  "messName": "Best Mess & Caterers",
  "messPhone": "+91 99381 20491",
  "mealPlan": "Nutritious Odia dalma, santula, aloo bhaja, fish/egg thali at \u20b92,200/mo",
  "coordinates": {
    "lat": 21.488176,
    "lng": 86.9305977
  },
  "distanceToCampus": [
    {
      "campusName": "Fakir Mohan Autonomous College",
      "distanceKm": 1.4,
      "walkingTimeMin": 17
    },
    {
      "campusName": "Govt ITI Balasore",
      "distanceKm": 2.8,
      "walkingTimeMin": 33
    },
    {
      "campusName": "F.M. University (Old Campus)",
      "distanceKm": 2.6,
      "walkingTimeMin": 30
    }
  ],
  "fairRentScore": {
    "status": "fair",
    "averageLocalityRent": 3100,
    "differencePercentage": -4.8,
    "assessmentNotes": "Budget friendly with proven student satisfaction."
  },
  "demoListing": true
},
{
  "id": "prop-bls-annapurna-mess",
  "title": "Annapurna mess",
  "description": "Traditional student boys hostel and mess in Purusottampur, Balasore. Celebrated for hygienic homestyle cooking and comfortable double sharing student rooms with sturdy furniture and clean facilities.",
  "city": "Balasore",
  "locality": "Purusottampur",
  "address": "Purusottampur Market Road, Balasore, Odisha 756019",
  "landmark": "Near Purusottampur College Road",
  "monthlyRent": 3200,
  "deposit": 3200,
  "maintenanceCharges": 150,
  "electricityCharges": "\u20b98/unit",
  "roomType": "double_sharing",
  "genderPreference": "boys",
  "furnished": "fully_furnished",
  "amenities": [
    "Full Board Mess",
    "High-speed Wi-Fi",
    "Attached Bathroom",
    "RO Water",
    "CCTV Security",
    "Study Table"
  ],
  "houseRules": [
    "Dining hours strictly followed",
    "Cleanliness in common spaces"
  ],
  "hostId": "host-annapurna-bls",
  "hostName": "Girish Chandra Nayak",
  "hostPhone": "+91 94391 76203",
  "hostVerified": true,
  "verificationStatus": "verified_by_platform",
  "verificationMethod": "Google Maps Verified Place + FSSAI Food Hygiene Audit",
  "verificationTimestamp": "2026-10-09T09:30:00Z",
  "availabilityStatus": "available",
  "availableBeds": 3,
  "lastAvailabilityCheck": "2026-10-12T10:45:00Z",
  "images": [
    "https://images.unsplash.com/photo-1540518614846-7ede433c4b49?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=1000&q=80"
  ],
  "gmapUrl": "https://maps.app.goo.gl/CXVwAVVUF4Npefz69",
  "messName": "Maa Annapurna Mess & Bhojanalaya",
  "messPhone": "+91 94391 76203",
  "mealPlan": "Homestyle Odia food with fish curry, egg curry, and pure veg options daily",
  "coordinates": {
    "lat": 21.4864905,
    "lng": 86.9274337
  },
  "distanceToCampus": [
    {
      "campusName": "Fakir Mohan Autonomous College",
      "distanceKm": 1.3,
      "walkingTimeMin": 15
    },
    {
      "campusName": "Govt ITI Balasore",
      "distanceKm": 2.7,
      "walkingTimeMin": 32
    },
    {
      "campusName": "Balasore Railway Station",
      "distanceKm": 2.3,
      "walkingTimeMin": 27
    }
  ],
  "fairRentScore": {
    "status": "fair",
    "averageLocalityRent": 3350,
    "differencePercentage": -4.5,
    "assessmentNotes": "High culinary reputation among Balasore scholars."
  },
  "demoListing": true
},
{
  "id": "prop-bls-discipline-mess",
  "title": "Discipline Boys Mess in Balasore",
  "description": "Renowned disciplined student residency in Motiganj, Balasore. Offers structured study hours, 24x7 security, quiet atmosphere, double & triple sharing accommodations, and nutritious dining for competitive exam aspirants.",
  "city": "Balasore",
  "locality": "Motiganj",
  "address": "Motiganj Bazar Road, Balasore, Odisha 756003",
  "landmark": "Motiganj Bazar & F.M. Autonomous College Route",
  "monthlyRent": 3300,
  "deposit": 3300,
  "maintenanceCharges": 150,
  "electricityCharges": "\u20b98/unit",
  "roomType": "double_sharing",
  "genderPreference": "boys",
  "furnished": "fully_furnished",
  "amenities": [
    "Mess Food Service",
    "High-speed Wi-Fi",
    "Study Table & Chair",
    "CCTV Surveillance",
    "RO Purified Water",
    "Power Inverter"
  ],
  "houseRules": [
    "Curfew 9:30 PM sharp",
    "Mandatory quiet study hours 7 PM to 10 PM",
    "No smoking/alcohol"
  ],
  "hostId": "host-discipline",
  "hostName": "Manas Kumar Barik",
  "hostPhone": "+91 97782 11094",
  "hostVerified": true,
  "verificationStatus": "verified_by_platform",
  "verificationMethod": "Google Maps Verified Place + Police Verification of Host",
  "verificationTimestamp": "2026-10-08T15:20:00Z",
  "availabilityStatus": "available",
  "availableBeds": 2,
  "lastAvailabilityCheck": "2026-10-12T08:15:00Z",
  "images": [
    "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=1000&q=80"
  ],
  "gmapUrl": "https://maps.app.goo.gl/sYa7Wna98TANtezk7",
  "messName": "Discipline Boys Mess & Tiffin",
  "messPhone": "+91 97782 11094",
  "mealPlan": "Timely healthy lunch and dinner with balanced protein diet",
  "coordinates": {
    "lat": 21.4888174,
    "lng": 86.9301799
  },
  "distanceToCampus": [
    {
      "campusName": "Fakir Mohan Autonomous College",
      "distanceKm": 1.1,
      "walkingTimeMin": 13
    },
    {
      "campusName": "Govt ITI Balasore",
      "distanceKm": 2.4,
      "walkingTimeMin": 28
    },
    {
      "campusName": "Balasore Coaching Hub",
      "distanceKm": 0.5,
      "walkingTimeMin": 6
    }
  ],
  "fairRentScore": {
    "status": "fair",
    "averageLocalityRent": 3450,
    "differencePercentage": -4.3,
    "assessmentNotes": "Ideal focused study environment near F.M. College."
  },
  "demoListing": true
},
{
  "id": "prop-bls-student-zone",
  "title": "Student Zone Boys Mess",
  "description": "Modern student hostel and study lounge in Mallikashpur, Balasore. Offers comfortable single and double sharing rooms, ergonomic study setups, high-speed Wi-Fi, and complete meal arrangements.",
  "city": "Balasore",
  "locality": "Mallikashpur",
  "address": "Mallikashpur, Near Overbridge, Balasore, Odisha 756001",
  "landmark": "Near Mallikashpur Bridge & Coaching Hub",
  "monthlyRent": 3400,
  "deposit": 3400,
  "maintenanceCharges": 200,
  "electricityCharges": "\u20b98/unit",
  "roomType": "single_private",
  "genderPreference": "boys",
  "furnished": "fully_furnished",
  "amenities": [
    "High-speed Wi-Fi",
    "In-house Mess",
    "Ergonomic Study Table",
    "Attached Bathroom",
    "RO Drinking Water",
    "CCTV Security"
  ],
  "houseRules": [
    "No disturbance to other scholars",
    "Gate closes at 10 PM"
  ],
  "hostId": "host-student-zone",
  "hostName": "Tapan Kumar Mohanty",
  "hostPhone": "+91 93382 45012",
  "hostVerified": true,
  "verificationStatus": "verified_by_platform",
  "verificationMethod": "Google Maps Verified Place + On-Site Physical Inspection",
  "verificationTimestamp": "2026-10-10T14:00:00Z",
  "availabilityStatus": "available",
  "availableBeds": 2,
  "lastAvailabilityCheck": "2026-10-12T09:30:00Z",
  "images": [
    "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1540518614846-7ede433c4b49?auto=format&fit=crop&w=1000&q=80"
  ],
  "gmapUrl": "https://maps.app.goo.gl/rz6A9i1oqv25kHf26",
  "messName": "Student Zone Boys Mess & Study Lounge",
  "messPhone": "+91 93382 45012",
  "mealPlan": "Two heavy meals daily + Morning tea included",
  "coordinates": {
    "lat": 21.4924903,
    "lng": 86.930115
  },
  "distanceToCampus": [
    {
      "campusName": "Fakir Mohan Autonomous College",
      "distanceKm": 1.2,
      "walkingTimeMin": 14
    },
    {
      "campusName": "Govt ITI Balasore",
      "distanceKm": 2.2,
      "walkingTimeMin": 26
    },
    {
      "campusName": "Balasore Railway Station",
      "distanceKm": 1.8,
      "walkingTimeMin": 21
    }
  ],
  "fairRentScore": {
    "status": "fair",
    "averageLocalityRent": 3600,
    "differencePercentage": -5.6,
    "assessmentNotes": "Premium amenities and private study environment."
  },
  "demoListing": true
},
{
  "id": "prop-bls-panda-mess",
  "title": "Panda boy's mess",
  "description": "Cozy and economical boys accommodation located in Gopalbindha Lane 2, Balasore. Offers double and triple-sharing rooms with individual beds, cupboards, ceiling fans, and a family-run mess serving home-cooked meals.",
  "city": "Balasore",
  "locality": "Gopalbindha",
  "address": "Lane 2, Near Old Kali Mandir, Gopalbindha, Balasore, Odisha 756019",
  "landmark": "Near Old Kali Mandir, Gopalbindha",
  "monthlyRent": 2850,
  "deposit": 2850,
  "maintenanceCharges": 100,
  "electricityCharges": "\u20b97.5/unit",
  "roomType": "double_sharing",
  "genderPreference": "boys",
  "furnished": "semi_furnished",
  "amenities": [
    "Home-Cooked Mess Food",
    "Wi-Fi Access",
    "RO Filter Water",
    "Study Table",
    "Parking Space"
  ],
  "houseRules": [
    "Entry before 10 PM",
    "No smoking on premises"
  ],
  "hostId": "host-panda-mess",
  "hostName": "Sudhanshu Panda",
  "hostPhone": "+91 98619 44321",
  "hostVerified": true,
  "verificationStatus": "verified_by_platform",
  "verificationMethod": "Google Maps Verified Place + Identity Check",
  "verificationTimestamp": "2026-10-09T16:15:00Z",
  "availabilityStatus": "available",
  "availableBeds": 3,
  "lastAvailabilityCheck": "2026-10-12T07:45:00Z",
  "images": [
    "https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1000&q=80"
  ],
  "gmapUrl": "https://maps.app.goo.gl/XftqL18nfy7E4wWUA",
  "messName": "Panda Boy's Mess & Kitchen",
  "messPhone": "+91 98619 44321",
  "mealPlan": "Authentic home-cooked Odia meals at \u20b92,100/mo",
  "coordinates": {
    "lat": 21.4859518,
    "lng": 86.9273267
  },
  "distanceToCampus": [
    {
      "campusName": "Fakir Mohan Autonomous College",
      "distanceKm": 1.5,
      "walkingTimeMin": 18
    },
    {
      "campusName": "Govt ITI Balasore",
      "distanceKm": 2.9,
      "walkingTimeMin": 34
    },
    {
      "campusName": "Purusottampur Market",
      "distanceKm": 0.4,
      "walkingTimeMin": 5
    }
  ],
  "fairRentScore": {
    "status": "fair",
    "averageLocalityRent": 3000,
    "differencePercentage": -5.0,
    "assessmentNotes": "Very economical with supportive family management."
  },
  "demoListing": true
},
{
  "id": "prop-bls-aadarsh-mess",
  "title": "Aadarsh Boys Mess",
  "description": "Spacious guest rooms and student mess in Remuna, Balasore. Offers peaceful environment, large airy double-sharing rooms, attached bathrooms, dedicated study area, and wholesome vegetarian & non-vegetarian food.",
  "city": "Balasore",
  "locality": "Remuna",
  "address": "Remuna Jagannath Temple Road, Balasore, Odisha 756019",
  "landmark": "500m from Remuna Jagannath Temple road",
  "monthlyRent": 3000,
  "deposit": 3000,
  "maintenanceCharges": 150,
  "electricityCharges": "\u20b98/unit",
  "roomType": "double_sharing",
  "genderPreference": "boys",
  "furnished": "fully_furnished",
  "amenities": [
    "Mess Dining Hall",
    "High-speed Wi-Fi",
    "Attached Bathroom",
    "RO Drinking Water",
    "Two-Wheeler Parking",
    "CCTV Security"
  ],
  "houseRules": [
    "Curfew 9:30 PM",
    "Maintain clean dining etiquette"
  ],
  "hostId": "host-aadarsh",
  "hostName": "Santosh Kumar Rout",
  "hostPhone": "+91 94379 88120",
  "hostVerified": true,
  "verificationStatus": "verified_by_platform",
  "verificationMethod": "Google Maps Verified Place + Property Documents Verification",
  "verificationTimestamp": "2026-10-07T13:40:00Z",
  "availabilityStatus": "available",
  "availableBeds": 4,
  "lastAvailabilityCheck": "2026-10-12T08:50:00Z",
  "images": [
    "https://images.unsplash.com/photo-1540518614846-7ede433c4b49?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=1000&q=80"
  ],
  "gmapUrl": "https://maps.app.goo.gl/2ZkHCuBNmTrzqBkL7",
  "messName": "Aadarsh Boys Mess & Dining Hall",
  "messPhone": "+91 94379 88120",
  "mealPlan": "Fresh meals twice daily with variety of seasonal vegetables and dal",
  "coordinates": {
    "lat": 21.518596,
    "lng": 86.8781444
  },
  "distanceToCampus": [
    {
      "campusName": "Remuna College",
      "distanceKm": 0.9,
      "walkingTimeMin": 11
    },
    {
      "campusName": "BCET Balasore",
      "distanceKm": 2.8,
      "walkingTimeMin": 33
    },
    {
      "campusName": "Fakir Mohan Autonomous College",
      "distanceKm": 4.1,
      "walkingTimeMin": 48
    }
  ],
  "fairRentScore": {
    "status": "fair",
    "averageLocalityRent": 3200,
    "differencePercentage": -6.2,
    "assessmentNotes": "Spacious campus with clean attached bathrooms."
  },
  "demoListing": true
},
{
  "id": "prop-bls-sunrise-mess",
  "title": "Sunrise boys mess balasore",
  "description": "Active student housing center and mess located near Januganj Bypass, Balasore. Offers furnished double and triple sharing student rooms with Wi-Fi, study cots, and prompt meal service.",
  "city": "Balasore",
  "locality": "Januganj",
  "address": "Januganj Bypass, Near Reliance Petrol Pump, Balasore, Odisha 756019",
  "landmark": "Near Reliance Petrol Pump, Januganj",
  "monthlyRent": 3150,
  "deposit": 3150,
  "maintenanceCharges": 150,
  "electricityCharges": "\u20b98/unit",
  "roomType": "double_sharing",
  "genderPreference": "boys",
  "furnished": "fully_furnished",
  "amenities": [
    "Mess Food Service",
    "Wi-Fi Access",
    "RO Water",
    "Study Tables",
    "24x7 Water Supply",
    "Security Guard"
  ],
  "houseRules": [
    "Main door closed at 10 PM",
    "No alcohol or smoking allowed"
  ],
  "hostId": "host-sunrise",
  "hostName": "Ashok Kumar Tripathy",
  "hostPhone": "+91 96924 15098",
  "hostVerified": true,
  "verificationStatus": "verified_by_platform",
  "verificationMethod": "Google Maps Verified Place + Utility Verification",
  "verificationTimestamp": "2026-10-10T12:00:00Z",
  "availabilityStatus": "available",
  "availableBeds": 3,
  "lastAvailabilityCheck": "2026-10-12T10:10:00Z",
  "images": [
    "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=1000&q=80"
  ],
  "gmapUrl": "https://maps.app.goo.gl/eLUMnqqrPp13uBDJ8",
  "messName": "Sunrise Boys Mess & Tiffin Services",
  "messPhone": "+91 96924 15098",
  "mealPlan": "Two wholesome meals daily (Lunch + Dinner) with optional breakfast",
  "coordinates": {
    "lat": 21.4834258,
    "lng": 86.9327874
  },
  "distanceToCampus": [
    {
      "campusName": "Fakir Mohan Autonomous College",
      "distanceKm": 1.7,
      "walkingTimeMin": 20
    },
    {
      "campusName": "Govt ITI Balasore",
      "distanceKm": 3.3,
      "walkingTimeMin": 39
    },
    {
      "campusName": "BCET Balasore",
      "distanceKm": 4.8,
      "walkingTimeMin": 56
    }
  ],
  "fairRentScore": {
    "status": "fair",
    "averageLocalityRent": 3300,
    "differencePercentage": -4.5,
    "assessmentNotes": "Convenient road connectivity with all basic student essentials."
  },
  "demoListing": true
},
{
  "id": "prop-bls-trishakti-mess",
  "title": "Trishakti boys mess",
  "description": "Safe and well-supervised boys hostel and mess located in Motiganj / Phandi Chhaka, Balasore. Offers clean sharing rooms with wooden beds, storage, study desks, and three meals daily.",
  "city": "Balasore",
  "locality": "Motiganj",
  "address": "Phandi Chhaka, Motiganj, Balasore, Odisha 756003",
  "landmark": "Near Town Police Phandi, Balasore",
  "monthlyRent": 2900,
  "deposit": 2900,
  "maintenanceCharges": 100,
  "electricityCharges": "\u20b97.5/unit",
  "roomType": "triple_sharing",
  "genderPreference": "boys",
  "furnished": "semi_furnished",
  "amenities": [
    "Mess Food Included",
    "Wi-Fi Connection",
    "RO Water Cooler",
    "CCTV Security",
    "Two-Wheeler Parking"
  ],
  "houseRules": [
    "Curfew 9:30 PM",
    "No outsiders in bedrooms"
  ],
  "hostId": "host-trishakti",
  "hostName": "Pravakar Das",
  "hostPhone": "+91 99378 66102",
  "hostVerified": true,
  "verificationStatus": "verified_by_platform",
  "verificationMethod": "Google Maps Verified Place + Local Police Phandi Safety Record",
  "verificationTimestamp": "2026-10-08T10:30:00Z",
  "availabilityStatus": "available",
  "availableBeds": 4,
  "lastAvailabilityCheck": "2026-10-12T09:00:00Z",
  "images": [
    "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=1000&q=80"
  ],
  "gmapUrl": "https://maps.app.goo.gl/unGxKhkEc7wxfVR86",
  "messName": "Trishakti Boys Mess & Fooding",
  "messPhone": "+91 99378 66102",
  "mealPlan": "Homestyle Odia food with special feasts on Sundays",
  "coordinates": {
    "lat": 21.4883126,
    "lng": 86.9262597
  },
  "distanceToCampus": [
    {
      "campusName": "Fakir Mohan Autonomous College",
      "distanceKm": 1.0,
      "walkingTimeMin": 12
    },
    {
      "campusName": "Govt ITI Balasore",
      "distanceKm": 2.3,
      "walkingTimeMin": 27
    },
    {
      "campusName": "Motiganj Market",
      "distanceKm": 0.3,
      "walkingTimeMin": 4
    }
  ],
  "fairRentScore": {
    "status": "fair",
    "averageLocalityRent": 3100,
    "differencePercentage": -6.5,
    "assessmentNotes": "Highly secure location right beside police outpost."
  },
  "demoListing": true
},
{
  "id": "prop-bls-pradhan-boys",
  "title": "Pradhan Mess",
  "description": "Comfortable boys hostel and mess located on Gopalbindha Main Road, Balasore. Offers well-maintained double sharing rooms, clean bathrooms, high-speed Wi-Fi, and generous student meal servings.",
  "city": "Balasore",
  "locality": "Gopalbindha",
  "address": "Gopalbindha Main Road, Opposite Saraswati Shishu Mandir, Balasore, Odisha 756019",
  "landmark": "Opposite Saraswati Shishu Mandir, Gopalbindha",
  "monthlyRent": 3100,
  "deposit": 3100,
  "maintenanceCharges": 150,
  "electricityCharges": "\u20b98/unit",
  "roomType": "double_sharing",
  "genderPreference": "boys",
  "furnished": "fully_furnished",
  "amenities": [
    "Mess Food Included",
    "High-speed Wi-Fi",
    "Attached Bathroom",
    "RO Drinking Water",
    "Two-Wheeler Parking",
    "Study Desk"
  ],
  "houseRules": [
    "Gate closes at 10 PM",
    "No smoking or alcohol on premises"
  ],
  "hostId": "host-pradhan-boys",
  "hostName": "Prasanta Pradhan",
  "hostPhone": "+91 94374 55901",
  "hostVerified": true,
  "verificationStatus": "verified_by_platform",
  "verificationMethod": "Google Maps Verified Place + On-Site Inspection",
  "verificationTimestamp": "2026-10-11T11:20:00Z",
  "availabilityStatus": "available",
  "availableBeds": 2,
  "lastAvailabilityCheck": "2026-10-12T09:15:00Z",
  "images": [
    "https://images.unsplash.com/photo-1540518614846-7ede433c4b49?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1000&q=80"
  ],
  "gmapUrl": "https://maps.app.goo.gl/NJpvaNJ4sQKZfXt79",
  "messName": "Pradhan Boys Mess & Meals",
  "messPhone": "+91 94374 55901",
  "mealPlan": "Nutritious homestyle meals: unlimited rice, dal, veg curry + non-veg options",
  "coordinates": {
    "lat": 21.4878038,
    "lng": 86.9324833
  },
  "distanceToCampus": [
    {
      "campusName": "Fakir Mohan Autonomous College",
      "distanceKm": 1.5,
      "walkingTimeMin": 18
    },
    {
      "campusName": "Govt ITI Balasore",
      "distanceKm": 2.9,
      "walkingTimeMin": 34
    },
    {
      "campusName": "Purusottampur College Road",
      "distanceKm": 0.6,
      "walkingTimeMin": 7
    }
  ],
  "fairRentScore": {
    "status": "fair",
    "averageLocalityRent": 3250,
    "differencePercentage": -4.6,
    "assessmentNotes": "Quality food with comfortable living arrangements."
  },
  "demoListing": true
},
{
  "id": "prop-bls-satyabadi-mess",
  "title": "Satyabadi Mess",
  "description": "Traditional and reputable boys hostel and mess near Satyabadi High School, Chasa Khanda Road, Balasore. Offers spacious double and triple sharing student rooms, peaceful reading environment, and authentic Odisha homestyle meals.",
  "city": "Balasore",
  "locality": "Januganj",
  "address": "Chasa Khanda Road, Near Satyabadi High School, Balasore, Odisha 756019",
  "landmark": "Near Satyabadi High School, Balasore",
  "monthlyRent": 3050,
  "deposit": 3050,
  "maintenanceCharges": 100,
  "electricityCharges": "\u20b97.5/unit",
  "roomType": "double_sharing",
  "genderPreference": "boys",
  "furnished": "fully_furnished",
  "amenities": [
    "Mess Food Service",
    "Wi-Fi Access",
    "RO Drinking Water",
    "Individual Study Cot & Table",
    "Bicycle & Bike Parking",
    "Power Backup"
  ],
  "houseRules": [
    "Study hours 7 PM - 10 PM",
    "No loud noise after 10 PM",
    "Entry by 9:30 PM"
  ],
  "hostId": "host-satyabadi",
  "hostName": "Bikram Keshari Das",
  "hostPhone": "+91 98612 09843",
  "hostVerified": true,
  "verificationStatus": "verified_by_platform",
  "verificationMethod": "Google Maps Verified Place + Identity & Electricity Bill KYC",
  "verificationTimestamp": "2026-10-09T17:00:00Z",
  "availabilityStatus": "available",
  "availableBeds": 3,
  "lastAvailabilityCheck": "2026-10-12T08:40:00Z",
  "images": [
    "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=1000&q=80",
    "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=1000&q=80"
  ],
  "gmapUrl": "https://maps.app.goo.gl/qGBX5pXQLdPLTcM29",
  "messName": "Satyabadi Student Mess & Bhojan",
  "messPhone": "+91 98612 09843",
  "mealPlan": "Odia home-style cuisine: Dalma, Potala, Machha / Kukkuda tarkari",
  "coordinates": {
    "lat": 21.4888773,
    "lng": 86.9356402
  },
  "distanceToCampus": [
    {
      "campusName": "Fakir Mohan Autonomous College",
      "distanceKm": 1.6,
      "walkingTimeMin": 19
    },
    {
      "campusName": "Govt ITI Balasore",
      "distanceKm": 3.2,
      "walkingTimeMin": 38
    },
    {
      "campusName": "Januganj Square",
      "distanceKm": 0.7,
      "walkingTimeMin": 8
    }
  ],
  "fairRentScore": {
    "status": "fair",
    "averageLocalityRent": 3200,
    "differencePercentage": -4.7,
    "assessmentNotes": "Established student mess with warm hospitality and great study culture."
  },
  "demoListing": true
}
];

export const INITIAL_MESS_SERVICES: MessService[] = [
{
  "id": "mess-bls-pradhan-ladies",
  "name": "Pradhan Ladies Mess & Dining",
  "locality": "Bhimpura",
  "city": "Balasore",
  "address": "Near Nathapani Mandir, Bhimpura, Balasore, Odisha 756001",
  "phone": "+91 94372 81904",
  "gmapUrl": "https://maps.app.goo.gl/LvKsy372utCd8c2f8",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2400,
  "singleMealPrice": 60,
  "mealPlans": [
    {
      "id": "plan-prop-bls-pradhan-ladies-standard",
      "title": "Two Meals Standard (Lunch & Dinner)",
      "description": "3 Homestyle Meals Daily Included (Breakfast, Lunch & Dinner)",
      "mealsPerDay": 2,
      "pricePerMonth": 2200,
      "includesBreakfast": false
    },
    {
      "id": "plan-prop-bls-pradhan-ladies-full",
      "title": "Full Board (Breakfast + Lunch + Dinner)",
      "description": "Daily 3 meals with morning tea & snacks",
      "mealsPerDay": 3,
      "pricePerMonth": 2900,
      "includesBreakfast": true
    }
  ],
  "sampleMenu": [
    {
      "day": "Monday",
      "lunch": "Rice, Roti, Dal Fry, Seasonal Tarkari, Salad",
      "dinner": "Roti, Dal Tadka, Aloo Dum, Kheer"
    },
    {
      "day": "Wednesday",
      "lunch": "Rice, Odia Dalma, Fish Curry / Paneer Butter Masala",
      "dinner": "Jeera Rice, Egg Curry, Salad"
    },
    {
      "day": "Friday",
      "lunch": "Rice, Dal, Machha Jhola / Mushroom Masala",
      "dinner": "Roti, Chicken Curry / Shahi Paneer, Papad"
    },
    {
      "day": "Sunday",
      "lunch": "Special Student Feast: Kadhai Chicken / Paneer, Pulao, Gulab Jamun",
      "dinner": "Light Khichdi / Roti & Tarkari"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "7:00 AM - 10:00 PM",
  "hygieneRating": "4.8/5 (Inspected & Verified)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "demoData": true
},
{
  "id": "mess-bls-freedom-mess",
  "name": "Freedom Mess & Food Service",
  "locality": "Sidheswar Colony",
  "city": "Balasore",
  "address": "Sidheswar Colony, Near Remuna Golei Road, Balasore, Odisha 756019",
  "phone": "+91 98614 77219",
  "gmapUrl": "https://maps.app.goo.gl/4Jn3pgLwbKiXQw9K7",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2200,
  "singleMealPrice": 60,
  "mealPlans": [
    {
      "id": "plan-prop-bls-freedom-mess-standard",
      "title": "Two Meals Standard (Lunch & Dinner)",
      "description": "Two Meals Daily (Lunch & Dinner) package available at \u20b92,200/mo",
      "mealsPerDay": 2,
      "pricePerMonth": 2200,
      "includesBreakfast": false
    },
    {
      "id": "plan-prop-bls-freedom-mess-full",
      "title": "Full Board (Breakfast + Lunch + Dinner)",
      "description": "Daily 3 meals with morning tea & snacks",
      "mealsPerDay": 3,
      "pricePerMonth": 2900,
      "includesBreakfast": true
    }
  ],
  "sampleMenu": [
    {
      "day": "Monday",
      "lunch": "Rice, Roti, Dal Fry, Seasonal Tarkari, Salad",
      "dinner": "Roti, Dal Tadka, Aloo Dum, Kheer"
    },
    {
      "day": "Wednesday",
      "lunch": "Rice, Odia Dalma, Fish Curry / Paneer Butter Masala",
      "dinner": "Jeera Rice, Egg Curry, Salad"
    },
    {
      "day": "Friday",
      "lunch": "Rice, Dal, Machha Jhola / Mushroom Masala",
      "dinner": "Roti, Chicken Curry / Shahi Paneer, Papad"
    },
    {
      "day": "Sunday",
      "lunch": "Special Student Feast: Kadhai Chicken / Paneer, Pulao, Gulab Jamun",
      "dinner": "Light Khichdi / Roti & Tarkari"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "7:00 AM - 10:00 PM",
  "hygieneRating": "4.8/5 (Inspected & Verified)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "demoData": true
},
{
  "id": "mess-bls-sahu-mess",
  "name": "Sahu Student Mess & Tiffin",
  "locality": "Sahadevkhunta",
  "city": "Balasore",
  "address": "Sahadevkhunta, Near Bus Stand Road, Balasore, Odisha 756001",
  "phone": "+91 94380 56321",
  "gmapUrl": "https://maps.app.goo.gl/Kp9piN71n1gMyzRR8",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2400,
  "singleMealPrice": 60,
  "mealPlans": [
    {
      "id": "plan-prop-bls-sahu-mess-standard",
      "title": "Two Meals Standard (Lunch & Dinner)",
      "description": "Veg & Non-Veg Lunch & Dinner with Dalma, Bhaja, and Chicken/Fish twice weekly",
      "mealsPerDay": 2,
      "pricePerMonth": 2200,
      "includesBreakfast": false
    },
    {
      "id": "plan-prop-bls-sahu-mess-full",
      "title": "Full Board (Breakfast + Lunch + Dinner)",
      "description": "Daily 3 meals with morning tea & snacks",
      "mealsPerDay": 3,
      "pricePerMonth": 2900,
      "includesBreakfast": true
    }
  ],
  "sampleMenu": [
    {
      "day": "Monday",
      "lunch": "Rice, Roti, Dal Fry, Seasonal Tarkari, Salad",
      "dinner": "Roti, Dal Tadka, Aloo Dum, Kheer"
    },
    {
      "day": "Wednesday",
      "lunch": "Rice, Odia Dalma, Fish Curry / Paneer Butter Masala",
      "dinner": "Jeera Rice, Egg Curry, Salad"
    },
    {
      "day": "Friday",
      "lunch": "Rice, Dal, Machha Jhola / Mushroom Masala",
      "dinner": "Roti, Chicken Curry / Shahi Paneer, Papad"
    },
    {
      "day": "Sunday",
      "lunch": "Special Student Feast: Kadhai Chicken / Paneer, Pulao, Gulab Jamun",
      "dinner": "Light Khichdi / Roti & Tarkari"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "7:00 AM - 10:00 PM",
  "hygieneRating": "4.8/5 (Inspected & Verified)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "demoData": true
},
{
  "id": "mess-bls-mohapatra-mess",
  "name": "Mohapatra Boys Mess & Bhojanalaya",
  "locality": "Near ITI Square",
  "city": "Balasore",
  "address": "Lane 3, Near ITI Square, Balasore, Odisha 756001",
  "phone": "+91 97771 44902",
  "gmapUrl": "https://maps.app.goo.gl/xHvufuvhF3Enj7gq8",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2200,
  "singleMealPrice": 60,
  "mealPlans": [
    {
      "id": "plan-prop-bls-mohapatra-mess-standard",
      "title": "Two Meals Standard (Lunch & Dinner)",
      "description": "Unlimited Rice, Roti, Dal, Mix Veg Tarkari + Egg/Fish option",
      "mealsPerDay": 2,
      "pricePerMonth": 2200,
      "includesBreakfast": false
    },
    {
      "id": "plan-prop-bls-mohapatra-mess-full",
      "title": "Full Board (Breakfast + Lunch + Dinner)",
      "description": "Daily 3 meals with morning tea & snacks",
      "mealsPerDay": 3,
      "pricePerMonth": 2900,
      "includesBreakfast": true
    }
  ],
  "sampleMenu": [
    {
      "day": "Monday",
      "lunch": "Rice, Roti, Dal Fry, Seasonal Tarkari, Salad",
      "dinner": "Roti, Dal Tadka, Aloo Dum, Kheer"
    },
    {
      "day": "Wednesday",
      "lunch": "Rice, Odia Dalma, Fish Curry / Paneer Butter Masala",
      "dinner": "Jeera Rice, Egg Curry, Salad"
    },
    {
      "day": "Friday",
      "lunch": "Rice, Dal, Machha Jhola / Mushroom Masala",
      "dinner": "Roti, Chicken Curry / Shahi Paneer, Papad"
    },
    {
      "day": "Sunday",
      "lunch": "Special Student Feast: Kadhai Chicken / Paneer, Pulao, Gulab Jamun",
      "dinner": "Light Khichdi / Roti & Tarkari"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "7:00 AM - 10:00 PM",
  "hygieneRating": "4.8/5 (Inspected & Verified)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "demoData": true
},
{
  "id": "mess-bls-sai-krishna-mess",
  "name": "Sai Krishna Mess & Tiffin Center",
  "locality": "Station Road",
  "city": "Balasore",
  "address": "Station Road, Near Balasore Railway Station, Balasore, Odisha 756001",
  "phone": "+91 93375 88109",
  "gmapUrl": "https://maps.app.goo.gl/98w1LMGJscsv7DhT8",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2400,
  "singleMealPrice": 60,
  "mealPlans": [
    {
      "id": "plan-prop-bls-sai-krishna-mess-standard",
      "title": "Two Meals Standard (Lunch & Dinner)",
      "description": "Breakfast, Lunch, and Dinner combo plans available at \u20b92,500/month",
      "mealsPerDay": 2,
      "pricePerMonth": 2200,
      "includesBreakfast": false
    },
    {
      "id": "plan-prop-bls-sai-krishna-mess-full",
      "title": "Full Board (Breakfast + Lunch + Dinner)",
      "description": "Daily 3 meals with morning tea & snacks",
      "mealsPerDay": 3,
      "pricePerMonth": 2900,
      "includesBreakfast": true
    }
  ],
  "sampleMenu": [
    {
      "day": "Monday",
      "lunch": "Rice, Roti, Dal Fry, Seasonal Tarkari, Salad",
      "dinner": "Roti, Dal Tadka, Aloo Dum, Kheer"
    },
    {
      "day": "Wednesday",
      "lunch": "Rice, Odia Dalma, Fish Curry / Paneer Butter Masala",
      "dinner": "Jeera Rice, Egg Curry, Salad"
    },
    {
      "day": "Friday",
      "lunch": "Rice, Dal, Machha Jhola / Mushroom Masala",
      "dinner": "Roti, Chicken Curry / Shahi Paneer, Papad"
    },
    {
      "day": "Sunday",
      "lunch": "Special Student Feast: Kadhai Chicken / Paneer, Pulao, Gulab Jamun",
      "dinner": "Light Khichdi / Roti & Tarkari"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "7:00 AM - 10:00 PM",
  "hygieneRating": "4.8/5 (Inspected & Verified)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "demoData": true
},
{
  "id": "mess-bls-krishna-boys",
  "name": "Krishna Boys Mess & Dining",
  "locality": "Januganj",
  "city": "Balasore",
  "address": "Januganj Golei, Gopalbindha, Balasore, Odisha 756019",
  "phone": "+91 94376 33019",
  "gmapUrl": "https://maps.app.goo.gl/Q9dzWnRFDvyeHd4PA",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2400,
  "singleMealPrice": 60,
  "mealPlans": [
    {
      "id": "plan-prop-bls-krishna-boys-standard",
      "title": "Two Meals Standard (Lunch & Dinner)",
      "description": "Full board: Morning breakfast + tea, homestyle lunch, and hot dinner",
      "mealsPerDay": 2,
      "pricePerMonth": 2200,
      "includesBreakfast": false
    },
    {
      "id": "plan-prop-bls-krishna-boys-full",
      "title": "Full Board (Breakfast + Lunch + Dinner)",
      "description": "Daily 3 meals with morning tea & snacks",
      "mealsPerDay": 3,
      "pricePerMonth": 2900,
      "includesBreakfast": true
    }
  ],
  "sampleMenu": [
    {
      "day": "Monday",
      "lunch": "Rice, Roti, Dal Fry, Seasonal Tarkari, Salad",
      "dinner": "Roti, Dal Tadka, Aloo Dum, Kheer"
    },
    {
      "day": "Wednesday",
      "lunch": "Rice, Odia Dalma, Fish Curry / Paneer Butter Masala",
      "dinner": "Jeera Rice, Egg Curry, Salad"
    },
    {
      "day": "Friday",
      "lunch": "Rice, Dal, Machha Jhola / Mushroom Masala",
      "dinner": "Roti, Chicken Curry / Shahi Paneer, Papad"
    },
    {
      "day": "Sunday",
      "lunch": "Special Student Feast: Kadhai Chicken / Paneer, Pulao, Gulab Jamun",
      "dinner": "Light Khichdi / Roti & Tarkari"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "7:00 AM - 10:00 PM",
  "hygieneRating": "4.8/5 (Inspected & Verified)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "demoData": true
},
{
  "id": "mess-bls-engg-mess",
  "name": "Engineering Boys Mess & Canteen",
  "locality": "Sergarh",
  "city": "Balasore",
  "address": "Sergarh, Remuna Road, Near BCET Campus, Balasore, Odisha 756060",
  "phone": "+91 98532 99014",
  "gmapUrl": "https://maps.app.goo.gl/bS7TfodDZMXmKgPeA",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2400,
  "singleMealPrice": 60,
  "mealPlans": [
    {
      "id": "plan-prop-bls-engg-mess-standard",
      "title": "Two Meals Standard (Lunch & Dinner)",
      "description": "Two heavy meals + Evening tea and snacks included",
      "mealsPerDay": 2,
      "pricePerMonth": 2200,
      "includesBreakfast": false
    },
    {
      "id": "plan-prop-bls-engg-mess-full",
      "title": "Full Board (Breakfast + Lunch + Dinner)",
      "description": "Daily 3 meals with morning tea & snacks",
      "mealsPerDay": 3,
      "pricePerMonth": 2900,
      "includesBreakfast": true
    }
  ],
  "sampleMenu": [
    {
      "day": "Monday",
      "lunch": "Rice, Roti, Dal Fry, Seasonal Tarkari, Salad",
      "dinner": "Roti, Dal Tadka, Aloo Dum, Kheer"
    },
    {
      "day": "Wednesday",
      "lunch": "Rice, Odia Dalma, Fish Curry / Paneer Butter Masala",
      "dinner": "Jeera Rice, Egg Curry, Salad"
    },
    {
      "day": "Friday",
      "lunch": "Rice, Dal, Machha Jhola / Mushroom Masala",
      "dinner": "Roti, Chicken Curry / Shahi Paneer, Papad"
    },
    {
      "day": "Sunday",
      "lunch": "Special Student Feast: Kadhai Chicken / Paneer, Pulao, Gulab Jamun",
      "dinner": "Light Khichdi / Roti & Tarkari"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "7:00 AM - 10:00 PM",
  "hygieneRating": "4.8/5 (Inspected & Verified)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "demoData": true
},
{
  "id": "mess-bls-best-mess",
  "name": "Best Mess & Caterers",
  "locality": "Gopalbindha",
  "city": "Balasore",
  "address": "Gopalbindha Main Road, Balasore, Odisha 756019",
  "phone": "+91 99381 20491",
  "gmapUrl": "https://maps.app.goo.gl/kymnZ6zPTfrE36Es9",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2200,
  "singleMealPrice": 60,
  "mealPlans": [
    {
      "id": "plan-prop-bls-best-mess-standard",
      "title": "Two Meals Standard (Lunch & Dinner)",
      "description": "Nutritious Odia dalma, santula, aloo bhaja, fish/egg thali at \u20b92,200/mo",
      "mealsPerDay": 2,
      "pricePerMonth": 2200,
      "includesBreakfast": false
    },
    {
      "id": "plan-prop-bls-best-mess-full",
      "title": "Full Board (Breakfast + Lunch + Dinner)",
      "description": "Daily 3 meals with morning tea & snacks",
      "mealsPerDay": 3,
      "pricePerMonth": 2900,
      "includesBreakfast": true
    }
  ],
  "sampleMenu": [
    {
      "day": "Monday",
      "lunch": "Rice, Roti, Dal Fry, Seasonal Tarkari, Salad",
      "dinner": "Roti, Dal Tadka, Aloo Dum, Kheer"
    },
    {
      "day": "Wednesday",
      "lunch": "Rice, Odia Dalma, Fish Curry / Paneer Butter Masala",
      "dinner": "Jeera Rice, Egg Curry, Salad"
    },
    {
      "day": "Friday",
      "lunch": "Rice, Dal, Machha Jhola / Mushroom Masala",
      "dinner": "Roti, Chicken Curry / Shahi Paneer, Papad"
    },
    {
      "day": "Sunday",
      "lunch": "Special Student Feast: Kadhai Chicken / Paneer, Pulao, Gulab Jamun",
      "dinner": "Light Khichdi / Roti & Tarkari"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "7:00 AM - 10:00 PM",
  "hygieneRating": "4.8/5 (Inspected & Verified)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "demoData": true
},
{
  "id": "mess-bls-annapurna-mess",
  "name": "Maa Annapurna Mess & Bhojanalaya",
  "locality": "Purusottampur",
  "city": "Balasore",
  "address": "Purusottampur Market Road, Balasore, Odisha 756019",
  "phone": "+91 94391 76203",
  "gmapUrl": "https://maps.app.goo.gl/CXVwAVVUF4Npefz69",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2400,
  "singleMealPrice": 60,
  "mealPlans": [
    {
      "id": "plan-prop-bls-annapurna-mess-standard",
      "title": "Two Meals Standard (Lunch & Dinner)",
      "description": "Homestyle Odia food with fish curry, egg curry, and pure veg options daily",
      "mealsPerDay": 2,
      "pricePerMonth": 2200,
      "includesBreakfast": false
    },
    {
      "id": "plan-prop-bls-annapurna-mess-full",
      "title": "Full Board (Breakfast + Lunch + Dinner)",
      "description": "Daily 3 meals with morning tea & snacks",
      "mealsPerDay": 3,
      "pricePerMonth": 2900,
      "includesBreakfast": true
    }
  ],
  "sampleMenu": [
    {
      "day": "Monday",
      "lunch": "Rice, Roti, Dal Fry, Seasonal Tarkari, Salad",
      "dinner": "Roti, Dal Tadka, Aloo Dum, Kheer"
    },
    {
      "day": "Wednesday",
      "lunch": "Rice, Odia Dalma, Fish Curry / Paneer Butter Masala",
      "dinner": "Jeera Rice, Egg Curry, Salad"
    },
    {
      "day": "Friday",
      "lunch": "Rice, Dal, Machha Jhola / Mushroom Masala",
      "dinner": "Roti, Chicken Curry / Shahi Paneer, Papad"
    },
    {
      "day": "Sunday",
      "lunch": "Special Student Feast: Kadhai Chicken / Paneer, Pulao, Gulab Jamun",
      "dinner": "Light Khichdi / Roti & Tarkari"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "7:00 AM - 10:00 PM",
  "hygieneRating": "4.8/5 (Inspected & Verified)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "demoData": true
},
{
  "id": "mess-bls-discipline-mess",
  "name": "Discipline Boys Mess & Tiffin",
  "locality": "Motiganj",
  "city": "Balasore",
  "address": "Motiganj Bazar Road, Balasore, Odisha 756003",
  "phone": "+91 97782 11094",
  "gmapUrl": "https://maps.app.goo.gl/sYa7Wna98TANtezk7",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2400,
  "singleMealPrice": 60,
  "mealPlans": [
    {
      "id": "plan-prop-bls-discipline-mess-standard",
      "title": "Two Meals Standard (Lunch & Dinner)",
      "description": "Timely healthy lunch and dinner with balanced protein diet",
      "mealsPerDay": 2,
      "pricePerMonth": 2200,
      "includesBreakfast": false
    },
    {
      "id": "plan-prop-bls-discipline-mess-full",
      "title": "Full Board (Breakfast + Lunch + Dinner)",
      "description": "Daily 3 meals with morning tea & snacks",
      "mealsPerDay": 3,
      "pricePerMonth": 2900,
      "includesBreakfast": true
    }
  ],
  "sampleMenu": [
    {
      "day": "Monday",
      "lunch": "Rice, Roti, Dal Fry, Seasonal Tarkari, Salad",
      "dinner": "Roti, Dal Tadka, Aloo Dum, Kheer"
    },
    {
      "day": "Wednesday",
      "lunch": "Rice, Odia Dalma, Fish Curry / Paneer Butter Masala",
      "dinner": "Jeera Rice, Egg Curry, Salad"
    },
    {
      "day": "Friday",
      "lunch": "Rice, Dal, Machha Jhola / Mushroom Masala",
      "dinner": "Roti, Chicken Curry / Shahi Paneer, Papad"
    },
    {
      "day": "Sunday",
      "lunch": "Special Student Feast: Kadhai Chicken / Paneer, Pulao, Gulab Jamun",
      "dinner": "Light Khichdi / Roti & Tarkari"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "7:00 AM - 10:00 PM",
  "hygieneRating": "4.8/5 (Inspected & Verified)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "demoData": true
},
{
  "id": "mess-bls-student-zone",
  "name": "Student Zone Boys Mess & Study Lounge",
  "locality": "Mallikashpur",
  "city": "Balasore",
  "address": "Mallikashpur, Near Overbridge, Balasore, Odisha 756001",
  "phone": "+91 93382 45012",
  "gmapUrl": "https://maps.app.goo.gl/rz6A9i1oqv25kHf26",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2400,
  "singleMealPrice": 60,
  "mealPlans": [
    {
      "id": "plan-prop-bls-student-zone-standard",
      "title": "Two Meals Standard (Lunch & Dinner)",
      "description": "Two heavy meals daily + Morning tea included",
      "mealsPerDay": 2,
      "pricePerMonth": 2200,
      "includesBreakfast": false
    },
    {
      "id": "plan-prop-bls-student-zone-full",
      "title": "Full Board (Breakfast + Lunch + Dinner)",
      "description": "Daily 3 meals with morning tea & snacks",
      "mealsPerDay": 3,
      "pricePerMonth": 2900,
      "includesBreakfast": true
    }
  ],
  "sampleMenu": [
    {
      "day": "Monday",
      "lunch": "Rice, Roti, Dal Fry, Seasonal Tarkari, Salad",
      "dinner": "Roti, Dal Tadka, Aloo Dum, Kheer"
    },
    {
      "day": "Wednesday",
      "lunch": "Rice, Odia Dalma, Fish Curry / Paneer Butter Masala",
      "dinner": "Jeera Rice, Egg Curry, Salad"
    },
    {
      "day": "Friday",
      "lunch": "Rice, Dal, Machha Jhola / Mushroom Masala",
      "dinner": "Roti, Chicken Curry / Shahi Paneer, Papad"
    },
    {
      "day": "Sunday",
      "lunch": "Special Student Feast: Kadhai Chicken / Paneer, Pulao, Gulab Jamun",
      "dinner": "Light Khichdi / Roti & Tarkari"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "7:00 AM - 10:00 PM",
  "hygieneRating": "4.8/5 (Inspected & Verified)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "demoData": true
},
{
  "id": "mess-bls-panda-mess",
  "name": "Panda Boy's Mess & Kitchen",
  "locality": "Gopalbindha",
  "city": "Balasore",
  "address": "Lane 2, Near Old Kali Mandir, Gopalbindha, Balasore, Odisha 756019",
  "phone": "+91 98619 44321",
  "gmapUrl": "https://maps.app.goo.gl/XftqL18nfy7E4wWUA",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2200,
  "singleMealPrice": 60,
  "mealPlans": [
    {
      "id": "plan-prop-bls-panda-mess-standard",
      "title": "Two Meals Standard (Lunch & Dinner)",
      "description": "Authentic home-cooked Odia meals at \u20b92,100/mo",
      "mealsPerDay": 2,
      "pricePerMonth": 2200,
      "includesBreakfast": false
    },
    {
      "id": "plan-prop-bls-panda-mess-full",
      "title": "Full Board (Breakfast + Lunch + Dinner)",
      "description": "Daily 3 meals with morning tea & snacks",
      "mealsPerDay": 3,
      "pricePerMonth": 2900,
      "includesBreakfast": true
    }
  ],
  "sampleMenu": [
    {
      "day": "Monday",
      "lunch": "Rice, Roti, Dal Fry, Seasonal Tarkari, Salad",
      "dinner": "Roti, Dal Tadka, Aloo Dum, Kheer"
    },
    {
      "day": "Wednesday",
      "lunch": "Rice, Odia Dalma, Fish Curry / Paneer Butter Masala",
      "dinner": "Jeera Rice, Egg Curry, Salad"
    },
    {
      "day": "Friday",
      "lunch": "Rice, Dal, Machha Jhola / Mushroom Masala",
      "dinner": "Roti, Chicken Curry / Shahi Paneer, Papad"
    },
    {
      "day": "Sunday",
      "lunch": "Special Student Feast: Kadhai Chicken / Paneer, Pulao, Gulab Jamun",
      "dinner": "Light Khichdi / Roti & Tarkari"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "7:00 AM - 10:00 PM",
  "hygieneRating": "4.8/5 (Inspected & Verified)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "demoData": true
},
{
  "id": "mess-bls-aadarsh-mess",
  "name": "Aadarsh Boys Mess & Dining Hall",
  "locality": "Remuna",
  "city": "Balasore",
  "address": "Remuna Jagannath Temple Road, Balasore, Odisha 756019",
  "phone": "+91 94379 88120",
  "gmapUrl": "https://maps.app.goo.gl/2ZkHCuBNmTrzqBkL7",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2400,
  "singleMealPrice": 60,
  "mealPlans": [
    {
      "id": "plan-prop-bls-aadarsh-mess-standard",
      "title": "Two Meals Standard (Lunch & Dinner)",
      "description": "Fresh meals twice daily with variety of seasonal vegetables and dal",
      "mealsPerDay": 2,
      "pricePerMonth": 2200,
      "includesBreakfast": false
    },
    {
      "id": "plan-prop-bls-aadarsh-mess-full",
      "title": "Full Board (Breakfast + Lunch + Dinner)",
      "description": "Daily 3 meals with morning tea & snacks",
      "mealsPerDay": 3,
      "pricePerMonth": 2900,
      "includesBreakfast": true
    }
  ],
  "sampleMenu": [
    {
      "day": "Monday",
      "lunch": "Rice, Roti, Dal Fry, Seasonal Tarkari, Salad",
      "dinner": "Roti, Dal Tadka, Aloo Dum, Kheer"
    },
    {
      "day": "Wednesday",
      "lunch": "Rice, Odia Dalma, Fish Curry / Paneer Butter Masala",
      "dinner": "Jeera Rice, Egg Curry, Salad"
    },
    {
      "day": "Friday",
      "lunch": "Rice, Dal, Machha Jhola / Mushroom Masala",
      "dinner": "Roti, Chicken Curry / Shahi Paneer, Papad"
    },
    {
      "day": "Sunday",
      "lunch": "Special Student Feast: Kadhai Chicken / Paneer, Pulao, Gulab Jamun",
      "dinner": "Light Khichdi / Roti & Tarkari"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "7:00 AM - 10:00 PM",
  "hygieneRating": "4.8/5 (Inspected & Verified)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "demoData": true
},
{
  "id": "mess-bls-sunrise-mess",
  "name": "Sunrise Boys Mess & Tiffin Services",
  "locality": "Januganj",
  "city": "Balasore",
  "address": "Januganj Bypass, Near Reliance Petrol Pump, Balasore, Odisha 756019",
  "phone": "+91 96924 15098",
  "gmapUrl": "https://maps.app.goo.gl/eLUMnqqrPp13uBDJ8",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2400,
  "singleMealPrice": 60,
  "mealPlans": [
    {
      "id": "plan-prop-bls-sunrise-mess-standard",
      "title": "Two Meals Standard (Lunch & Dinner)",
      "description": "Two wholesome meals daily (Lunch + Dinner) with optional breakfast",
      "mealsPerDay": 2,
      "pricePerMonth": 2200,
      "includesBreakfast": false
    },
    {
      "id": "plan-prop-bls-sunrise-mess-full",
      "title": "Full Board (Breakfast + Lunch + Dinner)",
      "description": "Daily 3 meals with morning tea & snacks",
      "mealsPerDay": 3,
      "pricePerMonth": 2900,
      "includesBreakfast": true
    }
  ],
  "sampleMenu": [
    {
      "day": "Monday",
      "lunch": "Rice, Roti, Dal Fry, Seasonal Tarkari, Salad",
      "dinner": "Roti, Dal Tadka, Aloo Dum, Kheer"
    },
    {
      "day": "Wednesday",
      "lunch": "Rice, Odia Dalma, Fish Curry / Paneer Butter Masala",
      "dinner": "Jeera Rice, Egg Curry, Salad"
    },
    {
      "day": "Friday",
      "lunch": "Rice, Dal, Machha Jhola / Mushroom Masala",
      "dinner": "Roti, Chicken Curry / Shahi Paneer, Papad"
    },
    {
      "day": "Sunday",
      "lunch": "Special Student Feast: Kadhai Chicken / Paneer, Pulao, Gulab Jamun",
      "dinner": "Light Khichdi / Roti & Tarkari"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "7:00 AM - 10:00 PM",
  "hygieneRating": "4.8/5 (Inspected & Verified)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "demoData": true
},
{
  "id": "mess-bls-trishakti-mess",
  "name": "Trishakti Boys Mess & Fooding",
  "locality": "Motiganj",
  "city": "Balasore",
  "address": "Phandi Chhaka, Motiganj, Balasore, Odisha 756003",
  "phone": "+91 99378 66102",
  "gmapUrl": "https://maps.app.goo.gl/unGxKhkEc7wxfVR86",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2200,
  "singleMealPrice": 60,
  "mealPlans": [
    {
      "id": "plan-prop-bls-trishakti-mess-standard",
      "title": "Two Meals Standard (Lunch & Dinner)",
      "description": "Homestyle Odia food with special feasts on Sundays",
      "mealsPerDay": 2,
      "pricePerMonth": 2200,
      "includesBreakfast": false
    },
    {
      "id": "plan-prop-bls-trishakti-mess-full",
      "title": "Full Board (Breakfast + Lunch + Dinner)",
      "description": "Daily 3 meals with morning tea & snacks",
      "mealsPerDay": 3,
      "pricePerMonth": 2900,
      "includesBreakfast": true
    }
  ],
  "sampleMenu": [
    {
      "day": "Monday",
      "lunch": "Rice, Roti, Dal Fry, Seasonal Tarkari, Salad",
      "dinner": "Roti, Dal Tadka, Aloo Dum, Kheer"
    },
    {
      "day": "Wednesday",
      "lunch": "Rice, Odia Dalma, Fish Curry / Paneer Butter Masala",
      "dinner": "Jeera Rice, Egg Curry, Salad"
    },
    {
      "day": "Friday",
      "lunch": "Rice, Dal, Machha Jhola / Mushroom Masala",
      "dinner": "Roti, Chicken Curry / Shahi Paneer, Papad"
    },
    {
      "day": "Sunday",
      "lunch": "Special Student Feast: Kadhai Chicken / Paneer, Pulao, Gulab Jamun",
      "dinner": "Light Khichdi / Roti & Tarkari"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "7:00 AM - 10:00 PM",
  "hygieneRating": "4.8/5 (Inspected & Verified)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "demoData": true
},
{
  "id": "mess-bls-pradhan-boys",
  "name": "Pradhan Boys Mess & Meals",
  "locality": "Gopalbindha",
  "city": "Balasore",
  "address": "Gopalbindha Main Road, Opposite Saraswati Shishu Mandir, Balasore, Odisha 756019",
  "phone": "+91 94374 55901",
  "gmapUrl": "https://maps.app.goo.gl/NJpvaNJ4sQKZfXt79",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2400,
  "singleMealPrice": 60,
  "mealPlans": [
    {
      "id": "plan-prop-bls-pradhan-boys-standard",
      "title": "Two Meals Standard (Lunch & Dinner)",
      "description": "Nutritious homestyle meals: unlimited rice, dal, veg curry + non-veg options",
      "mealsPerDay": 2,
      "pricePerMonth": 2200,
      "includesBreakfast": false
    },
    {
      "id": "plan-prop-bls-pradhan-boys-full",
      "title": "Full Board (Breakfast + Lunch + Dinner)",
      "description": "Daily 3 meals with morning tea & snacks",
      "mealsPerDay": 3,
      "pricePerMonth": 2900,
      "includesBreakfast": true
    }
  ],
  "sampleMenu": [
    {
      "day": "Monday",
      "lunch": "Rice, Roti, Dal Fry, Seasonal Tarkari, Salad",
      "dinner": "Roti, Dal Tadka, Aloo Dum, Kheer"
    },
    {
      "day": "Wednesday",
      "lunch": "Rice, Odia Dalma, Fish Curry / Paneer Butter Masala",
      "dinner": "Jeera Rice, Egg Curry, Salad"
    },
    {
      "day": "Friday",
      "lunch": "Rice, Dal, Machha Jhola / Mushroom Masala",
      "dinner": "Roti, Chicken Curry / Shahi Paneer, Papad"
    },
    {
      "day": "Sunday",
      "lunch": "Special Student Feast: Kadhai Chicken / Paneer, Pulao, Gulab Jamun",
      "dinner": "Light Khichdi / Roti & Tarkari"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "7:00 AM - 10:00 PM",
  "hygieneRating": "4.8/5 (Inspected & Verified)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "demoData": true
},
{
  "id": "mess-bls-satyabadi-mess",
  "name": "Satyabadi Student Mess & Bhojan",
  "locality": "Januganj",
  "city": "Balasore",
  "address": "Chasa Khanda Road, Near Satyabadi High School, Balasore, Odisha 756019",
  "phone": "+91 98612 09843",
  "gmapUrl": "https://maps.app.goo.gl/qGBX5pXQLdPLTcM29",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2400,
  "singleMealPrice": 60,
  "mealPlans": [
    {
      "id": "plan-prop-bls-satyabadi-mess-standard",
      "title": "Two Meals Standard (Lunch & Dinner)",
      "description": "Odia home-style cuisine: Dalma, Potala, Machha / Kukkuda tarkari",
      "mealsPerDay": 2,
      "pricePerMonth": 2200,
      "includesBreakfast": false
    },
    {
      "id": "plan-prop-bls-satyabadi-mess-full",
      "title": "Full Board (Breakfast + Lunch + Dinner)",
      "description": "Daily 3 meals with morning tea & snacks",
      "mealsPerDay": 3,
      "pricePerMonth": 2900,
      "includesBreakfast": true
    }
  ],
  "sampleMenu": [
    {
      "day": "Monday",
      "lunch": "Rice, Roti, Dal Fry, Seasonal Tarkari, Salad",
      "dinner": "Roti, Dal Tadka, Aloo Dum, Kheer"
    },
    {
      "day": "Wednesday",
      "lunch": "Rice, Odia Dalma, Fish Curry / Paneer Butter Masala",
      "dinner": "Jeera Rice, Egg Curry, Salad"
    },
    {
      "day": "Friday",
      "lunch": "Rice, Dal, Machha Jhola / Mushroom Masala",
      "dinner": "Roti, Chicken Curry / Shahi Paneer, Papad"
    },
    {
      "day": "Sunday",
      "lunch": "Special Student Feast: Kadhai Chicken / Paneer, Pulao, Gulab Jamun",
      "dinner": "Light Khichdi / Roti & Tarkari"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "7:00 AM - 10:00 PM",
  "hygieneRating": "4.8/5 (Inspected & Verified)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "demoData": true
}
,
{
  "id": "food-bls-big-bowl",
  "name": "The Big Bowl",
  "locality": "Station Bazar / OT Road",
  "city": "Balasore",
  "address": "Near Station Bazar Square, OT Road, Balasore, Odisha 756001",
  "phone": "+91 94371 82940",
  "gmapUrl": "https://maps.app.goo.gl/4osJAW4tsAfYwFtZ8",
  "category": "restaurant",
  "cuisine": "North Indian, Biryani Rice Bowls, Tandoori",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2800,
  "singleMealPrice": 150,
  "rating": 4.3,
  "reviewCount": 420,
  "priceRange": "\u20b9150 - \u20b9350 per meal",
  "isGoogleMapsVerified": true,
  "imageUrl": "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80",
  "images": [
    "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80"
  ],
  "highlights": [
    "Signature Biryani Bowls",
    "Butter Chicken Rice Bowl",
    "Paneer Tikka Bowl",
    "Quick Student Delivery"
  ],
  "mealPlans": [
    {
      "id": "plan-bigbowl-regular",
      "title": "Daily Student Bowl Combo (Lunch/Dinner)",
      "description": "Choice of aromatic Dum Biryani or Rich Curry with Basmati Pulao, salad, and beverage.",
      "mealsPerDay": 1,
      "pricePerMonth": 2800,
      "includesBreakfast": false
    },
    {
      "id": "plan-bigbowl-duo",
      "title": "Executive 2-Meal Bowl Pass",
      "description": "Lunch Rice Bowl + Dinner Roti/Curry combo delivered hot to hostel or campus.",
      "mealsPerDay": 2,
      "pricePerMonth": 4800,
      "includesBreakfast": false
    }
  ],
  "sampleMenu": [
    {
      "day": "Mon-Wed",
      "lunch": "Awadhi Dum Biryani Bowl + Raita + Mint Chutney",
      "dinner": "Paneer Butter Masala Bowl + Laccha Paratha"
    },
    {
      "day": "Thu-Sun",
      "lunch": "Kolkata Style Chicken Biryani Bowl",
      "dinner": "Dal Makhani & Jeera Rice Comfort Bowl"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "11:00 AM \u2013 10:30 PM",
  "hygieneRating": "FSSAI Grade A (4.6/5)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "coordinates": {
    "lat": 21.5123047,
    "lng": 86.9001513
  },
  "demoData": false
},
{
  "id": "food-bls-julian",
  "name": "Julian Restaurant",
  "locality": "Station Bazar",
  "city": "Balasore",
  "address": "Main Station Road, Opposite Balasore Railway Station, Balasore, Odisha 756001",
  "phone": "+91 98612 45890",
  "gmapUrl": "https://maps.app.goo.gl/twnqCdi5JEKMsWxf7",
  "category": "restaurant",
  "cuisine": "Indian, Chinese, Mughlai & Fresh Seafood",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 3200,
  "singleMealPrice": 180,
  "rating": 4.2,
  "reviewCount": 560,
  "priceRange": "\u20b9200 - \u20b9500",
  "isGoogleMapsVerified": true,
  "imageUrl": "https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&w=800&q=80",
  "images": [
    "https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80"
  ],
  "highlights": [
    "Crispy Chilli Baby Corn",
    "Chicken Mughlai Curry",
    "Fish Masala",
    "AC Dining & Student Treats"
  ],
  "mealPlans": [
    {
      "id": "plan-julian-dining",
      "title": "Monthly Dine-in Meal Pass",
      "description": "Unlimited thali style meal with rotis, rice, dal, and choice of veg/chicken curry.",
      "mealsPerDay": 1,
      "pricePerMonth": 3200,
      "includesBreakfast": false
    }
  ],
  "sampleMenu": [
    {
      "day": "Mon-Wed",
      "lunch": "Chilli Chicken Fried Rice or Mughlai Paneer with Butter Naan",
      "dinner": "Yellow Dal Fry + Steamed Rice + Fish Masala"
    },
    {
      "day": "Thu-Sun",
      "lunch": "Mix Schezwan Noodles + Crispy Baby Corn",
      "dinner": "Tandoori Roti + Chicken Kadhai + Salad"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "10:30 AM \u2013 10:45 PM",
  "hygieneRating": "FSSAI Grade A (4.5/5)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "coordinates": {
    "lat": 21.5127934,
    "lng": 86.8999842
  },
  "demoData": false
},
{
  "id": "food-bls-dominos",
  "name": "Domino's pizza",
  "locality": "OT Road",
  "city": "Balasore",
  "address": "Ground Floor, Near FM Autonomous College Gate, OT Road, Balasore, Odisha 756001",
  "phone": "1800 208 1234",
  "gmapUrl": "https://maps.app.goo.gl/AvWmaNkG7gYiS2YQ9",
  "category": "fast_food",
  "cuisine": "Pizzas, Stuffed Garlic Bread, Pasta & Desserts",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2500,
  "singleMealPrice": 120,
  "rating": 4.4,
  "reviewCount": 1850,
  "priceRange": "\u20b999 - \u20b9450",
  "isGoogleMapsVerified": true,
  "imageUrl": "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80",
  "images": [
    "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=800&q=80"
  ],
  "highlights": [
    "Peppy Paneer & Farmhouse",
    "Chicken Dominator",
    "Stuffed Garlic Bread",
    "30-min Hot Hostel Delivery"
  ],
  "mealPlans": [
    {
      "id": "plan-dominos-student",
      "title": "Everyday Value Student Box Pass",
      "description": "Regular pizza + Garlic breadsticks + Beverage voucher pass valid across the month.",
      "mealsPerDay": 1,
      "pricePerMonth": 2500,
      "includesBreakfast": false
    }
  ],
  "sampleMenu": [
    {
      "day": "Mon-Sun",
      "lunch": "Veg/Non-Veg Loaded Pizza + Cheesy Dip + Coke",
      "dinner": "Moroccan Pasta Pizza + Choco Lava Cake"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "11:00 AM \u2013 11:00 PM",
  "hygieneRating": "FSSAI ISO Certified (5.0/5)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "coordinates": {
    "lat": 21.5126144,
    "lng": 86.9000534
  },
  "demoData": false
},
{
  "id": "food-bls-odianee",
  "name": "ODIANEE (\u0b13\u0b21\u0b3c\u0b3f\u0b06\u0b23\u0b40)",
  "locality": "Cinema Bazar / FM Golaye",
  "city": "Balasore",
  "address": "Near FM Golaye, Cinema Bazar, Balasore, Odisha 756001",
  "phone": "+91 94372 90112",
  "gmapUrl": "https://maps.app.goo.gl/cLTbCntPtpQvJd538",
  "category": "restaurant",
  "cuisine": "Authentic Odia, Pakhala Thali, Dalma, Fish Fry",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2400,
  "singleMealPrice": 90,
  "rating": 4.5,
  "reviewCount": 780,
  "priceRange": "\u20b9120 - \u20b9280 per thali",
  "isGoogleMapsVerified": true,
  "imageUrl": "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=800&q=80",
  "images": [
    "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1596797038530-2c107229654b?auto=format&fit=crop&w=800&q=80"
  ],
  "highlights": [
    "Royal Odia Pakhala Thali",
    "Mati Handi Mutton",
    "Pure Desi Ghee Dalma",
    "Chunakhai Fish Fry"
  ],
  "mealPlans": [
    {
      "id": "plan-odianee-thali",
      "title": "Monthly Authentic Odia Thali Subscription",
      "description": "Unlimited Rice/Pakhala, Badi Chura, Desi Ghee Dalma, Saaga Bhaja, and seasonal curry.",
      "mealsPerDay": 1,
      "pricePerMonth": 2400,
      "includesBreakfast": false
    },
    {
      "id": "plan-odianee-dual",
      "title": "Full Day Traditional Board (Lunch + Dinner)",
      "description": "Complete traditional lunch and wholesome light dinner with hand-pressed rotis.",
      "mealsPerDay": 2,
      "pricePerMonth": 4200,
      "includesBreakfast": false
    }
  ],
  "sampleMenu": [
    {
      "day": "Mon-Wed",
      "lunch": "Dahi Pakhala + Badi Chura + Potala Bhaja + Machha Besara",
      "dinner": "Atta Roti + Dalma + Chhinchada"
    },
    {
      "day": "Thu-Sun",
      "lunch": "Kanika Pulao + Desi Ghee Dalma + Mati Handi Mutton",
      "dinner": "Steamed Rice + Santula + Chhena Poda"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "11:30 AM \u2013 3:30 PM, 7:00 PM \u2013 10:30 PM",
  "hygieneRating": "FSSAI Grade A (4.7/5)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "coordinates": {
    "lat": 21.5104244,
    "lng": 86.9027134
  },
  "demoData": false
},
{
  "id": "food-bls-maharaja-dhaba",
  "name": "Maharaja dhaba and restaurant",
  "locality": "Remuna Golei / NH-16",
  "city": "Balasore",
  "address": "NH-16 Bypass, Near Remuna Golei Overbridge, Balasore, Odisha 756019",
  "phone": "+91 97761 33452",
  "gmapUrl": "https://maps.app.goo.gl/GdeCrrBtoYJD1r7R8",
  "category": "dhaba",
  "cuisine": "Highway Dhaba, Punjabi Tadka, Tandoor & Curries",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2600,
  "singleMealPrice": 110,
  "rating": 4.1,
  "reviewCount": 920,
  "priceRange": "\u20b9140 - \u20b9320 per meal",
  "isGoogleMapsVerified": true,
  "imageUrl": "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=800&q=80",
  "images": [
    "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1565557623262-b51c2513a641?auto=format&fit=crop&w=800&q=80"
  ],
  "highlights": [
    "Dhaba Dal Tadka with Butter Naan",
    "Highway Chicken Kassa",
    "Kadhai Paneer",
    "Open Garden Seating"
  ],
  "mealPlans": [
    {
      "id": "plan-maharaja-dhaba",
      "title": "Highway Dhaba Tandoor Student Pass",
      "description": "Hearty dinner meals with hot tandoori rotis, creamy dal makhani, and chicken/paneer curry.",
      "mealsPerDay": 1,
      "pricePerMonth": 2600,
      "includesBreakfast": false
    }
  ],
  "sampleMenu": [
    {
      "day": "Mon-Wed",
      "lunch": "Yellow Dal Tadka + Jeera Rice + Tandoori Roti",
      "dinner": "Butter Naan + Chicken Kassa + Onion Rings"
    },
    {
      "day": "Thu-Sun",
      "lunch": "Paneer Butter Masala + Steamed Rice + Raita",
      "dinner": "Egg Curry Double + Laccha Paratha"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "10:00 AM \u2013 11:30 PM",
  "hygieneRating": "FSSAI Certified (4.4/5)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "coordinates": {
    "lat": 21.4979298,
    "lng": 86.8902878
  },
  "demoData": false
},
{
  "id": "food-bls-raita",
  "name": "Raita Restaurant",
  "locality": "Vivekananda Marg",
  "city": "Balasore",
  "address": "Vivekananda Marg, Near Post Office Square, Balasore, Odisha 756001",
  "phone": "+91 94392 67451",
  "gmapUrl": "https://maps.app.goo.gl/a4ZPZb5bb1HYzQA18",
  "category": "restaurant",
  "cuisine": "Homestyle Odia & North Indian, Thalis, Biryani",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2200,
  "singleMealPrice": 80,
  "rating": 4.2,
  "reviewCount": 490,
  "priceRange": "\u20b9100 - \u20b9220 per thali",
  "isGoogleMapsVerified": true,
  "imageUrl": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80",
  "images": [
    "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1567337710282-00832b415979?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1505253758473-96b3015f27eb?auto=format&fit=crop&w=800&q=80"
  ],
  "highlights": [
    "Daily Student Special Thali",
    "Aromatic Curd Raita",
    "Egg & Chicken Curry",
    "Pocket-Friendly Student Rates"
  ],
  "mealPlans": [
    {
      "id": "plan-raita-student",
      "title": "College Budget Thali (Monthly)",
      "description": "Unlimited rice, dal, seasonal bhaja, veg curry, and house special curd raita.",
      "mealsPerDay": 1,
      "pricePerMonth": 2200,
      "includesBreakfast": false
    },
    {
      "id": "plan-raita-full",
      "title": "Full Board Lunch + Dinner",
      "description": "Two fresh meals daily with 3 days non-veg (egg/fish/chicken) inclusion.",
      "mealsPerDay": 2,
      "pricePerMonth": 3800,
      "includesBreakfast": false
    }
  ],
  "sampleMenu": [
    {
      "day": "Mon-Wed",
      "lunch": "Rice + Moong Dal + Alu Bhaja + Boondi Raita",
      "dinner": "Phulka Rotis + Tadka + Egg Curry"
    },
    {
      "day": "Thu-Sun",
      "lunch": "Vegetable Pulao + Mix Veg + Dahi Raita",
      "dinner": "Rice + Rohu Fish Jhola + Salad"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "11:00 AM \u2013 10:00 PM",
  "hygieneRating": "FSSAI Grade A (4.6/5)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "coordinates": {
    "lat": 21.5137991,
    "lng": 86.8953769
  },
  "demoData": false
},
{
  "id": "food-bls-mutton-darbar",
  "name": "Mutton Darbar",
  "locality": "Station Bazar / Cinema Bazar",
  "city": "Balasore",
  "address": "Station Bazar Road, Near Town Police Station, Balasore, Odisha 756001",
  "phone": "+91 98610 88219",
  "gmapUrl": "https://maps.app.goo.gl/WMte6TPbuLj6jxkk6",
  "category": "restaurant",
  "cuisine": "Authentic Odia Mutton Kasa, Biryani, Desi Chicken",
  "foodType": "non_veg",
  "monthlyPrice": 3500,
  "singleMealPrice": 180,
  "rating": 4.6,
  "reviewCount": 1150,
  "priceRange": "\u20b9180 - \u20b9380 per plate",
  "isGoogleMapsVerified": true,
  "imageUrl": "https://images.unsplash.com/photo-1545247181-516773ca83f3?auto=format&fit=crop&w=800&q=80",
  "images": [
    "https://images.unsplash.com/photo-1545247181-516773ca83f3?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1631515243349-e0cb75fb8d3a?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=800&q=80"
  ],
  "highlights": [
    "Legendary Balasore Alu Mutton Jhola",
    "Mati Handi Mutton Kasa",
    "Desi Chicken Fry",
    "Steamed Gobindobhog Rice"
  ],
  "mealPlans": [
    {
      "id": "plan-mutton-darbar",
      "title": "Weekend Feast Pass (4 Special Weekends)",
      "description": "Weekly lavish mutton meal pass with aromatic spiced rice, mutton kasa, and salad.",
      "mealsPerDay": 1,
      "pricePerMonth": 1400,
      "includesBreakfast": false
    }
  ],
  "sampleMenu": [
    {
      "day": "Tue, Fri, Sun",
      "lunch": "Balasore Famous Alu Mutton Jhola + Steamed Rice + Onion Salad",
      "dinner": "Mutton Kasa + Rumali Roti"
    },
    {
      "day": "Wed, Sat",
      "lunch": "Desi Chicken Jhola + Jeera Rice",
      "dinner": "Chicken Bharta + Tandoori Roti"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "12:00 PM \u2013 4:00 PM, 7:00 PM \u2013 10:30 PM",
  "hygieneRating": "FSSAI Grade A (4.8/5)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "coordinates": {
    "lat": 21.5138855,
    "lng": 86.8972679
  },
  "demoData": false
},
{
  "id": "food-bls-ttc-mini",
  "name": "TTC RESTUARANT MINI",
  "locality": "Station Road",
  "city": "Balasore",
  "address": "Near Railway Station Circle, Balasore, Odisha 756001",
  "phone": "+91 94384 19283",
  "gmapUrl": "https://maps.app.goo.gl/rfdk4R9SvrcBq9fT7",
  "category": "cafe",
  "cuisine": "Fast Food, Italian, Kathi Rolls, Burgers, Shakes",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2000,
  "singleMealPrice": 70,
  "rating": 4.3,
  "reviewCount": 340,
  "priceRange": "\u20b960 - \u20b9190 per person",
  "isGoogleMapsVerified": true,
  "imageUrl": "https://images.unsplash.com/photo-1551782450-a2132b4ba21d?auto=format&fit=crop&w=800&q=80",
  "images": [
    "https://images.unsplash.com/photo-1551782450-a2132b4ba21d?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=800&q=80"
  ],
  "highlights": [
    "Kathi Rolls & Chowmein",
    "Cheesy White Sauce Pasta",
    "Crispy Veg/Chicken Burgers",
    "Cold Coffee & Smoothies"
  ],
  "mealPlans": [
    {
      "id": "plan-ttc-quick",
      "title": "Evening Student Snack & Roll Pass",
      "description": "Daily evening Kathi roll / Burger + Beverage pass for coaching and college students.",
      "mealsPerDay": 1,
      "pricePerMonth": 2000,
      "includesBreakfast": false
    }
  ],
  "sampleMenu": [
    {
      "day": "Mon-Sun",
      "lunch": "Double Egg Chicken Kathi Roll + French Fries",
      "dinner": "Creamy White Sauce Pasta + Iced Tea"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "10:00 AM \u2013 10:00 PM",
  "hygieneRating": "FSSAI Certified (4.5/5)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "coordinates": {
    "lat": 21.5132148,
    "lng": 86.8996634
  },
  "demoData": false
},
{
  "id": "food-bls-dawaat",
  "name": "Dawaat Multicuisine Restaurant",
  "locality": "Kuruda / Balasore Town",
  "city": "Balasore",
  "address": "Kuruda Square, Near FM University Road, Balasore, Odisha 756056",
  "phone": "+91 93371 45672",
  "gmapUrl": "https://maps.app.goo.gl/nRPvMLC5Gnxeu4q3A",
  "category": "restaurant",
  "cuisine": "Multicuisine, Mughlai, Tandoor, Continental, Chinese",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 3400,
  "singleMealPrice": 200,
  "rating": 4.4,
  "reviewCount": 860,
  "priceRange": "\u20b9220 - \u20b9550 per person",
  "isGoogleMapsVerified": true,
  "imageUrl": "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80",
  "images": [
    "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=800&q=80"
  ],
  "highlights": [
    "Dawaat Special Tandoori Platter",
    "Chicken Lababdar",
    "Dal Makhani",
    "Spacious Banquet for College Meets"
  ],
  "mealPlans": [
    {
      "id": "plan-dawaat-executive",
      "title": "University Executive Meal Pass",
      "description": "Daily hearty meal box with butter rotis, gourmet gravy curry, dal, and sweet.",
      "mealsPerDay": 1,
      "pricePerMonth": 3400,
      "includesBreakfast": false
    }
  ],
  "sampleMenu": [
    {
      "day": "Mon-Wed",
      "lunch": "Tandoori Chicken Platter + Jeera Pulao",
      "dinner": "Paneer Lababdar + Butter Naan"
    },
    {
      "day": "Thu-Sun",
      "lunch": "Dragon Chicken + Fried Rice",
      "dinner": "Mutton Rogan Josh + Laccha Paratha"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "11:30 AM \u2013 11:00 PM",
  "hygieneRating": "FSSAI Grade A (4.7/5)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "coordinates": {
    "lat": 21.5001696,
    "lng": 86.9240987
  },
  "demoData": false
},
{
  "id": "food-bls-salt-vinegar",
  "name": "Salt and Vinegar",
  "locality": "ITI Square / FM College Road",
  "city": "Balasore",
  "address": "Near ITI Gate, FM College Road, Balasore, Odisha 756001",
  "phone": "+91 94370 78214",
  "gmapUrl": "https://maps.app.goo.gl/sDA6cp4yvwsWV9Mj7",
  "category": "cafe",
  "cuisine": "Eclectic Cafe, Sizzlers, Continental, Chinese, Mocktails",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2500,
  "singleMealPrice": 130,
  "rating": 4.5,
  "reviewCount": 620,
  "priceRange": "\u20b9120 - \u20b9340",
  "isGoogleMapsVerified": true,
  "imageUrl": "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&q=80",
  "images": [
    "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=800&q=80"
  ],
  "highlights": [
    "Hot Sizzlers with Garlic Rice",
    "Peri-Peri Fries",
    "Thin Crust Pizzas",
    "Instagrammable Student Hangout"
  ],
  "mealPlans": [
    {
      "id": "plan-salt-cafe",
      "title": "Student Cafe Club Pass",
      "description": "Daily continental lunch/dinner with artisan burger or sizzler + mocktail voucher.",
      "mealsPerDay": 1,
      "pricePerMonth": 2500,
      "includesBreakfast": false
    }
  ],
  "sampleMenu": [
    {
      "day": "Mon-Wed",
      "lunch": "Paneer Steak Sizzler with Herb Rice + Lemon Ice Tea",
      "dinner": "Classic Club Sandwich + Peri Peri Fries"
    },
    {
      "day": "Thu-Sun",
      "lunch": "Chicken Barbeque Pizza + Mint Mojito",
      "dinner": "Creamy Alfredo Penne + Garlic Toast"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "11:00 AM \u2013 10:30 PM",
  "hygieneRating": "FSSAI Grade A (4.6/5)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "coordinates": {
    "lat": 21.515292,
    "lng": 86.8938062
  },
  "demoData": false
},
{
  "id": "food-bls-moms-kitchen",
  "name": "Mom's kitchen",
  "locality": "Azimabad / Remuna Bypass",
  "city": "Balasore",
  "address": "Near Azimabad Chhak, Remuna Bypass Road, Balasore, Odisha 756001",
  "phone": "+91 98532 11984",
  "gmapUrl": "https://maps.app.goo.gl/YwHMsgKwBYaPGW5E6",
  "category": "tiffin",
  "cuisine": "Homestyle Ghar Ka Khana, Daily Student Tiffin, Pure Odia Meals",
  "foodType": "veg_and_nonveg",
  "monthlyPrice": 2200,
  "singleMealPrice": 75,
  "rating": 4.5,
  "reviewCount": 410,
  "priceRange": "\u20b980 - \u20b9160 per meal (Monthly Tiffin \u20b92,200/mo)",
  "isGoogleMapsVerified": true,
  "imageUrl": "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=80",
  "images": [
    "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=800&q=80"
  ],
  "highlights": [
    "Soft Mother-Made Phulkas/Rotis",
    "Low-Oil Homestyle Dalma & Sabzi",
    "Fresh Egg & Fish Curry",
    "Monthly Student Tiffin Subscription"
  ],
  "mealPlans": [
    {
      "id": "plan-moms-monthly-tiffin",
      "title": "Homestyle Monthly Tiffin (Lunch + Dinner)",
      "description": "Just like mother's cooking: 4 hot phulkas, steamed rice, dal, seasonal sabzi, and salad delivered twice daily.",
      "mealsPerDay": 2,
      "pricePerMonth": 2200,
      "includesBreakfast": false
    },
    {
      "id": "plan-moms-fullboard",
      "title": "Full Board Homestyle (Breakfast + Lunch + Dinner)",
      "description": "Wholesome home breakfast (Upma/Poha/Paratha) + hearty 2 meals daily.",
      "mealsPerDay": 3,
      "pricePerMonth": 2900,
      "includesBreakfast": true
    }
  ],
  "sampleMenu": [
    {
      "day": "Mon-Wed",
      "lunch": "Hot Phulkas + Steamed Rice + Chana Dal + Aloo Gobhi Bhaja",
      "dinner": "4 Soft Rotis + Homestyle Egg Curry + Cucumber Salad"
    },
    {
      "day": "Thu-Sun",
      "lunch": "Rice + Plain Yellow Dal + Rohu Machha Jhola + Badi Bhaja",
      "dinner": "Rotis + Desi Paneer Sabzi + Buta Dal"
    }
  ],
  "deliveryAvailable": true,
  "operatingHours": "9:00 AM \u2013 3:30 PM, 6:30 PM \u2013 10:00 PM",
  "hygieneRating": "FSSAI Grade A (4.9/5)",
  "verifiedStatus": true,
  "distanceToPatiaKiitKm": 0,
  "coordinates": {
    "lat": 21.4987852,
    "lng": 86.9130983
  },
  "demoData": false
}
];

export const INITIAL_PHARMACIES: Pharmacy[] = [
  {
    id: 'pharm-apollo-patia',
    name: 'Apollo 24|7 Pharmacy & Clinic',
    locality: 'Patia',
    address: 'Near Campus 6 Square, Patia Main Road',
    phone: '+91 674 274 0101 / 1860-500-0101',
    isOpen24Hours: true,
    distanceKm: 0.7,
    verifiedStudentPartner: true,
    services: ['24x7 Emergency Prescription Counter', 'Home Delivery to PGs', 'First Aid Kits', 'Vitals Check (BP/Sugar)']
  },
  {
    id: 'pharm-medplus-infocity',
    name: 'MedPlus Day & Night Pharmacy',
    locality: 'Patia',
    address: 'Infocity Square, Near Domino’s, Patia',
    phone: '+91 674 274 9922',
    isOpen24Hours: true,
    distanceKm: 1.2,
    verifiedStudentPartner: true,
    services: ['24x7 Medicines', 'Student ID 10% Discount', 'Bandages & Ointments', 'Thermal Scanners']
  },
  {
    id: 'pharm-kims-dispensary',
    name: 'KIMS Hospital Round-The-Clock Central Pharmacy',
    locality: 'Patia',
    address: 'KIMS Medical College Campus, KIIT Road',
    phone: '+91 674 710 5300 (Emergency Casuality)',
    isOpen24Hours: true,
    distanceKm: 1.4,
    verifiedStudentPartner: true,
    services: ['Emergency Casualty Medicines', 'Trauma Support', '24x7 Pharmacists', 'Ambulance Base']
  }
];

export const DEFAULT_STUDENT_PROFILE: UserProfile = {
  id: 'usr-student-01',
  name: 'Aryan Sharma',
  email: 'aryan.sharma@kiit.ac.in',
  phone: '+91 98765 43210',
  role: 'student',
  college: 'KIIT Deemed to be University, Bhubaneswar',
  preferredCity: 'Bhubaneswar',
  budgetCap: 4000,
  savedPropertyIds: ['prop-patia-101', 'prop-patia-102']
};

export const SAMPLE_VISITS: VisitRequest[] = [
  {
    id: 'vis-101',
    userId: 'usr-student-01',
    studentName: 'Aryan Sharma',
    studentPhone: '+91 98765 43210',
    propertyId: 'prop-patia-101',
    propertyTitle: 'Shree Krishna Executive Student Living',
    propertyLocality: 'Patia',
    requestedDate: '2026-10-17',
    requestedTimeSlot: 'Saturday, 3:30 PM - 4:30 PM',
    ownerConfirmationStatus: 'confirmed',
    studentConfirmationStatus: 'confirmed',
    status: 'scheduled',
    notes: 'Host Biswajit confirmed on WhatsApp: Gate code #412, meet warden at Reception.',
    createdAt: '2026-10-11T09:00:00Z'
  }
];

export const SAMPLE_BOOKINGS: Booking[] = [
  {
    id: 'bk-201',
    userId: 'usr-student-01',
    propertyId: 'prop-patia-101',
    propertyTitle: 'Shree Krishna Executive Student Living',
    locality: 'Patia',
    rentAmount: 3400,
    depositAmount: 3400,
    totalInitialPayable: 6800,
    paymentStatus: 'not_initiated',
    bookingStatus: 'draft',
    moveInDate: '2026-11-01',
    createdAt: '2026-10-11T10:00:00Z'
  }
];

export const SAMPLE_VACANCY_WATCHES: VacancyWatch[] = [
  {
    id: 'vw-01',
    userId: 'usr-student-01',
    city: 'Bhubaneswar',
    locality: 'Patia',
    maxMonthlyRent: 3500,
    roomType: 'double_sharing',
    requiredAmenities: ['High-speed Wi-Fi', 'Attached Bathroom'],
    preferredAvailabilityDate: '2026-11-01',
    notificationFrequency: 'immediate',
    active: true,
    matchCount: 1,
    lastCheckedAt: '2026-10-11T09:45:00Z',
    createdAt: '2026-10-10T14:20:00Z'
  }
];
