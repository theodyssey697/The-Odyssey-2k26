import { FoodingPlace } from '../types';

export const BALASORE_RESTAURANTS: FoodingPlace[] = [
  {
    id: 'food-bls-big-bowl',
    name: 'The Big Bowl',
    locality: 'Station Bazar / OT Road',
    city: 'Balasore',
    address: 'Near Station Bazar Square, OT Road, Balasore, Odisha 756001',
    phone: '+91 94371 82940',
    gmapUrl: 'https://maps.app.goo.gl/4osJAW4tsAfYwFtZ8',
    category: 'restaurant',
    cuisine: 'North Indian, Biryani Rice Bowls, Tandoori & Mughlai',
    foodType: 'veg_and_nonveg',
    rating: 4.3,
    reviewCount: 420,
    priceRange: '₹150 - ₹350 per person',
    isGoogleMapsVerified: true,
    imageUrl: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80'
    ],
    highlights: [
      'Signature Awadhi Dum Biryani Bowl',
      'Butter Chicken Rice Bowl Combo',
      'Paneer Tikka Masala Bowl',
      'Fresh Rumali Roti & Garlic Naan'
    ],
    operatingHours: '11:00 AM – 10:30 PM (Daily)',
    deliveryAvailable: true,
    hygieneRating: 'FSSAI Grade A (4.6/5)',
    coordinates: { lat: 21.5123047, lng: 86.9001513 }
  },
  {
    id: 'food-bls-julian',
    name: 'Julian Restaurant',
    locality: 'Cinema Chhak / Main Road',
    city: 'Balasore',
    address: 'Opposite Cinema Chhak, Main Road, Balasore, Odisha 756001',
    phone: '+91 98612 45890',
    gmapUrl: 'https://maps.app.goo.gl/twnqCdi5JEKMsWxf7',
    category: 'restaurant',
    cuisine: 'Indian, Chinese, Mughlai & Fresh Bay Seafood',
    foodType: 'veg_and_nonveg',
    rating: 4.4,
    reviewCount: 680,
    priceRange: '₹200 - ₹500 per person',
    isGoogleMapsVerified: true,
    imageUrl: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1514933651103-005eec06c04b?auto=format&fit=crop&w=800&q=80'
    ],
    highlights: [
      'Family Dining AC Hall',
      'Crispy Chilli Babycorn & Schezwan Chicken',
      'Prawn Malai Curry (Fresh Bay Catch)',
      'Handi Mutton & Jeera Rice'
    ],
    operatingHours: '11:30 AM – 11:00 PM (Daily)',
    deliveryAvailable: true,
    hygieneRating: 'FSSAI Grade A (4.7/5)',
    coordinates: { lat: 21.4938221, lng: 86.9298412 }
  },
  {
    id: 'food-bls-dominos',
    name: "Domino's pizza",
    locality: 'FM Gollei / Station Road',
    city: 'Balasore',
    address: 'Ground Floor, FM Square, Station Road, Balasore, Odisha 756001',
    phone: '1800 208 1234',
    gmapUrl: 'https://maps.app.goo.gl/AvWmaNkG7gYiS2YQ9',
    category: 'fast_food',
    cuisine: 'Pizzas, Stuffed Garlic Bread, Pastas & Choco Lava Cake',
    foodType: 'veg_and_nonveg',
    rating: 4.2,
    reviewCount: 1450,
    priceRange: '₹120 - ₹350 per person',
    isGoogleMapsVerified: true,
    imageUrl: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?auto=format&fit=crop&w=800&q=80'
    ],
    highlights: [
      'Cheese Burst Farmhouse Pizza',
      'Peppy Paneer & Chicken Golden Delight',
      'Stuffed Garlic Breadsticks',
      'Hot Choco Lava Cake'
    ],
    operatingHours: '10:30 AM – 11:00 PM (Daily)',
    deliveryAvailable: true,
    hygieneRating: 'FSSAI Verified National Brand (4.8/5)',
    coordinates: { lat: 21.5034182, lng: 86.9184512 }
  },
  {
    id: 'food-bls-odianee',
    name: 'ODIANEE (ଓଡ଼ିଆଣୀ)',
    locality: 'Fakir Mohan Circle / Jail Road',
    city: 'Balasore',
    address: 'FM Circle, Jail Road, Balasore, Odisha 756001',
    phone: '+91 94372 90112',
    gmapUrl: 'https://maps.app.goo.gl/cLTbCntPtpQvJd538',
    category: 'restaurant',
    cuisine: 'Authentic Odia, Pakhala Thali, Dalma, Fish Curry & Chhena Poda',
    foodType: 'veg_and_nonveg',
    rating: 4.5,
    reviewCount: 890,
    priceRange: '₹140 - ₹380 per person',
    isGoogleMapsVerified: true,
    imageUrl: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1610057099431-d73a1c9d2f2f?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80'
    ],
    highlights: [
      'Traditional Odia Kansa Thali Dining',
      'Royal Pakhala Platter with 7 Bhajas & Badi Chura',
      'Mati Handi Mutton with Desi Aloo',
      'Fresh Chenna Poda & Rasabali'
    ],
    operatingHours: '11:00 AM – 4:00 PM, 7:00 PM – 10:30 PM',
    deliveryAvailable: true,
    hygieneRating: 'FSSAI Grade A+ (4.8/5)',
    coordinates: { lat: 21.4981105, lng: 86.9247814 }
  },
  {
    id: 'food-bls-maharaja-dhaba',
    name: 'Maharaja dhaba and restaurant',
    locality: 'NH 16 Bypass / Kuruda',
    city: 'Balasore',
    address: 'NH 16 Kolkata-Chennai Highway, Near Kuruda Toll Gate, Balasore 756056',
    phone: '+91 97761 33452',
    gmapUrl: 'https://maps.app.goo.gl/GdeCrrBtoYJD1r7R8',
    category: 'dhaba',
    cuisine: 'Highway Dhaba, Punjabi Tadka, Charcoal Tandoor & Desi Curries',
    foodType: 'veg_and_nonveg',
    rating: 4.2,
    reviewCount: 1120,
    priceRange: '₹120 - ₹300 per person',
    isGoogleMapsVerified: true,
    imageUrl: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80'
    ],
    highlights: [
      'Open Highway Air Seating & Family AC Cabin',
      'Dal Makhani & Butter Naan Combo',
      'Clay Oven Tandoori Chicken & Kadhai Paneer',
      'Kulhad Chai & Late Night Highway Dining'
    ],
    operatingHours: '9:00 AM – 1:00 AM (Late Night Service)',
    deliveryAvailable: true,
    hygieneRating: 'FSSAI Grade A (4.5/5)',
    coordinates: { lat: 21.5289412, lng: 86.8834912 }
  },
  {
    id: 'food-bls-raita',
    name: 'Raita Restaurant',
    locality: 'Azimabad / Remuna Road',
    city: 'Balasore',
    address: 'Near Remuna Chhak, Azimabad Road, Balasore, Odisha 756001',
    phone: '+91 94392 67451',
    gmapUrl: 'https://maps.app.goo.gl/a4ZPZb5bb1HYzQA18',
    category: 'restaurant',
    cuisine: 'Homestyle Odia & North Indian, Thalis, Biryani & Chinese',
    foodType: 'veg_and_nonveg',
    rating: 4.3,
    reviewCount: 395,
    priceRange: '₹100 - ₹260 per person',
    isGoogleMapsVerified: true,
    imageUrl: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80'
    ],
    highlights: [
      'Deluxe Veg Thali with 5 Sabzis & Sweet',
      'Signature Boondi & Mixed Vegetable Raita',
      'Special Chicken Dum Biryani with Gravy',
      'Affordable College Student Friendly Pricing'
    ],
    operatingHours: '10:30 AM – 10:30 PM (Daily)',
    deliveryAvailable: true,
    hygieneRating: 'FSSAI Grade A (4.5/5)',
    coordinates: { lat: 21.5012481, lng: 86.9145612 }
  },
  {
    id: 'food-bls-mutton-darbar',
    name: 'Mutton Darbar',
    locality: 'Motiganj / Hospital Road',
    city: 'Balasore',
    address: 'Motiganj Bazar, Near District Hospital, Balasore, Odisha 756003',
    phone: '+91 98610 88219',
    gmapUrl: 'https://maps.app.goo.gl/WMte6TPbuLj6jxkk6',
    category: 'restaurant',
    cuisine: 'Authentic Odia Mutton Kasa, Biryani & Desi Kukkuda Curry',
    foodType: 'veg_and_nonveg',
    rating: 4.6,
    reviewCount: 940,
    priceRange: '₹180 - ₹450 per person',
    isGoogleMapsVerified: true,
    imageUrl: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=800&q=80'
    ],
    highlights: [
      'Slow Cooked Desi Clay-Pot Mutton Kasa',
      'Kolkata & Balasore Fragrant Mutton Biryani',
      'Desi Kukkuda (Country Chicken) Jhola',
      'Hot Steamed Basmati Rice & Desi Ghee'
    ],
    operatingHours: '12:00 PM – 4:00 PM, 7:00 PM – 10:45 PM',
    deliveryAvailable: true,
    hygieneRating: 'FSSAI Grade A (4.7/5)',
    coordinates: { lat: 21.4912041, lng: 86.9348123 }
  },
  {
    id: 'food-bls-ttc-mini',
    name: 'TTC RESTUARANT MINI',
    locality: 'Fakir Mohan College Road',
    city: 'Balasore',
    address: 'Opposite FM Autonomous College Gate, College Road, Balasore 756001',
    phone: '+91 94384 19283',
    gmapUrl: 'https://maps.app.goo.gl/rfdk4R9SvrcBq9fT7',
    category: 'cafe',
    cuisine: 'Youth Cafe, Kathi Rolls, Burgers, Italian Pastas & Cold Brews',
    foodType: 'veg_and_nonveg',
    rating: 4.3,
    reviewCount: 510,
    priceRange: '₹80 - ₹220 per person',
    isGoogleMapsVerified: true,
    imageUrl: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1521017432531-fbd92d768814?auto=format&fit=crop&w=800&q=80'
    ],
    highlights: [
      'Double Egg Double Chicken Kathi Roll',
      'Cheesy Loaded Grilled Burger',
      'Creamy White Sauce Penne Pasta',
      'Cold Coffee with Ice Cream & Brownie Shakes'
    ],
    operatingHours: '10:00 AM – 10:00 PM (Daily)',
    deliveryAvailable: true,
    hygieneRating: 'FSSAI Grade A (4.6/5)',
    coordinates: { lat: 21.4998124, lng: 86.9213451 }
  },
  {
    id: 'food-bls-dawaat',
    name: 'Dawaat Multicuisine Restaurant',
    locality: 'OT Road / Sahadevkhunta',
    city: 'Balasore',
    address: 'Near Sahadevkhunta Bus Stand, OT Road, Balasore, Odisha 756001',
    phone: '+91 93371 45672',
    gmapUrl: 'https://maps.app.goo.gl/nRPvMLC5Gnxeu4q3A',
    category: 'restaurant',
    cuisine: 'Multicuisine, Mughlai, Tandoor & Sizzling Chinese',
    foodType: 'veg_and_nonveg',
    rating: 4.4,
    reviewCount: 780,
    priceRange: '₹180 - ₹420 per person',
    isGoogleMapsVerified: true,
    imageUrl: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=800&q=80'
    ],
    highlights: [
      'Spacious AC Banquet & Family Dining',
      'Murgh Dawaat-e-Khas Special',
      'Paneer Tikka Lababdar & Butter Kulcha',
      'Sizzling Brownie with Vanilla Scoop'
    ],
    operatingHours: '11:00 AM – 10:45 PM (Daily)',
    deliveryAvailable: true,
    hygieneRating: 'FSSAI Grade A (4.7/5)',
    coordinates: { lat: 21.5067812, lng: 86.9123045 }
  },
  {
    id: 'food-bls-salt-vinegar',
    name: 'Salt and Vinegar',
    locality: 'Vivekananda Marg / Near ITI',
    city: 'Balasore',
    address: 'Vivekananda Marg, Near ITI Square, Balasore, Odisha 756001',
    phone: '+91 94370 78214',
    gmapUrl: 'https://maps.app.goo.gl/sDA6cp4yvwsWV9Mj7',
    category: 'cafe',
    cuisine: 'Eclectic Cafe, Sizzlers, Continental, Chinese & Mocktails',
    foodType: 'veg_and_nonveg',
    rating: 4.5,
    reviewCount: 620,
    priceRange: '₹200 - ₹480 per person',
    isGoogleMapsVerified: true,
    imageUrl: 'https://images.unsplash.com/photo-1559339352-11d035aa65de?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1559339352-11d035aa65de?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&q=80'
    ],
    highlights: [
      'Vibrant Youth Cafe Aesthetic & Mood Lighting',
      'Hot Pepper Chicken Sizzler with Fries',
      'Crispy Honey Chilli Lotus Stem & Momos',
      'Blue Lagoon & Mint Mojito Refreshers'
    ],
    operatingHours: '11:00 AM – 10:30 PM (Daily)',
    deliveryAvailable: true,
    hygieneRating: 'FSSAI Grade A+ (4.8/5)',
    coordinates: { lat: 21.4965123, lng: 86.9204561 }
  },
  {
    id: 'food-bls-moms-kitchen',
    name: "Mom's kitchen",
    locality: 'Gopalgaon / Puruna Bazar',
    city: 'Balasore',
    address: 'Gopalgaon Main Road, Near Puruna Bazar Square, Balasore 756001',
    phone: '+91 98532 11984',
    gmapUrl: 'https://maps.app.goo.gl/YwHMsgKwBYaPGW5E6',
    category: 'homestyle_dining',
    cuisine: 'Homestyle Ghar Ka Khana, Fresh Thalis, Odia Curries & Phulkas',
    foodType: 'veg_and_nonveg',
    rating: 4.7,
    reviewCount: 430,
    priceRange: '₹90 - ₹200 per meal',
    isGoogleMapsVerified: true,
    imageUrl: 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=800&q=80'
    ],
    highlights: [
      'Pure Mother-Cooked Fresh Homemade Flavors',
      'Piping Hot Ghee Phulkas & Steamed Rice',
      'Homestyle Rohu Fish Curry (Machha Jhola)',
      'Desi Egg Curry & Aloo Bhaja Comfort Meals'
    ],
    operatingHours: '10:00 AM – 3:30 PM, 6:30 PM – 10:00 PM',
    deliveryAvailable: true,
    hygieneRating: 'FSSAI Grade A (4.9/5)',
    coordinates: { lat: 21.4987852, lng: 86.9130983 }
  }
];
