import { auth } from '@/src/firebaseConfig';
import { CareerProfile, CareerPlan, CareerAgentEvent, CareerChatMessage } from '@/src/types/career';

async function getAuthToken(): Promise<string> {
  const currentUser = auth.currentUser;
  if (!currentUser) {
    throw new Error('User not authenticated with Firebase. Please sign in to access career services.');
  }
  return await currentUser.getIdToken();
}

async function parseResponse(response: Response): Promise<any> {
  const text = await response.text();
  try {
    const data = JSON.parse(text);
    if (!response.ok) {
      throw new Error(data.error || data.message || `Server error (HTTP ${response.status})`);
    }
    return data;
  } catch (e: any) {
    if (text.trim().toLowerCase().startsWith('<!doctype') || text.trim().toLowerCase().startsWith('<html')) {
      throw new Error(`Server returned HTML error page (HTTP ${response.status}). Please ensure backend API server is running.`);
    }
    if (!response.ok) {
      throw new Error(text || `Server error (HTTP ${response.status})`);
    }
    throw e;
  }
}

export async function fetchStudentCareerData(): Promise<{ profile: CareerProfile | null; plan: CareerPlan | null }> {
  try {
    const token = await getAuthToken();
    const response = await fetch('/api/career/get', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    const data = await parseResponse(response);
    return { profile: data.profile || null, plan: data.plan || null };
  } catch (error) {
    console.error('Error fetching career data:', error);
    throw error;
  }
}

export async function saveCareerProfileDraft(profileData: Partial<CareerProfile>): Promise<{ success: boolean; profile: CareerProfile }> {
  try {
    const token = await getAuthToken();
    const response = await fetch('/api/career/save-profile', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(profileData)
    });
    return await parseResponse(response);
  } catch (error) {
    console.error('Error saving profile draft:', error);
    throw error;
  }
}

export async function analyzeCareerProfile(profileData: CareerProfile, onEvent?: (event: CareerAgentEvent) => void): Promise<{ plan: CareerPlan; events: CareerAgentEvent[] }> {
  try {
    const token = await getAuthToken();
    const response = await fetch('/api/career/analyze', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(profileData)
    });

    const data = await parseResponse(response);
    if (data.events && onEvent) {
      data.events.forEach((ev: CareerAgentEvent) => onEvent(ev));
    }
    return { plan: data.plan, events: data.events || [] };
  } catch (error) {
    console.error('Error running career analysis:', error);
    throw error;
  }
}

export async function sendCareerCoachMessage(message: string, currentPlanId?: string, proposedChanges?: any): Promise<CareerChatMessage> {
  try {
    const token = await getAuthToken();
    const response = await fetch('/api/career/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ message, currentPlanId, proposedChanges })
    });

    const data = await parseResponse(response);
    return data.message;
  } catch (error) {
    console.error('Error in career coach chat:', error);
    throw error;
  }
}
