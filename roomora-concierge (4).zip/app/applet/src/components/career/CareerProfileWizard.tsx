import React, { useState, useEffect } from 'react';
import { CareerProfile, CareerEducation, CareerSkills, CareerInterests, CareerConstraints } from '../../types/career';
import { CareerQuestionPage } from './CareerQuestionPage';
import { Sparkles, CheckCircle2, ArrowRight, Edit3, GraduationCap, Compass, BookOpen } from 'lucide-react';

interface CareerProfileWizardProps {
  initialProfile?: CareerProfile | null;
  onSaveDraft: (profile: Partial<CareerProfile>) => void;
  onGeneratePlan: (profile: CareerProfile) => void;
  isLoading: boolean;
}

export const CareerProfileWizard: React.FC<CareerProfileWizardProps> = ({
  initialProfile,
  onSaveDraft,
  onGeneratePlan,
  isLoading
}) => {
  // Read step from hash if available (e.g., #student_profile/assessment/5)
  const getInitialStepFromHash = () => {
    const hash = window.location.hash;
    const match = hash.match(/assessment\/(\d+|review)/);
    if (match) {
      if (match[1] === 'review') return 22;
      const num = parseInt(match[1], 10);
      if (!isNaN(num) && num >= 1 && num <= 21) return num;
    }
    return 1;
  };

  const [step, setStep] = useState<number>(getInitialStepFromHash());

  // Assessment answers state for all 21 questions
  const [answers, setAnswers] = useState<Record<string, any>>({
    q1: initialProfile?.education?.currentYear ? 'Undergraduate student' : '',
    q2: initialProfile?.education?.branch || 'Computer Science & Engineering',
    q3: initialProfile?.education?.expectedGraduationYear || '2027',
    q4: initialProfile?.education?.enjoyedSubjects || ['Data Structures', 'Algorithms', 'Web Development'],
    q5: ['building things', 'solving puzzles', 'analysing information'],
    q6: ['Technical/logical problems', 'Open-ended exploration'],
    q7: ['Logical reasoning', 'Problem Solving', 'Curiosity'],
    q8: ['Programming & web development', 'Data & mathematics'],
    q9: ['Academic projects', 'Personal projects', 'Internships'],
    q10: initialProfile?.skills?.projectsCertifications || 'Built Roomora student concierge full-stack app with React and TypeScript.',
    q11: ['Full Stack Software Engineer', 'AI Product Engineer'],
    q12: 'I already have a fairly clear direction.',
    q13: 'Coding and building software applications',
    q14: 'Small collaborative teams',
    q15: ['Learning and intellectual challenge', 'Earning potential'],
    q16: 'Getting an internship or full-time software engineering role',
    q17: 'Remote / hybrid or Bhubaneswar / Bengaluru',
    q18: '5–10 hours',
    q19: 'Free resources only',
    q20: ['Hands-on projects', 'Structured courses'],
    q21: initialProfile?.constraints?.voluntaryConstraints || ''
  });

  useEffect(() => {
    // Update hash when step changes
    const hashTarget = step === 22 ? 'assessment/review' : `assessment/${step}`;
    window.location.hash = `student_profile/${hashTarget}`;
  }, [step]);

  // Handle browser popstate / hashchange
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      const match = hash.match(/assessment\/(\d+|review)/);
      if (match) {
        if (match[1] === 'review') setStep(22);
        else {
          const num = parseInt(match[1], 10);
          if (!isNaN(num) && num >= 1 && num <= 21) setStep(num);
        }
      }
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const totalQuestions = 21;

  const handleAnswerChange = (qKey: string, val: any) => {
    setAnswers(prev => ({ ...prev, [qKey]: val }));
  };

  const handleSaveDraftAction = () => {
    const builtProfile = buildProfileFromAnswers();
    onSaveDraft(builtProfile);
  };

  const handleNext = () => {
    if (step < totalQuestions) {
      setStep(s => s + 1);
    } else {
      setStep(22); // Review step
    }
  };

  const handlePrev = () => {
    if (step > 1) {
      setStep(s => s - 1);
    }
  };

  const buildProfileFromAnswers = (): CareerProfile => {
    return {
      uid: initialProfile?.uid || 'current-user',
      email: initialProfile?.email || 'student@roomora.in',
      fullName: initialProfile?.fullName || 'Aryan Sharma',
      education: {
        collegeName: answers.q1 || 'KIIT University, Bhubaneswar',
        degree: 'B.Tech',
        branch: answers.q2 || 'Computer Science & Engineering',
        currentYear: answers.q3 || '3rd Year',
        semester: '6th Semester',
        expectedGraduationYear: answers.q3 || '2027',
        enjoyedSubjects: Array.isArray(answers.q4) ? answers.q4 : ['Computer Science'],
        cgpa: '8.8'
      },
      skills: {
        technicalSkills: answers.q11 || ['JavaScript', 'React', 'TypeScript', 'Node.js'],
        softSkills: answers.q7 || ['Problem Solving', 'Team Collaboration'],
        skillProficiency: { 'JavaScript': 'advanced', 'React': 'advanced' },
        projectsCertifications: answers.q10 || 'Roomora Full Stack Project',
        practicalExperience: 'Student developer intern'
      },
      interests: {
        domains: answers.q11 || ['Software Engineering'],
        roles: answers.q11 || ['Software Engineer'],
        enjoyedActivities: answers.q5 || ['building'],
        preferredOutcome: 'job',
        shortTermGoals: answers.q16 || 'Secure internship',
        longTermGoals: 'Become Lead Tech Architect',
        preferredLocation: answers.q17 || 'Remote / India'
      },
      constraints: {
        weeklyHoursAvailable: 15,
        learningBudget: answers.q19 === 'Free resources only' ? 'free' : 'flexible',
        preferredFormats: answers.q20 || ['hands-on projects'],
        learningLanguages: ['English', 'Hindi'],
        voluntaryConstraints: answers.q21 || ''
      },
      draftSaved: true,
      updatedAt: new Date().toISOString()
    };
  };

  const questionsConfig = [
    {
      id: 'q1',
      text: 'Which option best describes your current education or career stage?',
      whyUseful: 'Helps us tailor your career roadmap to your exact stage of study or professional journey.',
      type: 'radio' as const,
      options: ['School student', 'Diploma student', 'Undergraduate student', 'Postgraduate student', 'Recently graduated', 'Currently working', 'Exploring a career change']
    },
    {
      id: 'q2',
      text: 'What are you currently studying, or what did you study most recently?',
      whyUseful: 'Provides context regarding your academic foundation and core curriculum.',
      type: 'text' as const
    },
    {
      id: 'q3',
      text: 'Which academic year are you in, and when do you expect to complete your studies?',
      whyUseful: 'Used to size your 30/60/90-day milestones relative to your graduation timeline.',
      type: 'text' as const
    },
    {
      id: 'q4',
      text: 'Which subjects or topics do you genuinely enjoy learning about?',
      whyUseful: 'Directs us towards subject domains that align with your natural curiosity.',
      type: 'checkbox' as const,
      options: ['Data Structures & Algorithms', 'Web & App Development', 'Artificial Intelligence & ML', 'Cloud & DevOps', 'Electronics & IoT', 'Business & Finance', 'Design & UI/UX', 'I am not sure yet']
    },
    {
      id: 'q5',
      text: 'Which activities do you find most enjoyable or satisfying?',
      whyUseful: 'Identifies the types of hands-on work that give you a sense of accomplishment.',
      type: 'checkbox' as const,
      options: ['Building things', 'Solving puzzles', 'Analysing information', 'Designing', 'Writing', 'Explaining concepts', 'Helping people', 'Researching', 'Experimenting', 'Organising', 'Leading', 'Creating content']
    },
    {
      id: 'q6',
      text: 'What types of problems would you most enjoy solving?',
      whyUseful: 'Matches your problem-solving style with appropriate career roles.',
      type: 'checkbox' as const,
      options: ['Technical / logical problems', 'Business and financial decisions', 'Visual and creative challenges', 'Scientific questions', 'People-related challenges', 'Practical / mechanical problems', 'Environmental or social issues', 'Open-ended exploration']
    },
    {
      id: 'q7',
      text: 'What do you consider your strongest personal qualities?',
      whyUseful: 'Highlights your natural strengths to leverage in team environments and interviews.',
      type: 'checkbox' as const,
      options: ['Logical reasoning', 'Creativity', 'Communication', 'Patience', 'Persistence', 'Organisation', 'Empathy', 'Leadership', 'Attention to detail', 'Curiosity', 'Practical troubleshooting', 'Collaboration', 'Not sure yet']
    },
    {
      id: 'q8',
      text: 'Which skill categories have you already tried, and how comfortable are you using them?',
      whyUseful: 'Maps your baseline competencies to recommend appropriate difficulty levels.',
      type: 'checkbox' as const,
      options: ['Programming & web development', 'Data & mathematics', 'Hardware, electronics & practical work', 'Design & creative tools', 'Writing & communication', 'Business, marketing & finance', 'Research methods', 'Teaching & teamwork']
    },
    {
      id: 'q9',
      text: 'What practical experience have you gained so far?',
      whyUseful: 'Ensures we acknowledge your real-world experience without penalizing beginners.',
      type: 'checkbox' as const,
      options: ['Academic projects', 'Personal projects', 'Internships', 'Hackathons & competitions', 'Volunteering', 'Clubs or societies', 'Part-time work', 'Research', 'Family business', 'No experience yet']
    },
    {
      id: 'q10',
      text: 'Which project, activity, or achievement are you most proud of, and what was your contribution?',
      whyUseful: 'Provides key context for your portfolio recommendations and interview talking points.',
      type: 'textarea' as const,
      isOptional: true
    },
    {
      id: 'q11',
      text: 'Which career fields or job roles are you curious about right now?',
      whyUseful: 'Helps us prioritize pathways matching your curiosity while suggesting adjacent options.',
      type: 'checkbox' as const,
      options: ['Full Stack Software Engineer', 'AI Product Engineer', 'Cloud & DevOps Associate', 'Data Analyst / Scientist', 'UI/UX Product Designer', 'Cybersecurity Engineer', 'Business Analyst', 'I don\'t know yet / Suggest options']
    },
    {
      id: 'q12',
      text: 'How clear are you about your future career direction?',
      whyUseful: 'Adjusts whether recommendations are focused on deep specialization or broad exploration.',
      type: 'radio' as const,
      options: [
        'I already have a fairly clear direction.',
        'I have two or three possibilities.',
        'I know the type of work I like, but not the role.',
        'I have no clear direction and want to explore.',
        'I want to change my current plan.'
      ]
    },
    {
      id: 'q13',
      text: 'Which kind of work would you most like to do regularly?',
      whyUseful: 'Pinpoints your day-to-day task preferences.',
      type: 'radio' as const,
      options: [
        'Coding and building software applications',
        'Analysing data and producing reports',
        'Designing user interfaces and experiences',
        'Working directly with people and clients',
        'Conducting research and experimentation',
        'Organising operations and managing projects',
        'Developing a business or startup'
      ]
    },
    {
      id: 'q14',
      text: 'How would you prefer to work with other people?',
      whyUseful: 'Helps match you with appropriate team structures and work environments.',
      type: 'radio' as const,
      options: [
        'Independent work with minimal oversight',
        'Small collaborative engineering teams',
        'Frequent communication with clients or users',
        'Leading and coordinating teams',
        'A flexible mixture of all of the above'
      ]
    },
    {
      id: 'q15',
      text: 'What matters most to you in a future career?',
      whyUseful: 'Aligns recommendations with your personal priorities and values.',
      type: 'checkbox' as const,
      options: ['Earning potential', 'Stability and predictable employment', 'Creativity', 'Learning and intellectual challenge', 'Flexibility and work-life balance', 'Meaningful social impact', 'Independence', 'Leadership and advancement']
    },
    {
      id: 'q16',
      text: 'What would you most like to achieve in the next two to three years?',
      whyUseful: 'Defines your immediate milestone target.',
      type: 'radio' as const,
      options: [
        'Getting an internship',
        'Obtaining a first full-time job',
        'Building a strong project portfolio',
        'Preparing for higher education',
        'Gaining professional certifications',
        'Starting a business or freelance practice',
        'Exploring career options'
      ]
    },
    {
      id: 'q17',
      text: 'Where and in what kind of working arrangement would you prefer to work?',
      whyUseful: 'Reflects location and remote/hybrid preferences.',
      type: 'text' as const,
      isOptional: true
    },
    {
      id: 'q18',
      text: 'How much time can you realistically spend developing your skills each week?',
      whyUseful: 'Ensures the 30/60/90-day roadmap is realistic and achievable without burnout.',
      type: 'radio' as const,
      options: ['Under 2 hours', '2–5 hours', '5–10 hours', 'More than 10 hours']
    },
    {
      id: 'q19',
      text: 'What is your budget for courses, certifications, and career preparation?',
      whyUseful: 'Ensures recommended resources match your financial comfort.',
      type: 'radio' as const,
      options: ['Free resources only', 'Prefer free resources, but some low-cost options are possible', 'A limited budget is available', 'Flexible budget']
    },
    {
      id: 'q20',
      text: 'How do you learn new skills most comfortably?',
      whyUseful: 'Tailors learning formats (hands-on vs structured courses) to your style.',
      type: 'checkbox' as const,
      options: ['Hands-on projects', 'Structured courses', 'Video tutorials', 'Books and articles', 'Guided exercises', 'Mentors and study groups']
    },
    {
      id: 'q21',
      text: 'Is there any practical constraint or preference you would like your career plan to take into account?',
      whyUseful: 'Accounts for exam schedules or personal commitments.',
      type: 'textarea' as const,
      isOptional: true
    }
  ];

  if (step === 22) {
    // Review Screen
    return (
      <div className="bg-white border border-rose-200/90 rounded-3xl p-6 sm:p-10 shadow-sm max-w-3xl mx-auto animate-in fade-in duration-200 space-y-8">
        <div className="flex items-center justify-between border-b border-rose-100 pb-4">
          <div>
            <h2 className="text-lg font-extrabold text-[#4c0519] font-heading">Review Your Assessment Answers</h2>
            <p className="text-xs text-slate-500">You have completed all {totalQuestions} questions. Review or edit any step below before generating your plan.</p>
          </div>
          <button
            onClick={handleSaveDraftAction}
            className="px-4 py-2 rounded-xl bg-rose-50 text-[#881337] font-bold text-xs hover:bg-rose-100 border border-rose-200"
          >
            Save Complete Draft
          </button>
        </div>

        <div className="space-y-4 max-h-[450px] overflow-y-auto pr-2">
          {questionsConfig.map((q, idx) => {
            const stepNum = idx + 1;
            const val = answers[q.id];
            const displayVal = Array.isArray(val) ? val.join(', ') : (val || 'Not answered');
            return (
              <div key={q.id} className="p-4 rounded-2xl border border-rose-200/70 bg-rose-50/20 flex items-start justify-between gap-4">
                <div>
                  <span className="text-[10px] uppercase font-bold text-rose-700 bg-rose-100 px-2 py-0.5 rounded-md">Q{stepNum}</span>
                  <h4 className="text-xs font-bold text-[#4c0519] mt-1 mb-0.5">{q.text}</h4>
                  <p className="text-xs text-slate-700 font-medium">{displayVal}</p>
                </div>
                <button
                  onClick={() => setStep(stepNum)}
                  className="flex items-center gap-1 text-xs font-bold text-[#881337] hover:underline shrink-0"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Edit</span>
                </button>
              </div>
            );
          })}
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-rose-100">
          <button
            onClick={() => setStep(21)}
            className="px-4 py-2.5 rounded-xl border border-rose-200 text-[#4c0519] hover:bg-rose-50 font-bold text-xs"
          >
            Back to Question 21
          </button>

          <button
            onClick={() => onGeneratePlan(buildProfileFromAnswers())}
            disabled={isLoading}
            className="flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-[#881337] to-[#be123c] hover:from-[#700f2d] hover:to-[#a50f34] text-white font-extrabold text-xs shadow-lg transition-all disabled:opacity-50"
          >
            <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
            <span>{isLoading ? 'Running 5-Stage Agentic Analysis...' : 'Generate My Career Plan'}</span>
          </button>
        </div>
      </div>
    );
  }

  const currentQ = questionsConfig[step - 1];

  return (
    <CareerQuestionPage
      stepNumber={step}
      totalSteps={totalQuestions}
      questionId={currentQ.id}
      questionText={currentQ.text}
      whyUseful={currentQ.whyUseful}
      inputType={currentQ.type}
      options={currentQ.options}
      value={answers[currentQ.id]}
      onChange={(val) => handleAnswerChange(currentQ.id, val)}
      onSaveDraft={handleSaveDraftAction}
      onPrev={handlePrev}
      onNext={handleNext}
      isOptional={currentQ.isOptional}
    />
  );
};
