import json

restaurants_data = [
    {
        "id": "food-bls-big-bowl",
        "name": "The Big Bowl",
        "locality": "Station Bazar / OT Road",
        "city": "Balasore",
        "address": "Near Station Bazar Square, OT Road, Balasore, Odisha 756001",
        "phone": "+91 94371 82940",
        "gmapUrl": "https://maps.app.goo.gl/4osJAW4tsAfYwFtZ8",
        "category": "restaurant",
        "cuisine": "North Indian, Biryani Rice Bowls, Tandoori",
        "foodType": "veg_and_nonveg",
        "monthlyPrice": 2800,
        "singleMealPrice": 150,
        "rating": 4.3,
        "reviewCount": 420,
        "priceRange": "₹150 - ₹350 per meal",
        "isGoogleMapsVerified": True,
        "imageUrl": "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80",
        "images": [
            "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80"
        ],
        "highlights": ["Signature Biryani Bowls", "Butter Chicken Rice Bowl", "Paneer Tikka Bowl", "Quick Student Delivery"],
        "mealPlans": [
            {
                "id": "plan-bigbowl-regular",
                "title": "Daily Student Bowl Combo (Lunch/Dinner)",
                "description": "Choice of aromatic Dum Biryani or Rich Curry with Basmati Pulao, salad, and beverage.",
                "mealsPerDay": 1,
                "pricePerMonth": 2800,
                "includesBreakfast": False
            },
            {
                "id": "plan-bigbowl-duo",
                "title": "Executive 2-Meal Bowl Pass",
                "description": "Lunch Rice Bowl + Dinner Roti/Curry combo delivered hot to hostel or campus.",
                "mealsPerDay": 2,
                "pricePerMonth": 4800,
                "includesBreakfast": False
            }
        ],
        "sampleMenu": [
            {"day": "Mon-Wed", "lunch": "Awadhi Dum Biryani Bowl + Raita + Mint Chutney", "dinner": "Paneer Butter Masala Bowl + Laccha Paratha"},
            {"day": "Thu-Sun", "lunch": "Kolkata Style Chicken Biryani Bowl", "dinner": "Dal Makhani & Jeera Rice Comfort Bowl"}
        ],
        "deliveryAvailable": True,
        "operatingHours": "11:00 AM – 10:30 PM",
        "hygieneRating": "FSSAI Grade A (4.6/5)",
        "verifiedStatus": True,
        "distanceToPatiaKiitKm": 0,
        "coordinates": {"lat": 21.5123047, "lng": 86.9001513},
        "demoData": False
    },
    {
        "id": "food-bls-julian",
        "name": "Julian Restaurant",
        "locality": "Station Bazar",
        "city": "Balasore",
        "address": "Main Station Road, Opposite Balasore Railway Station, Balasore, Odisha 756001",
        "phone": "+91 98612 45890",
        "gmapUrl": "https://maps.app.goo.gl/twnqCdi5JEKMsWxf7",
        "category": "restaurant",
        "cuisine": "Indian, Chinese, Mughlai & Fresh Seafood",
        "foodType": "veg_and_nonveg",
        "monthlyPrice": 3200,
        "singleMealPrice": 180,
        "rating": 4.2,
        "reviewCount": 560,
        "priceRange": "₹200 - ₹500",
        "isGoogleMapsVerified": True,
        "imageUrl": "https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&w=800&q=80",
        "images": [
            "https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80"
        ],
        "highlights": ["Crispy Chilli Baby Corn", "Chicken Mughlai Curry", "Fish Masala", "AC Dining & Student Treats"],
        "mealPlans": [
            {
                "id": "plan-julian-dining",
                "title": "Monthly Dine-in Meal Pass",
                "description": "Unlimited thali style meal with rotis, rice, dal, and choice of veg/chicken curry.",
                "mealsPerDay": 1,
                "pricePerMonth": 3200,
                "includesBreakfast": False
            }
        ],
        "sampleMenu": [
            {"day": "Mon-Wed", "lunch": "Chilli Chicken Fried Rice or Mughlai Paneer with Butter Naan", "dinner": "Yellow Dal Fry + Steamed Rice + Fish Masala"},
            {"day": "Thu-Sun", "lunch": "Mix Schezwan Noodles + Crispy Baby Corn", "dinner": "Tandoori Roti + Chicken Kadhai + Salad"}
        ],
        "deliveryAvailable": True,
        "operatingHours": "10:30 AM – 10:45 PM",
        "hygieneRating": "FSSAI Grade A (4.5/5)",
        "verifiedStatus": True,
        "distanceToPatiaKiitKm": 0,
        "coordinates": {"lat": 21.5127934, "lng": 86.8999842},
        "demoData": False
    },
    {
        "id": "food-bls-dominos",
        "name": "Domino's pizza",
        "locality": "OT Road",
        "city": "Balasore",
        "address": "Ground Floor, Near FM Autonomous College Gate, OT Road, Balasore, Odisha 756001",
        "phone": "1800 208 1234",
        "gmapUrl": "https://maps.app.goo.gl/AvWmaNkG7gYiS2YQ9",
        "category": "fast_food",
        "cuisine": "Pizzas, Stuffed Garlic Bread, Pasta & Desserts",
        "foodType": "veg_and_nonveg",
        "monthlyPrice": 2500,
        "singleMealPrice": 120,
        "rating": 4.4,
        "reviewCount": 1850,
        "priceRange": "₹99 - ₹450",
        "isGoogleMapsVerified": True,
        "imageUrl": "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80",
        "images": [
            "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=800&q=80"
        ],
        "highlights": ["Peppy Paneer & Farmhouse", "Chicken Dominator", "Stuffed Garlic Bread", "30-min Hot Hostel Delivery"],
        "mealPlans": [
            {
                "id": "plan-dominos-student",
                "title": "Everyday Value Student Box Pass",
                "description": "Regular pizza + Garlic breadsticks + Beverage voucher pass valid across the month.",
                "mealsPerDay": 1,
                "pricePerMonth": 2500,
                "includesBreakfast": False
            }
        ],
        "sampleMenu": [
            {"day": "Mon-Sun", "lunch": "Veg/Non-Veg Loaded Pizza + Cheesy Dip + Coke", "dinner": "Moroccan Pasta Pizza + Choco Lava Cake"}
        ],
        "deliveryAvailable": True,
        "operatingHours": "11:00 AM – 11:00 PM",
        "hygieneRating": "FSSAI ISO Certified (5.0/5)",
        "verifiedStatus": True,
        "distanceToPatiaKiitKm": 0,
        "coordinates": {"lat": 21.5126144, "lng": 86.9000534},
        "demoData": False
    },
    {
        "id": "food-bls-odianee",
        "name": "ODIANEE (ଓଡ଼ିଆଣୀ)",
        "locality": "Cinema Bazar / FM Golaye",
        "city": "Balasore",
        "address": "Near FM Golaye, Cinema Bazar, Balasore, Odisha 756001",
        "phone": "+91 94372 90112",
        "gmapUrl": "https://maps.app.goo.gl/cLTbCntPtpQvJd538",
        "category": "restaurant",
        "cuisine": "Authentic Odia, Pakhala Thali, Dalma, Fish Fry",
        "foodType": "veg_and_nonveg",
        "monthlyPrice": 2400,
        "singleMealPrice": 90,
        "rating": 4.5,
        "reviewCount": 780,
        "priceRange": "₹120 - ₹280 per thali",
        "isGoogleMapsVerified": True,
        "imageUrl": "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=800&q=80",
        "images": [
            "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1596797038530-2c107229654b?auto=format&fit=crop&w=800&q=80"
        ],
        "highlights": ["Royal Odia Pakhala Thali", "Mati Handi Mutton", "Pure Desi Ghee Dalma", "Chunakhai Fish Fry"],
        "mealPlans": [
            {
                "id": "plan-odianee-thali",
                "title": "Monthly Authentic Odia Thali Subscription",
                "description": "Unlimited Rice/Pakhala, Badi Chura, Desi Ghee Dalma, Saaga Bhaja, and seasonal curry.",
                "mealsPerDay": 1,
                "pricePerMonth": 2400,
                "includesBreakfast": False
            },
            {
                "id": "plan-odianee-dual",
                "title": "Full Day Traditional Board (Lunch + Dinner)",
                "description": "Complete traditional lunch and wholesome light dinner with hand-pressed rotis.",
                "mealsPerDay": 2,
                "pricePerMonth": 4200,
                "includesBreakfast": False
            }
        ],
        "sampleMenu": [
            {"day": "Mon-Wed", "lunch": "Dahi Pakhala + Badi Chura + Potala Bhaja + Machha Besara", "dinner": "Atta Roti + Dalma + Chhinchada"},
            {"day": "Thu-Sun", "lunch": "Kanika Pulao + Desi Ghee Dalma + Mati Handi Mutton", "dinner": "Steamed Rice + Santula + Chhena Poda"}
        ],
        "deliveryAvailable": True,
        "operatingHours": "11:30 AM – 3:30 PM, 7:00 PM – 10:30 PM",
        "hygieneRating": "FSSAI Grade A (4.7/5)",
        "verifiedStatus": True,
        "distanceToPatiaKiitKm": 0,
        "coordinates": {"lat": 21.5104244, "lng": 86.9027134},
        "demoData": False
    },
    {
        "id": "food-bls-maharaja-dhaba",
        "name": "Maharaja dhaba and restaurant",
        "locality": "Remuna Golei / NH-16",
        "city": "Balasore",
        "address": "NH-16 Bypass, Near Remuna Golei Overbridge, Balasore, Odisha 756019",
        "phone": "+91 97761 33452",
        "gmapUrl": "https://maps.app.goo.gl/GdeCrrBtoYJD1r7R8",
        "category": "dhaba",
        "cuisine": "Highway Dhaba, Punjabi Tadka, Tandoor & Curries",
        "foodType": "veg_and_nonveg",
        "monthlyPrice": 2600,
        "singleMealPrice": 110,
        "rating": 4.1,
        "reviewCount": 920,
        "priceRange": "₹140 - ₹320 per meal",
        "isGoogleMapsVerified": True,
        "imageUrl": "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=800&q=80",
        "images": [
            "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1565557623262-b51c2513a641?auto=format&fit=crop&w=800&q=80"
        ],
        "highlights": ["Dhaba Dal Tadka with Butter Naan", "Highway Chicken Kassa", "Kadhai Paneer", "Open Garden Seating"],
        "mealPlans": [
            {
                "id": "plan-maharaja-dhaba",
                "title": "Highway Dhaba Tandoor Student Pass",
                "description": "Hearty dinner meals with hot tandoori rotis, creamy dal makhani, and chicken/paneer curry.",
                "mealsPerDay": 1,
                "pricePerMonth": 2600,
                "includesBreakfast": False
            }
        ],
        "sampleMenu": [
            {"day": "Mon-Wed", "lunch": "Yellow Dal Tadka + Jeera Rice + Tandoori Roti", "dinner": "Butter Naan + Chicken Kassa + Onion Rings"},
            {"day": "Thu-Sun", "lunch": "Paneer Butter Masala + Steamed Rice + Raita", "dinner": "Egg Curry Double + Laccha Paratha"}
        ],
        "deliveryAvailable": True,
        "operatingHours": "10:00 AM – 11:30 PM",
        "hygieneRating": "FSSAI Certified (4.4/5)",
        "verifiedStatus": True,
        "distanceToPatiaKiitKm": 0,
        "coordinates": {"lat": 21.4979298, "lng": 86.8902878},
        "demoData": False
    },
    {
        "id": "food-bls-raita",
        "name": "Raita Restaurant",
        "locality": "Vivekananda Marg",
        "city": "Balasore",
        "address": "Vivekananda Marg, Near Post Office Square, Balasore, Odisha 756001",
        "phone": "+91 94392 67451",
        "gmapUrl": "https://maps.app.goo.gl/a4ZPZb5bb1HYzQA18",
        "category": "restaurant",
        "cuisine": "Homestyle Odia & North Indian, Thalis, Biryani",
        "foodType": "veg_and_nonveg",
        "monthlyPrice": 2200,
        "singleMealPrice": 80,
        "rating": 4.2,
        "reviewCount": 490,
        "priceRange": "₹100 - ₹220 per thali",
        "isGoogleMapsVerified": True,
        "imageUrl": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80",
        "images": [
            "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1567337710282-00832b415979?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1505253758473-96b3015f27eb?auto=format&fit=crop&w=800&q=80"
        ],
        "highlights": ["Daily Student Special Thali", "Aromatic Curd Raita", "Egg & Chicken Curry", "Pocket-Friendly Student Rates"],
        "mealPlans": [
            {
                "id": "plan-raita-student",
                "title": "College Budget Thali (Monthly)",
                "description": "Unlimited rice, dal, seasonal bhaja, veg curry, and house special curd raita.",
                "mealsPerDay": 1,
                "pricePerMonth": 2200,
                "includesBreakfast": False
            },
            {
                "id": "plan-raita-full",
                "title": "Full Board Lunch + Dinner",
                "description": "Two fresh meals daily with 3 days non-veg (egg/fish/chicken) inclusion.",
                "mealsPerDay": 2,
                "pricePerMonth": 3800,
                "includesBreakfast": False
            }
        ],
        "sampleMenu": [
            {"day": "Mon-Wed", "lunch": "Rice + Moong Dal + Alu Bhaja + Boondi Raita", "dinner": "Phulka Rotis + Tadka + Egg Curry"},
            {"day": "Thu-Sun", "lunch": "Vegetable Pulao + Mix Veg + Dahi Raita", "dinner": "Rice + Rohu Fish Jhola + Salad"}
        ],
        "deliveryAvailable": True,
        "operatingHours": "11:00 AM – 10:00 PM",
        "hygieneRating": "FSSAI Grade A (4.6/5)",
        "verifiedStatus": True,
        "distanceToPatiaKiitKm": 0,
        "coordinates": {"lat": 21.5137991, "lng": 86.8953769},
        "demoData": False
    },
    {
        "id": "food-bls-mutton-darbar",
        "name": "Mutton Darbar",
        "locality": "Station Bazar / Cinema Bazar",
        "city": "Balasore",
        "address": "Station Bazar Road, Near Town Police Station, Balasore, Odisha 756001",
        "phone": "+91 98610 88219",
        "gmapUrl": "https://maps.app.goo.gl/WMte6TPbuLj6jxkk6",
        "category": "restaurant",
        "cuisine": "Authentic Odia Mutton Kasa, Biryani, Desi Chicken",
        "foodType": "non_veg",
        "monthlyPrice": 3500,
        "singleMealPrice": 180,
        "rating": 4.6,
        "reviewCount": 1150,
        "priceRange": "₹180 - ₹380 per plate",
        "isGoogleMapsVerified": True,
        "imageUrl": "https://images.unsplash.com/photo-1545247181-516773ca83f3?auto=format&fit=crop&w=800&q=80",
        "images": [
            "https://images.unsplash.com/photo-1545247181-516773ca83f3?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1631515243349-e0cb75fb8d3a?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=800&q=80"
        ],
        "highlights": ["Legendary Balasore Alu Mutton Jhola", "Mati Handi Mutton Kasa", "Desi Chicken Fry", "Steamed Gobindobhog Rice"],
        "mealPlans": [
            {
                "id": "plan-mutton-darbar",
                "title": "Weekend Feast Pass (4 Special Weekends)",
                "description": "Weekly lavish mutton meal pass with aromatic spiced rice, mutton kasa, and salad.",
                "mealsPerDay": 1,
                "pricePerMonth": 1400,
                "includesBreakfast": False
            }
        ],
        "sampleMenu": [
            {"day": "Tue, Fri, Sun", "lunch": "Balasore Famous Alu Mutton Jhola + Steamed Rice + Onion Salad", "dinner": "Mutton Kasa + Rumali Roti"},
            {"day": "Wed, Sat", "lunch": "Desi Chicken Jhola + Jeera Rice", "dinner": "Chicken Bharta + Tandoori Roti"}
        ],
        "deliveryAvailable": True,
        "operatingHours": "12:00 PM – 4:00 PM, 7:00 PM – 10:30 PM",
        "hygieneRating": "FSSAI Grade A (4.8/5)",
        "verifiedStatus": True,
        "distanceToPatiaKiitKm": 0,
        "coordinates": {"lat": 21.5138855, "lng": 86.8972679},
        "demoData": False
    },
    {
        "id": "food-bls-ttc-mini",
        "name": "TTC RESTUARANT MINI",
        "locality": "Station Road",
        "city": "Balasore",
        "address": "Near Railway Station Circle, Balasore, Odisha 756001",
        "phone": "+91 94384 19283",
        "gmapUrl": "https://maps.app.goo.gl/rfdk4R9SvrcBq9fT7",
        "category": "cafe",
        "cuisine": "Fast Food, Italian, Kathi Rolls, Burgers, Shakes",
        "foodType": "veg_and_nonveg",
        "monthlyPrice": 2000,
        "singleMealPrice": 70,
        "rating": 4.3,
        "reviewCount": 340,
        "priceRange": "₹60 - ₹190 per person",
        "isGoogleMapsVerified": True,
        "imageUrl": "https://images.unsplash.com/photo-1551782450-a2132b4ba21d?auto=format&fit=crop&w=800&q=80",
        "images": [
            "https://images.unsplash.com/photo-1551782450-a2132b4ba21d?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=800&q=80"
        ],
        "highlights": ["Kathi Rolls & Chowmein", "Cheesy White Sauce Pasta", "Crispy Veg/Chicken Burgers", "Cold Coffee & Smoothies"],
        "mealPlans": [
            {
                "id": "plan-ttc-quick",
                "title": "Evening Student Snack & Roll Pass",
                "description": "Daily evening Kathi roll / Burger + Beverage pass for coaching and college students.",
                "mealsPerDay": 1,
                "pricePerMonth": 2000,
                "includesBreakfast": False
            }
        ],
        "sampleMenu": [
            {"day": "Mon-Sun", "lunch": "Double Egg Chicken Kathi Roll + French Fries", "dinner": "Creamy White Sauce Pasta + Iced Tea"}
        ],
        "deliveryAvailable": True,
        "operatingHours": "10:00 AM – 10:00 PM",
        "hygieneRating": "FSSAI Certified (4.5/5)",
        "verifiedStatus": True,
        "distanceToPatiaKiitKm": 0,
        "coordinates": {"lat": 21.5132148, "lng": 86.8996634},
        "demoData": False
    },
    {
        "id": "food-bls-dawaat",
        "name": "Dawaat Multicuisine Restaurant",
        "locality": "Kuruda / Balasore Town",
        "city": "Balasore",
        "address": "Kuruda Square, Near FM University Road, Balasore, Odisha 756056",
        "phone": "+91 93371 45672",
        "gmapUrl": "https://maps.app.goo.gl/nRPvMLC5Gnxeu4q3A",
        "category": "restaurant",
        "cuisine": "Multicuisine, Mughlai, Tandoor, Continental, Chinese",
        "foodType": "veg_and_nonveg",
        "monthlyPrice": 3400,
        "singleMealPrice": 200,
        "rating": 4.4,
        "reviewCount": 860,
        "priceRange": "₹220 - ₹550 per person",
        "isGoogleMapsVerified": True,
        "imageUrl": "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80",
        "images": [
            "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=800&q=80"
        ],
        "highlights": ["Dawaat Special Tandoori Platter", "Chicken Lababdar", "Dal Makhani", "Spacious Banquet for College Meets"],
        "mealPlans": [
            {
                "id": "plan-dawaat-executive",
                "title": "University Executive Meal Pass",
                "description": "Daily hearty meal box with butter rotis, gourmet gravy curry, dal, and sweet.",
                "mealsPerDay": 1,
                "pricePerMonth": 3400,
                "includesBreakfast": False
            }
        ],
        "sampleMenu": [
            {"day": "Mon-Wed", "lunch": "Tandoori Chicken Platter + Jeera Pulao", "dinner": "Paneer Lababdar + Butter Naan"},
            {"day": "Thu-Sun", "lunch": "Dragon Chicken + Fried Rice", "dinner": "Mutton Rogan Josh + Laccha Paratha"}
        ],
        "deliveryAvailable": True,
        "operatingHours": "11:30 AM – 11:00 PM",
        "hygieneRating": "FSSAI Grade A (4.7/5)",
        "verifiedStatus": True,
        "distanceToPatiaKiitKm": 0,
        "coordinates": {"lat": 21.5001696, "lng": 86.9240987},
        "demoData": False
    },
    {
        "id": "food-bls-salt-vinegar",
        "name": "Salt and Vinegar",
        "locality": "ITI Square / FM College Road",
        "city": "Balasore",
        "address": "Near ITI Gate, FM College Road, Balasore, Odisha 756001",
        "phone": "+91 94370 78214",
        "gmapUrl": "https://maps.app.goo.gl/sDA6cp4yvwsWV9Mj7",
        "category": "cafe",
        "cuisine": "Eclectic Cafe, Sizzlers, Continental, Chinese, Mocktails",
        "foodType": "veg_and_nonveg",
        "monthlyPrice": 2500,
        "singleMealPrice": 130,
        "rating": 4.5,
        "reviewCount": 620,
        "priceRange": "₹120 - ₹340",
        "isGoogleMapsVerified": True,
        "imageUrl": "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&q=80",
        "images": [
            "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=800&q=80"
        ],
        "highlights": ["Hot Sizzlers with Garlic Rice", "Peri-Peri Fries", "Thin Crust Pizzas", "Instagrammable Student Hangout"],
        "mealPlans": [
            {
                "id": "plan-salt-cafe",
                "title": "Student Cafe Club Pass",
                "description": "Daily continental lunch/dinner with artisan burger or sizzler + mocktail voucher.",
                "mealsPerDay": 1,
                "pricePerMonth": 2500,
                "includesBreakfast": False
            }
        ],
        "sampleMenu": [
            {"day": "Mon-Wed", "lunch": "Paneer Steak Sizzler with Herb Rice + Lemon Ice Tea", "dinner": "Classic Club Sandwich + Peri Peri Fries"},
            {"day": "Thu-Sun", "lunch": "Chicken Barbeque Pizza + Mint Mojito", "dinner": "Creamy Alfredo Penne + Garlic Toast"}
        ],
        "deliveryAvailable": True,
        "operatingHours": "11:00 AM – 10:30 PM",
        "hygieneRating": "FSSAI Grade A (4.6/5)",
        "verifiedStatus": True,
        "distanceToPatiaKiitKm": 0,
        "coordinates": {"lat": 21.515292, "lng": 86.8938062},
        "demoData": False
    },
    {
        "id": "food-bls-moms-kitchen",
        "name": "Mom's kitchen",
        "locality": "Azimabad / Remuna Bypass",
        "city": "Balasore",
        "address": "Near Azimabad Chhak, Remuna Bypass Road, Balasore, Odisha 756001",
        "phone": "+91 98532 11984",
        "gmapUrl": "https://maps.app.goo.gl/YwHMsgKwBYaPGW5E6",
        "category": "tiffin",
        "cuisine": "Homestyle Ghar Ka Khana, Daily Student Tiffin, Pure Odia Meals",
        "foodType": "veg_and_nonveg",
        "monthlyPrice": 2200,
        "singleMealPrice": 75,
        "rating": 4.5,
        "reviewCount": 410,
        "priceRange": "₹80 - ₹160 per meal (Monthly Tiffin ₹2,200/mo)",
        "isGoogleMapsVerified": True,
        "imageUrl": "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=80",
        "images": [
            "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=800&q=80",
            "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=800&q=80"
        ],
        "highlights": ["Soft Mother-Made Phulkas/Rotis", "Low-Oil Homestyle Dalma & Sabzi", "Fresh Egg & Fish Curry", "Monthly Student Tiffin Subscription"],
        "mealPlans": [
            {
                "id": "plan-moms-monthly-tiffin",
                "title": "Homestyle Monthly Tiffin (Lunch + Dinner)",
                "description": "Just like mother's cooking: 4 hot phulkas, steamed rice, dal, seasonal sabzi, and salad delivered twice daily.",
                "mealsPerDay": 2,
                "pricePerMonth": 2200,
                "includesBreakfast": False
            },
            {
                "id": "plan-moms-fullboard",
                "title": "Full Board Homestyle (Breakfast + Lunch + Dinner)",
                "description": "Wholesome home breakfast (Upma/Poha/Paratha) + hearty 2 meals daily.",
                "mealsPerDay": 3,
                "pricePerMonth": 2900,
                "includesBreakfast": True
            }
        ],
        "sampleMenu": [
            {"day": "Mon-Wed", "lunch": "Hot Phulkas + Steamed Rice + Chana Dal + Aloo Gobhi Bhaja", "dinner": "4 Soft Rotis + Homestyle Egg Curry + Cucumber Salad"},
            {"day": "Thu-Sun", "lunch": "Rice + Plain Yellow Dal + Rohu Machha Jhola + Badi Bhaja", "dinner": "Rotis + Desi Paneer Sabzi + Buta Dal"}
        ],
        "deliveryAvailable": True,
        "operatingHours": "9:00 AM – 3:30 PM, 6:30 PM – 10:00 PM",
        "hygieneRating": "FSSAI Grade A (4.9/5)",
        "verifiedStatus": True,
        "distanceToPatiaKiitKm": 0,
        "coordinates": {"lat": 21.4987852, "lng": 86.9130983},
        "demoData": False
    }
]

with open('src/data/mockData.ts', 'r') as f:
    content = f.read()

# Let's find INITIAL_MESS_SERVICES
start_idx = content.find('export const INITIAL_MESS_SERVICES: MessService[] = [')
end_bracket = content.find('];\n\nexport const INITIAL_PHARM', start_idx)

if start_idx != -1 and end_bracket != -1:
    # Format the new entries as JSON strings with indentation
    new_entries_code = ',\n' + ',\n'.join(json.dumps(r, indent=2) for r in restaurants_data) + '\n'
    new_content = content[:end_bracket] + new_entries_code + content[end_bracket:]
    with open('src/data/mockData.ts', 'w') as f:
        f.write(new_content)
    print(f"Successfully added {len(restaurants_data)} restaurants to INITIAL_MESS_SERVICES!")
else:
    print(f"Failed to find boundary: start_idx={start_idx}, end_bracket={end_bracket}")
