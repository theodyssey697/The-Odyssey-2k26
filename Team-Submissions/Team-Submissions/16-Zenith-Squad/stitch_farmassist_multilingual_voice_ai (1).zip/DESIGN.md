---
name: AgriField & Studio
colors:
  surface: '#f2fcf5'
  surface-dim: '#d3dcd6'
  surface-bright: '#f2fcf5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#ecf6f0'
  surface-container: '#e6f0ea'
  surface-container-high: '#e1eae4'
  surface-container-highest: '#dbe5df'
  on-surface: '#151d1a'
  on-surface-variant: '#414941'
  inverse-surface: '#29322e'
  inverse-on-surface: '#e9f3ed'
  outline: '#717970'
  outline-variant: '#c0c9be'
  surface-tint: '#326942'
  primary: '#003e1c'
  on-primary: '#ffffff'
  primary-container: '#1e5631'
  on-primary-container: '#8fca9b'
  inverse-primary: '#99d4a4'
  secondary: '#1b6d24'
  on-secondary: '#ffffff'
  secondary-container: '#a0f399'
  on-secondary-container: '#217128'
  tertiary: '#493000'
  on-tertiary: '#ffffff'
  tertiary-container: '#674500'
  on-tertiary-container: '#f6af28'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b5f1bf'
  primary-fixed-dim: '#99d4a4'
  on-primary-fixed: '#00210c'
  on-primary-fixed-variant: '#18512c'
  secondary-fixed: '#a3f69c'
  secondary-fixed-dim: '#88d982'
  on-secondary-fixed: '#002204'
  on-secondary-fixed-variant: '#005312'
  tertiary-fixed: '#ffddae'
  tertiary-fixed-dim: '#ffba40'
  on-tertiary-fixed: '#281800'
  on-tertiary-fixed-variant: '#604000'
  background: '#f2fcf5'
  on-background: '#151d1a'
  surface-variant: '#dbe5df'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 3rem
    fontWeight: '800'
    lineHeight: 3.5rem
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '800'
    lineHeight: 2.75rem
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.625rem
    fontWeight: '700'
    lineHeight: 2.125rem
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.375rem
    fontWeight: '600'
    lineHeight: 1.875rem
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.625rem
  body-lg:
    fontFamily: Noto Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-md:
    fontFamily: Noto Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-sm:
    fontFamily: Noto Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
  label-lg:
    fontFamily: Noto Sans
    fontSize: 1rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Noto Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Noto Sans
    fontSize: 0.75rem
    fontWeight: '700'
    lineHeight: 1rem
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system merges high-utility agrarian field tools with precise computational telemetry. It serves two distinct archetypes within one cohesive visual framework: rural agricultural operators needing direct, resilient outdoor visibility under harsh daylight, and agricultural data engineers monitoring real-time telemetry and model evaluations in studio interfaces.

The design movement combines **Tactile Utility** with **Modern Data-Dense Functionalism**. Interfaces rely on earthy, high-contrast, organic grounding rather than sterile tech tropes. Layouts prioritize tangible physical confidence—sturdy interactive modules, deliberate tactile responsiveness, clear visual affordances, and zero decorative noise. 

The emotional response must be steadfast, trustworthy, and immediate: zero cognitive friction in high-glare environments, coupled with technical precision during analytical workflows.

## Colors

The palette is derived from deep foliage, fertile loam, sun-drenched grain, and natural unbleached cotton. 

- **Primary Canvas & Surfaces**: The base canvas is warm cream (`#FFFDF6`), avoiding sterile digital white. Subordinate container tiers use pale sprouted leafy tones (`#F1F8E9`) and calming mint wash (`#E8F5E9`) to differentiate sections without heavy borders.
- **Primary & Secondary Action Greens**: Forest Green (`#1E5631`) anchors core actions, structural headers, and primary interaction elements. Emerald Green (`#2E7D32`) drives active selections, confirmations, and focus indicators.
- **Harvest Accent**: Harvest Gold (`#E6A117`) provides high-salience attention states, alerts, crop-yield milestones, and real-time processing telemetry markers.
- **Neutral Soil & Slate**: Text and baseline data metrics utilize dark warm slate (`#2C3531`) and rich loam (`#1B201E`) to ensure crisp WCAG AAA contrast against cream foundations under direct sunlight.

Color is strictly functional: greens denote healthy status and verified telemetry; harvest gold indicates warnings or pending model inference; loam slate delivers structural data.

## Typography

The typography system is built for robust multilingual rendering across English, Odia, and Hindi.

- **English Headlines**: Set in `Plus Jakarta Sans` for its open apertures, clear counters, and friendly yet grounded geometric rhythm.
- **Multilingual Body & UI**: Set in `Noto Sans` with direct fallbacks to `Kalinga` and `Nirmala UI` for Odia script, alongside `Noto Sans Devanagari` for Hindi. The baseline grid and line heights are expanded by 10–15% compared to conventional Latin stacks to accommodate vertical vowel signs (matras), conjunct clusters, and diacritics without clipping.
- **Scale and Legibility**: Micro-typography (sub-12px) is completely avoided. Touch targets and reading sizes prioritize field legibility on low-spec displays.

## Layout & Spacing

The layout model adapts across field handhelds and studio monitors:

- **Mobile Viewports (<640px)**: 4-column fluid layout with `1rem` outer margins and `1rem` gutters. Touch components run full-width or side-by-side, enforcing a strict vertical flow. Fixed bottom anchors house vital single-action tasks (e.g., Voice Query, Scan Leaf).
- **Tablet Viewports (640px–1024px)**: 8-column layout with `2rem` margins. Introduces dual-panel cards: diagnostics on the left, telemetry and soil insights on the right.
- **Desktop & Telemetry Studio (>1024px)**: 12-column layout capped at an 80rem max-container, or a fluid workbench for Judge Studio. Employs asymmetric column spans: 4 columns for pipeline navigation and parameters, 8 columns for high-density evaluation runs, logs, and comparative inference cards.
- **Vertical Spacing Cadence**: Governed strictly by the 4px/8px base rhythm (`0.25rem` through `2.5rem`), ensuring tactile grouping between visual indicators and label sets.

## Elevation & Depth

Visual hierarchy uses **Tonal Layering** paired with subtle **Loam-Tinted Ambient Shadows** to maintain outdoor legibility without harsh black cast shadows.

- **Level 0 (Flat Canvas)**: `#FFFDF6` canvas with zero elevation.
- **Level 1 (Grounded Containers)**: Surfaces use `#F1F8E9` or solid white with a 1px border of `#E8F5E9` and an ultra-soft ambient shadow: `0 2px 6px -1px rgba(27, 32, 30, 0.05)`. Used for routine cards, weather panels, and telemetry metrics.
- **Level 2 (Interactive Floating Modules)**: Modals, active diagnostic cards, and drop-downs lift using an earthy shadow: `0 8px 24px -4px rgba(27, 32, 30, 0.10), 0 2px 6px -2px rgba(27, 32, 30, 0.04)`.
- **Level 3 (Tactile Anchors & Critical Alerts)**: Bottom sheets and floating voice action triggers feature: `0 14px 32px -4px rgba(30, 86, 49, 0.16)`.
- **Telemetry Inset**: Data panels, prompt evaluation views, and log streams in Judge Studio use an inverted tonal depth: a flat `#F8FAF6` background framed by a subtle 1px border of `#E0E6DA` with no exterior shadow.

## Shapes

The design uses **Rounded** geometry (`roundedness: 2`), balancing organic agricultural warmth with structural engineering precision:

- Standard elements (interactive cards, metric containers, inputs) carry a `0.5rem` (8px) radius.
- Large contextual units and mobile bottom-sheet dialogues use `1rem` (16px) radius (`rounded-lg`).
- Status chips, interaction tags, and floating audio/scanner action pills use fully rounded circular capsules (`9999px`) to emphasize touch affordance and tactile safety.
- Data tables and telemetry raw log views maintain a tighter, disciplined `0.375rem` (6px) corner to reinforce systematic density.

## Components

### Buttons & Interactive Triggers
- **Primary Field Action**: Minimum target size of 52px height on mobile. Filled with `#1E5631`, crisp white typography (`label-lg`), and `rounded-lg` radius. Active state provides an organic press depth (inset tone `#153F24`).
- **Telemetry Secondary**: 40px height for studio viewports. Bordered with 1.5px `#2E7D32`, tinted background `#E8F5E9`, and text in `#1E5631`.
- **Voice & Capture Button**: An oversized 64px floating pill button finished in `#E6A117` with `#1B201E` icon/text to ensure visual precedence for non-literate field interaction.

### Cards & Telemetry Containers
- **Field Metric Card**: Surface tinted in unbleached cream or `#F1F8E9`, wrapped in 1px `#E0EAD9` border. Displays crop status, moisture indices, and actionable advisories with 16px internal padding.
- **Judge Studio Evaluation Card**: Monospaced data tags, model confidence bars rendered in harvest gold and emerald green, and structured parameter columns with divider lines in `#E8F5E9`.

### Chips & Status Badges
- **Capsule Structure**: Height of 28px to 32px with full pill radius.
- **Status Tiers**:
  - *Optimal/Healthy*: Background `#E8F5E9`, text `#1E5631`, 6px solid emerald dot indicator.
  - *Advisory/Pest Warning*: Background `#FEF8E7`, text `#8A5E00`, 6px harvest gold dot.
  - *Critical Action*: Background `#FCE8E6`, text `#A81B10`, 6px deep red dot.

### Inputs & Selection Controls
- **Touch-First Form Elements**: Text inputs feature a minimum height of 48px, background `#FFFFFF`, and a 1.5px border of `#D3DEC8`. On focus, transition to a 2px `#2E7D32` outline with an `#E8F5E9` ambient ring.
- **Multilingual Support**: Input placeholders and helper copy accommodate high vertical line heights for Odia and Devanagari script.
- **Checkboxes & Radios**: 24px by 24px touch targets. Check fill uses `#1E5631` with an interior white checkmark. Unselected states display a prominent 2px border in `#7C8B7E` for high outdoor visibility.

### Lists & Activity Logs
- Separated by 1px subtle divider lines (`#EDF3E7`) with 16px vertical touch cushions. Includes iconography indicating crop, weather, or automated AI model validation steps.